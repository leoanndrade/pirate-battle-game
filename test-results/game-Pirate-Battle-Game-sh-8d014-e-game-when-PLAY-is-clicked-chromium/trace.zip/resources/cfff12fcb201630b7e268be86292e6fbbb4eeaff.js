import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/MenuOverlay.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport10_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { useGameStore } from "/src/store/gameStore.ts";
import { StartMenu } from "/src/ui/components/menus/StartMenu.tsx";
import { OptionsMenu } from "/src/ui/components/menus/OptionsMenu.tsx";
import { GameOverMenu } from "/src/ui/components/menus/GameOverMenu.tsx";
import { PauseMenu } from "/src/ui/components/menus/PauseMenu.tsx";
import { CaptainsLog } from "/src/ui/components/menus/CaptainsLog.tsx";
import { HUD } from "/src/ui/components/HUD.tsx";
import { gameEvents } from "/src/utils/EventEmitter.ts";
import { gameEngine } from "/src/game/GameApplication.ts";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/MenuOverlay.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
export const MenuOverlay = () => {
	_s();
	const { gameState, setGameState, setScore, setTimeRemaining, setLastResult } = useGameStore();
	useEffect(() => {
		const onGameOver = (reason) => {
			const { matchDuration, timeRemaining } = useGameStore.getState();
			setLastResult({
				reason: reason ?? "TIME_UP",
				duration: matchDuration - timeRemaining
			});
			setGameState("GAME_OVER");
		};
		const onScoreChanged = (score) => {
			setScore(score);
		};
		const onTimeChanged = (time) => {
			setTimeRemaining(time);
		};
		gameEvents.on("GAME_OVER", onGameOver);
		gameEvents.on("SCORE_CHANGED", onScoreChanged);
		gameEvents.on("TIME_CHANGED", onTimeChanged);
		return () => {
			gameEvents.off("GAME_OVER", onGameOver);
			gameEvents.off("SCORE_CHANGED", onScoreChanged);
			gameEvents.off("TIME_CHANGED", onTimeChanged);
		};
	}, [
		setGameState,
		setScore,
		setTimeRemaining,
		setLastResult
	]);
	useEffect(() => {
		const handleKeyDown = (e) => {
			if (e.key === "Escape" && gameState === "PLAYING") {
				gameEngine.pauseGame();
				setGameState("PAUSED");
			} else if (e.key === "Escape" && gameState === "PAUSED") {
				gameEngine.resumeGame();
				setGameState("PLAYING");
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [gameState, setGameState]);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		gameState === "PLAYING" && /* @__PURE__ */ _jsxDEV(HUD, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 35
		}, this),
		gameState === "START_MENU" && /* @__PURE__ */ _jsxDEV(StartMenu, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 38
		}, this),
		gameState === "OPTIONS_MENU" && /* @__PURE__ */ _jsxDEV(OptionsMenu, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 40
		}, this),
		gameState === "LOG_MENU" && /* @__PURE__ */ _jsxDEV(CaptainsLog, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 36
		}, this),
		gameState === "PAUSED" && /* @__PURE__ */ _jsxDEV(PauseMenu, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 34
		}, this),
		gameState === "GAME_OVER" && /* @__PURE__ */ _jsxDEV(GameOverMenu, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 37
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
};
_s(MenuOverlay, "a7tlISC4OP92nl6mqWxEkV4c7Cg=", false, function() {
	return [useGameStore];
});
_c = MenuOverlay;
var _c;
$RefreshReg$(_c, "MenuOverlay");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/MenuOverlay.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/MenuOverlay.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/MenuOverlay.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/MenuOverlay.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGlCQUFpQjtBQUNqQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLFdBQVc7QUFDcEIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7Ozs7QUFFM0IsT0FBTyxNQUFNLG9CQUE4Qjs7Q0FDekMsTUFBTSxFQUFFLFdBQVcsY0FBYyxVQUFVLGtCQUFrQixrQkFBa0IsYUFBYTtDQUU1RixnQkFBZ0I7RUFDZCxNQUFNLGNBQWMsV0FBdUM7R0FDekQsTUFBTSxFQUFFLGVBQWUsa0JBQWtCLGFBQWEsU0FBUztHQUMvRCxjQUFjO0lBQUUsUUFBUSxVQUFVO0lBQVcsVUFBVSxnQkFBZ0I7R0FBYyxDQUFDO0dBQ3RGLGFBQWEsV0FBVztFQUMxQjtFQUNBLE1BQU0sa0JBQWtCLFVBQWtCO0dBQ3hDLFNBQVMsS0FBSztFQUNoQjtFQUNBLE1BQU0saUJBQWlCLFNBQWlCO0dBQ3RDLGlCQUFpQixJQUFJO0VBQ3ZCO0VBRUEsV0FBVyxHQUFHLGFBQWEsVUFBVTtFQUNyQyxXQUFXLEdBQUcsaUJBQWlCLGNBQWM7RUFDN0MsV0FBVyxHQUFHLGdCQUFnQixhQUFhO0VBRTNDLGFBQWE7R0FDWCxXQUFXLElBQUksYUFBYSxVQUFVO0dBQ3RDLFdBQVcsSUFBSSxpQkFBaUIsY0FBYztHQUM5QyxXQUFXLElBQUksZ0JBQWdCLGFBQWE7RUFDOUM7Q0FDRixHQUFHO0VBQUM7RUFBYztFQUFVO0VBQWtCO0NBQWEsQ0FBQztDQUU1RCxnQkFBZ0I7RUFDZCxNQUFNLGlCQUFpQixNQUFxQjtHQUMxQyxJQUFJLEVBQUUsUUFBUSxZQUFZLGNBQWMsV0FBVztJQUNqRCxXQUFXLFVBQVU7SUFDckIsYUFBYSxRQUFRO0dBQ3ZCLE9BQU8sSUFBSSxFQUFFLFFBQVEsWUFBWSxjQUFjLFVBQVU7SUFDdkQsV0FBVyxXQUFXO0lBQ3RCLGFBQWEsU0FBUztHQUN4QjtFQUNGO0VBQ0EsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBQ2hELGFBQWEsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0NBQ2xFLEdBQUcsQ0FBQyxXQUFXLFlBQVksQ0FBQztDQUU1QixPQUNFO0VBQ0csY0FBYyxhQUFhLHdCQUFDLEtBQUQsQ0FBTTs7Ozs7RUFDakMsY0FBYyxnQkFBZ0Isd0JBQUMsV0FBRCxDQUFZOzs7OztFQUMxQyxjQUFjLGtCQUFrQix3QkFBQyxhQUFELENBQWM7Ozs7O0VBQzlDLGNBQWMsY0FBYyx3QkFBQyxhQUFELENBQWM7Ozs7O0VBQzFDLGNBQWMsWUFBWSx3QkFBQyxXQUFELENBQVk7Ozs7O0VBQ3RDLGNBQWMsZUFBZSx3QkFBQyxjQUFELENBQWU7Ozs7O0NBQzdDOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1lbnVPdmVybGF5LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlR2FtZVN0b3JlIH0gZnJvbSAnLi4vLi4vc3RvcmUvZ2FtZVN0b3JlJztcbmltcG9ydCB7IFN0YXJ0TWVudSB9IGZyb20gJy4vbWVudXMvU3RhcnRNZW51JztcbmltcG9ydCB7IE9wdGlvbnNNZW51IH0gZnJvbSAnLi9tZW51cy9PcHRpb25zTWVudSc7XG5pbXBvcnQgeyBHYW1lT3Zlck1lbnUgfSBmcm9tICcuL21lbnVzL0dhbWVPdmVyTWVudSc7XG5pbXBvcnQgeyBQYXVzZU1lbnUgfSBmcm9tICcuL21lbnVzL1BhdXNlTWVudSc7XHJcbmltcG9ydCB7IENhcHRhaW5zTG9nIH0gZnJvbSAnLi9tZW51cy9DYXB0YWluc0xvZyc7XG5pbXBvcnQgeyBIVUQgfSBmcm9tICcuL0hVRCc7XG5pbXBvcnQgeyBnYW1lRXZlbnRzIH0gZnJvbSAnLi4vLi4vdXRpbHMvRXZlbnRFbWl0dGVyJztcbmltcG9ydCB7IGdhbWVFbmdpbmUgfSBmcm9tICcuLi8uLi9nYW1lL0dhbWVBcHBsaWNhdGlvbic7XG5cbmV4cG9ydCBjb25zdCBNZW51T3ZlcmxheTogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgZ2FtZVN0YXRlLCBzZXRHYW1lU3RhdGUsIHNldFNjb3JlLCBzZXRUaW1lUmVtYWluaW5nLCBzZXRMYXN0UmVzdWx0IH0gPSB1c2VHYW1lU3RvcmUoKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IG9uR2FtZU92ZXIgPSAocmVhc29uPzogJ1RJTUVfVVAnIHwgJ1BMQVlFUl9ESUVEJykgPT4ge1xuICAgICAgY29uc3QgeyBtYXRjaER1cmF0aW9uLCB0aW1lUmVtYWluaW5nIH0gPSB1c2VHYW1lU3RvcmUuZ2V0U3RhdGUoKTtcbiAgICAgIHNldExhc3RSZXN1bHQoeyByZWFzb246IHJlYXNvbiA/PyAnVElNRV9VUCcsIGR1cmF0aW9uOiBtYXRjaER1cmF0aW9uIC0gdGltZVJlbWFpbmluZyB9KTtcbiAgICAgIHNldEdhbWVTdGF0ZSgnR0FNRV9PVkVSJyk7XG4gICAgfTtcbiAgICBjb25zdCBvblNjb3JlQ2hhbmdlZCA9IChzY29yZTogbnVtYmVyKSA9PiB7XG4gICAgICBzZXRTY29yZShzY29yZSk7XG4gICAgfTtcbiAgICBjb25zdCBvblRpbWVDaGFuZ2VkID0gKHRpbWU6IG51bWJlcikgPT4ge1xuICAgICAgc2V0VGltZVJlbWFpbmluZyh0aW1lKTtcbiAgICB9O1xuXG4gICAgZ2FtZUV2ZW50cy5vbignR0FNRV9PVkVSJywgb25HYW1lT3Zlcik7XG4gICAgZ2FtZUV2ZW50cy5vbignU0NPUkVfQ0hBTkdFRCcsIG9uU2NvcmVDaGFuZ2VkKTtcbiAgICBnYW1lRXZlbnRzLm9uKCdUSU1FX0NIQU5HRUQnLCBvblRpbWVDaGFuZ2VkKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBnYW1lRXZlbnRzLm9mZignR0FNRV9PVkVSJywgb25HYW1lT3Zlcik7XG4gICAgICBnYW1lRXZlbnRzLm9mZignU0NPUkVfQ0hBTkdFRCcsIG9uU2NvcmVDaGFuZ2VkKTtcbiAgICAgIGdhbWVFdmVudHMub2ZmKCdUSU1FX0NIQU5HRUQnLCBvblRpbWVDaGFuZ2VkKTtcbiAgICB9O1xuICB9LCBbc2V0R2FtZVN0YXRlLCBzZXRTY29yZSwgc2V0VGltZVJlbWFpbmluZywgc2V0TGFzdFJlc3VsdF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnICYmIGdhbWVTdGF0ZSA9PT0gJ1BMQVlJTkcnKSB7XG4gICAgICAgIGdhbWVFbmdpbmUucGF1c2VHYW1lKCk7XG4gICAgICAgIHNldEdhbWVTdGF0ZSgnUEFVU0VEJyk7XG4gICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSAnRXNjYXBlJyAmJiBnYW1lU3RhdGUgPT09ICdQQVVTRUQnKSB7XG4gICAgICAgIGdhbWVFbmdpbmUucmVzdW1lR2FtZSgpO1xuICAgICAgICBzZXRHYW1lU3RhdGUoJ1BMQVlJTkcnKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gIH0sIFtnYW1lU3RhdGUsIHNldEdhbWVTdGF0ZV0pO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIHtnYW1lU3RhdGUgPT09ICdQTEFZSU5HJyAmJiA8SFVEIC8+fVxuICAgICAge2dhbWVTdGF0ZSA9PT0gJ1NUQVJUX01FTlUnICYmIDxTdGFydE1lbnUgLz59XG4gICAgICB7Z2FtZVN0YXRlID09PSAnT1BUSU9OU19NRU5VJyAmJiA8T3B0aW9uc01lbnUgLz59XHJcbiAgICAgIHtnYW1lU3RhdGUgPT09ICdMT0dfTUVOVScgJiYgPENhcHRhaW5zTG9nIC8+fVxuICAgICAge2dhbWVTdGF0ZSA9PT0gJ1BBVVNFRCcgJiYgPFBhdXNlTWVudSAvPn1cbiAgICAgIHtnYW1lU3RhdGUgPT09ICdHQU1FX09WRVInICYmIDxHYW1lT3Zlck1lbnUgLz59XG4gICAgPC8+XG4gICk7XG59O1xuIl19