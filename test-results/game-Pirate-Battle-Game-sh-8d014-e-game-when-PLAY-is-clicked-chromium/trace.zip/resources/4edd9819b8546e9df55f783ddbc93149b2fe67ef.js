import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/menus/StartMenu.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { useGameStore } from "/src/store/gameStore.ts";
import { SpriteIcon } from "/src/ui/components/SpriteIcon.tsx";
import { SpriteButton } from "/src/ui/components/SpriteButton.tsx";
import { gameEngine } from "/src/game/GameApplication.ts";
import { soundManager } from "/src/game/SoundManager.ts";
import { MenuScreen, Panel, theme } from "/src/ui/components/menus/MenuKit.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/StartMenu.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
export const StartMenu = () => {
	_s();
	const { setGameState, matchDuration, spawnRate, openOptions, openLog } = useGameStore();
	const handlePlay = () => {
		soundManager.play("ui_click");
		setGameState("PLAYING");
		gameEngine.startGame(matchDuration, spawnRate);
	};
	return /* @__PURE__ */ _jsxDEV(MenuScreen, { children: /* @__PURE__ */ _jsxDEV(Panel, {
		width: 780,
		style: { padding: "10px 20px 0" },
		children: [
			/* @__PURE__ */ _jsxDEV(SpriteIcon, {
				name: "title_pirate_battle",
				scale: 1
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				style: {
					margin: "18px 0 10px",
					fontSize: "0.85rem",
					letterSpacing: 4,
					fontWeight: 700,
					color: theme.cream
				},
				children: "SET SAIL. TAKE COMMAND."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(SpriteButton, {
				baseName: "button_primary",
				scale: 1.25,
				text: "PLAY",
				textStyle: { fontSize: "1.6rem" },
				onClick: handlePlay,
				style: { margin: "6px" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(SpriteButton, {
				baseName: "button_primary",
				scale: 1.25,
				text: "OPTIONS",
				textStyle: { fontSize: "1.6rem" },
				onClick: () => {
					soundManager.play("ui_click");
					openOptions("START_MENU");
				},
				style: { margin: "6px" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("img", {
				src: "/assets/png/default/ships/ship_1.png",
				alt: "",
				style: {
					height: 80,
					margin: "18px 0 14px",
					imageRendering: "auto"
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				style: {
					margin: "0 0 14px",
					fontSize: "0.95rem",
					fontWeight: 600,
					color: theme.cream
				},
				children: "Navigate the islands. Survive the battle."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				style: {
					display: "flex",
					gap: 20
				},
				children: [/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_secondary",
					scale: .85,
					text: "RANKING",
					textStyle: { fontSize: "1rem" },
					onClick: () => {
						soundManager.play("ui_click");
						openLog("RANKING");
					},
					style: { margin: 0 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_secondary",
					scale: .85,
					text: "MATCH HISTORY",
					textStyle: { fontSize: "1rem" },
					onClick: () => {
						soundManager.play("ui_click");
						openLog("HISTORY");
					},
					style: { margin: 0 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
};
_s(StartMenu, "1s7cLxkxGfvfBvi16BujCJMr2qE=", false, function() {
	return [useGameStore];
});
_c = StartMenu;
var _c;
$RefreshReg$(_c, "StartMenu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/menus/StartMenu.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/StartMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/StartMenu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/StartMenu.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsWUFBWSxPQUFPLGFBQWE7Ozs7QUFFekMsT0FBTyxNQUFNLGtCQUE0Qjs7Q0FDdkMsTUFBTSxFQUFFLGNBQWMsZUFBZSxXQUFXLGFBQWEsWUFBWSxhQUFhO0NBRXRGLE1BQU0sbUJBQW1CO0VBQ3ZCLGFBQWEsS0FBSyxVQUFVO0VBQzVCLGFBQWEsU0FBUztFQUN0QixXQUFXLFVBQVUsZUFBZSxTQUFTO0NBQy9DO0NBRUEsT0FDRSx3QkFBQyxZQUFELFlBQ0Usd0JBQUMsT0FBRDtFQUFPLE9BQU87RUFBSyxPQUFPLEVBQUUsU0FBUyxjQUFjO1lBQW5EO0dBQ0Usd0JBQUMsWUFBRDtJQUFZLE1BQUs7SUFBc0IsT0FBTztHQUFJOzs7OztHQUVsRCx3QkFBQyxLQUFEO0lBQUcsT0FBTztLQUFFLFFBQVE7S0FBZSxVQUFVO0tBQVcsZUFBZTtLQUFHLFlBQVk7S0FBSyxPQUFPLE1BQU07SUFBTTtjQUFHO0dBRTlHOzs7OztHQUVILHdCQUFDLGNBQUQ7SUFBYyxVQUFTO0lBQWlCLE9BQU87SUFBTSxNQUFLO0lBQU8sV0FBVyxFQUFFLFVBQVUsU0FBUztJQUFHLFNBQVM7SUFBWSxPQUFPLEVBQUUsUUFBUSxNQUFNO0dBQUk7Ozs7O0dBQ3BKLHdCQUFDLGNBQUQ7SUFDRSxVQUFTO0lBQWlCLE9BQU87SUFBTSxNQUFLO0lBQVUsV0FBVyxFQUFFLFVBQVUsU0FBUztJQUN0RixlQUFlO0tBQUUsYUFBYSxLQUFLLFVBQVU7S0FBRyxZQUFZLFlBQVk7SUFBRztJQUMzRSxPQUFPLEVBQUUsUUFBUSxNQUFNO0dBQ3hCOzs7OztHQUVELHdCQUFDLE9BQUQ7SUFBSyxLQUFJO0lBQXVDLEtBQUk7SUFBRyxPQUFPO0tBQUUsUUFBUTtLQUFJLFFBQVE7S0FBZSxnQkFBZ0I7SUFBTztHQUFJOzs7OztHQUU5SCx3QkFBQyxLQUFEO0lBQUcsT0FBTztLQUFFLFFBQVE7S0FBWSxVQUFVO0tBQVcsWUFBWTtLQUFLLE9BQU8sTUFBTTtJQUFNO2NBQUc7R0FFekY7Ozs7O0dBRUgsd0JBQUMsT0FBRDtJQUFLLE9BQU87S0FBRSxTQUFTO0tBQVEsS0FBSztJQUFHO2NBQXZDLENBQ0Usd0JBQUMsY0FBRDtLQUNFLFVBQVM7S0FBbUIsT0FBTztLQUFNLE1BQUs7S0FBVSxXQUFXLEVBQUUsVUFBVSxPQUFPO0tBQ3RGLGVBQWU7TUFBRSxhQUFhLEtBQUssVUFBVTtNQUFHLFFBQVEsU0FBUztLQUFHO0tBQUcsT0FBTyxFQUFFLFFBQVEsRUFBRTtJQUMzRjs7OztjQUNELHdCQUFDLGNBQUQ7S0FDRSxVQUFTO0tBQW1CLE9BQU87S0FBTSxNQUFLO0tBQWdCLFdBQVcsRUFBRSxVQUFVLE9BQU87S0FDNUYsZUFBZTtNQUFFLGFBQWEsS0FBSyxVQUFVO01BQUcsUUFBUSxTQUFTO0tBQUc7S0FBRyxPQUFPLEVBQUUsUUFBUSxFQUFFO0lBQzNGOzs7O1lBQ0U7Ozs7OztFQUNBOzs7OztVQUNHOzs7OztBQUVoQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTdGFydE1lbnUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VHYW1lU3RvcmUgfSBmcm9tICcuLi8uLi8uLi9zdG9yZS9nYW1lU3RvcmUnO1xuaW1wb3J0IHsgU3ByaXRlSWNvbiB9IGZyb20gJy4uL1Nwcml0ZUljb24nO1xuaW1wb3J0IHsgU3ByaXRlQnV0dG9uIH0gZnJvbSAnLi4vU3ByaXRlQnV0dG9uJztcbmltcG9ydCB7IGdhbWVFbmdpbmUgfSBmcm9tICcuLi8uLi8uLi9nYW1lL0dhbWVBcHBsaWNhdGlvbic7XG5pbXBvcnQgeyBzb3VuZE1hbmFnZXIgfSBmcm9tICcuLi8uLi8uLi9nYW1lL1NvdW5kTWFuYWdlcic7XG5pbXBvcnQgeyBNZW51U2NyZWVuLCBQYW5lbCwgdGhlbWUgfSBmcm9tICcuL01lbnVLaXQnO1xuXG5leHBvcnQgY29uc3QgU3RhcnRNZW51OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBzZXRHYW1lU3RhdGUsIG1hdGNoRHVyYXRpb24sIHNwYXduUmF0ZSwgb3Blbk9wdGlvbnMsIG9wZW5Mb2cgfSA9IHVzZUdhbWVTdG9yZSgpO1xuXG4gIGNvbnN0IGhhbmRsZVBsYXkgPSAoKSA9PiB7XG4gICAgc291bmRNYW5hZ2VyLnBsYXkoJ3VpX2NsaWNrJyk7XG4gICAgc2V0R2FtZVN0YXRlKCdQTEFZSU5HJyk7XG4gICAgZ2FtZUVuZ2luZS5zdGFydEdhbWUobWF0Y2hEdXJhdGlvbiwgc3Bhd25SYXRlKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxNZW51U2NyZWVuPlxuICAgICAgPFBhbmVsIHdpZHRoPXs3ODB9IHN0eWxlPXt7IHBhZGRpbmc6ICcxMHB4IDIwcHggMCcgfX0+XG4gICAgICAgIDxTcHJpdGVJY29uIG5hbWU9XCJ0aXRsZV9waXJhdGVfYmF0dGxlXCIgc2NhbGU9ezF9IC8+XG5cbiAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAnMThweCAwIDEwcHgnLCBmb250U2l6ZTogJzAuODVyZW0nLCBsZXR0ZXJTcGFjaW5nOiA0LCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiB0aGVtZS5jcmVhbSB9fT5cbiAgICAgICAgICBTRVQgU0FJTC4gVEFLRSBDT01NQU5ELlxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPFNwcml0ZUJ1dHRvbiBiYXNlTmFtZT1cImJ1dHRvbl9wcmltYXJ5XCIgc2NhbGU9ezEuMjV9IHRleHQ9XCJQTEFZXCIgdGV4dFN0eWxlPXt7IGZvbnRTaXplOiAnMS42cmVtJyB9fSBvbkNsaWNrPXtoYW5kbGVQbGF5fSBzdHlsZT17eyBtYXJnaW46ICc2cHgnIH19IC8+XG4gICAgICAgIDxTcHJpdGVCdXR0b25cbiAgICAgICAgICBiYXNlTmFtZT1cImJ1dHRvbl9wcmltYXJ5XCIgc2NhbGU9ezEuMjV9IHRleHQ9XCJPUFRJT05TXCIgdGV4dFN0eWxlPXt7IGZvbnRTaXplOiAnMS42cmVtJyB9fVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc291bmRNYW5hZ2VyLnBsYXkoJ3VpX2NsaWNrJyk7IG9wZW5PcHRpb25zKCdTVEFSVF9NRU5VJyk7IH19XG4gICAgICAgICAgc3R5bGU9e3sgbWFyZ2luOiAnNnB4JyB9fVxuICAgICAgICAvPlxuXG4gICAgICAgIDxpbWcgc3JjPVwiL2Fzc2V0cy9wbmcvZGVmYXVsdC9zaGlwcy9zaGlwXzEucG5nXCIgYWx0PVwiXCIgc3R5bGU9e3sgaGVpZ2h0OiA4MCwgbWFyZ2luOiAnMThweCAwIDE0cHgnLCBpbWFnZVJlbmRlcmluZzogJ2F1dG8nIH19IC8+XG5cbiAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAnMCAwIDE0cHgnLCBmb250U2l6ZTogJzAuOTVyZW0nLCBmb250V2VpZ2h0OiA2MDAsIGNvbG9yOiB0aGVtZS5jcmVhbSB9fT5cbiAgICAgICAgICBOYXZpZ2F0ZSB0aGUgaXNsYW5kcy4gU3Vydml2ZSB0aGUgYmF0dGxlLlxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogMjAgfX0+XG4gICAgICAgICAgPFNwcml0ZUJ1dHRvblxuICAgICAgICAgICAgYmFzZU5hbWU9XCJidXR0b25fc2Vjb25kYXJ5XCIgc2NhbGU9ezAuODV9IHRleHQ9XCJSQU5LSU5HXCIgdGV4dFN0eWxlPXt7IGZvbnRTaXplOiAnMXJlbScgfX1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc291bmRNYW5hZ2VyLnBsYXkoJ3VpX2NsaWNrJyk7IG9wZW5Mb2coJ1JBTktJTkcnKTsgfX0gc3R5bGU9e3sgbWFyZ2luOiAwIH19XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8U3ByaXRlQnV0dG9uXG4gICAgICAgICAgICBiYXNlTmFtZT1cImJ1dHRvbl9zZWNvbmRhcnlcIiBzY2FsZT17MC44NX0gdGV4dD1cIk1BVENIIEhJU1RPUllcIiB0ZXh0U3R5bGU9e3sgZm9udFNpemU6ICcxcmVtJyB9fVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzb3VuZE1hbmFnZXIucGxheSgndWlfY2xpY2snKTsgb3BlbkxvZygnSElTVE9SWScpOyB9fSBzdHlsZT17eyBtYXJnaW46IDAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvUGFuZWw+XG4gICAgPC9NZW51U2NyZWVuPlxuICApO1xufTtcbiJdfQ==