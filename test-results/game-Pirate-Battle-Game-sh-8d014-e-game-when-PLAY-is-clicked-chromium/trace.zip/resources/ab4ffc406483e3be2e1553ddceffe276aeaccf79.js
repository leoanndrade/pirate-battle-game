import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/GameCanvas.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { gameEngine } from "/src/game/GameApplication.ts";
import { MenuOverlay } from "/src/ui/components/MenuOverlay.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/GameCanvas.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
export const GameCanvas = () => {
	_s();
	const canvasRef = useRef(null);
	const containerRef = useRef(null);
	useEffect(() => {
		let isMounted = true;
		const initGame = async () => {
			if (canvasRef.current && containerRef.current && isMounted) {
				await gameEngine.init(canvasRef.current, containerRef.current);
			}
		};
		initGame();
		return () => {
			isMounted = false;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		ref: containerRef,
		style: {
			width: "100%",
			height: "100%",
			overflow: "hidden",
			position: "relative"
		},
		children: [/* @__PURE__ */ _jsxDEV("canvas", {
			ref: canvasRef,
			style: {
				display: "block",
				width: "100%",
				height: "100%",
				touchAction: "none"
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(MenuOverlay, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
};
_s(GameCanvas, "YBHFfwgnIhRWo1QyQuk5wi9Dwwo=");
_c = GameCanvas;
var _c;
$RefreshReg$(_c, "GameCanvas");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/GameCanvas.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/GameCanvas.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/GameCanvas.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/GameCanvas.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsY0FBYztBQUN6QyxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjs7OztBQUU1QixPQUFPLE1BQU0sbUJBQTZCOztDQUN4QyxNQUFNLFlBQVksT0FBMEIsSUFBSTtDQUNoRCxNQUFNLGVBQWUsT0FBdUIsSUFBSTtDQUVoRCxnQkFBZ0I7RUFDZCxJQUFJLFlBQVk7RUFFaEIsTUFBTSxXQUFXLFlBQVk7R0FDM0IsSUFBSSxVQUFVLFdBQVcsYUFBYSxXQUFXLFdBQVc7SUFDMUQsTUFBTSxXQUFXLEtBQUssVUFBVSxTQUFTLGFBQWEsT0FBTztHQUMvRDtFQUNGO0VBRUEsU0FBUztFQUVULGFBQWE7R0FDWCxZQUFZO0VBQ2Q7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLEtBQUs7RUFDTCxPQUFPO0dBQ0wsT0FBTztHQUNQLFFBQVE7R0FDUixVQUFVO0dBQ1YsVUFBVTtFQUNaO1lBUEYsQ0FTRSx3QkFBQyxVQUFEO0dBQ0UsS0FBSztHQUNMLE9BQU87SUFDTCxTQUFTO0lBQ1QsT0FBTztJQUNQLFFBQVE7SUFDUixhQUFhO0dBQ2Y7RUFDRDs7OztZQUVELHdCQUFDLGFBQUQsQ0FBYzs7OztVQUNYOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJHYW1lQ2FudmFzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnYW1lRW5naW5lIH0gZnJvbSAnLi4vLi4vZ2FtZS9HYW1lQXBwbGljYXRpb24nO1xuaW1wb3J0IHsgTWVudU92ZXJsYXkgfSBmcm9tICcuL01lbnVPdmVybGF5JztcblxuZXhwb3J0IGNvbnN0IEdhbWVDYW52YXM6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCBjYW52YXNSZWYgPSB1c2VSZWY8SFRNTENhbnZhc0VsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBjb250YWluZXJSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IGlzTW91bnRlZCA9IHRydWU7XG5cbiAgICBjb25zdCBpbml0R2FtZSA9IGFzeW5jICgpID0+IHtcbiAgICAgIGlmIChjYW52YXNSZWYuY3VycmVudCAmJiBjb250YWluZXJSZWYuY3VycmVudCAmJiBpc01vdW50ZWQpIHtcbiAgICAgICAgYXdhaXQgZ2FtZUVuZ2luZS5pbml0KGNhbnZhc1JlZi5jdXJyZW50LCBjb250YWluZXJSZWYuY3VycmVudCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGluaXRHYW1lKCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNNb3VudGVkID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgcmVmPXtjb250YWluZXJSZWZ9XG4gICAgICBzdHlsZT17e1xuICAgICAgICB3aWR0aDogJzEwMCUnLFxuICAgICAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGNhbnZhc1xuICAgICAgICByZWY9e2NhbnZhc1JlZn1cbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgIHdpZHRoOiAnMTAwJScsXG4gICAgICAgICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgICAgICAgdG91Y2hBY3Rpb246ICdub25lJyxcbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICBcbiAgICAgIDxNZW51T3ZlcmxheSAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==