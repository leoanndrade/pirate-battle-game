import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const React = __vite__cjsImport0_react;const ReactDOM = __vite__cjsImport1_reactDom_client;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=eccdfead";
import App from "/src/App.tsx";
import "/src/index.css";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=eccdfead";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/main.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
const queryClient = new QueryClient();
async function enableMocking() {
	if (import.meta.env.DEV) {
		const { worker } = await import("/src/mocks/browser.ts");
		return worker.start();
	}
}
enableMocking().then(() => {
	ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(React.StrictMode, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this));
});

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUNyQixPQUFPLFNBQVM7QUFDaEIsT0FBTztBQUNQLFNBQVMsYUFBYSwyQkFBMkI7OztBQUVqRCxNQUFNLGNBQWMsSUFBSSxZQUFZO0FBRXBDLGVBQWUsZ0JBQWdCO0NBQzdCLElBQUksWUFBWSxJQUFJLEtBQUs7RUFDdkIsTUFBTSxFQUFFLFdBQVcsTUFBTSxPQUFPO0VBQ2hDLE9BQU8sT0FBTyxNQUFNO0NBQ3RCO0FBQ0Y7QUFFQSxjQUFjLENBQUMsQ0FBQyxXQUFXO0NBQ3pCLFNBQVMsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFnQixDQUFDLENBQUMsT0FDbEUsd0JBQUMsTUFBTSxZQUFQLFlBQ0Usd0JBQUMscUJBQUQ7RUFBcUIsUUFBUTtZQUMzQix3QkFBQyxLQUFELENBQU07Ozs7O0NBQ2E7Ozs7VUFDTDs7OztTQUNwQjtBQUNGLENBQUMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50JztcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAudHN4JztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknO1xuXG5jb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpO1xuXG5hc3luYyBmdW5jdGlvbiBlbmFibGVNb2NraW5nKCkge1xuICBpZiAoaW1wb3J0Lm1ldGEuZW52LkRFVikge1xuICAgIGNvbnN0IHsgd29ya2VyIH0gPSBhd2FpdCBpbXBvcnQoJy4vbW9ja3MvYnJvd3NlcicpO1xuICAgIHJldHVybiB3b3JrZXIuc3RhcnQoKTtcbiAgfVxufVxuXG5lbmFibGVNb2NraW5nKCkudGhlbigoKSA9PiB7XG4gIFJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSBhcyBIVE1MRWxlbWVudCkucmVuZGVyKFxuICAgIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XG4gICAgICAgIDxBcHAgLz5cbiAgICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cbiAgICA8L1JlYWN0LlN0cmljdE1vZGU+LFxuICApO1xufSk7XG4iXX0=