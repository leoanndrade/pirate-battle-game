import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/menus/OptionsMenu.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { useGameStore } from "/src/store/gameStore.ts";
import { SpriteButton } from "/src/ui/components/SpriteButton.tsx";
import { soundManager } from "/src/game/SoundManager.ts";
import { MenuScreen, Panel, MenuTitle, theme } from "/src/ui/components/menus/MenuKit.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/OptionsMenu.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
const Stepper = ({ label, value, min, max, step, format, onChange }) => {
	const change = (dir) => {
		const next = Math.round((value + dir * step) * 100) / 100;
		if (next < min || next > max) return;
		soundManager.play("ui_click");
		onChange(next);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		style: {
			display: "flex",
			flexDirection: "column",
			alignItems: "center",
			marginBottom: 14
		},
		children: [/* @__PURE__ */ _jsxDEV("span", {
			style: {
				fontSize: "1rem",
				fontWeight: 700,
				color: theme.cream,
				marginBottom: 6
			},
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			style: {
				display: "flex",
				alignItems: "center"
			},
			children: [
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					"data-testid": `${label}-minus`,
					baseName: "button_round",
					scale: .75,
					icon: "icon_minus",
					iconScale: .55,
					disabled: value <= min,
					onClick: () => change(-1),
					style: { margin: 0 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					style: {
						width: 190,
						textAlign: "center",
						fontSize: "1.5rem",
						fontWeight: 900,
						color: theme.cream
					},
					children: format(value)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					"data-testid": `${label}-plus`,
					baseName: "button_round",
					scale: .75,
					icon: "icon_plus",
					iconScale: .55,
					disabled: value >= max,
					onClick: () => change(1),
					style: { margin: 0 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
};
_c = Stepper;
export const OptionsMenu = () => {
	_s();
	const { setGameState, matchDuration, setMatchDuration, spawnRate, setSpawnRate, optionsReturnTo } = useGameStore();
	const fromPause = optionsReturnTo === "PAUSED";
	const handleBack = () => {
		soundManager.play("ui_click");
		setGameState(optionsReturnTo);
	};
	return /* @__PURE__ */ _jsxDEV(MenuScreen, {
		dim: fromPause,
		children: /* @__PURE__ */ _jsxDEV(Panel, {
			width: 780,
			minHeight: 660,
			style: { justifyContent: "center" },
			children: [
				/* @__PURE__ */ _jsxDEV(MenuTitle, {
					style: { marginBottom: 24 },
					children: "OPTIONS"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Stepper, {
					label: "Game session time",
					value: matchDuration,
					min: 30,
					max: 300,
					step: 10,
					format: (v) => `${v} s`,
					onChange: setMatchDuration
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Stepper, {
					label: "Enemy spawn time",
					value: spawnRate,
					min: .5,
					max: 10,
					step: .5,
					format: (v) => `${v} s`,
					onChange: setSpawnRate
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				fromPause && /* @__PURE__ */ _jsxDEV("p", {
					style: {
						margin: "0 0 6px",
						fontSize: "0.8rem",
						color: theme.muted
					},
					children: "Changes apply to the next battle."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_primary",
					scale: 1.25,
					text: fromPause ? "BACK" : "MAIN MENU",
					textStyle: { fontSize: "1.6rem" },
					onClick: handleBack
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 47,
		columnNumber: 5
	}, this);
};
_s(OptionsMenu, "g1w9Hnj3I+14pe+fyvdQtxu5P4w=", false, function() {
	return [useGameStore];
});
_c2 = OptionsMenu;
var _c, _c2;
$RefreshReg$(_c, "Stepper");
$RefreshReg$(_c2, "OptionsMenu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/menus/OptionsMenu.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/OptionsMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/OptionsMenu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/OptionsMenu.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsWUFBWSxPQUFPLFdBQVcsYUFBYTs7OztBQVlwRCxNQUFNLFdBQW1DLEVBQUUsT0FBTyxPQUFPLEtBQUssS0FBSyxNQUFNLFFBQVEsZUFBZTtDQUM5RixNQUFNLFVBQVUsUUFBZ0I7RUFDOUIsTUFBTSxPQUFPLEtBQUssT0FBTyxRQUFRLE1BQU0sUUFBUSxHQUFHLElBQUk7RUFDdEQsSUFBSSxPQUFPLE9BQU8sT0FBTyxLQUFLO0VBQzlCLGFBQWEsS0FBSyxVQUFVO0VBQzVCLFNBQVMsSUFBSTtDQUNmO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssT0FBTztHQUFFLFNBQVM7R0FBUSxlQUFlO0dBQVUsWUFBWTtHQUFVLGNBQWM7RUFBRztZQUEvRixDQUNFLHdCQUFDLFFBQUQ7R0FBTSxPQUFPO0lBQUUsVUFBVTtJQUFRLFlBQVk7SUFBSyxPQUFPLE1BQU07SUFBTyxjQUFjO0dBQUU7YUFBSTtFQUFZOzs7O1lBQ3RHLHdCQUFDLE9BQUQ7R0FBSyxPQUFPO0lBQUUsU0FBUztJQUFRLFlBQVk7R0FBUzthQUFwRDtJQUNFLHdCQUFDLGNBQUQ7S0FBYyxlQUFhLEdBQUcsTUFBTTtLQUFTLFVBQVM7S0FBZSxPQUFPO0tBQU0sTUFBSztLQUFhLFdBQVc7S0FBTSxVQUFVLFNBQVM7S0FBSyxlQUFlLE9BQU8sQ0FBQyxDQUFDO0tBQUcsT0FBTyxFQUFFLFFBQVEsRUFBRTtJQUFJOzs7OztJQUMvTCx3QkFBQyxRQUFEO0tBQU0sT0FBTztNQUFFLE9BQU87TUFBSyxXQUFXO01BQVUsVUFBVTtNQUFVLFlBQVk7TUFBSyxPQUFPLE1BQU07S0FBTTtlQUFJLE9BQU8sS0FBSztJQUFROzs7OztJQUNoSSx3QkFBQyxjQUFEO0tBQWMsZUFBYSxHQUFHLE1BQU07S0FBUSxVQUFTO0tBQWUsT0FBTztLQUFNLE1BQUs7S0FBWSxXQUFXO0tBQU0sVUFBVSxTQUFTO0tBQUssZUFBZSxPQUFPLENBQUM7S0FBRyxPQUFPLEVBQUUsUUFBUSxFQUFFO0lBQUk7Ozs7O0dBQ3pMOzs7OztVQUNGOzs7Ozs7QUFFVDs7QUFFQSxPQUFPLE1BQU0sb0JBQThCOztDQUN6QyxNQUFNLEVBQUUsY0FBYyxlQUFlLGtCQUFrQixXQUFXLGNBQWMsb0JBQW9CLGFBQWE7Q0FDakgsTUFBTSxZQUFZLG9CQUFvQjtDQUV0QyxNQUFNLG1CQUFtQjtFQUN2QixhQUFhLEtBQUssVUFBVTtFQUM1QixhQUFhLGVBQWU7Q0FDOUI7Q0FFQSxPQUNFLHdCQUFDLFlBQUQ7RUFBWSxLQUFLO1lBQ2Ysd0JBQUMsT0FBRDtHQUFPLE9BQU87R0FBSyxXQUFXO0dBQUssT0FBTyxFQUFFLGdCQUFnQixTQUFTO2FBQXJFO0lBQ0Usd0JBQUMsV0FBRDtLQUFXLE9BQU8sRUFBRSxjQUFjLEdBQUc7ZUFBRztJQUFrQjs7Ozs7SUFFMUQsd0JBQUMsU0FBRDtLQUFTLE9BQU07S0FBb0IsT0FBTztLQUFlLEtBQUs7S0FBSSxLQUFLO0tBQUssTUFBTTtLQUFJLFNBQVMsTUFBTSxHQUFHLEVBQUU7S0FBSyxVQUFVO0lBQW1COzs7OztJQUM1SSx3QkFBQyxTQUFEO0tBQVMsT0FBTTtLQUFtQixPQUFPO0tBQVcsS0FBSztLQUFLLEtBQUs7S0FBSSxNQUFNO0tBQUssU0FBUyxNQUFNLEdBQUcsRUFBRTtLQUFLLFVBQVU7SUFBZTs7Ozs7SUFFbkksYUFDQyx3QkFBQyxLQUFEO0tBQUcsT0FBTztNQUFFLFFBQVE7TUFBVyxVQUFVO01BQVUsT0FBTyxNQUFNO0tBQU07ZUFBRztJQUFvQzs7Ozs7SUFHL0csd0JBQUMsY0FBRDtLQUFjLFVBQVM7S0FBaUIsT0FBTztLQUFNLE1BQU0sWUFBWSxTQUFTO0tBQWEsV0FBVyxFQUFFLFVBQVUsU0FBUztLQUFHLFNBQVM7SUFBYTs7Ozs7R0FDako7Ozs7OztDQUNHOzs7OztBQUVoQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPcHRpb25zTWVudS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUdhbWVTdG9yZSB9IGZyb20gJy4uLy4uLy4uL3N0b3JlL2dhbWVTdG9yZSc7XG5pbXBvcnQgeyBTcHJpdGVCdXR0b24gfSBmcm9tICcuLi9TcHJpdGVCdXR0b24nO1xuaW1wb3J0IHsgc291bmRNYW5hZ2VyIH0gZnJvbSAnLi4vLi4vLi4vZ2FtZS9Tb3VuZE1hbmFnZXInO1xuaW1wb3J0IHsgTWVudVNjcmVlbiwgUGFuZWwsIE1lbnVUaXRsZSwgdGhlbWUgfSBmcm9tICcuL01lbnVLaXQnO1xuXG5pbnRlcmZhY2UgU3RlcHBlclByb3BzIHtcbiAgbGFiZWw6IHN0cmluZztcbiAgdmFsdWU6IG51bWJlcjtcbiAgbWluOiBudW1iZXI7XG4gIG1heDogbnVtYmVyO1xuICBzdGVwOiBudW1iZXI7XG4gIGZvcm1hdDogKHY6IG51bWJlcikgPT4gc3RyaW5nO1xuICBvbkNoYW5nZTogKHY6IG51bWJlcikgPT4gdm9pZDtcbn1cblxuY29uc3QgU3RlcHBlcjogUmVhY3QuRkM8U3RlcHBlclByb3BzPiA9ICh7IGxhYmVsLCB2YWx1ZSwgbWluLCBtYXgsIHN0ZXAsIGZvcm1hdCwgb25DaGFuZ2UgfSkgPT4ge1xuICBjb25zdCBjaGFuZ2UgPSAoZGlyOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBuZXh0ID0gTWF0aC5yb3VuZCgodmFsdWUgKyBkaXIgKiBzdGVwKSAqIDEwMCkgLyAxMDA7XG4gICAgaWYgKG5leHQgPCBtaW4gfHwgbmV4dCA+IG1heCkgcmV0dXJuO1xuICAgIHNvdW5kTWFuYWdlci5wbGF5KCd1aV9jbGljaycpO1xuICAgIG9uQ2hhbmdlKG5leHQpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgbWFyZ2luQm90dG9tOiAxNCB9fT5cbiAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMXJlbScsIGZvbnRXZWlnaHQ6IDcwMCwgY29sb3I6IHRoZW1lLmNyZWFtLCBtYXJnaW5Cb3R0b206IDYgfX0+e2xhYmVsfTwvc3Bhbj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cbiAgICAgICAgPFNwcml0ZUJ1dHRvbiBkYXRhLXRlc3RpZD17YCR7bGFiZWx9LW1pbnVzYH0gYmFzZU5hbWU9XCJidXR0b25fcm91bmRcIiBzY2FsZT17MC43NX0gaWNvbj1cImljb25fbWludXNcIiBpY29uU2NhbGU9ezAuNTV9IGRpc2FibGVkPXt2YWx1ZSA8PSBtaW59IG9uQ2xpY2s9eygpID0+IGNoYW5nZSgtMSl9IHN0eWxlPXt7IG1hcmdpbjogMCB9fSAvPlxuICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogMTkwLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBmb250U2l6ZTogJzEuNXJlbScsIGZvbnRXZWlnaHQ6IDkwMCwgY29sb3I6IHRoZW1lLmNyZWFtIH19Pntmb3JtYXQodmFsdWUpfTwvc3Bhbj5cbiAgICAgICAgPFNwcml0ZUJ1dHRvbiBkYXRhLXRlc3RpZD17YCR7bGFiZWx9LXBsdXNgfSBiYXNlTmFtZT1cImJ1dHRvbl9yb3VuZFwiIHNjYWxlPXswLjc1fSBpY29uPVwiaWNvbl9wbHVzXCIgaWNvblNjYWxlPXswLjU1fSBkaXNhYmxlZD17dmFsdWUgPj0gbWF4fSBvbkNsaWNrPXsoKSA9PiBjaGFuZ2UoMSl9IHN0eWxlPXt7IG1hcmdpbjogMCB9fSAvPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgT3B0aW9uc01lbnU6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IHNldEdhbWVTdGF0ZSwgbWF0Y2hEdXJhdGlvbiwgc2V0TWF0Y2hEdXJhdGlvbiwgc3Bhd25SYXRlLCBzZXRTcGF3blJhdGUsIG9wdGlvbnNSZXR1cm5UbyB9ID0gdXNlR2FtZVN0b3JlKCk7XG4gIGNvbnN0IGZyb21QYXVzZSA9IG9wdGlvbnNSZXR1cm5UbyA9PT0gJ1BBVVNFRCc7XG5cbiAgY29uc3QgaGFuZGxlQmFjayA9ICgpID0+IHtcbiAgICBzb3VuZE1hbmFnZXIucGxheSgndWlfY2xpY2snKTtcbiAgICBzZXRHYW1lU3RhdGUob3B0aW9uc1JldHVyblRvKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxNZW51U2NyZWVuIGRpbT17ZnJvbVBhdXNlfT5cbiAgICAgIDxQYW5lbCB3aWR0aD17NzgwfSBtaW5IZWlnaHQ9ezY2MH0gc3R5bGU9e3sganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInIH19PlxuICAgICAgICA8TWVudVRpdGxlIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogMjQgfX0+T1BUSU9OUzwvTWVudVRpdGxlPlxuXG4gICAgICAgIDxTdGVwcGVyIGxhYmVsPVwiR2FtZSBzZXNzaW9uIHRpbWVcIiB2YWx1ZT17bWF0Y2hEdXJhdGlvbn0gbWluPXszMH0gbWF4PXszMDB9IHN0ZXA9ezEwfSBmb3JtYXQ9eyh2KSA9PiBgJHt2fSBzYH0gb25DaGFuZ2U9e3NldE1hdGNoRHVyYXRpb259IC8+XG4gICAgICAgIDxTdGVwcGVyIGxhYmVsPVwiRW5lbXkgc3Bhd24gdGltZVwiIHZhbHVlPXtzcGF3blJhdGV9IG1pbj17MC41fSBtYXg9ezEwfSBzdGVwPXswLjV9IGZvcm1hdD17KHYpID0+IGAke3Z9IHNgfSBvbkNoYW5nZT17c2V0U3Bhd25SYXRlfSAvPlxuXG4gICAgICAgIHtmcm9tUGF1c2UgJiYgKFxuICAgICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogJzAgMCA2cHgnLCBmb250U2l6ZTogJzAuOHJlbScsIGNvbG9yOiB0aGVtZS5tdXRlZCB9fT5DaGFuZ2VzIGFwcGx5IHRvIHRoZSBuZXh0IGJhdHRsZS48L3A+XG4gICAgICAgICl9XG5cbiAgICAgICAgPFNwcml0ZUJ1dHRvbiBiYXNlTmFtZT1cImJ1dHRvbl9wcmltYXJ5XCIgc2NhbGU9ezEuMjV9IHRleHQ9e2Zyb21QYXVzZSA/ICdCQUNLJyA6ICdNQUlOIE1FTlUnfSB0ZXh0U3R5bGU9e3sgZm9udFNpemU6ICcxLjZyZW0nIH19IG9uQ2xpY2s9e2hhbmRsZUJhY2t9IC8+XG4gICAgICA8L1BhbmVsPlxuICAgIDwvTWVudVNjcmVlbj5cbiAgKTtcbn07XG4iXX0=