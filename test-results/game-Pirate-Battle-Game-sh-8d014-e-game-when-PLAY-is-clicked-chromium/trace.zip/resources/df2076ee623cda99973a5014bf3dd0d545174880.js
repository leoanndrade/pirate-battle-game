import { Container, Sprite, Texture, Rectangle } from "/node_modules/.vite/deps/pixi__js.js?v=eccdfead";
import { AssetManager } from "/src/game/AssetManager.ts";
import { Island } from "/src/game/entities/Island.ts";
export class TiledMapParser {
	static async loadMap(jsonUrl, container, islandsArray) {
		const response = await fetch(jsonUrl);
		const mapData = await response.json();
		const baseTexture = AssetManager.getTexture("tiles");
		const cols = Math.floor(baseTexture.width / mapData.tilewidth);
		const mapWidth = mapData.width * mapData.tilewidth;
		const mapHeight = mapData.height * mapData.tileheight;
		for (const layer of mapData.layers) {
			if (layer.type === "tilelayer") {
				const layerContainer = new Container();
				for (let i = 0; i < layer.data.length; i++) {
					const gid = layer.data[i];
					if (gid === 0) continue;
					const tileId = gid - 1;
					const xPos = i % mapData.width * mapData.tilewidth;
					const yPos = Math.floor(i / mapData.width) * mapData.tileheight;
					const tx = tileId % cols * mapData.tilewidth;
					const ty = Math.floor(tileId / cols) * mapData.tileheight;
					const frame = new Rectangle(tx, ty, mapData.tilewidth, mapData.tileheight);
					const tileTex = new Texture({
						source: baseTexture.source,
						frame
					});
					const sprite = new Sprite(tileTex);
					sprite.x = xPos;
					sprite.y = yPos;
					layerContainer.addChild(sprite);
				}
				container.addChild(layerContainer);
			} else if (layer.type === "objectgroup" && layer.name === "Collisions") {
				for (const obj of layer.objects) {
					if (obj.ellipse) {
						const radius = obj.width / 2;
						const centerX = obj.x + radius;
						const centerY = obj.y + radius;
						const collisionIsland = new Island(centerX, centerY);
						collisionIsland.radius = radius;
						collisionIsland.container.visible = false;
						islandsArray.push(collisionIsland);
					} else {
						const centerX = obj.x + obj.width / 2;
						const centerY = obj.y + obj.height / 2;
						const collisionIsland = new Island(centerX, centerY);
						collisionIsland.isRect = true;
						collisionIsland.width = obj.width;
						collisionIsland.height = obj.height;
						collisionIsland.container.visible = false;
						islandsArray.push(collisionIsland);
					}
				}
			}
		}
		return {
			mapWidth,
			mapHeight
		};
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsU0FBUyxpQkFBaUI7QUFDdEQsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxjQUFjO0FBRXZCLE9BQU8sTUFBTSxlQUFlO0NBQzFCLGFBQW9CLFFBQVEsU0FBaUIsV0FBc0IsY0FBd0I7RUFDekYsTUFBTSxXQUFXLE1BQU0sTUFBTSxPQUFPO0VBQ3BDLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSztFQUVwQyxNQUFNLGNBQWMsYUFBYSxXQUFXLE9BQU87RUFDbkQsTUFBTSxPQUFPLEtBQUssTUFBTSxZQUFZLFFBQVEsUUFBUSxTQUFTO0VBRTdELE1BQU0sV0FBVyxRQUFRLFFBQVEsUUFBUTtFQUN6QyxNQUFNLFlBQVksUUFBUSxTQUFTLFFBQVE7RUFFM0MsS0FBSyxNQUFNLFNBQVMsUUFBUSxRQUFRO0dBQ2xDLElBQUksTUFBTSxTQUFTLGFBQWE7SUFDOUIsTUFBTSxpQkFBaUIsSUFBSSxVQUFVO0lBQ3JDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUssUUFBUSxLQUFLO0tBQzFDLE1BQU0sTUFBTSxNQUFNLEtBQUs7S0FDdkIsSUFBSSxRQUFRLEdBQUc7S0FFZixNQUFNLFNBQVMsTUFBTTtLQUNyQixNQUFNLE9BQVEsSUFBSSxRQUFRLFFBQVMsUUFBUTtLQUMzQyxNQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksUUFBUSxLQUFLLElBQUksUUFBUTtLQUVyRCxNQUFNLEtBQU0sU0FBUyxPQUFRLFFBQVE7S0FDckMsTUFBTSxLQUFLLEtBQUssTUFBTSxTQUFTLElBQUksSUFBSSxRQUFRO0tBRS9DLE1BQU0sUUFBUSxJQUFJLFVBQVUsSUFBSSxJQUFJLFFBQVEsV0FBVyxRQUFRLFVBQVU7S0FDekUsTUFBTSxVQUFVLElBQUksUUFBUTtNQUFFLFFBQVEsWUFBWTtNQUFRO0tBQU0sQ0FBQztLQUNqRSxNQUFNLFNBQVMsSUFBSSxPQUFPLE9BQU87S0FFakMsT0FBTyxJQUFJO0tBQ1gsT0FBTyxJQUFJO0tBQ1gsZUFBZSxTQUFTLE1BQU07SUFDaEM7SUFDQSxVQUFVLFNBQVMsY0FBYztHQUNuQyxPQUNLLElBQUksTUFBTSxTQUFTLGlCQUFpQixNQUFNLFNBQVMsY0FBYztJQUNwRSxLQUFLLE1BQU0sT0FBTyxNQUFNLFNBQVM7S0FDL0IsSUFBSSxJQUFJLFNBQVM7TUFDZixNQUFNLFNBQVMsSUFBSSxRQUFRO01BQzNCLE1BQU0sVUFBVSxJQUFJLElBQUk7TUFDeEIsTUFBTSxVQUFVLElBQUksSUFBSTtNQUV4QixNQUFNLGtCQUFrQixJQUFJLE9BQU8sU0FBUyxPQUFPO01BQ25ELGdCQUFnQixTQUFTO01BQ3pCLGdCQUFnQixVQUFVLFVBQVU7TUFDcEMsYUFBYSxLQUFLLGVBQWU7S0FDbkMsT0FBTztNQUVMLE1BQU0sVUFBVSxJQUFJLElBQUksSUFBSSxRQUFRO01BQ3BDLE1BQU0sVUFBVSxJQUFJLElBQUksSUFBSSxTQUFTO01BRXJDLE1BQU0sa0JBQWtCLElBQUksT0FBTyxTQUFTLE9BQU87TUFDbkQsZ0JBQWdCLFNBQVM7TUFDekIsZ0JBQWdCLFFBQVEsSUFBSTtNQUM1QixnQkFBZ0IsU0FBUyxJQUFJO01BQzdCLGdCQUFnQixVQUFVLFVBQVU7TUFDcEMsYUFBYSxLQUFLLGVBQWU7S0FDbkM7SUFDRjtHQUNGO0VBQ0Y7RUFFQSxPQUFPO0dBQUU7R0FBVTtFQUFVO0NBQy9CO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGlsZWRNYXBQYXJzZXIudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29udGFpbmVyLCBTcHJpdGUsIFRleHR1cmUsIFJlY3RhbmdsZSB9IGZyb20gJ3BpeGkuanMnO1xuaW1wb3J0IHsgQXNzZXRNYW5hZ2VyIH0gZnJvbSAnLi9Bc3NldE1hbmFnZXInO1xuaW1wb3J0IHsgSXNsYW5kIH0gZnJvbSAnLi9lbnRpdGllcy9Jc2xhbmQnO1xuXG5leHBvcnQgY2xhc3MgVGlsZWRNYXBQYXJzZXIge1xuICBwdWJsaWMgc3RhdGljIGFzeW5jIGxvYWRNYXAoanNvblVybDogc3RyaW5nLCBjb250YWluZXI6IENvbnRhaW5lciwgaXNsYW5kc0FycmF5OiBJc2xhbmRbXSkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goanNvblVybCk7XG4gICAgY29uc3QgbWFwRGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcblxuICAgIGNvbnN0IGJhc2VUZXh0dXJlID0gQXNzZXRNYW5hZ2VyLmdldFRleHR1cmUoJ3RpbGVzJyk7XG4gICAgY29uc3QgY29scyA9IE1hdGguZmxvb3IoYmFzZVRleHR1cmUud2lkdGggLyBtYXBEYXRhLnRpbGV3aWR0aCk7XG4gICAgXG4gICAgY29uc3QgbWFwV2lkdGggPSBtYXBEYXRhLndpZHRoICogbWFwRGF0YS50aWxld2lkdGg7XG4gICAgY29uc3QgbWFwSGVpZ2h0ID0gbWFwRGF0YS5oZWlnaHQgKiBtYXBEYXRhLnRpbGVoZWlnaHQ7XG5cbiAgICBmb3IgKGNvbnN0IGxheWVyIG9mIG1hcERhdGEubGF5ZXJzKSB7XG4gICAgICBpZiAobGF5ZXIudHlwZSA9PT0gJ3RpbGVsYXllcicpIHtcbiAgICAgICAgY29uc3QgbGF5ZXJDb250YWluZXIgPSBuZXcgQ29udGFpbmVyKCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGF5ZXIuZGF0YS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGdpZCA9IGxheWVyLmRhdGFbaV07XG4gICAgICAgICAgaWYgKGdpZCA9PT0gMCkgY29udGludWU7IC8vIEVtcHR5IHRpbGVcblxuICAgICAgICAgIGNvbnN0IHRpbGVJZCA9IGdpZCAtIDE7XG4gICAgICAgICAgY29uc3QgeFBvcyA9IChpICUgbWFwRGF0YS53aWR0aCkgKiBtYXBEYXRhLnRpbGV3aWR0aDtcbiAgICAgICAgICBjb25zdCB5UG9zID0gTWF0aC5mbG9vcihpIC8gbWFwRGF0YS53aWR0aCkgKiBtYXBEYXRhLnRpbGVoZWlnaHQ7XG5cbiAgICAgICAgICBjb25zdCB0eCA9ICh0aWxlSWQgJSBjb2xzKSAqIG1hcERhdGEudGlsZXdpZHRoO1xuICAgICAgICAgIGNvbnN0IHR5ID0gTWF0aC5mbG9vcih0aWxlSWQgLyBjb2xzKSAqIG1hcERhdGEudGlsZWhlaWdodDtcblxuICAgICAgICAgIGNvbnN0IGZyYW1lID0gbmV3IFJlY3RhbmdsZSh0eCwgdHksIG1hcERhdGEudGlsZXdpZHRoLCBtYXBEYXRhLnRpbGVoZWlnaHQpO1xuICAgICAgICAgIGNvbnN0IHRpbGVUZXggPSBuZXcgVGV4dHVyZSh7IHNvdXJjZTogYmFzZVRleHR1cmUuc291cmNlLCBmcmFtZSB9KTtcbiAgICAgICAgICBjb25zdCBzcHJpdGUgPSBuZXcgU3ByaXRlKHRpbGVUZXgpO1xuXG4gICAgICAgICAgc3ByaXRlLnggPSB4UG9zO1xuICAgICAgICAgIHNwcml0ZS55ID0geVBvcztcbiAgICAgICAgICBsYXllckNvbnRhaW5lci5hZGRDaGlsZChzcHJpdGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRhaW5lci5hZGRDaGlsZChsYXllckNvbnRhaW5lcik7XG4gICAgICB9IFxuICAgICAgZWxzZSBpZiAobGF5ZXIudHlwZSA9PT0gJ29iamVjdGdyb3VwJyAmJiBsYXllci5uYW1lID09PSAnQ29sbGlzaW9ucycpIHtcbiAgICAgICAgZm9yIChjb25zdCBvYmogb2YgbGF5ZXIub2JqZWN0cykge1xuICAgICAgICAgIGlmIChvYmouZWxsaXBzZSkge1xuICAgICAgICAgICAgY29uc3QgcmFkaXVzID0gb2JqLndpZHRoIC8gMjtcbiAgICAgICAgICAgIGNvbnN0IGNlbnRlclggPSBvYmoueCArIHJhZGl1cztcbiAgICAgICAgICAgIGNvbnN0IGNlbnRlclkgPSBvYmoueSArIHJhZGl1cztcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29uc3QgY29sbGlzaW9uSXNsYW5kID0gbmV3IElzbGFuZChjZW50ZXJYLCBjZW50ZXJZKTtcbiAgICAgICAgICAgIGNvbGxpc2lvbklzbGFuZC5yYWRpdXMgPSByYWRpdXM7XG4gICAgICAgICAgICBjb2xsaXNpb25Jc2xhbmQuY29udGFpbmVyLnZpc2libGUgPSBmYWxzZTsgXG4gICAgICAgICAgICBpc2xhbmRzQXJyYXkucHVzaChjb2xsaXNpb25Jc2xhbmQpO1xuICAgICAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgICAgIGNvbnN0IGNlbnRlclggPSBvYmoueCArIG9iai53aWR0aCAvIDI7XG4gICAgICAgICAgICBjb25zdCBjZW50ZXJZID0gb2JqLnkgKyBvYmouaGVpZ2h0IC8gMjtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29uc3QgY29sbGlzaW9uSXNsYW5kID0gbmV3IElzbGFuZChjZW50ZXJYLCBjZW50ZXJZKTtcbiAgICAgICAgICAgIGNvbGxpc2lvbklzbGFuZC5pc1JlY3QgPSB0cnVlO1xuICAgICAgICAgICAgY29sbGlzaW9uSXNsYW5kLndpZHRoID0gb2JqLndpZHRoO1xuICAgICAgICAgICAgY29sbGlzaW9uSXNsYW5kLmhlaWdodCA9IG9iai5oZWlnaHQ7XG4gICAgICAgICAgICBjb2xsaXNpb25Jc2xhbmQuY29udGFpbmVyLnZpc2libGUgPSBmYWxzZTsgXG4gICAgICAgICAgICBpc2xhbmRzQXJyYXkucHVzaChjb2xsaXNpb25Jc2xhbmQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBcbiAgICByZXR1cm4geyBtYXBXaWR0aCwgbWFwSGVpZ2h0IH07XG4gIH1cbn1cbiJdfQ==