import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=eccdfead";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=eccdfead";
//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* The context that `useQueryClient` reads from. `QueryClientProvider` is the normal way to set it.
*/
var QueryClientContext = import_react.createContext(void 0);
/**
* The `useQueryClient` hook returns the current `QueryClient` instance.
*
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The current `QueryClient` instance.
* @throws If no `queryClient` argument is passed and no `QueryClientProvider` is found in the component tree.
*/
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
/**
* Use the `QueryClientProvider` component to connect and provide a `QueryClient` to your application. Also
* calls `client.mount()`/`client.unmount()` as this component mounts/unmounts, which subscribes the client to
* focus/online events (resuming any paused mutations and refetching as needed when the app regains focus or
* comes back online).
*
* @returns The provided `children`, wrapped so they can read the `QueryClient` via `useQueryClient`.
*
* @example
* ```tsx
* import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
*
* const queryClient = new QueryClient()
*
* function App() {
*   return <QueryClientProvider client={queryClient}>...</QueryClientProvider>
* }
* ```
*/
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
/**
* Allows customization of how timeouts are created.
*
* @tanstack/query-core makes liberal use of timeouts to implement `staleTime`
* and `gcTime`. The default TimeoutManager provider uses the platform's global
* `setTimeout` implementation, which is known to have scalability issues with
* thousands of timeouts on the event loop.
*
* If you hit this limitation, consider providing a custom TimeoutProvider that
* coalesces timeouts.
*/
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	/**
	* `setTimeoutProvider` can be used to set a custom implementation of the
	* `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval` functions,
	* called a `TimeoutProvider`.
	*
	* This may be useful if you notice event loop performance issues with
	* thousands of queries. A custom TimeoutProvider could also support timer
	* delays longer than the global `setTimeout` maximum delay value of about
	* 24 days.
	*
	* It is important to call `setTimeoutProvider` before creating a
	* QueryClient or queries, so that the same provider is used consistently
	* for all timers in the application, since different TimeoutProviders
	* cannot cancel each others' timers.
	*
	* @example
	* ```ts
	* import { timeoutManager, QueryClient } from '@tanstack/query-core'
	* import { CustomTimeoutProvider } from './CustomTimeoutProvider'
	*
	* timeoutManager.setTimeoutProvider(new CustomTimeoutProvider())
	*
	* export const queryClient = new QueryClient()
	* ```
	*/
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	/**
	* `setTimeout` schedules a callback to run after approximately `delay`
	* milliseconds, like the global `setTimeout` function. The callback can be
	* canceled with `clearTimeout`.
	*
	* It returns a timer ID, which may be a number or an object that can be
	* coerced to a number via `Symbol.toPrimitive`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* const timeoutIdNumber: number = Number(timeoutId)
	* ```
	*/
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	/**
	* `clearTimeout` cancels a timeout callback scheduled with `setTimeout`,
	* like the global `clearTimeout` function. It should be called with a
	* timer ID returned by `setTimeout`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearTimeout(timeoutId)
	* ```
	*/
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	/**
	* `setInterval` schedules a callback to be called approximately every
	* `delay` milliseconds, like the global `setInterval` function.
	*
	* Like `setTimeout`, it returns a timer ID, which may be a number or an
	* object that can be coerced to a number via `Symbol.toPrimitive`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	* ```
	*/
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	/**
	* `clearInterval` can be used to cancel an interval, like the global
	* `clearInterval` function. It should be called with an interval ID
	* returned by `setInterval`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearInterval(intervalId)
	* ```
	*/
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
/**
* Singleton instance of {@link TimeoutManager}, used throughout TanStack Query to schedule and cancel timers.
*/
var timeoutManager = new TimeoutManager();
/**
* In many cases code wants to delay to the next event loop tick; this is not
* mediated by {@link timeoutManager}.
*
* This function is provided to make auditing the `tanstack/query-core` for
* incorrect use of system `setTimeout` easier.
*/
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/utils.js
/** @deprecated
* use `environmentManager.isServer()` instead.
*/
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveQueryValue(value, query) {
	return typeof value === "function" ? value(query) : value;
}
/**
* Checks whether a query matches the given {@link QueryFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
*
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
*
* const matchingQueries = queryCache
*   .getAll()
*   .filter((query) => matchQuery({ queryKey: ['posts'] }, query))
* ```
*/
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
/**
* Checks whether a mutation matches the given {@link MutationFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* If a `mutationKey` filter is provided but the mutation has no `mutationKey` of its own, it does not match.
*
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const matchingMutations = mutationCache
*   .getAll()
*   .filter((mutation) => matchMutation({ mutationKey: ['addPost'] }, mutation))
* ```
*/
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
*
* @example
* ```ts
* // Object keys are sorted, so key order doesn't affect the hash:
* hashKey(['todos', { page: 1, filter: 'done' }]) // === '["todos",{"filter":"done","page":1}]'
* ```
*/
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			if (b.length > a.length) return false;
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
/**
* Shallow compare objects.
*/
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (a[key] !== b[key]) return false;
	return true;
}
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const objectPrototype = Object.getPrototypeOf(o);
	const ctor = objectPrototype?.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return false;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (objectPrototype !== Object.prototype) return false;
	return true;
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
/**
* Intended to be passed as a query's `placeholderData` option, for example
* `placeholderData: keepPreviousData`. Instead of resetting the query's data to `undefined` while a new
* query key is fetching, it keeps displaying the previously fetched data until the new data arrives.
*
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['posts', page],
*   queryFn: () => fetchPosts(page),
*   placeholderData: keepPreviousData,
* })
* ```
*/
function keepPreviousData(previousData) {
	return previousData;
}
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(1) : newItems;
}
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
/**
* Sentinel value that can be passed as a query's `queryFn` to conditionally disable the query (equivalent
* to `enabled: false`) while preserving full type inference for the query's data. Unlike `enabled: false`,
* a query disabled via `skipToken` cannot be triggered with `refetch`.
*
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['post', postId],
*   queryFn: postId != null ? () => fetchPost(postId) : skipToken,
* })
* ```
*/
var skipToken = Symbol();
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
/**
* Resolves a `throwOnError` option to a boolean.
* If `throwOnError` is a function, it is called with `params` (e.g. the error and, depending on the caller,
* additional context such as the query or mutation) and its result is returned, allowing the throwing
* behavior to be decided per error. Otherwise, `throwOnError` itself is coerced to a boolean (`undefined`
* resolves to `false`).
*
* @example
* ```ts
* const throwOnError =
*   query.state.error && typeof options.throwOnError === 'function'
*     ? shouldThrowError(options.throwOnError, [query.state.error, query])
*     : options.throwOnError
* ```
*/
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
function addConsumeAwareSignal(object, getSignal, onCancelled) {
	let consumed = false;
	let signal;
	Object.defineProperty(object, "signal", {
		enumerable: true,
		get: () => {
			signal ??= getSignal();
			if (consumed) return signal;
			consumed = true;
			if (signal.aborted) onCancelled();
			else signal.addEventListener("abort", onCancelled, { once: true });
			return signal;
		}
	});
	return object;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/environmentManager.js
var isServerFn = () => isServer;
/**
* Returns whether the current runtime should be treated as a server environment.
*/
var isServer$1 = () => isServerFn();
/**
* Manages how TanStack Query detects whether the current runtime should be treated as
* server-side, which disables scheduling refetch timers and changes the default `retry` count
* and `gcTime`. By default, the detection treats a missing `window` (or the presence of a
* `Deno` global) as server.
*
* Override this for runtimes where that default detection would give the wrong answer — for
* example, a Service Worker, where `window` is undefined even though the environment should
* behave like a client.
*
* @example
* ```ts
* import { environmentManager } from '@tanstack/query-core'
*
* environmentManager.setIsServer(() => false)
* ```
*/
var environmentManager = {
	isServer: isServer$1,
	/**
	* Overrides the server check globally.
	*/
	setIsServer(isServerValue) {
		isServerFn = isServerValue;
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
/**
* The base class behind everything in Query that you can subscribe to: `QueryCache`, `MutationCache`,
* the observers, and the `FocusManager`/`OnlineManager` behind `focusManager` and `onlineManager`.
* Subclasses decide what a listener receives and when it is called.
*/
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	/**
	* Registers a listener to be called on every update this object notifies about. Returns a function
	* that removes the listener again — call it to stop listening. The base class never drops a listener
	* on its own, though some subclasses clear all of theirs in `destroy()`.
	* @param listener - Called on each update, with whatever the subclass passes to its subscribers.
	* @example
	* ```ts
	* const unsubscribe = subscribable.subscribe(() => {
	*   // react to the update
	* })
	*
	* unsubscribe()
	* ```
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	/**
	* Returns `true` while at least one listener is registered, `false` once they have all unsubscribed.
	*/
	hasListeners() {
		return this.listeners.size > 0;
	}
	onSubscribe() {}
	onUnsubscribe() {}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
/**
* The `FocusManager` manages the focus state within TanStack Query.
*
* It can be used to change the default event listeners or to manually change the focus state.
*/
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the focus state. The provided `setup` function
	* receives a `setFocused` callback: call it with a `boolean` to manually
	* set the focus state, or with no arguments to re-evaluate the current
	* focus state and notify subscribers.
	*
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* focusManager.setEventListener((handleFocus) => {
	*   const listener = () => handleFocus()
	*   // Listen to visibilitychange
	*   if (typeof window !== 'undefined' && window.addEventListener) {
	*     window.addEventListener('visibilitychange', listener, false)
	*   }
	*
	*   return () => {
	*     // Be sure to unsubscribe if a new handler is set
	*     window.removeEventListener('visibilitychange', listener)
	*   }
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	/**
	* `setFocused` can be used to manually set the focus state. Set `undefined`
	* to fall back to the default focus check.
	*
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* // Set focused
	* focusManager.setFocused(true)
	*
	* // Set unfocused
	* focusManager.setFocused(false)
	*
	* // Fallback to the default focus check
	* focusManager.setFocused(undefined)
	* ```
	*/
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	/**
	* `onFocus` notifies all subscribed listeners with the current focus state.
	*/
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	/**
	* `isFocused` can be used to get the current focus state.
	*/
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
/**
* Singleton instance of {@link FocusManager}, used to manage and observe the focus state within TanStack Query.
*/
var focusManager = new FocusManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/hydration.js
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch?.(noop);
	if (data !== void 0) return { data };
}
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
function dehydratePromise(query, serializeData, shouldRedactErrors) {
	const promise = query.promise?.then(serializeData).catch((error) => {
		if (shouldRedactErrors?.(error) === false) return Promise.reject(error);
		console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
		return Promise.reject(/* @__PURE__ */ new Error("redacted"));
	});
	promise?.catch(noop);
	return promise;
}
/**
* Dehydrates a single `Query` into a serializable `DehydratedQuery` snapshot. Note that most query config (e.g.
* `queryFn`, `staleTime`) is not dehydrated but instead meant to be configured again when consuming the
* de/rehydrated data, typically with `useQuery` on the client. If the query is still `pending`, its in-flight
* promise is dehydrated too so it can be resumed on the other side instead of re-fetched.
* @param query - The query to dehydrate.
* @param serializeData - Optional transform applied to `query.state.data` before it is included in the snapshot.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the promise's rejection error, that
* error is kept as-is instead of being redacted.
*/
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData ? serializeData(query.state.data) : query.state.data }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise(query, serializeData, shouldRedactErrors) },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
/**
* The default `shouldDehydrateMutation` predicate used by `dehydrate`. Only dehydrates mutations that are
* currently paused (e.g. paused by `networkMode` while offline).
*/
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
/**
* The default `shouldDehydrateQuery` predicate used by `dehydrate`. Only dehydrates queries whose status is
* `'success'`.
*/
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
/**
* Dehydrates a `QueryClient`'s cache (queries and mutations) into a plain, serializable `DehydratedState`,
* typically to embed in server-rendered markup and later restore into a client-side `QueryClient` via `hydrate`.
* Which queries/mutations are included, and how their data/errors are transformed, is controlled by `options`,
* falling back to the client's `dehydrate` default options, and finally to `defaultShouldDehydrateQuery` /
* `defaultShouldDehydrateMutation`.
* @example
* ```ts
* const queryClient = new QueryClient()
*
* await queryClient.prefetchQuery({
*   queryKey: ['posts'],
*   queryFn: getPosts,
* })
*
* const dehydratedState = dehydrate(queryClient)
* ```
*/
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
/**
* Restores a `DehydratedState` (as produced by `dehydrate`) into a `QueryClient`'s cache, typically to seed the
* client with data already fetched on the server. `mutations` and `queries` are each optional on `dehydratedState`.
* Queries not yet in the cache are built from the dehydrated snapshot; queries that already exist are only updated
* when the dehydrated data is newer than what's already cached. Newly built queries have their `fetchStatus` reset
* to `'idle'` so they don't hydrate stuck in a fetching state. If a dehydrated query still had an in-flight
* promise, it is resumed via `query.fetch()` (reusing that promise as `initialPromise`) rather than re-invoking
* `queryFn`.
* @example
* ```ts
* // dehydratedState was produced by `dehydrate` on the server
* // and sent to the client, e.g. embedded in server-rendered markup.
* const queryClient = new QueryClient()
*
* hydrate(queryClient, dehydratedState)
* ```
*/
function hydrate(client, dehydratedState, options) {
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData;
	dehydratedState.mutations?.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	dehydratedState.queries?.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData ? deserializeData(rawData) : rawData;
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt,
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && dehydratedAt > query.state.dataUpdatedAt) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
/**
* Default scheduling function used by the notify manager.
* Schedules the callback with the system's `setTimeout(callback, 0)`.
*/
var defaultScheduler = systemSetTimeoutZero;
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		/**
		* Batches all updates scheduled inside the passed callback.
		* This is mainly used internally to optimize query client updating.
		* Batches can be nested; the queue is only flushed once the outermost `batch` call finishes.
		* The return value of `callback` is passed through.
		*/
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		/**
		* Schedules a function to be run on the next batch.
		* By default, the batch is run with a `setTimeout`, but this can be configured via `setScheduler`.
		*/
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* Framework adapters use this to plug in their own batching primitive, so that a single query
		* update only triggers one re-render instead of one per subscriber.
		*
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		* import { batch } from 'solid-js'
		*
		* notifyManager.setBatchNotifyFunction(batch)
		* ```
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		/**
		* Configures a custom callback that schedules when the next batch runs.
		* The default behavior is `setTimeout(callback, 0)`.
		*
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		*
		* // Schedule batches in the next microtask
		* notifyManager.setScheduler(queueMicrotask)
		*
		* // Schedule batches before the next frame is rendered
		* notifyManager.setScheduler(requestAnimationFrame)
		*
		* // Schedule batches some time in the future
		* notifyManager.setScheduler((cb) => setTimeout(cb, 10))
		* ```
		*/
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
/**
* Handles scheduling and batching callbacks in TanStack Query.
*/
var notifyManager = createNotifyManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
/**
* The `OnlineManager` manages the online state within TanStack Query. It can
* be used to change the default event listeners or to manually change the
* online state.
*
* By default, the `onlineManager` assumes an active network connection, and
* listens to the `online` and `offline` events on the `window` object to
* detect changes.
*/
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the online state. The provided `setup` function
	* receives a `setOnline` callback that should be called with a `boolean`
	* whenever the online state changes.
	*
	* @example
	* ```ts
	* import NetInfo from '@react-native-community/netinfo'
	* import { onlineManager } from '@tanstack/query-core'
	*
	* onlineManager.setEventListener((setOnline) => {
	*   return NetInfo.addEventListener((state) => {
	*     setOnline(!!state.isConnected)
	*   })
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	/**
	* `setOnline` can be used to manually set the online state.
	*
	* @example
	* ```ts
	* import { onlineManager } from '@tanstack/query-core'
	*
	* // Set to online
	* onlineManager.setOnline(true)
	*
	* // Set to offline
	* onlineManager.setOnline(false)
	* ```
	*/
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	/**
	* `isOnline` can be used to get the current online state.
	*/
	isOnline() {
		return this.#online;
	}
};
/**
* Singleton instance of {@link OnlineManager}, used to manage and observe the online state within TanStack Query.
*/
var onlineManager = new OnlineManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/retryer.js
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
/**
* The error thrown by a `Retryer` (and surfaced to `query.promise`/`mutation`) when a fetch is cancelled, e.g. via
* `query.cancel()`. `revert`, if `true`, tells the caller to restore the state the query was in before the fetch
* started instead of surfacing the error. `silent`, if `true`, tells the caller to suppress this error and instead
* resolve with the promise of the fetch that triggered the cancellation.
* @example
* ```ts
* query.cancel()
*
* try {
*   await query.promise
* } catch (error) {
*   if (error instanceof CancelledError) {
*     // the fetch was cancelled, e.g. via `query.cancel()`
*   }
* }
* ```
*/
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
/**
* @deprecated Use instanceof `CancelledError` instead.
*/
function isCancelledError(value) {
	return value instanceof CancelledError;
}
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	let status = "pending";
	let promiseResolve;
	let promiseReject;
	const promise = new Promise((resolve, reject) => {
		promiseResolve = resolve;
		promiseReject = reject;
	});
	promise.catch(noop);
	const isResolved = () => status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "resolved";
			promiseResolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "rejected";
			promiseReject(value);
		}
	};
	const pause = () => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canContinue()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (isServer$1() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return canContinue() ? void 0 : pause();
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise,
		status: () => status,
		cancel,
		continue: () => {
			continueFn?.();
			return promise;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause().then(run);
			return promise;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/removable.js
/**
* The base class for cache entries that are garbage collected once nothing is using them —
* `Query` and `Mutation` both extend it. `gcTime` controls how long an unused entry is kept.
*/
var Removable = class {
	#gcTimeout;
	/**
	* Clears the pending garbage collection timeout, so the entry is no longer scheduled for removal.
	* A subclass may override this to release what it holds on to as well — `Query` also cancels any
	* in-flight fetch.
	*/
	destroy() {
		this.clearGcTimeout();
	}
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer$1() ? Infinity : 3e5));
	}
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext);
					return queryFnContext;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
/**
* Checks if there is a next page.
*/
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
/**
* Checks if there is a previous page.
*/
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/query.js
/**
* Represents a single cached query. A `Query` holds the query's key, options,
* state (data/error/status), and the observers currently subscribed to it.
*
* Instances are created and managed internally by `QueryCache`; application
* code typically interacts with queries indirectly through `QueryClient` or
* a framework hook like `useQuery`. Direct access to a `Query` instance is
* possible via `queryCache.find()`/`findAll()` for inspecting cache state.
*
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
* const query = queryCache.find({ queryKey: ['posts'] })
*
* if (query) {
*   console.log(query.state.dataUpdatedAt)
* }
* ```
*/
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	/**
	* The `meta` object passed in the query's options, if any.
	*/
	get meta() {
		return this.options.meta;
	}
	/** @internal */
	get queryType() {
		return this.#queryType;
	}
	/**
	* The promise for the currently in-flight fetch, if the query is fetching.
	* `undefined` when the query is not fetching.
	*/
	get promise() {
		return this.#retryer?.promise;
	}
	/** @internal */
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	/** @internal */
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	/**
	* Merges the given partial state directly into this query's state, notifying observers. Used
	* by persistence and broadcast plugins to restore a state snapshot, and by devtools to let a
	* user manually trigger a loading/error state or edit the cached data.
	*/
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	/**
	* Cancels the query's currently in-flight fetch, if any.
	* - Returns a promise that resolves once the cancellation has settled.
	* - If no fetch is in progress, resolves immediately.
	*
	* @example
	* ```ts
	* await query.cancel()
	* ```
	*/
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	/**
	* Clears the query's garbage collection timeout and silently cancels any
	* in-flight fetch. Called by `QueryCache` when the query is removed from
	* the cache.
	*
	* @see {@link Query#cancel}
	*/
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	/** @internal */
	get resetState() {
		return this.#initialState;
	}
	/**
	* Resets the query back to its initial state (the state it had when it was
	* first created, e.g. any `initialData`), destroying it first to cancel any
	* in-flight fetch.
	*/
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	/**
	* Returns `true` if the query has at least one observer for which `enabled`
	* does not resolve to `false`.
	*/
	isActive() {
		return this.observers.some((observer) => resolveQueryValue(observer.options.enabled, this) !== false);
	}
	/**
	* Returns `true` if the query is disabled, meaning it will not fetch
	* automatically.
	* - If the query has observers, it is disabled when none of them are active
	*   (see `isActive`).
	* - If the query has no observers, it is disabled when its `queryFn` is
	*   `skipToken` or it has never been fetched.
	*/
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	/**
	* Returns `true` if the query has been fetched, i.e. it has resolved with
	* either data or an error at least once.
	*/
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	/**
	* Returns `true` if the query has at least one observer configured with
	* `staleTime: 'static'`, meaning it is treated as never stale.
	*/
	isStatic() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveQueryValue(observer.options.staleTime, this) === "static");
		return false;
	}
	/**
	* Returns `true` if the query is stale.
	* - If the query has observers, defers to whether any observer's current
	*   result reports `isStale` (which accounts for each observer's own
	*   `staleTime` and `enabled` state).
	* - If the query has no observers, it is considered stale when it has no
	*   data or has been invalidated.
	*
	* @see {@link Query#isStaleByTime}
	* @example
	* ```ts
	* if (query.isStale()) {
	*   // refetch or otherwise treat the cached data as outdated
	* }
	* ```
	*/
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	/**
	* Returns `true` if the query's data is stale relative to the given
	* `staleTime` (defaults to `0`).
	* - A query with no data is always stale.
	* - `staleTime: 'static'` is never stale.
	* - An invalidated query is always stale.
	* - Otherwise, staleness is based on elapsed time since `dataUpdatedAt`.
	*
	* @see {@link Query#isStale}
	* @example
	* ```ts
	* const isStale = query.isStaleByTime(1000 * 60)
	* ```
	*/
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	/** @internal */
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/** @internal */
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/** @internal */
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	/** @internal */
	removeObserver(observer) {
		const index = this.observers.indexOf(observer);
		if (index !== -1) {
			this.observers.splice(index, 1);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.state.fetchStatus === "paused" && this.state.status === "pending") this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	/**
	* Returns the number of observers currently subscribed to this query.
	*
	* @example
	* ```ts
	* if (query.getObserversCount() === 0) {
	*   // no component is currently watching this query
	* }
	* ```
	*/
	getObserversCount() {
		return this.observers.length;
	}
	/**
	* Marks the query as invalidated, unless it is already invalidated. This
	* updates `state.isInvalidated` and notifies observers, but does not by
	* itself trigger a refetch.
	*
	* @example
	* ```ts
	* query.invalidate()
	* ```
	*/
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	/**
	* Fetches the query, i.e. runs its `queryFn` (through any configured
	* retryer/behavior) and updates the query's state with the result.
	* - If a fetch is already in flight, returns its promise instead of
	*   starting a new one, unless `fetchOptions.cancelRefetch` is set and the
	*   query already has data, in which case the current fetch is silently
	*   cancelled first.
	* - If `options` is passed, it replaces the query's current options
	*   before fetching.
	*/
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer) {
				this.#retryer.continueRetry();
				return this.#retryer.promise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperty(object, "signal", {
				enumerable: true,
				get: () => {
					this.#abortSignalConsumed = true;
					return abortController.signal;
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext);
				return queryFnContext;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context);
			return context;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		const retryer = this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		try {
			const data = await retryer.start();
			if (data === void 0) {
				console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
				throw new Error(`${this.queryHash} data is undefined`);
			}
			this.setData(data);
			this.#cache.config.onSuccess?.(data, this);
			this.#cache.config.onSettled?.(data, this.state.error, this);
			return data;
		} catch (error) {
			if (error instanceof CancelledError) {
				if (error.silent) return this.#retryer.promise;
				else if (error.revert) {
					if (this.state.data === void 0) throw error;
					return this.state.data;
				}
			}
			this.#dispatch({
				type: "error",
				error
			});
			this.#cache.config.onError?.(error, this);
			this.#cache.config.onSettled?.(this.state.data, error, this);
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.scheduleGc();
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.slice().forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
/**
* A `QueryObserver` watches a single query in the `QueryCache` and computes a
* `QueryObserverResult` from its state, recomputing and notifying subscribers
* whenever the underlying query (or the observer's options) changes. It is
* the primitive that framework adapters (e.g. `useQuery`) build their hooks
* on top of, but it can also be used directly to observe and switch between
* queries outside of any framework.
*
* @example
* ```ts
* const observer = new QueryObserver(queryClient, {
*   queryKey: ['posts'],
*   queryFn: fetchPosts,
* })
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result.data)
* })
* ```
*/
var QueryObserver = class extends Subscribable {
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.bindMethods();
		this.setOptions(options);
	}
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnReconnect` option) to refetch when the network
	* reconnects.
	*/
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnWindowFocus` option) to refetch when the window
	* regains focus.
	*/
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	/**
	* Stops observing the current query: clears all listeners, cancels the
	* stale and refetch-interval timers, and removes this observer from the
	* query it was observing.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	/**
	* Updates the observer's options. This will re-resolve the query being
	* observed (switching to a different query if the `queryKey` changed),
	* trigger a fetch if the new options require one and the observer has
	* subscribers, recompute the current result, and reschedule the stale and
	* refetch-interval timers as needed.
	*
	* @example
	* ```ts
	* observer.setOptions({ queryKey: ['posts', 1], queryFn: () => fetchPost(1) })
	* // later: switch to a different query, reusing the same observer
	* observer.setOptions({ queryKey: ['posts', 2], queryFn: () => fetchPost(2) })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryValue(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || resolveQueryValue(this.options.staleTime, this.#currentQuery) !== resolveQueryValue(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	/**
	* Computes the result the observer would produce for the given (already-defaulted) options
	* right now, building the underlying `Query` if it doesn't exist yet, without waiting for a
	* subscription callback. Called by framework adapters on every render (e.g. `useQuery`) so the
	* returned value is available synchronously, ahead of `setOptions` triggering an actual fetch.
	*/
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (!shallowEqualObjects(this.getCurrentResult(), result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	/**
	* Returns the most recently computed `QueryObserverResult` for the
	* observed query. This is a point-in-time read; to be notified of updates
	* as they happen, subscribe to the observer instead (its inherited
	* `subscribe` method).
	*
	* @example
	* ```ts
	* const result = observer.getCurrentResult()
	* console.log(result.status, result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Wraps a `QueryObserverResult` in a `Proxy` that records which properties are read, via
	* {@link QueryObserver#trackProp} (and an optional `onPropTracked` callback). Used by framework
	* adapters when `notifyOnChangeProps` is not set, to implement its default "only re-render on
	* properties you actually read" behavior.
	*/
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			return Reflect.get(target, key);
		} });
	}
	/**
	* Records that the given `QueryObserverResult` property was read, so a subsequent update only
	* notifies this observer if a tracked property actually changed. Normally called indirectly via
	* {@link QueryObserver#trackResult}'s proxy; exposed directly for adapters that track property
	* access themselves (e.g. through their own reactivity system) instead of via the proxy.
	*/
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	/**
	* Returns the `Query` instance this observer is currently observing.
	*/
	getCurrentQuery() {
		return this.#currentQuery;
	}
	/**
	* Refetches the observed query and returns a promise that resolves with
	* the resulting `QueryObserverResult`.
	*
	* @example
	* ```ts
	* const result = await observer.refetch({ cancelRefetch: false })
	* console.log(result.data)
	* ```
	*/
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	/**
	* Fetches a query defined by the given options without affecting this
	* observer's own tracked query or result, and returns a promise that
	* resolves with the `QueryObserverResult` for that fetch. This is useful
	* for prefetching data that another observer (e.g. a query about to be
	* navigated to) will need, ahead of time.
	*
	* @example
	* ```ts
	* const result = await observer.fetchOptimistic({
	*   queryKey: ['posts', 2],
	*   queryFn: () => fetchPost(2),
	* })
	* console.log(result.data)
	* ```
	*/
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		let unsubscribe = () => {};
		let resolveEarly;
		const cachePromise = new Promise((resolve) => {
			resolveEarly = resolve;
			unsubscribe = this.#client.getQueryCache().subscribe((event) => {
				if (event.type === "updated" && event.query.queryHash === query.queryHash && query.state.data !== void 0) {
					unsubscribe();
					resolve(this.createResult(query, defaultedOptions));
				}
			});
		});
		return Promise.race([query.fetch().then(() => {
			const result = this.createResult(query, defaultedOptions);
			resolveEarly?.(result);
			return result;
		}).finally(() => {
			unsubscribe();
		}), cachePromise]);
	}
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#shouldScheduleTimer(timeout) {
		return !isServer$1() && resolveQueryValue(this.options.enabled, this.#currentQuery) !== false && isValidTimeout(timeout);
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveQueryValue(this.options.staleTime, this.#currentQuery);
		if (this.#currentResult.isStale || !this.#shouldScheduleTimer(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return resolveQueryValue(this.options.refetchInterval, this.#currentQuery) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (this.#currentRefetchInterval === 0 || !this.#shouldScheduleTimer(this.#currentRefetchInterval)) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		} else if (data === void 0) this.#selectError = null;
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = Date.now();
			status = "error";
			isPlaceholderData = false;
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		return {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			isEnabled: resolveQueryValue(options.enabled, query) !== false
		};
	}
	/**
	* Recomputes and stores the current result from the current query/options, notifying listeners
	* if it changed. Framework adapters call this right after subscribing to make sure no query
	* update was missed in the gap between creating the observer and subscribing to it.
	*/
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
			if (this.options.throwOnError) includedProps.add("error");
			return Object.keys(this.#currentResult).some((key) => {
				const typedKey = key;
				return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
			});
		};
		const notifyListeners = shouldNotifyListeners();
		notifyManager.batch(() => {
			if (notifyListeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	/** @internal */
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
};
function shouldLoadOnMount(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryValue(options.retryOnMount, query) === false);
}
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
	if (resolveQueryValue(options.enabled, query) !== false && resolveQueryValue(options.staleTime, query) !== "static") {
		const value = resolveQueryValue(field, query);
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryValue(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
function isStale(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.isStaleByTime(resolveQueryValue(options.staleTime, query));
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
/**
* An `InfiniteQueryObserver` extends `QueryObserver` to observe and switch
* between infinite queries. It augments the base `QueryObserverResult` with
* infinite-query-specific fields and methods, such as `hasNextPage` and
* `fetchNextPage`, and is the primitive that framework adapters (e.g.
* `useInfiniteQuery`) build their hooks on top of.
*
* @example
* ```ts
* const observer = new InfiniteQueryObserver(queryClient, {
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextCursor,
* })
*
* const unsubscribe = observer.subscribe((result) => console.log(result))
* ```
*/
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	/**
	* Updates the observer's options. Behaves the same as
	* `QueryObserver.setOptions`, additionally marking the options as
	* belonging to an infinite query before delegating to the base
	* implementation.
	*/
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	/**
	* The infinite-query counterpart of {@link QueryObserver#getOptimisticResult}, marking the
	* options as an infinite query before delegating to it. Called by framework adapters (e.g.
	* `useInfiniteQuery`) ahead of subscribing, to compute the current `InfiniteQueryObserverResult`
	* synchronously.
	*/
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	/**
	* Fetches the next page of the infinite query and returns a promise that
	* resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getNextPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasNextPage`.
	*
	* @example
	* ```ts
	* const { hasNextPage } = observer.getCurrentResult()
	*
	* if (hasNextPage) {
	*   await observer.fetchNextPage()
	* }
	* ```
	*
	* @see {@link InfiniteQueryObserver#fetchPreviousPage}
	*/
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	/**
	* Fetches the previous page of the infinite query and returns a promise
	* that resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getPreviousPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasPreviousPage`.
	*
	* @example
	* ```ts
	* const { hasPreviousPage } = observer.getCurrentResult()
	*
	* if (hasPreviousPage) {
	*   await observer.fetchPreviousPage()
	* }
	* ```
	*
	* @see {@link InfiniteQueryObserver#fetchNextPage}
	*/
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutation.js
/**
* Represents a single mutation attempt. A `Mutation` holds the mutation's
* options, state (data/error/status), and the `MutationObserver`s currently
* subscribed to it.
*
* Instances are created and managed internally by `MutationCache`; application
* code typically interacts with mutations indirectly through `QueryClient` or
* a framework hook like `useMutation`. Direct access to a `Mutation` instance
* is possible via `mutationCache.find()`/`getAll()` for inspecting cache state.
*
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
* ```
*/
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	/** @internal */
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	/**
	* The `meta` object passed in the mutation's options, if any.
	*/
	get meta() {
		return this.options.meta;
	}
	/** @internal */
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	/** @internal */
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	/**
	* Resumes a mutation that is currently paused or was restored from a
	* dehydrated, still-`pending` state.
	*
	* - If this mutation has an active retryer (it paused mid-attempt, e.g. due
	*   to the network mode or scope-based queuing), its retryer is resumed.
	* - Otherwise, if the mutation's status is still `pending` (e.g. it was
	*   dehydrated while an attempt was in flight and never got a retryer in
	*   this instance), `execute` is called again with the last known variables.
	* - Otherwise the mutation has already settled and this resolves immediately
	*   without running anything again.
	*
	* @example
	* ```ts
	* // typically driven by reconnect handling, e.g. queryClient.resumePausedMutations()
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* await mutation?.continue()
	* ```
	*
	* @see {@link Mutation#execute}
	*/
	continue() {
		return this.#retryer?.continue() ?? (this.state.status === "pending" ? this.execute(this.state.variables) : Promise.resolve());
	}
	/**
	* Runs the mutation function for the given variables through a retryer, and
	* drives the mutation's state and lifecycle callbacks through to settlement.
	*
	* If this mutation's state is already `pending` when `execute` is called
	* (i.e. it was restored, still in-flight, from a dehydrated state), the
	* `onMutate` step is skipped and a `continue` action is dispatched to
	* unpause it; otherwise a `pending` action is dispatched first, then the
	* mutation cache's `onMutate` and the mutation's own `onMutate` option are
	* awaited in that order, and the resulting context is stored.
	*
	* The mutation function is then run (subject to `retry`/`retryDelay`/
	* `networkMode`, and to the mutation cache's scope-based serialization).
	* On success, the cache's `onSuccess`/`onSettled` callbacks run before the
	* mutation's own `onSuccess`/`onSettled` options, a `success` action is
	* dispatched, and the resolved data is returned. On failure, the same
	* cache-then-option ordering is used for `onError`/`onSettled`, but each of
	* those four callbacks is individually caught so that a throwing callback
	* cannot mask the original error; an `error` action is then dispatched and
	* the original error is re-thrown.
	*
	* @example
	* ```ts
	* // Called internally by `MutationObserver.mutate` and `Mutation.continue` —
	* // applications normally trigger mutations through those, not this method.
	* const data = await mutation.execute(variables)
	* ```
	*
	* @see {@link Mutation#continue}
	*/
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		const retryer = this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			const data = await retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationCache.js
/**
* The `MutationCache` is the storage for mutations.
*
* Normally, you will not interact with the `MutationCache` directly and instead use a
* `QueryClient`. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as mutations being added, removed, or updated.
*
* @example
* ```ts
* const unsubscribe = mutationCache.subscribe((event) => {
*   console.log(event.type, event.mutation)
* })
* ```
*/
var MutationCache = class extends Subscribable {
	#mutations;
	#scopes;
	#mutationId;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	/** @internal */
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	/** @internal */
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	/** @internal */
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	/** @internal */
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	/** @internal */
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	/**
	* Removes all mutations from the cache.
	*
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* mutationCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.#mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
			this.#mutations.clear();
			this.#scopes.clear();
		});
	}
	/**
	* Returns all mutations within the cache.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	*
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.getAll()
	* ```
	*/
	getAll() {
		return Array.from(this.#mutations);
	}
	/**
	* A slightly more advanced method that can be used to get an existing mutation instance from
	* the cache. If the mutation does not exist, `undefined` is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	*
	* @see {@link MutationCache#findAll}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	/**
	* An even more advanced method that can be used to get existing mutation instances from the
	* cache that match the given filters. If no mutations match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about mutations in rare scenarios.
	*
	* @see {@link MutationCache#find}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.findAll({ mutationKey: ['addPost'] })
	* ```
	*/
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	/** @internal */
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/** @internal */
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
/**
* Observes a single mutation and derives a `MutationObserverResult` from it.
* A framework hook like `useMutation` creates one `MutationObserver` per hook
* call, keeps it stable across re-renders, calls `setOptions` when the options
* passed to the hook change, subscribes to it to re-render on updates, and
* reads `getCurrentResult()` for the value to return. Calling `mutate()`
* builds a new underlying `Mutation` in the `MutationCache` and executes it.
*
* @example
* ```ts
* const observer = new MutationObserver(queryClient, {
*   mutationFn: (variables: { title: string }) => addPost(variables),
* })
* ```
*/
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	/**
	* Updates the observer's options.
	*
	* If the new `mutationKey` differs from the previous one (and both were
	* defined), the observer is reset, detaching it from the mutation it was
	* observing. Otherwise, if the currently observed mutation is still
	* `pending`, its options are updated in place as well.
	*
	* @example
	* ```ts
	* observer.setOptions({
	*   mutationFn: (variables: { title: string }) => addPost(variables),
	*   onSuccess: (data) => console.log(data),
	* })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onSubscribe() {
		if (this.listeners.size === 1 && this.#currentMutation) {
			this.#currentMutation.addObserver(this);
			this.#updateResult();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	/** @internal */
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	/**
	* Returns the observer's current result, derived from the observed
	* mutation's state (or the default, `idle` state if no mutation has been
	* built yet, e.g. before the first `mutate()` call or after `reset()`).
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Detaches the observer from the mutation it is currently observing (if
	* any) and resets the observed result back to its default, `idle` state.
	*
	* This does not cancel an in-flight mutation; the mutation itself keeps
	* running to completion and its own callbacks still fire, but this
	* observer stops reflecting its state and a subsequent `mutate()` call
	* will build a brand new mutation.
	*
	* @example
	* ```ts
	* observer.reset()
	* ```
	*
	* @see {@link MutationObserver#mutate}
	*/
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	/**
	* Builds a new `Mutation` in the `MutationCache` using the observer's
	* current options, detaches this observer from any previously observed
	* mutation, attaches it to the new one, and executes it with the given
	* variables.
	*
	* The optional per-call `options` (`onSuccess`/`onError`/`onSettled`) are
	* invoked once the mutation settles, in addition to any callbacks defined
	* on the observer's own options.
	*
	* @example
	* ```ts
	* await observer.mutate(
	*   { title: 'New post' },
	*   { onSuccess: (data) => console.log(data) },
	* )
	* ```
	*/
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			if (this.#mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						this.#mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						this.#mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queriesObserver.js
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
/**
* A `QueriesObserver` watches an array of queries at once, exposing them as
* a single array of `QueryObserverResult`s (or, when a `combine` option is
* given, as a combined value derived from that array). It manages one
* internal `QueryObserver` per query, and is the primitive that framework
* adapters (e.g. `useQueries`) build their hooks on top of.
*
* @example
* ```ts
* const observer = new QueriesObserver(queryClient, [
*   { queryKey: ['post', 1], queryFn: fetchPost },
*   { queryKey: ['post', 2], queryFn: fetchPost },
* ])
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result)
* })
* ```
*/
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => {
			observer.subscribe((result) => {
				this.#onUpdate(observer, result);
			});
		});
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	/**
	* Stops observing all queries: clears all listeners and destroys every
	* underlying `QueryObserver` this observer manages.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	/**
	* Replaces the set of queries being observed. Existing `QueryObserver`s
	* are reused for queries that match an already-observed query hash;
	* observers for queries that are no longer present are destroyed, and new
	* observers are created and subscribed to for newly added queries.
	*
	* @example
	* ```ts
	* observer.setQueries([
	*   { queryKey: ['post', 1], queryFn: fetchPost },
	*   { queryKey: ['post', 3], queryFn: fetchPost },
	* ])
	* ```
	*/
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => {
					observer.subscribe((result) => {
						this.#onUpdate(observer, result);
					});
				});
			}
			this.#notify();
		});
	}
	/**
	* Returns the most recently computed array of `QueryObserverResult`s, one
	* per observed query, in the same order as the queries passed to the
	* constructor or `setQueries`.
	*
	* @example
	* ```ts
	* const results = observer.getCurrentResult()
	* const data = results.map((result) => result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#result;
	}
	/**
	* Returns the underlying `Query` instances currently being observed, in
	* the same order as the queries passed to the constructor or `setQueries`.
	*/
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	/**
	* Returns the underlying `QueryObserver` instances this observer manages,
	* in the same order as the queries passed to the constructor or
	* `setQueries`.
	*/
	getObservers() {
		return this.#observers;
	}
	/**
	* The `QueriesObserver` counterpart of {@link QueryObserver#getOptimisticResult} — computes
	* the result for the given (already-defaulted) queries right now, synchronously. Called by
	* framework adapters (e.g. `useQueries`) ahead of subscribing, returning a tuple of the raw
	* per-query results, a function to compute the combined result from them, and a function to
	* wrap the results for property-access tracking.
	*/
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		const trackedProps = /* @__PURE__ */ new Set();
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				if (!trackedProps.has(accessedProp)) {
					trackedProps.add(accessedProp);
					matches.forEach((m) => {
						m.observer.trackProp(accessedProp);
					});
				}
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return !this.#options?.combine || this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = this.#result.slice();
			this.#result[index] = result;
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(this.#trackResult(this.#result, this.#observerMatches), this.#options?.combine);
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryCache.js
/**
* The `QueryCache` is the storage mechanism for TanStack Query. It stores all the data, meta
* information, and state of the queries it contains.
*
* Normally, you will not interact with the `QueryCache` directly and instead use a `QueryClient`
* for a specific cache. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as queries being added, removed, or updated — updates made
* outside of the cache's own tracked mechanisms (e.g. mutating a query's state object directly) do
* not notify subscribers.
*
* @example
* ```ts
* const unsubscribe = queryCache.subscribe((event) => {
*   console.log(event.type, event.query)
* })
* ```
*/
var QueryCache = class extends Subscribable {
	#queries;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	/**
	* Returns the existing `Query` instance for the given options' `queryKey`/`queryHash`, or
	* builds and adds a new one to the cache if none exists yet. Used by framework adapters and
	* plugins (e.g. broadcast/persistence) that need to get-or-create a `Query` directly, bypassing
	* the reactive `QueryObserver` machinery.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.build(queryClient, {
	*   queryKey: ['posts'],
	*   queryFn: fetchPosts,
	* })
	* ```
	*/
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	/** @internal */
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	/**
	* Destroys the given `Query` and removes it from the cache, notifying subscribers with a
	* `'removed'` event. A no-op if the query is no longer the one currently stored under its hash
	* (e.g. it was already replaced). Used by plugins (e.g. the broadcast client) that mirror
	* removals across `QueryCache` instances.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const query = queryCache.find({ queryKey: ['posts'] })
	*
	* if (query) {
	*   queryCache.remove(query)
	* }
	* ```
	*/
	remove(query) {
		if (this.#queries.get(query.queryHash) === query) {
			query.destroy();
			this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	/**
	* Removes all queries from the cache.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* queryCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	/**
	* Returns the `Query` instance stored under the given `queryHash`, or `undefined` if none
	* exists. Unlike {@link QueryCache#find}, this looks up by the already-computed hash rather
	* than by `QueryFilters`. Used by plugins (e.g. broadcast/hydration) that already have a hash
	* to look up directly.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const queryHash = hashKey(['posts'])
	*
	* const query = queryCache.get(queryHash)
	* ```
	*/
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	/**
	* Returns all queries within the cache.
	*
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.getAll()
	* ```
	*/
	getAll() {
		return [...this.#queries.values()];
	}
	/**
	* A slightly more advanced method that can be used to get an existing query instance from the
	* cache. This instance not only contains all the state for the query, but all of the instances,
	* and underlying guts of the query as well. If the query does not exist, `undefined` is
	* returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a query in rare scenarios (e.g. looking at `query.state.dataUpdatedAt` to
	* decide whether a query is fresh enough to be used as an initial value).
	*
	* @see {@link QueryCache#findAll}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.find({ queryKey: ['posts'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	/**
	* An even more advanced method that can be used to get existing query instances from the cache
	* that partially match a query key. If no queries match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about queries in rare scenarios.
	*
	* @see {@link QueryCache#find}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	/** @internal */
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/** @internal */
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	/** @internal */
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryClient.js
/**
* `QueryClient` is used to interact with a cache of queries and mutations. It owns a
* `QueryCache` and a `MutationCache` (creating default ones if none are passed in) and holds
* the default options that are applied to queries and mutations created through it.
*
* @example
* ```ts
* const queryClient = new QueryClient({
*   defaultOptions: {
*     queries: {
*       staleTime: Infinity,
*     },
*   },
* })
*
* await queryClient.query({ queryKey: ['posts'], queryFn: fetchPosts })
* ```
*/
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	/**
	* Called by a framework adapter's `QueryClientProvider`-equivalent when it mounts, to start
	* listening for focus/online events and resume paused mutations. Ref-counted via an internal
	* mount count, so nested or multiple providers sharing the same `QueryClient` don't tear down
	* the shared listeners until the last one unmounts.
	*/
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	/**
	* The inverse of {@link QueryClient#mount} — called by a framework adapter's
	* `QueryClientProvider`-equivalent when it unmounts. Only tears down the focus/online
	* listeners once the mount count returns to `0`.
	*/
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	/**
	* Returns the number of queries in the cache that are currently fetching, optionally
	* matching a set of filters. This includes background-fetching, loading new pages, and
	* loading more infinite query results.
	*
	* @example
	* ```ts
	* if (queryClient.isFetching()) {
	*   console.log('At least one query is fetching!')
	* }
	* ```
	*/
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	/**
	* Returns the number of mutations in the cache that are currently pending, optionally
	* matching a set of filters.
	*
	* @example
	* ```ts
	* if (queryClient.isMutating()) {
	*   console.log('At least one mutation is pending!')
	* }
	* ```
	*/
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	*
	* @returns The cached data for the query, or `undefined` if no query with this key has been observed yet.
	* @see {@link QueryClient#getQueriesData}
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	/**
	* @deprecated Use queryClient.query({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	/**
	* Imperative (non-reactive) way to retrieve the cached data of multiple queries at once.
	* Only queries matching the given filters are returned; if none match, an empty array is
	* returned.
	*
	* Because the matched queries can hold data of different shapes (e.g. a broad filter can match
	* queries with unrelated data types), the `TQueryFnData` generic defaults to `unknown` rather
	* than being inferred. Passing a more specific type is a convenience for call sites that know
	* every matched query holds the same shape — it is not checked against the actual cache
	* contents.
	*
	* @returns An array of query key and data pairs. The data is `undefined` for a query with no cached data.
	* @see {@link QueryClient#getQueryData}
	* @example
	* ```ts
	* const data = queryClient.getQueriesData({ queryKey: ['posts'] })
	* ```
	*/
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	/**
	* Synchronous way to immediately update a query's cached data. If the updater (or the value
	* passed) resolves to `undefined`, the cache is left untouched and no query is created;
	* otherwise, if the query does not exist yet, it will be created. To update multiple queries
	* at once by partially matching query keys, use {@link QueryClient#setQueriesData} instead.
	*
	* Updates must be performed immutably: do not mutate `oldData`, or data previously retrieved
	* via {@link QueryClient#getQueryData}, in place.
	*
	* @param queryKey - The query key to set data for.
	* @param updater - Either the new data, or a function that receives the current data (which
	* may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns The data that was written, or `undefined` if the updater returned `undefined` — in that case
	* the write is skipped and the cache is left unchanged.
	*
	* @example
	* ```ts
	* queryClient.setQueryData(['posts'], newPosts)
	*
	* // Or, using an updater function that receives the current data:
	* queryClient.setQueryData(['posts'], (oldPosts) => [...oldPosts, newPost])
	* ```
	*/
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
		const data = functionalUpdate(updater, prevData);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	/**
	* Synchronous way to immediately update the cached data of multiple queries at once, using
	* filters or partial query key matching. Only queries that already exist and match the given
	* filters are updated; no new cache entries are created. Internally this calls
	* {@link QueryClient#setQueryData} for each matching query.
	*
	* @returns One `[queryKey, data]` tuple per matched query, in the same shape and with the same
	* `undefined` case as {@link QueryClient#setQueryData}.
	* @example
	* ```ts
	* queryClient.setQueriesData({ queryKey: ['posts'] }, (oldPosts) =>
	*   oldPosts ? oldPosts.filter((post) => post.id !== deletedId) : oldPosts,
	* )
	* ```
	*/
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	/**
	* Imperative (non-reactive) way to retrieve an existing query's state. If the query does not
	* exist, `undefined` is returned.
	*
	* @example
	* ```ts
	* const state = queryClient.getQueryState(['posts'])
	* console.log(state?.dataUpdatedAt)
	* ```
	*/
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	/**
	* Removes queries from the cache that match the given filters. Unlike
	* {@link QueryClient#invalidateQueries} or {@link QueryClient#refetchQueries}, this removes
	* matching queries from the cache instead of refetching them. Without filters, every query in
	* the cache is removed.
	*
	* @example
	* ```ts
	* queryClient.removeQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	/**
	* Resets queries matching the given filters back to their initial state (e.g. any
	* `initialData`), notifying subscribers rather than removing them. Active queries among the
	* matched set are then refetched, and the returned promise resolves once that refetch settles.
	*
	* @example
	* ```ts
	* await queryClient.resetQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			const matched = queryCache.findAll(filters);
			const queriesToRefetch = new Set(matched);
			matched.forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				predicate: (query) => queriesToRefetch.has(query)
			}, options);
		});
	}
	/**
	* Cancels outgoing fetches for queries matching the given filters. Most useful when performing
	* optimistic updates, since any outgoing refetch that resolves afterwards would otherwise
	* overwrite the optimistic update. By default (`revert: true`), a cancelled query's data is
	* reverted to its state before the outgoing fetch started.
	*
	* The returned promise never rejects, even if individual cancellations fail.
	*
	* @example
	* ```ts
	* await queryClient.cancelQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	/**
	* Marks queries matching the given filters as invalidated. Unlike
	* {@link QueryClient#removeQueries}, invalidated queries stay in the cache.
	*
	* Unless `filters.refetchType` is `'none'`, matching queries are then refetched via
	* {@link QueryClient#refetchQueries}, using `filters.refetchType` if set, otherwise
	* `filters.type`, otherwise `'active'`.
	*
	* @example
	* ```ts
	* await queryClient.invalidateQueries({ queryKey: ['posts'], refetchType: 'active' })
	* ```
	*/
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	/**
	* Refetches queries matching the given filters, regardless of whether they are stale. Without
	* filters, every query in the cache is refetched. Queries that are disabled, or static (only
	* have observers with a static `staleTime`), are never refetched.
	*
	* By default (`cancelRefetch: true`), a currently running fetch is cancelled before the new
	* one starts. The returned promise resolves once all matching queries have settled; it does
	* not reject on individual query failures unless `throwOnError` is set.
	*
	* @example
	* ```ts
	* // refetch all active queries partially matching a query key:
	* await queryClient.refetchQueries({ queryKey: ['posts'], type: 'active' })
	* ```
	*/
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			if (!fetchOptions.throwOnError) promise = promise.catch(noop);
			return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	/**
	* Asynchronous method to fetch and cache a query, resolving with the data or throwing with
	* the error.
	*
	* If the query already exists in the cache and its data is not stale (per the given
	* `staleTime`), the cached data is returned without fetching. Otherwise, the query is fetched
	* and the promise resolves once the fetch settles. If a `select` function is provided, it is
	* applied to the data in both cases (cached or freshly fetched) before it is returned.
	*
	* Unlike a reactive observer, retries are disabled by default here (`retry: false`) unless
	* explicitly configured, since there is no component to catch a thrown error and retry through
	* re-render.
	*
	* The accepted options are `QueryObserverOptions` minus the fields that only make sense for a
	* reactive observer — `enabled`, `refetchInterval`, `refetchIntervalInBackground`,
	* `refetchOnWindowFocus`, `refetchOnReconnect`, `refetchOnMount`, `retryOnMount`,
	* `notifyOnChangeProps`, `throwOnError`, `suspense`, and `placeholderData` are not part of this
	* method's options.
	*
	* This method replaces the deprecated `fetchQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureQueryData`.
	*
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.query({ queryKey, queryFn, staleTime: 10000 })
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	async query(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		const queryData = query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? await query.fetch(defaultedOptions) : query.state.data;
		const select = defaultedOptions.select;
		if (select) return select(queryData);
		return queryData;
	}
	/**
	* @deprecated Use queryClient.query(options) instead. This method will be removed in the next major version.
	*/
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	/**
	* @deprecated Use queryClient.query(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	/**
	* Asynchronous method to fetch and cache an infinite query, resolving with an
	* {@link InfiniteData} object or throwing with the error.
	*
	* Behaves like {@link QueryClient#query}, accepting the same options (minus
	* `initialPageParam`), plus the required `initialPageParam`, and an optional `pages` /
	* `getNextPageParam` pair used to refetch a fixed number of pages from the start.
	*
	* This method replaces the deprecated `fetchInfiniteQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureInfiniteQueryData`.
	*
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.infiniteQuery({ queryKey, queryFn, initialPageParam: 0 })
	*   console.log(data.pages)
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	infiniteQuery(options) {
		options._type = "infinite";
		return this.query(options);
	}
	/**
	* @deprecated Use queryClient.infiniteQuery(options) instead. This method will be removed in the next major version.
	*/
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	/**
	* @deprecated Use queryClient.infiniteQuery(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	/**
	* @deprecated Use queryClient.infiniteQuery({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	/**
	* Resumes mutations that were paused because there was no network connection. Does nothing
	* (resolving immediately) if the client is currently offline.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* await queryClient.resumePausedMutations()
	* ```
	*/
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	/**
	* Returns the query cache this client is connected to.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const queryCache = queryClient.getQueryCache()
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	getQueryCache() {
		return this.#queryCache;
	}
	/**
	* Returns the mutation cache this client is connected to.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const mutationCache = queryClient.getMutationCache()
	* const mutations = mutationCache.findAll({ status: 'pending' })
	* ```
	*/
	getMutationCache() {
		return this.#mutationCache;
	}
	/**
	* Returns the default options that were set when creating the client, or via
	* {@link QueryClient#setDefaultOptions}.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const defaultOptions = queryClient.getDefaultOptions()
	* ```
	*/
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	/**
	* Dynamically sets the default options for this client, overwriting any previously defined
	* default options.
	*
	* @see {@link QueryClient#getDefaultOptions}
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.setDefaultOptions({
	*   queries: {
	*     staleTime: Infinity,
	*   },
	* })
	* ```
	*/
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	/**
	* Sets default options for queries whose query key partially matches the given `queryKey`.
	*
	* If several registered query defaults match a given query key, they are merged together in
	* registration order by {@link QueryClient#getQueryDefaults}, so register defaults from the
	* most generic key to the least generic one — more specific defaults should be registered
	* after more generic ones so they take precedence.
	*
	* @example
	* ```ts
	* queryClient.setQueryDefaults(['posts'], { queryFn: fetchPosts })
	*
	* await queryClient.query({ queryKey: ['posts'] })
	* ```
	*/
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for queries whose query key partially matches the
	* given `queryKey`, via {@link QueryClient#setQueryDefaults}. If multiple registered defaults
	* match, they are merged together in registration order.
	*
	* @example
	* ```ts
	* const defaultOptions = queryClient.getQueryDefaults(['posts'])
	* ```
	*/
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Sets default options for mutations whose mutation key partially matches the given
	* `mutationKey`. As with {@link QueryClient#setQueryDefaults}, the order of registration
	* matters when several registered defaults match the same mutation key.
	*
	* @see {@link QueryClient#getMutationDefaults}
	* @example
	* ```ts
	* queryClient.setMutationDefaults(['addPost'], { mutationFn: addPost })
	* ```
	*/
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for mutations whose mutation key partially matches
	* the given `mutationKey`, via {@link QueryClient#setMutationDefaults}. If multiple registered
	* defaults match, they are merged together in registration order.
	*
	* @example
	* ```ts
	* const defaultOptions = queryClient.getMutationDefaults(['addPost'])
	* ```
	*/
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Called by framework adapters (e.g. inside `useQuery`) to resolve the options passed by the
	* caller into their final, defaulted form: merging `queryClient.setQueryDefaults` for the
	* given `queryKey`, then the client's own `defaultOptions.queries`, then the caller's options
	* on top. A no-op if the options are already defaulted (`_defaulted: true`).
	*/
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	/**
	* The mutation counterpart of {@link QueryClient#defaultQueryOptions}. Called by framework
	* adapters (e.g. inside `useMutation`) to merge `queryClient.setMutationDefaults` for the
	* given `mutationKey`, then the client's `defaultOptions.mutations`, then the caller's options
	* on top. A no-op if the options are already defaulted (`_defaulted: true`).
	*/
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	/**
	* Clears both the query cache and the mutation cache this client is connected to.
	*
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.clear()
	* ```
	*/
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/streamedQuery.js
/**
* This is a helper function to create a query function that streams data from an AsyncIterable.
* Data will be an Array of all the chunks received.
* The query will be in a 'pending' state until the first chunk of data is received, but will go to 'success' after that.
* The query will stay in fetchStatus 'fetching' until the stream ends.
* @param streamFn - The function that returns an AsyncIterable to stream data from.
* @example
* ```ts
* await queryClient.query({
*   queryKey: ['data'],
*   queryFn: streamedQuery({
*     streamFn: fetchDataInChunks,
*   }),
* })
* ```
*/
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => addToEnd(items, chunk), initialValue = [] }) {
	return async (context) => {
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const stream = await streamFn(addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true));
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (cancelled) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !cancelled) context.client.setQueryData(context.queryKey, result);
		const data = context.client.getQueryData(context.queryKey);
		return data === void 0 ? initialValue : data;
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/types.js
/* istanbul ignore file */
var dataTagSymbol = Symbol();
var dataTagErrorSymbol = Symbol();
var unsetMarker = Symbol();
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
/**
* `HydrationBoundary` adds a previously dehydrated state into the `queryClient` that would be returned by
* `useQueryClient()`. If the client already contains data, the new queries will be intelligently merged based on
* update timestamp.
*
* Note: Only `queries` can be dehydrated with an `HydrationBoundary`.
*
* @returns The provided `children`, rendered unconditionally. New queries in `state` are hydrated into the
* cache during render; for queries already in the cache, only newer dehydrated data is hydrated, in an effect
* after commit.
*
* @example
* ```tsx
* import { HydrationBoundary } from '@tanstack/react-query'
*
* function App() {
*   return <HydrationBoundary state={dehydratedState}>...</HydrationBoundary>
* }
* ```
*
* @example
* Server-side prefetch handed off to the client via `dehydrate`:
* ```tsx
* import { HydrationBoundary, dehydrate, noop } from '@tanstack/react-query'
*
* async function ServerComponent() {
*   const queryClient = getQueryClient()
*
*   await queryClient
*     .query({
*       queryKey: ['posts'],
*       queryFn: fetchPosts,
*     })
*     .catch(noop)
*
*   return (
*     <HydrationBoundary state={dehydrate(queryClient)}>
*       <Posts />
*     </HydrationBoundary>
*   )
* }
* ```
*/
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
/**
* If you are using `PersistQueryClientProvider`, you can also use the `useIsRestoring` hook alongside it to
* check if a restore is currently in progress. `useQuery` and friends also check this internally to avoid
* race conditions between the restore and mounting queries.
*
* @returns `true` while a persisted client is being restored, `false` otherwise.
*/
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
/**
* The Provider that `PersistQueryClientProvider` uses to signal whether a persisted client is currently
* being restored, read by `useIsRestoring`.
*/
var IsRestoringProvider = IsRestoringContext.Provider;
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
/**
* Resets any query errors within the boundary, so queries know they can try again.
*/
function createValue() {
	let isReset = false;
	return {
		/**
		* Clears the reset state, so queries know not to try again until the boundary is reset again.
		*/
		clearReset: () => {
			isReset = false;
		},
		/**
		* Resets any query errors within the boundary, so queries know they can try again.
		*/
		reset: () => {
			isReset = true;
		},
		/**
		* Returns whether the boundary has been reset and not yet cleared.
		*/
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
/**
* This hook will reset any query errors within the closest `QueryErrorResetBoundary`. If there is no boundary
* defined it will reset them globally.
*
* @returns The boundary's {@link QueryErrorResetBoundaryValue}.
*
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { useQueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App({ children }: { children: React.ReactNode }) {
*   const { reset } = useQueryErrorResetBoundary()
*
*   return (
*     <ErrorBoundary
*       onReset={reset}
*       fallbackRender={({ resetErrorBoundary }) => (
*         <div>
*           There was an error!
*           <button onClick={() => resetErrorBoundary()}>Try again</button>
*         </div>
*       )}
*     >
*       {children}
*     </ErrorBoundary>
*   )
* }
* ```
*/
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
/**
* When using `suspense` or `throwOnError` in your queries, you need a way to let queries know that you want to
* try again when re-rendering after some error occurred. With the `QueryErrorResetBoundary` component you can
* reset any query errors within the boundaries of the component.
*
* @returns The `children`, rendered as-is, or called with the boundary's {@link QueryErrorResetBoundaryValue}
* if `children` is a function.
*
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Page />
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.error && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/suspense.js
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQueries.js
/**
* The `useQueries` hook can be used to fetch a variable number of queries.
*
* The `queries` key accepts an array with query option objects mostly identical to `useQuery` — the top-level
* `subscribed` option isn't accepted per query (see `placeholderData` below for another difference). A custom
* `QueryClient` is supplied once, as `useQueries`' own top-level second argument, rather than per query.
*
* Having the same query key more than once in the array of query objects may cause some data to be shared
* between queries. To avoid this, consider de-duplicating the queries and map the results back to the desired
* structure.
*
* The `combine` option can be used to combine the results of the queries into a single value. The result will
* be structurally shared to be as referentially stable as possible.
*
* @remarks The `combine` function only re-runs if it changed referentially, or if any of the query results
* changed. An inlined `combine` function, as shown in the example below, therefore runs on every render — wrap
* it in `useCallback`, or extract it to a stable function reference if it doesn't have any dependencies, to
* avoid that.
*
* Unlike `useQuery`, `useQueries` cannot infer the `data` argument of an _inline_ `select` from its sibling
* `queryFn`. Because `useQueries` infers the type of the whole `queries` array at once, the `select` parameter
* of a query object written inline cannot be contextually typed from that same object's `queryFn`, so it falls
* back to `unknown` — a [known TypeScript limitation](https://github.com/TanStack/query/issues/6556). Annotate
* the `select` parameter explicitly, or define the query with {@link queryOptions}, which resolves its types in
* a single object _before_ it reaches `useQueries`, to work around this — see the example below. The same
* limitation applies to {@link useSuspenseQueries}.
*
* `placeholderData` is supported here too, but unlike `useQuery`, it doesn't receive information from
* previously rendered queries, because the number of queries can differ between renders.
* @param queryClient - Use this to provide a custom `QueryClient`. Otherwise, the one from the nearest context
* will be used.
* @returns The combined result. Without `combine`, this is an array with all the query results, in the same
* order as the input. When `combine` is provided, this is the value returned by `combine` instead.
*
* @example
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const postQueries = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*       staleTime: Infinity,
*     })),
*   })
*
*   return (
*     <ul>
*       {postQueries.map((query, index) => {
*         if (query.isPending) return <li key={ids[index]}>Loading...</li>
*         if (query.isError) return <li key={ids[index]}>Error: {query.error.message}</li>
*         return <li key={ids[index]}>{query.data.title}</li>
*       })}
*     </ul>
*   )
* }
* ```
*
* @example
* Combining results into a single value:
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const { data, isPending, isError } = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*     })),
*     combine: (postQueries) => {
*       return {
*         data: postQueries.map((query) => query.data),
*         isPending: postQueries.some((query) => query.isPending),
*         isError: postQueries.some((query) => query.isError),
*       }
*     },
*   })
*
*   if (isPending) return 'Loading...'
*   if (isError) return 'Error loading posts'
*
*   return (
*     <ul>
*       {data.map((post) => (
*         <li key={post?.id}>{post?.title}</li>
*       ))}
*     </ul>
*   )
* }
* ```
*
* @example
* Typing `select` via {@link queryOptions}. Note that spreading a `queryOptions` result and overriding
* `select` inline still falls back to `unknown` — wrap the spread in `queryOptions` again so the override is
* resolved before it reaches `useQueries`:
* ```tsx
* import { queryOptions, useQueries } from '@tanstack/react-query'
*
* const postOptions = (id: number) =>
*   queryOptions({
*     queryKey: ['post', id],
*     queryFn: () => fetchPost(id),
*   })
*
* function PostTitle({ id }: { id: number }) {
*   const [{ data: broken }] = useQueries({
*     queries: [
*       {
*         ...postOptions(id),
*         // ❌ `data` is `unknown` here
*         select: (data) => data.title,
*       },
*     ],
*   })
*
*   const [{ data: fixed }] = useQueries({
*     queries: [
*       queryOptions({
*         ...postOptions(id),
*         // ✅ `data` is `Post`
*         select: (data) => data.title,
*       }),
*     ],
*   })
*
*   return <h1>{fixed}</h1>
* }
* ```
*/
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const subscribed = options.subscribed !== false;
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring,
		subscribed
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
/**
* The options for `useSuspenseQuery` are the same as for `useQuery`, except for `throwOnError`, `enabled`, and
* `placeholderData` — and `queryFn` may not be `skipToken`, since Suspense hooks can't render a "disabled" state.
*
* Caveat: cancellation does not work.
*
* @remarks Multiple `useSuspenseQuery` calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until then.
* Use {@link useSuspenseQueries} instead when you have more than one suspenseful query in a component, so they
* fetch in parallel.
* @param options - The {@link UseSuspenseQueryOptions} to use — the same options as `useQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useQuery`, except that `data` is guaranteed to be defined, `isPlaceholderData`
* is missing, and `status` is either `success` or `error` (with the derived flags set accordingly).
*
* @example
* The query error is thrown if the fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary, useSuspenseQuery } from '@tanstack/react-query'
*
* function Posts() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, isFetching } = useSuspenseQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <div>
*       <h1>Posts {isFetching ? '(refreshing...)' : null}</h1>
*       <ul>
*         {data.map((post) => (
*           <li key={post.id}>{post.title}</li>
*         ))}
*       </ul>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading posts...</h1>}>
*             <Posts />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
/**
* The options for `useSuspenseInfiniteQuery` are the same as for `useInfiniteQuery`, except for `throwOnError`,
* `enabled`, and `placeholderData`.
*
* Caveat: cancellation does not work.
*
* @remarks Multiple suspenseful query calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until
* then. There's no way to parallelize multiple infinite queries under Suspense. Also keep in mind that
* imperative fetch calls, such as `fetchNextPage`, may interfere with the default refetch behavior,
* resulting in outdated data. Make sure to call these functions only in response to user actions, or add
* conditions like `hasNextPage && !isFetching`.
* @see {@link useInfiniteQuery} for the non-Suspense version of this hook.
* @param options - The {@link UseSuspenseInfiniteQueryOptions} to use — the same options as `useInfiniteQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useInfiniteQuery`, except that `data` is guaranteed to be defined,
* `isPlaceholderData` is missing, and `status` is either `success` or `error` (with the derived flags set
* accordingly).
*
* @example
* The query error is thrown if a fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import {
*   QueryErrorResetBoundary,
*   useSuspenseInfiniteQuery,
* } from '@tanstack/react-query'
*
* function Projects() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, fetchNextPage, hasNextPage, isFetching, isFetchingNextPage } =
*     useSuspenseInfiniteQuery({
*       queryKey: ['projects'],
*       queryFn: ({ pageParam }) => fetchProjects(pageParam),
*       initialPageParam: 0,
*       getNextPageParam: (lastPage) => lastPage.nextId,
*     })
*
*   return (
*     <div>
*       <ul>
*         {data.pages.map((page) =>
*           page.projects.map((project) => <li key={project.id}>{project.name}</li>),
*         )}
*       </ul>
*       <button
*         onClick={() => fetchNextPage()}
*         disabled={!hasNextPage || isFetching}
*       >
*         {isFetchingNextPage
*           ? 'Loading more...'
*           : hasNextPage
*             ? 'Load More'
*             : 'Nothing more to load'}
*       </button>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading projects...</h1>}>
*             <Projects />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
/**
* `usePrefetchQuery` does not return anything, it should be used just to fire a prefetch during render, before
* a suspense boundary that wraps a component that uses `useSuspenseQuery`. You can pass everything to
* `usePrefetchQuery` that you can pass to `queryClient.query`, though `queryKey` is always required, and
* `queryFn` is required unless a default query function has been defined.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
*
* @param options - The {@link UsePrefetchQueryOptions} to use — everything you can pass to `queryClient.query`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `void` — nothing is returned.
*
* @example
* ```tsx
* import { Suspense } from 'react'
* import { usePrefetchQuery } from '@tanstack/react-query'
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <Suspense fallback={<h1>Loading posts...</h1>}>
*       <Posts />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.query(options).catch(noop);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
/**
* `usePrefetchInfiniteQuery` does not return anything, it should be used just to fire a prefetch during render,
* before a suspense boundary that wraps a component that uses `useSuspenseInfiniteQuery`. You can pass
* everything to `usePrefetchInfiniteQuery` that you can pass to `queryClient.infiniteQuery`, though
* `queryKey`, `initialPageParam`, and `getNextPageParam` are always required, and `queryFn` is required unless
* a default query function has been defined.
*
* `getNextPageParam` receives both the last page of the infinite list of data and the full array of all pages,
* as well as pageParam information, and should return a single variable that will be passed to your query
* function as `context.pageParam`. Return `undefined` or `null` to indicate there is no next page available.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
*
* @param options - The {@link UsePrefetchInfiniteQueryOptions} to use — everything you can pass to `queryClient.infiniteQuery`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `void` — nothing is returned.
*
* @example
* ```tsx
* import { Suspense } from 'react'
* import { infiniteQueryOptions, usePrefetchInfiniteQuery } from '@tanstack/react-query'
*
* const projectsOptions = infiniteQueryOptions({
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextId,
* })
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchInfiniteQuery(projectsOptions)
*
*   return (
*     <Suspense fallback={<h1>Loading projects...</h1>}>
*       <Projects />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.infiniteQuery(options).catch(noop);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useIsFetching.js
/**
* The `useIsFetching` hook returns the `number` of the queries that your application is loading or fetching in
* the background (useful for app-wide loading indicators).
*
* @param filters - The {@link QueryFilters} to narrow down the matched queries.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the queries that your application is currently loading or fetching in the
* background.
*
* @example
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function PostsFetchingIndicator() {
*   // How many queries matching the posts prefix are fetching?
*   const isFetchingPosts = useIsFetching({ queryKey: ['posts'] })
*
*   return isFetchingPosts ? <span>Refreshing posts...</span> : null
* }
* ```
*
* @example
* A global loading indicator for any query fetching in the background, not just the ones on screen:
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function GlobalLoadingIndicator() {
*   const isFetching = useIsFetching()
*
*   return isFetching ? (
*     <div>Queries are fetching in the background...</div>
*   ) : null
* }
* ```
*/
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutationState.js
/**
* The `useIsMutating` hook returns the `number` of mutations that your application currently has `pending`
* (useful for app-wide loading indicators).
*
* @param filters - The {@link MutationFilters} to narrow down the matched mutations.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the mutations that your application currently has `pending`.
*
* @example
* ```tsx
* import { useIsMutating } from '@tanstack/react-query'
*
* function PostsMutatingIndicator() {
*   // How many mutations matching the posts prefix are in progress?
*   const isMutatingPosts = useIsMutating({ mutationKey: ['posts'] })
*
*   return isMutatingPosts ? <span>Saving posts...</span> : null
* }
* ```
*/
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
function getResult(mutationCache, options) {
	return mutationCache.findAll(options.filters).map((mutation) => options.select ? options.select(mutation) : mutation.state);
}
/**
* `useMutationState` is a hook that gives you access to all mutations in the `MutationCache`. You can pass
* `filters` ({@link MutationFilters}) to narrow down your mutations, and `select` to transform the mutation
* state.
*
* @param options - The `filters` to narrow down matched mutations, and an optional `select` to transform the
* mutation state.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be an Array of whatever `select` returns for each matching mutation.
*
* @example
* Get all variables of all running mutations:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function PendingPosts() {
*   const pendingVariables = useMutationState({
*     filters: { status: 'pending' },
*     select: (mutation) => mutation.state.variables,
*   })
*
*   return <>{pendingVariables.length} posts saving...</>
* }
* ```
*
* @example
* Get all data for specific mutations via the `mutationKey`:
* ```tsx
* import { useMutation, useMutationState } from '@tanstack/react-query'
*
* const mutationKey = ['posts']
*
* function Posts() {
*   // Some mutation that we want to get the state for
*   const mutation = useMutation({
*     mutationKey,
*     mutationFn: createPosts,
*   })
*
*   const savedPosts = useMutationState({
*     // this mutation key needs to match the mutation key of the given mutation (see above)
*     filters: { mutationKey, status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   return (
*     <button onClick={() => mutation.mutate(['New Post'])}>
*       Create post ({savedPosts.length} saved so far)
*     </button>
*   )
* }
* ```
*
* @example
* Access the latest successful mutation data via the `mutationKey`. Each invocation of `mutate` adds a new
* entry to the mutation cache for `gcTime` milliseconds — with the `status: 'success'` filter below, check the
* last item that `useMutationState` returns to get the latest successful invocation:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function LatestPost() {
*   const savedPosts = useMutationState({
*     filters: { mutationKey: ['posts'], status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   const latestSavedPost = savedPosts[savedPosts.length - 1]
*
*   return <>{latestSavedPost ? 'Saved' : 'Nothing saved yet'}</>
* }
* ```
*/
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const optionsRef = import_react.useRef(options);
	const resultRef = import_react.useRef(null);
	if (resultRef.current === null) resultRef.current = getResult(mutationCache, options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(() => {
		const nextResult = replaceEqualDeep(resultRef.current, getResult(mutationCache, optionsRef.current));
		if (resultRef.current !== nextResult) {
			resultRef.current = nextResult;
			notifyManager.schedule(onStoreChange);
		}
	}), [mutationCache]), () => resultRef.current, () => resultRef.current);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
/**
* Unlike queries, mutations are typically used to create/update/delete data or perform server side-effects.
* `useMutation` is the hook for that.
*
* @see {@link mutationOptions} to share these options across multiple `useMutation` call sites, or to look
* the mutation up elsewhere via its `mutationKey` (e.g. with `useMutationState`).
* @param options - The {@link UseMutationOptions} to use — everything you can pass to `useMutation`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `mutate`/`mutateAsync` also accept per-call `onSuccess`/`onError`/`onSettled` callbacks as a second
* argument, useful for triggering call-site side effects (e.g. navigation) without coupling them to the shared
* mutation definition. Hook-level callbacks (passed to `options`) fire for every mutation; per-call callbacks
* fire only for the latest call you've made, and only while the component is still mounted — unmounting before
* the mutation settles removes the subscription and prevents them from firing.
*
* @example
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <button
*       onClick={() =>
*         addMutation.mutate('Item', {
*           onError: (error) => console.error('Failed to add item:', error),
*         })
*       }
*     >
*       Add
*     </button>
*   )
* }
* ```
*
* @example
* Rendering the mutation's own state, rather than just firing it off:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <div>
*       {addMutation.isPending ? (
*         'Adding todo...'
*       ) : (
*         <>
*           {addMutation.isError ? (
*             <div>An error occurred: {addMutation.error.message}</div>
*           ) : null}
*           <button onClick={() => addMutation.mutate('Item')}>Add</button>
*         </>
*       )}
*     </div>
*   )
* }
* ```
*
* @example
* Optimistic update via `onMutate`, rolling back on `onError`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onMutate: async (newTodo) => {
*       await queryClient.cancelQueries({ queryKey: ['todos'] })
*       const previousTodos = queryClient.getQueryData<Array<string>>(['todos'])
*
*       queryClient.setQueryData<Array<string>>(['todos'], (old) => [
*         ...(old ?? []),
*         newTodo,
*       ])
*
*       // Passed to `onError` as `onMutateResult` if the mutation fails.
*       return { previousTodos }
*     },
*     onError: (_err, _newTodo, onMutateResult) => {
*       queryClient.setQueryData(['todos'], onMutateResult?.previousTodos)
*     },
*     onSettled: () => {
*       queryClient.invalidateQueries({ queryKey: ['todos'] })
*     },
*   })
*
*   return (
*     <button onClick={() => addMutation.mutate('Item')}>Add</button>
*   )
* }
* ```
*
* @example
* Callbacks passed per call to `mutate` only fire for the last call — `mutateAsync` gives you a
* promise per call instead, so you can wait for all of them when they succeed:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     try {
*       await Promise.all(todos.map((todo) => addMutation.mutateAsync(todo)))
*     } catch (error) {
*       console.error('Failed to add todos:', error)
*     }
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*
* @example
* If some of the mutations above can fail independently of the others, and you want to know which ones
* did — rather than losing that information the moment the first one rejects — swap `Promise.all` for
* `Promise.allSettled`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     const addResults = await Promise.allSettled(
*       todos.map((todo) => addMutation.mutateAsync(todo)),
*     )
*
*     addResults.forEach((addResult, index) => {
*       if (addResult.status === 'rejected') {
*         console.error(`Failed to add "${todos[index]}":`, addResult.reason)
*       }
*     })
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*/
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((...args) => {
		observer.mutate(args[0], args[1]).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/index.js
/* istanbul ignore file */
//#endregion
export { CancelledError, HydrationBoundary, InfiniteQueryObserver, IsRestoringProvider, Mutation, MutationCache, MutationObserver, QueriesObserver, Query, QueryCache, QueryClient, QueryClientContext, QueryClientProvider, QueryErrorResetBoundary, QueryObserver, dataTagErrorSymbol, dataTagSymbol, defaultScheduler, defaultShouldDehydrateMutation, defaultShouldDehydrateQuery, dehydrate, dehydrateQuery, environmentManager, streamedQuery as experimental_streamedQuery, focusManager, hashKey, hydrate, infiniteQueryOptions, isCancelledError, isServer, keepPreviousData, matchMutation, matchQuery, mutationOptions, noop, notifyManager, onlineManager, partialMatchKey, queryOptions, replaceEqualDeep, shouldThrowError, skipToken, timeoutManager, unsetMarker, useInfiniteQuery, useIsFetching, useIsMutating, useIsRestoring, useMutation, useMutationState, usePrefetchInfiniteQuery, usePrefetchQuery, useQueries, useQuery, useQueryClient, useQueryErrorResetBoundary, useSuspenseInfiniteQuery, useSuspenseQueries, useSuspenseQuery };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXF1ZXJ5LmpzIiwibmFtZXMiOlsiaXNTZXJ2ZXIkMSIsImlzU2VydmVyIiwiaXNTZXJ2ZXIiLCJpc1NlcnZlciIsImdldERlZmF1bHRTdGF0ZSIsImlzU2VydmVyIl0sInNvdXJjZXMiOlsiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3RpbWVvdXRNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3V0aWxzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2Vudmlyb25tZW50TWFuYWdlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdWJzY3JpYmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vZm9jdXNNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2h5ZHJhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9ub3RpZnlNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL29ubGluZU1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcmV0cnllci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZW1vdmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5T2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uQ2FjaGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyaWVzT2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlDYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdHJlYW1lZFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3R5cGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9IeWRyYXRpb25Cb3VuZGFyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSXNSZXN0b3JpbmdQcm92aWRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2Vycm9yQm91bmRhcnlVdGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vc3VzcGVuc2UuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVF1ZXJpZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUJhc2VRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VRdWVyaWVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3F1ZXJ5T3B0aW9ucy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUlzRmV0Y2hpbmcuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uU3RhdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9tdXRhdGlvbk9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvUXVlcnlDbGllbnRQcm92aWRlci50c3hcbi8qKlxuKiBUaGUgY29udGV4dCB0aGF0IGB1c2VRdWVyeUNsaWVudGAgcmVhZHMgZnJvbS4gYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGlzIHRoZSBub3JtYWwgd2F5IHRvIHNldCBpdC5cbiovXG5jb25zdCBRdWVyeUNsaWVudENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KHZvaWQgMCk7XG4vKipcbiogVGhlIGB1c2VRdWVyeUNsaWVudGAgaG9vayByZXR1cm5zIHRoZSBjdXJyZW50IGBRdWVyeUNsaWVudGAgaW5zdGFuY2UuXG4qXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIGN1cnJlbnQgYFF1ZXJ5Q2xpZW50YCBpbnN0YW5jZS5cbiogQHRocm93cyBJZiBubyBgcXVlcnlDbGllbnRgIGFyZ3VtZW50IGlzIHBhc3NlZCBhbmQgbm8gYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgIGlzIGZvdW5kIGluIHRoZSBjb21wb25lbnQgdHJlZS5cbiovXG5jb25zdCB1c2VRdWVyeUNsaWVudCA9IChxdWVyeUNsaWVudCkgPT4ge1xuXHRjb25zdCBjbGllbnQgPSBSZWFjdC51c2VDb250ZXh0KFF1ZXJ5Q2xpZW50Q29udGV4dCk7XG5cdGlmIChxdWVyeUNsaWVudCkgcmV0dXJuIHF1ZXJ5Q2xpZW50O1xuXHRpZiAoIWNsaWVudCkgdGhyb3cgbmV3IEVycm9yKFwiTm8gUXVlcnlDbGllbnQgc2V0LCB1c2UgUXVlcnlDbGllbnRQcm92aWRlciB0byBzZXQgb25lXCIpO1xuXHRyZXR1cm4gY2xpZW50O1xufTtcbi8qKlxuKiBVc2UgdGhlIGBRdWVyeUNsaWVudFByb3ZpZGVyYCBjb21wb25lbnQgdG8gY29ubmVjdCBhbmQgcHJvdmlkZSBhIGBRdWVyeUNsaWVudGAgdG8geW91ciBhcHBsaWNhdGlvbi4gQWxzb1xuKiBjYWxscyBgY2xpZW50Lm1vdW50KClgL2BjbGllbnQudW5tb3VudCgpYCBhcyB0aGlzIGNvbXBvbmVudCBtb3VudHMvdW5tb3VudHMsIHdoaWNoIHN1YnNjcmliZXMgdGhlIGNsaWVudCB0b1xuKiBmb2N1cy9vbmxpbmUgZXZlbnRzIChyZXN1bWluZyBhbnkgcGF1c2VkIG11dGF0aW9ucyBhbmQgcmVmZXRjaGluZyBhcyBuZWVkZWQgd2hlbiB0aGUgYXBwIHJlZ2FpbnMgZm9jdXMgb3JcbiogY29tZXMgYmFjayBvbmxpbmUpLlxuKlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgd3JhcHBlZCBzbyB0aGV5IGNhbiByZWFkIHRoZSBgUXVlcnlDbGllbnRgIHZpYSBgdXNlUXVlcnlDbGllbnRgLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT4uLi48L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4qIH1cbiogYGBgXG4qL1xuY29uc3QgUXVlcnlDbGllbnRQcm92aWRlciA9ICh7IGNsaWVudCwgY2hpbGRyZW4gfSkgPT4ge1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGNsaWVudC5tb3VudCgpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjbGllbnQudW5tb3VudCgpO1xuXHRcdH07XG5cdH0sIFtjbGllbnRdKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlDbGllbnRDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IGNsaWVudCxcblx0XHRjaGlsZHJlblxuXHR9KTtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFF1ZXJ5Q2xpZW50Q29udGV4dCwgUXVlcnlDbGllbnRQcm92aWRlciwgdXNlUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UXVlcnlDbGllbnRQcm92aWRlci5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3RpbWVvdXRNYW5hZ2VyLnRzXG5jb25zdCBkZWZhdWx0VGltZW91dFByb3ZpZGVyID0ge1xuXHRzZXRUaW1lb3V0OiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSksXG5cdGNsZWFyVGltZW91dDogKHRpbWVvdXRJZCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCksXG5cdHNldEludGVydmFsOiAoY2FsbGJhY2ssIGRlbGF5KSA9PiBzZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpLFxuXHRjbGVhckludGVydmFsOiAoaW50ZXJ2YWxJZCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxufTtcbi8qKlxuKiBBbGxvd3MgY3VzdG9taXphdGlvbiBvZiBob3cgdGltZW91dHMgYXJlIGNyZWF0ZWQuXG4qXG4qIEB0YW5zdGFjay9xdWVyeS1jb3JlIG1ha2VzIGxpYmVyYWwgdXNlIG9mIHRpbWVvdXRzIHRvIGltcGxlbWVudCBgc3RhbGVUaW1lYFxuKiBhbmQgYGdjVGltZWAuIFRoZSBkZWZhdWx0IFRpbWVvdXRNYW5hZ2VyIHByb3ZpZGVyIHVzZXMgdGhlIHBsYXRmb3JtJ3MgZ2xvYmFsXG4qIGBzZXRUaW1lb3V0YCBpbXBsZW1lbnRhdGlvbiwgd2hpY2ggaXMga25vd24gdG8gaGF2ZSBzY2FsYWJpbGl0eSBpc3N1ZXMgd2l0aFxuKiB0aG91c2FuZHMgb2YgdGltZW91dHMgb24gdGhlIGV2ZW50IGxvb3AuXG4qXG4qIElmIHlvdSBoaXQgdGhpcyBsaW1pdGF0aW9uLCBjb25zaWRlciBwcm92aWRpbmcgYSBjdXN0b20gVGltZW91dFByb3ZpZGVyIHRoYXRcbiogY29hbGVzY2VzIHRpbWVvdXRzLlxuKi9cbnZhciBUaW1lb3V0TWFuYWdlciA9IGNsYXNzIHtcblx0I3Byb3ZpZGVyID0gZGVmYXVsdFRpbWVvdXRQcm92aWRlcjtcblx0I3Byb3ZpZGVyQ2FsbGVkID0gZmFsc2U7XG5cdC8qKlxuXHQqIGBzZXRUaW1lb3V0UHJvdmlkZXJgIGNhbiBiZSB1c2VkIHRvIHNldCBhIGN1c3RvbSBpbXBsZW1lbnRhdGlvbiBvZiB0aGVcblx0KiBgc2V0VGltZW91dGAsIGBjbGVhclRpbWVvdXRgLCBgc2V0SW50ZXJ2YWxgLCBgY2xlYXJJbnRlcnZhbGAgZnVuY3Rpb25zLFxuXHQqIGNhbGxlZCBhIGBUaW1lb3V0UHJvdmlkZXJgLlxuXHQqXG5cdCogVGhpcyBtYXkgYmUgdXNlZnVsIGlmIHlvdSBub3RpY2UgZXZlbnQgbG9vcCBwZXJmb3JtYW5jZSBpc3N1ZXMgd2l0aFxuXHQqIHRob3VzYW5kcyBvZiBxdWVyaWVzLiBBIGN1c3RvbSBUaW1lb3V0UHJvdmlkZXIgY291bGQgYWxzbyBzdXBwb3J0IHRpbWVyXG5cdCogZGVsYXlzIGxvbmdlciB0aGFuIHRoZSBnbG9iYWwgYHNldFRpbWVvdXRgIG1heGltdW0gZGVsYXkgdmFsdWUgb2YgYWJvdXRcblx0KiAyNCBkYXlzLlxuXHQqXG5cdCogSXQgaXMgaW1wb3J0YW50IHRvIGNhbGwgYHNldFRpbWVvdXRQcm92aWRlcmAgYmVmb3JlIGNyZWF0aW5nIGFcblx0KiBRdWVyeUNsaWVudCBvciBxdWVyaWVzLCBzbyB0aGF0IHRoZSBzYW1lIHByb3ZpZGVyIGlzIHVzZWQgY29uc2lzdGVudGx5XG5cdCogZm9yIGFsbCB0aW1lcnMgaW4gdGhlIGFwcGxpY2F0aW9uLCBzaW5jZSBkaWZmZXJlbnQgVGltZW91dFByb3ZpZGVyc1xuXHQqIGNhbm5vdCBjYW5jZWwgZWFjaCBvdGhlcnMnIHRpbWVycy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciwgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KiBpbXBvcnQgeyBDdXN0b21UaW1lb3V0UHJvdmlkZXIgfSBmcm9tICcuL0N1c3RvbVRpbWVvdXRQcm92aWRlcidcblx0KlxuXHQqIHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXRQcm92aWRlcihuZXcgQ3VzdG9tVGltZW91dFByb3ZpZGVyKCkpXG5cdCpcblx0KiBleHBvcnQgY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRUaW1lb3V0UHJvdmlkZXIocHJvdmlkZXIpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAodGhpcy4jcHJvdmlkZXJDYWxsZWQgJiYgcHJvdmlkZXIgIT09IHRoaXMuI3Byb3ZpZGVyKSBjb25zb2xlLmVycm9yKGBbdGltZW91dE1hbmFnZXJdOiBTd2l0Y2hpbmcgcHJvdmlkZXIgYWZ0ZXIgY2FsbHMgdG8gcHJldmlvdXMgcHJvdmlkZXIgbWlnaHQgcmVzdWx0IGluIHVuZXhwZWN0ZWQgYmVoYXZpb3IuYCwge1xuXHRcdFx0XHRwcmV2aW91czogdGhpcy4jcHJvdmlkZXIsXG5cdFx0XHRcdHByb3ZpZGVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0dGhpcy4jcHJvdmlkZXIgPSBwcm92aWRlcjtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aGlzLiNwcm92aWRlckNhbGxlZCA9IGZhbHNlO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRUaW1lb3V0YCBzY2hlZHVsZXMgYSBjYWxsYmFjayB0byBydW4gYWZ0ZXIgYXBwcm94aW1hdGVseSBgZGVsYXlgXG5cdCogbWlsbGlzZWNvbmRzLCBsaWtlIHRoZSBnbG9iYWwgYHNldFRpbWVvdXRgIGZ1bmN0aW9uLiBUaGUgY2FsbGJhY2sgY2FuIGJlXG5cdCogY2FuY2VsZWQgd2l0aCBgY2xlYXJUaW1lb3V0YC5cblx0KlxuXHQqIEl0IHJldHVybnMgYSB0aW1lciBJRCwgd2hpY2ggbWF5IGJlIGEgbnVtYmVyIG9yIGFuIG9iamVjdCB0aGF0IGNhbiBiZVxuXHQqIGNvZXJjZWQgdG8gYSBudW1iZXIgdmlhIGBTeW1ib2wudG9QcmltaXRpdmVgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogY29uc3QgdGltZW91dElkTnVtYmVyOiBudW1iZXIgPSBOdW1iZXIodGltZW91dElkKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRUaW1lb3V0KGNhbGxiYWNrLCBkZWxheSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gdHJ1ZTtcblx0XHRyZXR1cm4gdGhpcy4jcHJvdmlkZXIuc2V0VGltZW91dChjYWxsYmFjaywgZGVsYXkpO1xuXHR9XG5cdC8qKlxuXHQqIGBjbGVhclRpbWVvdXRgIGNhbmNlbHMgYSB0aW1lb3V0IGNhbGxiYWNrIHNjaGVkdWxlZCB3aXRoIGBzZXRUaW1lb3V0YCxcblx0KiBsaWtlIHRoZSBnbG9iYWwgYGNsZWFyVGltZW91dGAgZnVuY3Rpb24uIEl0IHNob3VsZCBiZSBjYWxsZWQgd2l0aCBhXG5cdCogdGltZXIgSUQgcmV0dXJuZWQgYnkgYHNldFRpbWVvdXRgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXJUaW1lb3V0KHRpbWVvdXRJZCkge1xuXHRcdHRoaXMuI3Byb3ZpZGVyLmNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRJbnRlcnZhbGAgc2NoZWR1bGVzIGEgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIGFwcHJveGltYXRlbHkgZXZlcnlcblx0KiBgZGVsYXlgIG1pbGxpc2Vjb25kcywgbGlrZSB0aGUgZ2xvYmFsIGBzZXRJbnRlcnZhbGAgZnVuY3Rpb24uXG5cdCpcblx0KiBMaWtlIGBzZXRUaW1lb3V0YCwgaXQgcmV0dXJucyBhIHRpbWVyIElELCB3aGljaCBtYXkgYmUgYSBudW1iZXIgb3IgYW5cblx0KiBvYmplY3QgdGhhdCBjYW4gYmUgY29lcmNlZCB0byBhIG51bWJlciB2aWEgYFN5bWJvbC50b1ByaW1pdGl2ZWAuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IGludGVydmFsSWQgPSB0aW1lb3V0TWFuYWdlci5zZXRJbnRlcnZhbChcblx0KiAgICgpID0+IGNvbnNvbGUubG9nKCdyYW4gYXQ6JywgbmV3IERhdGUoKSksXG5cdCogICAxMDAwLFxuXHQqIClcblx0KiBgYGBcblx0Ki9cblx0c2V0SW50ZXJ2YWwoY2FsbGJhY2ssIGRlbGF5KSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSB0cnVlO1xuXHRcdHJldHVybiB0aGlzLiNwcm92aWRlci5zZXRJbnRlcnZhbChjYWxsYmFjaywgZGVsYXkpO1xuXHR9XG5cdC8qKlxuXHQqIGBjbGVhckludGVydmFsYCBjYW4gYmUgdXNlZCB0byBjYW5jZWwgYW4gaW50ZXJ2YWwsIGxpa2UgdGhlIGdsb2JhbFxuXHQqIGBjbGVhckludGVydmFsYCBmdW5jdGlvbi4gSXQgc2hvdWxkIGJlIGNhbGxlZCB3aXRoIGFuIGludGVydmFsIElEXG5cdCogcmV0dXJuZWQgYnkgYHNldEludGVydmFsYC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgaW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJJbnRlcnZhbChpbnRlcnZhbElkKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhckludGVydmFsKGludGVydmFsSWQpIHtcblx0XHR0aGlzLiNwcm92aWRlci5jbGVhckludGVydmFsKGludGVydmFsSWQpO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgVGltZW91dE1hbmFnZXJ9LCB1c2VkIHRocm91Z2hvdXQgVGFuU3RhY2sgUXVlcnkgdG8gc2NoZWR1bGUgYW5kIGNhbmNlbCB0aW1lcnMuXG4qL1xuY29uc3QgdGltZW91dE1hbmFnZXIgPSBuZXcgVGltZW91dE1hbmFnZXIoKTtcbi8qKlxuKiBJbiBtYW55IGNhc2VzIGNvZGUgd2FudHMgdG8gZGVsYXkgdG8gdGhlIG5leHQgZXZlbnQgbG9vcCB0aWNrOyB0aGlzIGlzIG5vdFxuKiBtZWRpYXRlZCBieSB7QGxpbmsgdGltZW91dE1hbmFnZXJ9LlxuKlxuKiBUaGlzIGZ1bmN0aW9uIGlzIHByb3ZpZGVkIHRvIG1ha2UgYXVkaXRpbmcgdGhlIGB0YW5zdGFjay9xdWVyeS1jb3JlYCBmb3JcbiogaW5jb3JyZWN0IHVzZSBvZiBzeXN0ZW0gYHNldFRpbWVvdXRgIGVhc2llci5cbiovXG5mdW5jdGlvbiBzeXN0ZW1TZXRUaW1lb3V0WmVybyhjYWxsYmFjaykge1xuXHRzZXRUaW1lb3V0KGNhbGxiYWNrLCAwKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgVGltZW91dE1hbmFnZXIsIGRlZmF1bHRUaW1lb3V0UHJvdmlkZXIsIHN5c3RlbVNldFRpbWVvdXRaZXJvLCB0aW1lb3V0TWFuYWdlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD10aW1lb3V0TWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzLnRzXG4vKiogQGRlcHJlY2F0ZWRcbiogdXNlIGBlbnZpcm9ubWVudE1hbmFnZXIuaXNTZXJ2ZXIoKWAgaW5zdGVhZC5cbiovXG5jb25zdCBpc1NlcnZlciA9IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIgfHwgXCJEZW5vXCIgaW4gZ2xvYmFsVGhpcztcbmZ1bmN0aW9uIG5vb3AoKSB7fVxuZnVuY3Rpb24gZnVuY3Rpb25hbFVwZGF0ZSh1cGRhdGVyLCBpbnB1dCkge1xuXHRyZXR1cm4gdHlwZW9mIHVwZGF0ZXIgPT09IFwiZnVuY3Rpb25cIiA/IHVwZGF0ZXIoaW5wdXQpIDogdXBkYXRlcjtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRUaW1lb3V0KHZhbHVlKSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgJiYgdmFsdWUgPj0gMCAmJiB2YWx1ZSAhPT0gSW5maW5pdHk7XG59XG5mdW5jdGlvbiB0aW1lVW50aWxTdGFsZSh1cGRhdGVkQXQsIHN0YWxlVGltZSkge1xuXHRyZXR1cm4gTWF0aC5tYXgodXBkYXRlZEF0ICsgKHN0YWxlVGltZSB8fCAwKSAtIERhdGUubm93KCksIDApO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVF1ZXJ5VmFsdWUodmFsdWUsIHF1ZXJ5KSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IHZhbHVlKHF1ZXJ5KSA6IHZhbHVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgbWF0Y2hlcyB0aGUgZ2l2ZW4ge0BsaW5rIFF1ZXJ5RmlsdGVyc30uXG4qIEV2ZXJ5IGZpbHRlciB0aGF0IGlzIHNwZWNpZmllZCBtdXN0IG1hdGNoOyBmaWx0ZXJzIHRoYXQgYXJlIGxlZnQgdW5zcGVjaWZpZWQgYXJlIGlnbm9yZWQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcbipcbiogY29uc3QgbWF0Y2hpbmdRdWVyaWVzID0gcXVlcnlDYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKHF1ZXJ5KSA9PiBtYXRjaFF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9LCBxdWVyeSkpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpIHtcblx0Y29uc3QgeyB0eXBlID0gXCJhbGxcIiwgZXhhY3QsIGZldGNoU3RhdHVzLCBwcmVkaWNhdGUsIHF1ZXJ5S2V5LCBzdGFsZSB9ID0gZmlsdGVycztcblx0aWYgKHF1ZXJ5S2V5KSB7XG5cdFx0aWYgKGV4YWN0KSB7XG5cdFx0XHRpZiAocXVlcnkucXVlcnlIYXNoICE9PSBoYXNoUXVlcnlLZXlCeU9wdGlvbnMocXVlcnlLZXksIHF1ZXJ5Lm9wdGlvbnMpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KHF1ZXJ5LnF1ZXJ5S2V5LCBxdWVyeUtleSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAodHlwZSAhPT0gXCJhbGxcIikge1xuXHRcdGNvbnN0IGlzQWN0aXZlID0gcXVlcnkuaXNBY3RpdmUoKTtcblx0XHRpZiAodHlwZSA9PT0gXCJhY3RpdmVcIiAmJiAhaXNBY3RpdmUpIHJldHVybiBmYWxzZTtcblx0XHRpZiAodHlwZSA9PT0gXCJpbmFjdGl2ZVwiICYmIGlzQWN0aXZlKSByZXR1cm4gZmFsc2U7XG5cdH1cblx0aWYgKHR5cGVvZiBzdGFsZSA9PT0gXCJib29sZWFuXCIgJiYgcXVlcnkuaXNTdGFsZSgpICE9PSBzdGFsZSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoZmV0Y2hTdGF0dXMgJiYgZmV0Y2hTdGF0dXMgIT09IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwcmVkaWNhdGUgJiYgIXByZWRpY2F0ZShxdWVyeSkpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBtdXRhdGlvbiBtYXRjaGVzIHRoZSBnaXZlbiB7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfS5cbiogRXZlcnkgZmlsdGVyIHRoYXQgaXMgc3BlY2lmaWVkIG11c3QgbWF0Y2g7IGZpbHRlcnMgdGhhdCBhcmUgbGVmdCB1bnNwZWNpZmllZCBhcmUgaWdub3JlZC5cbiogSWYgYSBgbXV0YXRpb25LZXlgIGZpbHRlciBpcyBwcm92aWRlZCBidXQgdGhlIG11dGF0aW9uIGhhcyBubyBgbXV0YXRpb25LZXlgIG9mIGl0cyBvd24sIGl0IGRvZXMgbm90IG1hdGNoLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG4qXG4qIGNvbnN0IG1hdGNoaW5nTXV0YXRpb25zID0gbXV0YXRpb25DYWNoZVxuKiAgIC5nZXRBbGwoKVxuKiAgIC5maWx0ZXIoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0sIG11dGF0aW9uKSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gbWF0Y2hNdXRhdGlvbihmaWx0ZXJzLCBtdXRhdGlvbikge1xuXHRjb25zdCB7IGV4YWN0LCBzdGF0dXMsIHByZWRpY2F0ZSwgbXV0YXRpb25LZXkgfSA9IGZpbHRlcnM7XG5cdGlmIChtdXRhdGlvbktleSkge1xuXHRcdGlmICghbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmIChleGFjdCkge1xuXHRcdFx0aWYgKGhhc2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkobXV0YXRpb25LZXkpKSByZXR1cm4gZmFsc2U7XG5cdFx0fSBlbHNlIGlmICghcGFydGlhbE1hdGNoS2V5KG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksIG11dGF0aW9uS2V5KSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdGlmIChzdGF0dXMgJiYgbXV0YXRpb24uc3RhdGUuc3RhdHVzICE9PSBzdGF0dXMpIHJldHVybiBmYWxzZTtcblx0aWYgKHByZWRpY2F0ZSAmJiAhcHJlZGljYXRlKG11dGF0aW9uKSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucykge1xuXHRyZXR1cm4gKG9wdGlvbnM/LnF1ZXJ5S2V5SGFzaEZuIHx8IGhhc2hLZXkpKHF1ZXJ5S2V5KTtcbn1cbi8qKlxuKiBEZWZhdWx0IHF1ZXJ5ICYgbXV0YXRpb24ga2V5cyBoYXNoIGZ1bmN0aW9uLlxuKiBIYXNoZXMgdGhlIHZhbHVlIGludG8gYSBzdGFibGUgaGFzaC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogLy8gT2JqZWN0IGtleXMgYXJlIHNvcnRlZCwgc28ga2V5IG9yZGVyIGRvZXNuJ3QgYWZmZWN0IHRoZSBoYXNoOlxuKiBoYXNoS2V5KFsndG9kb3MnLCB7IHBhZ2U6IDEsIGZpbHRlcjogJ2RvbmUnIH1dKSAvLyA9PT0gJ1tcInRvZG9zXCIse1wiZmlsdGVyXCI6XCJkb25lXCIsXCJwYWdlXCI6MX1dJ1xuKiBgYGBcbiovXG5mdW5jdGlvbiBoYXNoS2V5KHF1ZXJ5S2V5KSB7XG5cdHJldHVybiBKU09OLnN0cmluZ2lmeShxdWVyeUtleSwgKF8sIHZhbCkgPT4gaXNQbGFpbk9iamVjdCh2YWwpID8gT2JqZWN0LmtleXModmFsKS5zb3J0KCkucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuXHRcdHJlc3VsdFtrZXldID0gdmFsW2tleV07XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSwge30pIDogdmFsKTtcbn1cbmZ1bmN0aW9uIHBhcnRpYWxNYXRjaEtleShhLCBiKSB7XG5cdGlmIChhID09PSBiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBhICE9PSB0eXBlb2YgYikgcmV0dXJuIGZhbHNlO1xuXHRpZiAoYSAmJiBiICYmIHR5cGVvZiBhID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBiID09PSBcIm9iamVjdFwiKSB7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoYSkgJiYgQXJyYXkuaXNBcnJheShiKSkge1xuXHRcdFx0aWYgKGIubGVuZ3RoID4gYS5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgYi5sZW5ndGg7IGkrKykgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkoYVtpXSwgYltpXSkpIHJldHVybiBmYWxzZTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRjb25zdCBiS2V5cyA9IE9iamVjdC5rZXlzKGIpO1xuXHRcdGZvciAoY29uc3Qga2V5IG9mIGJLZXlzKSBpZiAoIXBhcnRpYWxNYXRjaEtleShhW2tleV0sIGJba2V5XSkpIHJldHVybiBmYWxzZTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG5jb25zdCBoYXNPd24gPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5O1xuZnVuY3Rpb24gcmVwbGFjZUVxdWFsRGVlcChhLCBiLCBkZXB0aCA9IDApIHtcblx0aWYgKGEgPT09IGIpIHJldHVybiBhO1xuXHRpZiAoZGVwdGggPiA1MDApIHJldHVybiBiO1xuXHRjb25zdCBhcnJheSA9IGlzUGxhaW5BcnJheShhKSAmJiBpc1BsYWluQXJyYXkoYik7XG5cdGlmICghYXJyYXkgJiYgIShpc1BsYWluT2JqZWN0KGEpICYmIGlzUGxhaW5PYmplY3QoYikpKSByZXR1cm4gYjtcblx0Y29uc3QgYVNpemUgPSAoYXJyYXkgPyBhIDogT2JqZWN0LmtleXMoYSkpLmxlbmd0aDtcblx0Y29uc3QgYkl0ZW1zID0gYXJyYXkgPyBiIDogT2JqZWN0LmtleXMoYik7XG5cdGNvbnN0IGJTaXplID0gYkl0ZW1zLmxlbmd0aDtcblx0Y29uc3QgY29weSA9IGFycmF5ID8gbmV3IEFycmF5KGJTaXplKSA6IHt9O1xuXHRsZXQgZXF1YWxJdGVtcyA9IDA7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYlNpemU7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IGFycmF5ID8gaSA6IGJJdGVtc1tpXTtcblx0XHRjb25zdCBhSXRlbSA9IGFba2V5XTtcblx0XHRjb25zdCBiSXRlbSA9IGJba2V5XTtcblx0XHRpZiAoYUl0ZW0gPT09IGJJdGVtKSB7XG5cdFx0XHRjb3B5W2tleV0gPSBhSXRlbTtcblx0XHRcdGlmIChhcnJheSA/IGkgPCBhU2l6ZSA6IGhhc093bi5jYWxsKGEsIGtleSkpIGVxdWFsSXRlbXMrKztcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRpZiAoYUl0ZW0gPT09IG51bGwgfHwgYkl0ZW0gPT09IG51bGwgfHwgdHlwZW9mIGFJdGVtICE9PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBiSXRlbSAhPT0gXCJvYmplY3RcIikge1xuXHRcdFx0Y29weVtrZXldID0gYkl0ZW07XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgdiA9IHJlcGxhY2VFcXVhbERlZXAoYUl0ZW0sIGJJdGVtLCBkZXB0aCArIDEpO1xuXHRcdGNvcHlba2V5XSA9IHY7XG5cdFx0aWYgKHYgPT09IGFJdGVtKSBlcXVhbEl0ZW1zKys7XG5cdH1cblx0cmV0dXJuIGFTaXplID09PSBiU2l6ZSAmJiBlcXVhbEl0ZW1zID09PSBhU2l6ZSA/IGEgOiBjb3B5O1xufVxuLyoqXG4qIFNoYWxsb3cgY29tcGFyZSBvYmplY3RzLlxuKi9cbmZ1bmN0aW9uIHNoYWxsb3dFcXVhbE9iamVjdHMoYSwgYikge1xuXHRpZiAoIWIgfHwgT2JqZWN0LmtleXMoYSkubGVuZ3RoICE9PSBPYmplY3Qua2V5cyhiKS5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0Zm9yIChjb25zdCBrZXkgaW4gYSkgaWYgKGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNQbGFpbkFycmF5KHZhbHVlKSB7XG5cdHJldHVybiBBcnJheS5pc0FycmF5KHZhbHVlKSAmJiB2YWx1ZS5sZW5ndGggPT09IE9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGg7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KG8pIHtcblx0aWYgKCFoYXNPYmplY3RQcm90b3R5cGUobykpIHJldHVybiBmYWxzZTtcblx0Y29uc3Qgb2JqZWN0UHJvdG90eXBlID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pO1xuXHRjb25zdCBjdG9yID0gb2JqZWN0UHJvdG90eXBlPy5jb25zdHJ1Y3Rvcjtcblx0aWYgKGN0b3IgPT09IHZvaWQgMCkgcmV0dXJuIHRydWU7XG5cdGlmICh0eXBlb2YgY3RvciAhPT0gXCJmdW5jdGlvblwiKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IHByb3QgPSBjdG9yLnByb3RvdHlwZTtcblx0aWYgKCFoYXNPYmplY3RQcm90b3R5cGUocHJvdCkpIHJldHVybiBmYWxzZTtcblx0aWYgKCFwcm90Lmhhc093blByb3BlcnR5KFwiaXNQcm90b3R5cGVPZlwiKSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAob2JqZWN0UHJvdG90eXBlICE9PSBPYmplY3QucHJvdG90eXBlKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaGFzT2JqZWN0UHJvdG90eXBlKG8pIHtcblx0cmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbmZ1bmN0aW9uIHNsZWVwKHRpbWVvdXQpIHtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0dGltZW91dE1hbmFnZXIuc2V0VGltZW91dChyZXNvbHZlLCB0aW1lb3V0KTtcblx0fSk7XG59XG5mdW5jdGlvbiByZXBsYWNlRGF0YShwcmV2RGF0YSwgZGF0YSwgb3B0aW9ucykge1xuXHRpZiAodHlwZW9mIG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIG9wdGlvbnMuc3RydWN0dXJhbFNoYXJpbmcocHJldkRhdGEsIGRhdGEpO1xuXHRlbHNlIGlmIChvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nICE9PSBmYWxzZSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRyeSB7XG5cdFx0XHRyZXR1cm4gcmVwbGFjZUVxdWFsRGVlcChwcmV2RGF0YSwgZGF0YSk7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGNvbnNvbGUuZXJyb3IoYFN0cnVjdHVyYWwgc2hhcmluZyByZXF1aXJlcyBkYXRhIHRvIGJlIEpTT04gc2VyaWFsaXphYmxlLiBUbyBmaXggdGhpcywgdHVybiBvZmYgc3RydWN0dXJhbFNoYXJpbmcgb3IgcmV0dXJuIEpTT04tc2VyaWFsaXphYmxlIGRhdGEgZnJvbSB5b3VyIHF1ZXJ5Rm4uIFske29wdGlvbnMucXVlcnlIYXNofV06ICR7ZXJyb3J9YCk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9XG5cdFx0cmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuXHR9XG5cdHJldHVybiBkYXRhO1xufVxuLyoqXG4qIEludGVuZGVkIHRvIGJlIHBhc3NlZCBhcyBhIHF1ZXJ5J3MgYHBsYWNlaG9sZGVyRGF0YWAgb3B0aW9uLCBmb3IgZXhhbXBsZVxuKiBgcGxhY2Vob2xkZXJEYXRhOiBrZWVwUHJldmlvdXNEYXRhYC4gSW5zdGVhZCBvZiByZXNldHRpbmcgdGhlIHF1ZXJ5J3MgZGF0YSB0byBgdW5kZWZpbmVkYCB3aGlsZSBhIG5ld1xuKiBxdWVyeSBrZXkgaXMgZmV0Y2hpbmcsIGl0IGtlZXBzIGRpc3BsYXlpbmcgdGhlIHByZXZpb3VzbHkgZmV0Y2hlZCBkYXRhIHVudGlsIHRoZSBuZXcgZGF0YSBhcnJpdmVzLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBuZXcgUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJywgcGFnZV0sXG4qICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0cyhwYWdlKSxcbiogICBwbGFjZWhvbGRlckRhdGE6IGtlZXBQcmV2aW91c0RhdGEsXG4qIH0pXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGtlZXBQcmV2aW91c0RhdGEocHJldmlvdXNEYXRhKSB7XG5cdHJldHVybiBwcmV2aW91c0RhdGE7XG59XG5mdW5jdGlvbiBhZGRUb0VuZChpdGVtcywgaXRlbSwgbWF4ID0gMCkge1xuXHRjb25zdCBuZXdJdGVtcyA9IFsuLi5pdGVtcywgaXRlbV07XG5cdHJldHVybiBtYXggJiYgbmV3SXRlbXMubGVuZ3RoID4gbWF4ID8gbmV3SXRlbXMuc2xpY2UoMSkgOiBuZXdJdGVtcztcbn1cbmZ1bmN0aW9uIGFkZFRvU3RhcnQoaXRlbXMsIGl0ZW0sIG1heCA9IDApIHtcblx0Y29uc3QgbmV3SXRlbXMgPSBbaXRlbSwgLi4uaXRlbXNdO1xuXHRyZXR1cm4gbWF4ICYmIG5ld0l0ZW1zLmxlbmd0aCA+IG1heCA/IG5ld0l0ZW1zLnNsaWNlKDAsIC0xKSA6IG5ld0l0ZW1zO1xufVxuLyoqXG4qIFNlbnRpbmVsIHZhbHVlIHRoYXQgY2FuIGJlIHBhc3NlZCBhcyBhIHF1ZXJ5J3MgYHF1ZXJ5Rm5gIHRvIGNvbmRpdGlvbmFsbHkgZGlzYWJsZSB0aGUgcXVlcnkgKGVxdWl2YWxlbnRcbiogdG8gYGVuYWJsZWQ6IGZhbHNlYCkgd2hpbGUgcHJlc2VydmluZyBmdWxsIHR5cGUgaW5mZXJlbmNlIGZvciB0aGUgcXVlcnkncyBkYXRhLiBVbmxpa2UgYGVuYWJsZWQ6IGZhbHNlYCxcbiogYSBxdWVyeSBkaXNhYmxlZCB2aWEgYHNraXBUb2tlbmAgY2Fubm90IGJlIHRyaWdnZXJlZCB3aXRoIGByZWZldGNoYC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogbmV3IFF1ZXJ5T2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBxdWVyeUtleTogWydwb3N0JywgcG9zdElkXSxcbiogICBxdWVyeUZuOiBwb3N0SWQgIT0gbnVsbCA/ICgpID0+IGZldGNoUG9zdChwb3N0SWQpIDogc2tpcFRva2VuLFxuKiB9KVxuKiBgYGBcbiovXG5jb25zdCBza2lwVG9rZW4gPSBTeW1ib2woKTtcbmZ1bmN0aW9uIGVuc3VyZVF1ZXJ5Rm4ob3B0aW9ucywgZmV0Y2hPcHRpb25zKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAob3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGNvbnNvbGUuZXJyb3IoYEF0dGVtcHRlZCB0byBpbnZva2UgcXVlcnlGbiB3aGVuIHNldCB0byBza2lwVG9rZW4uIFRoaXMgaXMgbGlrZWx5IGEgY29uZmlndXJhdGlvbiBlcnJvci4gUXVlcnkgaGFzaDogJyR7b3B0aW9ucy5xdWVyeUhhc2h9J2ApO1xuXHR9XG5cdGlmICghb3B0aW9ucy5xdWVyeUZuICYmIGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UpIHJldHVybiAoKSA9PiBmZXRjaE9wdGlvbnMuaW5pdGlhbFByb21pc2U7XG5cdGlmICghb3B0aW9ucy5xdWVyeUZuIHx8IG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSByZXR1cm4gKCkgPT4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgTWlzc2luZyBxdWVyeUZuOiAnJHtvcHRpb25zLnF1ZXJ5SGFzaH0nYCkpO1xuXHRyZXR1cm4gb3B0aW9ucy5xdWVyeUZuO1xufVxuLyoqXG4qIFJlc29sdmVzIGEgYHRocm93T25FcnJvcmAgb3B0aW9uIHRvIGEgYm9vbGVhbi5cbiogSWYgYHRocm93T25FcnJvcmAgaXMgYSBmdW5jdGlvbiwgaXQgaXMgY2FsbGVkIHdpdGggYHBhcmFtc2AgKGUuZy4gdGhlIGVycm9yIGFuZCwgZGVwZW5kaW5nIG9uIHRoZSBjYWxsZXIsXG4qIGFkZGl0aW9uYWwgY29udGV4dCBzdWNoIGFzIHRoZSBxdWVyeSBvciBtdXRhdGlvbikgYW5kIGl0cyByZXN1bHQgaXMgcmV0dXJuZWQsIGFsbG93aW5nIHRoZSB0aHJvd2luZ1xuKiBiZWhhdmlvciB0byBiZSBkZWNpZGVkIHBlciBlcnJvci4gT3RoZXJ3aXNlLCBgdGhyb3dPbkVycm9yYCBpdHNlbGYgaXMgY29lcmNlZCB0byBhIGJvb2xlYW4gKGB1bmRlZmluZWRgXG4qIHJlc29sdmVzIHRvIGBmYWxzZWApLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB0aHJvd09uRXJyb3IgPVxuKiAgIHF1ZXJ5LnN0YXRlLmVycm9yICYmIHR5cGVvZiBvcHRpb25zLnRocm93T25FcnJvciA9PT0gJ2Z1bmN0aW9uJ1xuKiAgICAgPyBzaG91bGRUaHJvd0Vycm9yKG9wdGlvbnMudGhyb3dPbkVycm9yLCBbcXVlcnkuc3RhdGUuZXJyb3IsIHF1ZXJ5XSlcbiogICAgIDogb3B0aW9ucy50aHJvd09uRXJyb3JcbiogYGBgXG4qL1xuZnVuY3Rpb24gc2hvdWxkVGhyb3dFcnJvcih0aHJvd09uRXJyb3IsIHBhcmFtcykge1xuXHRpZiAodHlwZW9mIHRocm93T25FcnJvciA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdGhyb3dPbkVycm9yKC4uLnBhcmFtcyk7XG5cdHJldHVybiAhIXRocm93T25FcnJvcjtcbn1cbmZ1bmN0aW9uIGFkZENvbnN1bWVBd2FyZVNpZ25hbChvYmplY3QsIGdldFNpZ25hbCwgb25DYW5jZWxsZWQpIHtcblx0bGV0IGNvbnN1bWVkID0gZmFsc2U7XG5cdGxldCBzaWduYWw7XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmplY3QsIFwic2lnbmFsXCIsIHtcblx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdGdldDogKCkgPT4ge1xuXHRcdFx0c2lnbmFsID8/PSBnZXRTaWduYWwoKTtcblx0XHRcdGlmIChjb25zdW1lZCkgcmV0dXJuIHNpZ25hbDtcblx0XHRcdGNvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdGlmIChzaWduYWwuYWJvcnRlZCkgb25DYW5jZWxsZWQoKTtcblx0XHRcdGVsc2Ugc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvbkNhbmNlbGxlZCwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFx0cmV0dXJuIHNpZ25hbDtcblx0XHR9XG5cdH0pO1xuXHRyZXR1cm4gb2JqZWN0O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhZGRDb25zdW1lQXdhcmVTaWduYWwsIGFkZFRvRW5kLCBhZGRUb1N0YXJ0LCBlbnN1cmVRdWVyeUZuLCBmdW5jdGlvbmFsVXBkYXRlLCBoYXNoS2V5LCBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIGlzUGxhaW5BcnJheSwgaXNQbGFpbk9iamVjdCwgaXNTZXJ2ZXIsIGlzVmFsaWRUaW1lb3V0LCBrZWVwUHJldmlvdXNEYXRhLCBtYXRjaE11dGF0aW9uLCBtYXRjaFF1ZXJ5LCBub29wLCBwYXJ0aWFsTWF0Y2hLZXksIHJlcGxhY2VEYXRhLCByZXBsYWNlRXF1YWxEZWVwLCByZXNvbHZlUXVlcnlWYWx1ZSwgc2hhbGxvd0VxdWFsT2JqZWN0cywgc2hvdWxkVGhyb3dFcnJvciwgc2tpcFRva2VuLCBzbGVlcCwgdGltZVVudGlsU3RhbGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgYXMgaXNTZXJ2ZXIkMSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL2Vudmlyb25tZW50TWFuYWdlci50c1xubGV0IGlzU2VydmVyRm4gPSAoKSA9PiBpc1NlcnZlciQxO1xuLyoqXG4qIFJldHVybnMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzIGEgc2VydmVyIGVudmlyb25tZW50LlxuKi9cbmNvbnN0IGlzU2VydmVyID0gKCkgPT4gaXNTZXJ2ZXJGbigpO1xuLyoqXG4qIE1hbmFnZXMgaG93IFRhblN0YWNrIFF1ZXJ5IGRldGVjdHMgd2hldGhlciB0aGUgY3VycmVudCBydW50aW1lIHNob3VsZCBiZSB0cmVhdGVkIGFzXG4qIHNlcnZlci1zaWRlLCB3aGljaCBkaXNhYmxlcyBzY2hlZHVsaW5nIHJlZmV0Y2ggdGltZXJzIGFuZCBjaGFuZ2VzIHRoZSBkZWZhdWx0IGByZXRyeWAgY291bnRcbiogYW5kIGBnY1RpbWVgLiBCeSBkZWZhdWx0LCB0aGUgZGV0ZWN0aW9uIHRyZWF0cyBhIG1pc3NpbmcgYHdpbmRvd2AgKG9yIHRoZSBwcmVzZW5jZSBvZiBhXG4qIGBEZW5vYCBnbG9iYWwpIGFzIHNlcnZlci5cbipcbiogT3ZlcnJpZGUgdGhpcyBmb3IgcnVudGltZXMgd2hlcmUgdGhhdCBkZWZhdWx0IGRldGVjdGlvbiB3b3VsZCBnaXZlIHRoZSB3cm9uZyBhbnN3ZXIg4oCUIGZvclxuKiBleGFtcGxlLCBhIFNlcnZpY2UgV29ya2VyLCB3aGVyZSBgd2luZG93YCBpcyB1bmRlZmluZWQgZXZlbiB0aG91Z2ggdGhlIGVudmlyb25tZW50IHNob3VsZFxuKiBiZWhhdmUgbGlrZSBhIGNsaWVudC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogaW1wb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG4qXG4qIGVudmlyb25tZW50TWFuYWdlci5zZXRJc1NlcnZlcigoKSA9PiBmYWxzZSlcbiogYGBgXG4qL1xuY29uc3QgZW52aXJvbm1lbnRNYW5hZ2VyID0ge1xuXHRpc1NlcnZlcixcblx0LyoqXG5cdCogT3ZlcnJpZGVzIHRoZSBzZXJ2ZXIgY2hlY2sgZ2xvYmFsbHkuXG5cdCovXG5cdHNldElzU2VydmVyKGlzU2VydmVyVmFsdWUpIHtcblx0XHRpc1NlcnZlckZuID0gaXNTZXJ2ZXJWYWx1ZTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyLCBpc1NlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1lbnZpcm9ubWVudE1hbmFnZXIuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zdWJzY3JpYmFibGUudHNcbi8qKlxuKiBUaGUgYmFzZSBjbGFzcyBiZWhpbmQgZXZlcnl0aGluZyBpbiBRdWVyeSB0aGF0IHlvdSBjYW4gc3Vic2NyaWJlIHRvOiBgUXVlcnlDYWNoZWAsIGBNdXRhdGlvbkNhY2hlYCxcbiogdGhlIG9ic2VydmVycywgYW5kIHRoZSBgRm9jdXNNYW5hZ2VyYC9gT25saW5lTWFuYWdlcmAgYmVoaW5kIGBmb2N1c01hbmFnZXJgIGFuZCBgb25saW5lTWFuYWdlcmAuXG4qIFN1YmNsYXNzZXMgZGVjaWRlIHdoYXQgYSBsaXN0ZW5lciByZWNlaXZlcyBhbmQgd2hlbiBpdCBpcyBjYWxsZWQuXG4qL1xudmFyIFN1YnNjcmliYWJsZSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuc3Vic2NyaWJlID0gdGhpcy5zdWJzY3JpYmUuYmluZCh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBSZWdpc3RlcnMgYSBsaXN0ZW5lciB0byBiZSBjYWxsZWQgb24gZXZlcnkgdXBkYXRlIHRoaXMgb2JqZWN0IG5vdGlmaWVzIGFib3V0LiBSZXR1cm5zIGEgZnVuY3Rpb25cblx0KiB0aGF0IHJlbW92ZXMgdGhlIGxpc3RlbmVyIGFnYWluIOKAlCBjYWxsIGl0IHRvIHN0b3AgbGlzdGVuaW5nLiBUaGUgYmFzZSBjbGFzcyBuZXZlciBkcm9wcyBhIGxpc3RlbmVyXG5cdCogb24gaXRzIG93biwgdGhvdWdoIHNvbWUgc3ViY2xhc3NlcyBjbGVhciBhbGwgb2YgdGhlaXJzIGluIGBkZXN0cm95KClgLlxuXHQqIEBwYXJhbSBsaXN0ZW5lciAtIENhbGxlZCBvbiBlYWNoIHVwZGF0ZSwgd2l0aCB3aGF0ZXZlciB0aGUgc3ViY2xhc3MgcGFzc2VzIHRvIGl0cyBzdWJzY3JpYmVycy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgdW5zdWJzY3JpYmUgPSBzdWJzY3JpYmFibGUuc3Vic2NyaWJlKCgpID0+IHtcblx0KiAgIC8vIHJlYWN0IHRvIHRoZSB1cGRhdGVcblx0KiB9KVxuXHQqXG5cdCogdW5zdWJzY3JpYmUoKVxuXHQqIGBgYFxuXHQqL1xuXHRzdWJzY3JpYmUobGlzdGVuZXIpIHtcblx0XHR0aGlzLmxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xuXHRcdHRoaXMub25TdWJzY3JpYmUoKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcblx0XHRcdHRoaXMub25VbnN1YnNjcmliZSgpO1xuXHRcdH07XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgd2hpbGUgYXQgbGVhc3Qgb25lIGxpc3RlbmVyIGlzIHJlZ2lzdGVyZWQsIGBmYWxzZWAgb25jZSB0aGV5IGhhdmUgYWxsIHVuc3Vic2NyaWJlZC5cblx0Ki9cblx0aGFzTGlzdGVuZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLmxpc3RlbmVycy5zaXplID4gMDtcblx0fVxuXHRvblN1YnNjcmliZSgpIHt9XG5cdG9uVW5zdWJzY3JpYmUoKSB7fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgU3Vic2NyaWJhYmxlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN1YnNjcmliYWJsZS5qcy5tYXAiLCJpbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbi8vI3JlZ2lvbiBzcmMvZm9jdXNNYW5hZ2VyLnRzXG4vKipcbiogVGhlIGBGb2N1c01hbmFnZXJgIG1hbmFnZXMgdGhlIGZvY3VzIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbipcbiogSXQgY2FuIGJlIHVzZWQgdG8gY2hhbmdlIHRoZSBkZWZhdWx0IGV2ZW50IGxpc3RlbmVycyBvciB0byBtYW51YWxseSBjaGFuZ2UgdGhlIGZvY3VzIHN0YXRlLlxuKi9cbnZhciBGb2N1c01hbmFnZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNmb2N1c2VkO1xuXHQjY2xlYW51cDtcblx0I3NldHVwO1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI3NldHVwID0gKG9uRm9jdXMpID0+IHtcblx0XHRcdGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG5cdFx0XHRcdGNvbnN0IGxpc3RlbmVyID0gKCkgPT4gb25Gb2N1cygpO1xuXHRcdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgbGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInZpc2liaWxpdHljaGFuZ2VcIiwgbGlzdGVuZXIpO1xuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLiNjbGVhbnVwKSB0aGlzLnNldEV2ZW50TGlzdGVuZXIodGhpcy4jc2V0dXApO1xuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHRcdHRoaXMuI2NsZWFudXAgPSB2b2lkIDA7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIGBzZXRFdmVudExpc3RlbmVyYCBjYW4gYmUgdXNlZCB0byBzZXQgYSBjdXN0b20gZXZlbnQgbGlzdGVuZXIgdGhhdCB3aWxsXG5cdCogYmUgdXNlZCB0byBkZXRlcm1pbmUgdGhlIGZvY3VzIHN0YXRlLiBUaGUgcHJvdmlkZWQgYHNldHVwYCBmdW5jdGlvblxuXHQqIHJlY2VpdmVzIGEgYHNldEZvY3VzZWRgIGNhbGxiYWNrOiBjYWxsIGl0IHdpdGggYSBgYm9vbGVhbmAgdG8gbWFudWFsbHlcblx0KiBzZXQgdGhlIGZvY3VzIHN0YXRlLCBvciB3aXRoIG5vIGFyZ3VtZW50cyB0byByZS1ldmFsdWF0ZSB0aGUgY3VycmVudFxuXHQqIGZvY3VzIHN0YXRlIGFuZCBub3RpZnkgc3Vic2NyaWJlcnMuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBmb2N1c01hbmFnZXIuc2V0RXZlbnRMaXN0ZW5lcigoaGFuZGxlRm9jdXMpID0+IHtcblx0KiAgIGNvbnN0IGxpc3RlbmVyID0gKCkgPT4gaGFuZGxlRm9jdXMoKVxuXHQqICAgLy8gTGlzdGVuIHRvIHZpc2liaWxpdHljaGFuZ2Vcblx0KiAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHQqICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyLCBmYWxzZSlcblx0KiAgIH1cblx0KlxuXHQqICAgcmV0dXJuICgpID0+IHtcblx0KiAgICAgLy8gQmUgc3VyZSB0byB1bnN1YnNjcmliZSBpZiBhIG5ldyBoYW5kbGVyIGlzIHNldFxuXHQqICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyKVxuXHQqICAgfVxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldEV2ZW50TGlzdGVuZXIoc2V0dXApIHtcblx0XHR0aGlzLiNzZXR1cCA9IHNldHVwO1xuXHRcdHRoaXMuI2NsZWFudXA/LigpO1xuXHRcdHRoaXMuI2NsZWFudXAgPSBzZXR1cCgoZm9jdXNlZCkgPT4ge1xuXHRcdFx0aWYgKHR5cGVvZiBmb2N1c2VkID09PSBcImJvb2xlYW5cIikgdGhpcy5zZXRGb2N1c2VkKGZvY3VzZWQpO1xuXHRcdFx0ZWxzZSB0aGlzLm9uRm9jdXMoKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBgc2V0Rm9jdXNlZGAgY2FuIGJlIHVzZWQgdG8gbWFudWFsbHkgc2V0IHRoZSBmb2N1cyBzdGF0ZS4gU2V0IGB1bmRlZmluZWRgXG5cdCogdG8gZmFsbCBiYWNrIHRvIHRoZSBkZWZhdWx0IGZvY3VzIGNoZWNrLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogLy8gU2V0IGZvY3VzZWRcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZCh0cnVlKVxuXHQqXG5cdCogLy8gU2V0IHVuZm9jdXNlZFxuXHQqIGZvY3VzTWFuYWdlci5zZXRGb2N1c2VkKGZhbHNlKVxuXHQqXG5cdCogLy8gRmFsbGJhY2sgdG8gdGhlIGRlZmF1bHQgZm9jdXMgY2hlY2tcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZCh1bmRlZmluZWQpXG5cdCogYGBgXG5cdCovXG5cdHNldEZvY3VzZWQoZm9jdXNlZCkge1xuXHRcdGlmICh0aGlzLiNmb2N1c2VkICE9PSBmb2N1c2VkKSB7XG5cdFx0XHR0aGlzLiNmb2N1c2VkID0gZm9jdXNlZDtcblx0XHRcdHRoaXMub25Gb2N1cygpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgb25Gb2N1c2Agbm90aWZpZXMgYWxsIHN1YnNjcmliZWQgbGlzdGVuZXJzIHdpdGggdGhlIGN1cnJlbnQgZm9jdXMgc3RhdGUuXG5cdCovXG5cdG9uRm9jdXMoKSB7XG5cdFx0Y29uc3QgaXNGb2N1c2VkID0gdGhpcy5pc0ZvY3VzZWQoKTtcblx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0bGlzdGVuZXIoaXNGb2N1c2VkKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBgaXNGb2N1c2VkYCBjYW4gYmUgdXNlZCB0byBnZXQgdGhlIGN1cnJlbnQgZm9jdXMgc3RhdGUuXG5cdCovXG5cdGlzRm9jdXNlZCgpIHtcblx0XHRpZiAodHlwZW9mIHRoaXMuI2ZvY3VzZWQgPT09IFwiYm9vbGVhblwiKSByZXR1cm4gdGhpcy4jZm9jdXNlZDtcblx0XHRyZXR1cm4gZ2xvYmFsVGhpcy5kb2N1bWVudD8udmlzaWJpbGl0eVN0YXRlICE9PSBcImhpZGRlblwiO1xuXHR9XG59O1xuLyoqXG4qIFNpbmdsZXRvbiBpbnN0YW5jZSBvZiB7QGxpbmsgRm9jdXNNYW5hZ2VyfSwgdXNlZCB0byBtYW5hZ2UgYW5kIG9ic2VydmUgdGhlIGZvY3VzIHN0YXRlIHdpdGhpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBmb2N1c01hbmFnZXIgPSBuZXcgRm9jdXNNYW5hZ2VyKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEZvY3VzTWFuYWdlciwgZm9jdXNNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWZvY3VzTWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvaHlkcmF0aW9uLnRzXG5mdW5jdGlvbiB0cnlSZXNvbHZlU3luYyhwcm9taXNlKSB7XG5cdGxldCBkYXRhO1xuXHRwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdGRhdGEgPSByZXN1bHQ7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSwgbm9vcCk/LmNhdGNoPy4obm9vcCk7XG5cdGlmIChkYXRhICE9PSB2b2lkIDApIHJldHVybiB7IGRhdGEgfTtcbn1cbmZ1bmN0aW9uIGRlaHlkcmF0ZU11dGF0aW9uKG11dGF0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0bXV0YXRpb25LZXk6IG11dGF0aW9uLm9wdGlvbnMubXV0YXRpb25LZXksXG5cdFx0c3RhdGU6IG11dGF0aW9uLnN0YXRlLFxuXHRcdC4uLm11dGF0aW9uLm9wdGlvbnMuc2NvcGUgJiYgeyBzY29wZTogbXV0YXRpb24ub3B0aW9ucy5zY29wZSB9LFxuXHRcdC4uLm11dGF0aW9uLm1ldGEgJiYgeyBtZXRhOiBtdXRhdGlvbi5tZXRhIH1cblx0fTtcbn1cbmZ1bmN0aW9uIGRlaHlkcmF0ZVByb21pc2UocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykge1xuXHRjb25zdCBwcm9taXNlID0gcXVlcnkucHJvbWlzZT8udGhlbihzZXJpYWxpemVEYXRhKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRpZiAoc2hvdWxkUmVkYWN0RXJyb3JzPy4oZXJyb3IpID09PSBmYWxzZSkgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLmVycm9yKGBBIHF1ZXJ5IHRoYXQgd2FzIGRlaHlkcmF0ZWQgYXMgcGVuZGluZyBlbmRlZCB1cCByZWplY3RpbmcuIFske3F1ZXJ5LnF1ZXJ5SGFzaH1dOiAke2Vycm9yfTsgVGhlIGVycm9yIHdpbGwgYmUgcmVkYWN0ZWQgaW4gcHJvZHVjdGlvbiBidWlsZHNgKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcInJlZGFjdGVkXCIpKTtcblx0fSk7XG5cdHByb21pc2U/LmNhdGNoKG5vb3ApO1xuXHRyZXR1cm4gcHJvbWlzZTtcbn1cbi8qKlxuKiBEZWh5ZHJhdGVzIGEgc2luZ2xlIGBRdWVyeWAgaW50byBhIHNlcmlhbGl6YWJsZSBgRGVoeWRyYXRlZFF1ZXJ5YCBzbmFwc2hvdC4gTm90ZSB0aGF0IG1vc3QgcXVlcnkgY29uZmlnIChlLmcuXG4qIGBxdWVyeUZuYCwgYHN0YWxlVGltZWApIGlzIG5vdCBkZWh5ZHJhdGVkIGJ1dCBpbnN0ZWFkIG1lYW50IHRvIGJlIGNvbmZpZ3VyZWQgYWdhaW4gd2hlbiBjb25zdW1pbmcgdGhlXG4qIGRlL3JlaHlkcmF0ZWQgZGF0YSwgdHlwaWNhbGx5IHdpdGggYHVzZVF1ZXJ5YCBvbiB0aGUgY2xpZW50LiBJZiB0aGUgcXVlcnkgaXMgc3RpbGwgYHBlbmRpbmdgLCBpdHMgaW4tZmxpZ2h0XG4qIHByb21pc2UgaXMgZGVoeWRyYXRlZCB0b28gc28gaXQgY2FuIGJlIHJlc3VtZWQgb24gdGhlIG90aGVyIHNpZGUgaW5zdGVhZCBvZiByZS1mZXRjaGVkLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gZGVoeWRyYXRlLlxuKiBAcGFyYW0gc2VyaWFsaXplRGF0YSAtIE9wdGlvbmFsIHRyYW5zZm9ybSBhcHBsaWVkIHRvIGBxdWVyeS5zdGF0ZS5kYXRhYCBiZWZvcmUgaXQgaXMgaW5jbHVkZWQgaW4gdGhlIHNuYXBzaG90LlxuKiBAcGFyYW0gc2hvdWxkUmVkYWN0RXJyb3JzIC0gT3B0aW9uYWwgcHJlZGljYXRlOyBpZiBpdCByZXR1cm5zIGBmYWxzZWAgZm9yIHRoZSBwcm9taXNlJ3MgcmVqZWN0aW9uIGVycm9yLCB0aGF0XG4qIGVycm9yIGlzIGtlcHQgYXMtaXMgaW5zdGVhZCBvZiBiZWluZyByZWRhY3RlZC5cbiovXG5mdW5jdGlvbiBkZWh5ZHJhdGVRdWVyeShxdWVyeSwgc2VyaWFsaXplRGF0YSwgc2hvdWxkUmVkYWN0RXJyb3JzKSB7XG5cdHJldHVybiB7XG5cdFx0ZGVoeWRyYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdHN0YXRlOiB7XG5cdFx0XHQuLi5xdWVyeS5zdGF0ZSxcblx0XHRcdC4uLnF1ZXJ5LnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiB7IGRhdGE6IHNlcmlhbGl6ZURhdGEgPyBzZXJpYWxpemVEYXRhKHF1ZXJ5LnN0YXRlLmRhdGEpIDogcXVlcnkuc3RhdGUuZGF0YSB9XG5cdFx0fSxcblx0XHRxdWVyeUtleTogcXVlcnkucXVlcnlLZXksXG5cdFx0cXVlcnlIYXNoOiBxdWVyeS5xdWVyeUhhc2gsXG5cdFx0Li4ucXVlcnkuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiB7IHByb21pc2U6IGRlaHlkcmF0ZVByb21pc2UocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykgfSxcblx0XHQuLi5xdWVyeS5tZXRhICYmIHsgbWV0YTogcXVlcnkubWV0YSB9LFxuXHRcdC4uLnF1ZXJ5LnF1ZXJ5VHlwZSAmJiB7IHF1ZXJ5VHlwZTogcXVlcnkucXVlcnlUeXBlIH1cblx0fTtcbn1cbi8qKlxuKiBUaGUgZGVmYXVsdCBgc2hvdWxkRGVoeWRyYXRlTXV0YXRpb25gIHByZWRpY2F0ZSB1c2VkIGJ5IGBkZWh5ZHJhdGVgLiBPbmx5IGRlaHlkcmF0ZXMgbXV0YXRpb25zIHRoYXQgYXJlXG4qIGN1cnJlbnRseSBwYXVzZWQgKGUuZy4gcGF1c2VkIGJ5IGBuZXR3b3JrTW9kZWAgd2hpbGUgb2ZmbGluZSkuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uKG11dGF0aW9uKSB7XG5cdHJldHVybiBtdXRhdGlvbi5zdGF0ZS5pc1BhdXNlZDtcbn1cbi8qKlxuKiBUaGUgZGVmYXVsdCBgc2hvdWxkRGVoeWRyYXRlUXVlcnlgIHByZWRpY2F0ZSB1c2VkIGJ5IGBkZWh5ZHJhdGVgLiBPbmx5IGRlaHlkcmF0ZXMgcXVlcmllcyB3aG9zZSBzdGF0dXMgaXNcbiogYCdzdWNjZXNzJ2AuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5KSB7XG5cdHJldHVybiBxdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwic3VjY2Vzc1wiO1xufVxuLyoqXG4qIERlaHlkcmF0ZXMgYSBgUXVlcnlDbGllbnRgJ3MgY2FjaGUgKHF1ZXJpZXMgYW5kIG11dGF0aW9ucykgaW50byBhIHBsYWluLCBzZXJpYWxpemFibGUgYERlaHlkcmF0ZWRTdGF0ZWAsXG4qIHR5cGljYWxseSB0byBlbWJlZCBpbiBzZXJ2ZXItcmVuZGVyZWQgbWFya3VwIGFuZCBsYXRlciByZXN0b3JlIGludG8gYSBjbGllbnQtc2lkZSBgUXVlcnlDbGllbnRgIHZpYSBgaHlkcmF0ZWAuXG4qIFdoaWNoIHF1ZXJpZXMvbXV0YXRpb25zIGFyZSBpbmNsdWRlZCwgYW5kIGhvdyB0aGVpciBkYXRhL2Vycm9ycyBhcmUgdHJhbnNmb3JtZWQsIGlzIGNvbnRyb2xsZWQgYnkgYG9wdGlvbnNgLFxuKiBmYWxsaW5nIGJhY2sgdG8gdGhlIGNsaWVudCdzIGBkZWh5ZHJhdGVgIGRlZmF1bHQgb3B0aW9ucywgYW5kIGZpbmFsbHkgdG8gYGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeWAgL1xuKiBgZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uYC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuKlxuKiBhd2FpdCBxdWVyeUNsaWVudC5wcmVmZXRjaFF1ZXJ5KHtcbiogICBxdWVyeUtleTogWydwb3N0cyddLFxuKiAgIHF1ZXJ5Rm46IGdldFBvc3RzLFxuKiB9KVxuKlxuKiBjb25zdCBkZWh5ZHJhdGVkU3RhdGUgPSBkZWh5ZHJhdGUocXVlcnlDbGllbnQpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGRlaHlkcmF0ZShjbGllbnQsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCBmaWx0ZXJNdXRhdGlvbiA9IG9wdGlvbnMuc2hvdWxkRGVoeWRyYXRlTXV0YXRpb24gPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGREZWh5ZHJhdGVNdXRhdGlvbiA/PyBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb247XG5cdGNvbnN0IG11dGF0aW9ucyA9IGNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCkuZ2V0QWxsKCkuZmxhdE1hcCgobXV0YXRpb24pID0+IGZpbHRlck11dGF0aW9uKG11dGF0aW9uKSA/IFtkZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbildIDogW10pO1xuXHRjb25zdCBmaWx0ZXJRdWVyeSA9IG9wdGlvbnMuc2hvdWxkRGVoeWRyYXRlUXVlcnkgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGREZWh5ZHJhdGVRdWVyeSA/PyBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnk7XG5cdGNvbnN0IHNob3VsZFJlZGFjdEVycm9ycyA9IG9wdGlvbnMuc2hvdWxkUmVkYWN0RXJyb3JzID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2hvdWxkUmVkYWN0RXJyb3JzO1xuXHRjb25zdCBzZXJpYWxpemVEYXRhID0gb3B0aW9ucy5zZXJpYWxpemVEYXRhID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmRlaHlkcmF0ZT8uc2VyaWFsaXplRGF0YTtcblx0cmV0dXJuIHtcblx0XHRtdXRhdGlvbnMsXG5cdFx0cXVlcmllczogY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXRBbGwoKS5mbGF0TWFwKChxdWVyeSkgPT4gZmlsdGVyUXVlcnkocXVlcnkpID8gW2RlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpXSA6IFtdKVxuXHR9O1xufVxuLyoqXG4qIFJlc3RvcmVzIGEgYERlaHlkcmF0ZWRTdGF0ZWAgKGFzIHByb2R1Y2VkIGJ5IGBkZWh5ZHJhdGVgKSBpbnRvIGEgYFF1ZXJ5Q2xpZW50YCdzIGNhY2hlLCB0eXBpY2FsbHkgdG8gc2VlZCB0aGVcbiogY2xpZW50IHdpdGggZGF0YSBhbHJlYWR5IGZldGNoZWQgb24gdGhlIHNlcnZlci4gYG11dGF0aW9uc2AgYW5kIGBxdWVyaWVzYCBhcmUgZWFjaCBvcHRpb25hbCBvbiBgZGVoeWRyYXRlZFN0YXRlYC5cbiogUXVlcmllcyBub3QgeWV0IGluIHRoZSBjYWNoZSBhcmUgYnVpbHQgZnJvbSB0aGUgZGVoeWRyYXRlZCBzbmFwc2hvdDsgcXVlcmllcyB0aGF0IGFscmVhZHkgZXhpc3QgYXJlIG9ubHkgdXBkYXRlZFxuKiB3aGVuIHRoZSBkZWh5ZHJhdGVkIGRhdGEgaXMgbmV3ZXIgdGhhbiB3aGF0J3MgYWxyZWFkeSBjYWNoZWQuIE5ld2x5IGJ1aWx0IHF1ZXJpZXMgaGF2ZSB0aGVpciBgZmV0Y2hTdGF0dXNgIHJlc2V0XG4qIHRvIGAnaWRsZSdgIHNvIHRoZXkgZG9uJ3QgaHlkcmF0ZSBzdHVjayBpbiBhIGZldGNoaW5nIHN0YXRlLiBJZiBhIGRlaHlkcmF0ZWQgcXVlcnkgc3RpbGwgaGFkIGFuIGluLWZsaWdodFxuKiBwcm9taXNlLCBpdCBpcyByZXN1bWVkIHZpYSBgcXVlcnkuZmV0Y2goKWAgKHJldXNpbmcgdGhhdCBwcm9taXNlIGFzIGBpbml0aWFsUHJvbWlzZWApIHJhdGhlciB0aGFuIHJlLWludm9raW5nXG4qIGBxdWVyeUZuYC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogLy8gZGVoeWRyYXRlZFN0YXRlIHdhcyBwcm9kdWNlZCBieSBgZGVoeWRyYXRlYCBvbiB0aGUgc2VydmVyXG4qIC8vIGFuZCBzZW50IHRvIHRoZSBjbGllbnQsIGUuZy4gZW1iZWRkZWQgaW4gc2VydmVyLXJlbmRlcmVkIG1hcmt1cC5cbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuKlxuKiBoeWRyYXRlKHF1ZXJ5Q2xpZW50LCBkZWh5ZHJhdGVkU3RhdGUpXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGh5ZHJhdGUoY2xpZW50LCBkZWh5ZHJhdGVkU3RhdGUsIG9wdGlvbnMpIHtcblx0Y29uc3QgbXV0YXRpb25DYWNoZSA9IGNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCk7XG5cdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRjb25zdCBkZXNlcmlhbGl6ZURhdGEgPSBvcHRpb25zPy5kZWZhdWx0T3B0aW9ucz8uZGVzZXJpYWxpemVEYXRhID8/IGNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/LmRlc2VyaWFsaXplRGF0YTtcblx0ZGVoeWRyYXRlZFN0YXRlLm11dGF0aW9ucz8uZm9yRWFjaCgoeyBzdGF0ZSwgLi4ubXV0YXRpb25PcHRpb25zIH0pID0+IHtcblx0XHRtdXRhdGlvbkNhY2hlLmJ1aWxkKGNsaWVudCwge1xuXHRcdFx0Li4uY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuaHlkcmF0ZT8ubXV0YXRpb25zLFxuXHRcdFx0Li4ub3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/Lm11dGF0aW9ucyxcblx0XHRcdC4uLm11dGF0aW9uT3B0aW9uc1xuXHRcdH0sIHN0YXRlKTtcblx0fSk7XG5cdGRlaHlkcmF0ZWRTdGF0ZS5xdWVyaWVzPy5mb3JFYWNoKCh7IHF1ZXJ5S2V5LCBzdGF0ZSwgcXVlcnlIYXNoLCBtZXRhLCBwcm9taXNlLCBkZWh5ZHJhdGVkQXQsIHF1ZXJ5VHlwZSB9KSA9PiB7XG5cdFx0Y29uc3Qgc3luY0RhdGEgPSBwcm9taXNlID8gdHJ5UmVzb2x2ZVN5bmMocHJvbWlzZSkgOiB2b2lkIDA7XG5cdFx0Y29uc3QgcmF3RGF0YSA9IHN0YXRlLmRhdGEgPT09IHZvaWQgMCA/IHN5bmNEYXRhPy5kYXRhIDogc3RhdGUuZGF0YTtcblx0XHRjb25zdCBkYXRhID0gcmF3RGF0YSA9PT0gdm9pZCAwID8gcmF3RGF0YSA6IGRlc2VyaWFsaXplRGF0YSA/IGRlc2VyaWFsaXplRGF0YShyYXdEYXRhKSA6IHJhd0RhdGE7XG5cdFx0bGV0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQocXVlcnlIYXNoKTtcblx0XHRjb25zdCBleGlzdGluZ1F1ZXJ5SXNQZW5kaW5nID0gcXVlcnk/LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0Y29uc3QgZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgPSBxdWVyeT8uc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiZmV0Y2hpbmdcIjtcblx0XHRpZiAocXVlcnkpIHtcblx0XHRcdGNvbnN0IGhhc05ld2VyU3luY0RhdGEgPSBzeW5jRGF0YSAmJiBkZWh5ZHJhdGVkQXQgPiBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0O1xuXHRcdFx0aWYgKHN0YXRlLmRhdGFVcGRhdGVkQXQgPiBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0IHx8IGhhc05ld2VyU3luY0RhdGEpIHtcblx0XHRcdFx0Y29uc3QgeyBmZXRjaFN0YXR1czogX2lnbm9yZWQsIC4uLnNlcmlhbGl6ZWRTdGF0ZSB9ID0gc3RhdGU7XG5cdFx0XHRcdHF1ZXJ5LnNldFN0YXRlKHtcblx0XHRcdFx0XHQuLi5zZXJpYWxpemVkU3RhdGUsXG5cdFx0XHRcdFx0ZGF0YSxcblx0XHRcdFx0XHQuLi5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCAmJiB7XG5cdFx0XHRcdFx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiLFxuXHRcdFx0XHRcdFx0ZGF0YVVwZGF0ZWRBdDogZGVoeWRyYXRlZEF0LFxuXHRcdFx0XHRcdFx0Li4uIWV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nICYmIHsgZmV0Y2hTdGF0dXM6IFwiaWRsZVwiIH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBxdWVyeSA9IHF1ZXJ5Q2FjaGUuYnVpbGQoY2xpZW50LCB7XG5cdFx0XHQuLi5jbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5xdWVyaWVzLFxuXHRcdFx0Li4ub3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/LnF1ZXJpZXMsXG5cdFx0XHRxdWVyeUtleSxcblx0XHRcdHF1ZXJ5SGFzaCxcblx0XHRcdG1ldGEsXG5cdFx0XHRfdHlwZTogcXVlcnlUeXBlXG5cdFx0fSwge1xuXHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRkYXRhLFxuXHRcdFx0ZmV0Y2hTdGF0dXM6IFwiaWRsZVwiLFxuXHRcdFx0c3RhdHVzOiBzdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiICYmIGRhdGEgIT09IHZvaWQgMCA/IFwic3VjY2Vzc1wiIDogc3RhdGUuc3RhdHVzLFxuXHRcdFx0Li4uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgJiYgeyBkYXRhVXBkYXRlZEF0OiBkZWh5ZHJhdGVkQXQgfVxuXHRcdH0pO1xuXHRcdGlmIChwcm9taXNlICYmICFzeW5jRGF0YSAmJiAhZXhpc3RpbmdRdWVyeUlzUGVuZGluZyAmJiAhZXhpc3RpbmdRdWVyeUlzRmV0Y2hpbmcgJiYgZGVoeWRyYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCkgcXVlcnkuZmV0Y2godm9pZCAwLCB7IGluaXRpYWxQcm9taXNlOiBQcm9taXNlLnJlc29sdmUocHJvbWlzZSkudGhlbihkZXNlcmlhbGl6ZURhdGEpIH0pLmNhdGNoKG5vb3ApO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uLCBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlUXVlcnksIGRlaHlkcmF0ZSwgZGVoeWRyYXRlUXVlcnksIGh5ZHJhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aHlkcmF0aW9uLmpzLm1hcCIsImltcG9ydCB7IHN5c3RlbVNldFRpbWVvdXRaZXJvIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvbm90aWZ5TWFuYWdlci50c1xuLyoqXG4qIERlZmF1bHQgc2NoZWR1bGluZyBmdW5jdGlvbiB1c2VkIGJ5IHRoZSBub3RpZnkgbWFuYWdlci5cbiogU2NoZWR1bGVzIHRoZSBjYWxsYmFjayB3aXRoIHRoZSBzeXN0ZW0ncyBgc2V0VGltZW91dChjYWxsYmFjaywgMClgLlxuKi9cbmNvbnN0IGRlZmF1bHRTY2hlZHVsZXIgPSBzeXN0ZW1TZXRUaW1lb3V0WmVybztcbmZ1bmN0aW9uIGNyZWF0ZU5vdGlmeU1hbmFnZXIoKSB7XG5cdGxldCBxdWV1ZSA9IFtdO1xuXHRsZXQgdHJhbnNhY3Rpb25zID0gMDtcblx0bGV0IG5vdGlmeUZuID0gKGNhbGxiYWNrKSA9PiB7XG5cdFx0Y2FsbGJhY2soKTtcblx0fTtcblx0bGV0IGJhdGNoTm90aWZ5Rm4gPSAoY2FsbGJhY2spID0+IHtcblx0XHRjYWxsYmFjaygpO1xuXHR9O1xuXHRsZXQgc2NoZWR1bGVGbiA9IGRlZmF1bHRTY2hlZHVsZXI7XG5cdGNvbnN0IHNjaGVkdWxlID0gKGNhbGxiYWNrKSA9PiB7XG5cdFx0aWYgKHRyYW5zYWN0aW9ucykgcXVldWUucHVzaChjYWxsYmFjayk7XG5cdFx0ZWxzZSBzY2hlZHVsZUZuKCgpID0+IHtcblx0XHRcdG5vdGlmeUZuKGNhbGxiYWNrKTtcblx0XHR9KTtcblx0fTtcblx0Y29uc3QgZmx1c2ggPSAoKSA9PiB7XG5cdFx0Y29uc3Qgb3JpZ2luYWxRdWV1ZSA9IHF1ZXVlO1xuXHRcdHF1ZXVlID0gW107XG5cdFx0aWYgKG9yaWdpbmFsUXVldWUubGVuZ3RoKSBzY2hlZHVsZUZuKCgpID0+IHtcblx0XHRcdGJhdGNoTm90aWZ5Rm4oKCkgPT4ge1xuXHRcdFx0XHRvcmlnaW5hbFF1ZXVlLmZvckVhY2goKGNhbGxiYWNrKSA9PiB7XG5cdFx0XHRcdFx0bm90aWZ5Rm4oY2FsbGJhY2spO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdC8qKlxuXHRcdCogQmF0Y2hlcyBhbGwgdXBkYXRlcyBzY2hlZHVsZWQgaW5zaWRlIHRoZSBwYXNzZWQgY2FsbGJhY2suXG5cdFx0KiBUaGlzIGlzIG1haW5seSB1c2VkIGludGVybmFsbHkgdG8gb3B0aW1pemUgcXVlcnkgY2xpZW50IHVwZGF0aW5nLlxuXHRcdCogQmF0Y2hlcyBjYW4gYmUgbmVzdGVkOyB0aGUgcXVldWUgaXMgb25seSBmbHVzaGVkIG9uY2UgdGhlIG91dGVybW9zdCBgYmF0Y2hgIGNhbGwgZmluaXNoZXMuXG5cdFx0KiBUaGUgcmV0dXJuIHZhbHVlIG9mIGBjYWxsYmFja2AgaXMgcGFzc2VkIHRocm91Z2guXG5cdFx0Ki9cblx0XHRiYXRjaDogKGNhbGxiYWNrKSA9PiB7XG5cdFx0XHRsZXQgcmVzdWx0O1xuXHRcdFx0dHJhbnNhY3Rpb25zKys7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyZXN1bHQgPSBjYWxsYmFjaygpO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0dHJhbnNhY3Rpb25zLS07XG5cdFx0XHRcdGlmICghdHJhbnNhY3Rpb25zKSBmbHVzaCgpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogQWxsIGNhbGxzIHRvIHRoZSB3cmFwcGVkIGZ1bmN0aW9uIHdpbGwgYmUgYmF0Y2hlZC5cblx0XHQqL1xuXHRcdGJhdGNoQ2FsbHM6IChjYWxsYmFjaykgPT4ge1xuXHRcdFx0cmV0dXJuICguLi5hcmdzKSA9PiB7XG5cdFx0XHRcdHNjaGVkdWxlKCgpID0+IHtcblx0XHRcdFx0XHRjYWxsYmFjayguLi5hcmdzKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9O1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBTY2hlZHVsZXMgYSBmdW5jdGlvbiB0byBiZSBydW4gb24gdGhlIG5leHQgYmF0Y2guXG5cdFx0KiBCeSBkZWZhdWx0LCB0aGUgYmF0Y2ggaXMgcnVuIHdpdGggYSBgc2V0VGltZW91dGAsIGJ1dCB0aGlzIGNhbiBiZSBjb25maWd1cmVkIHZpYSBgc2V0U2NoZWR1bGVyYC5cblx0XHQqL1xuXHRcdHNjaGVkdWxlLFxuXHRcdC8qKlxuXHRcdCogVXNlIHRoaXMgbWV0aG9kIHRvIHNldCBhIGN1c3RvbSBub3RpZnkgZnVuY3Rpb24uXG5cdFx0KiBUaGlzIGNhbiBiZSB1c2VkIHRvIGZvciBleGFtcGxlIHdyYXAgbm90aWZpY2F0aW9ucyB3aXRoIGBSZWFjdC5hY3RgIHdoaWxlIHJ1bm5pbmcgdGVzdHMuXG5cdFx0Ki9cblx0XHRzZXROb3RpZnlGdW5jdGlvbjogKGZuKSA9PiB7XG5cdFx0XHRub3RpZnlGbiA9IGZuO1xuXHRcdH0sXG5cdFx0LyoqXG5cdFx0KiBVc2UgdGhpcyBtZXRob2QgdG8gc2V0IGEgY3VzdG9tIGZ1bmN0aW9uIHRvIGJhdGNoIG5vdGlmaWNhdGlvbnMgdG9nZXRoZXIgaW50byBhIHNpbmdsZSB0aWNrLlxuXHRcdCogRnJhbWV3b3JrIGFkYXB0ZXJzIHVzZSB0aGlzIHRvIHBsdWcgaW4gdGhlaXIgb3duIGJhdGNoaW5nIHByaW1pdGl2ZSwgc28gdGhhdCBhIHNpbmdsZSBxdWVyeVxuXHRcdCogdXBkYXRlIG9ubHkgdHJpZ2dlcnMgb25lIHJlLXJlbmRlciBpbnN0ZWFkIG9mIG9uZSBwZXIgc3Vic2NyaWJlci5cblx0XHQqXG5cdFx0KiBAZXhhbXBsZVxuXHRcdCogYGBgdHNcblx0XHQqIGltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0XHQqIGltcG9ydCB7IGJhdGNoIH0gZnJvbSAnc29saWQtanMnXG5cdFx0KlxuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRCYXRjaE5vdGlmeUZ1bmN0aW9uKGJhdGNoKVxuXHRcdCogYGBgXG5cdFx0Ki9cblx0XHRzZXRCYXRjaE5vdGlmeUZ1bmN0aW9uOiAoZm4pID0+IHtcblx0XHRcdGJhdGNoTm90aWZ5Rm4gPSBmbjtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogQ29uZmlndXJlcyBhIGN1c3RvbSBjYWxsYmFjayB0aGF0IHNjaGVkdWxlcyB3aGVuIHRoZSBuZXh0IGJhdGNoIHJ1bnMuXG5cdFx0KiBUaGUgZGVmYXVsdCBiZWhhdmlvciBpcyBgc2V0VGltZW91dChjYWxsYmFjaywgMClgLlxuXHRcdCpcblx0XHQqIEBleGFtcGxlXG5cdFx0KiBgYGB0c1xuXHRcdCogaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHRcdCpcblx0XHQqIC8vIFNjaGVkdWxlIGJhdGNoZXMgaW4gdGhlIG5leHQgbWljcm90YXNrXG5cdFx0KiBub3RpZnlNYW5hZ2VyLnNldFNjaGVkdWxlcihxdWV1ZU1pY3JvdGFzaylcblx0XHQqXG5cdFx0KiAvLyBTY2hlZHVsZSBiYXRjaGVzIGJlZm9yZSB0aGUgbmV4dCBmcmFtZSBpcyByZW5kZXJlZFxuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRTY2hlZHVsZXIocmVxdWVzdEFuaW1hdGlvbkZyYW1lKVxuXHRcdCpcblx0XHQqIC8vIFNjaGVkdWxlIGJhdGNoZXMgc29tZSB0aW1lIGluIHRoZSBmdXR1cmVcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0U2NoZWR1bGVyKChjYikgPT4gc2V0VGltZW91dChjYiwgMTApKVxuXHRcdCogYGBgXG5cdFx0Ki9cblx0XHRzZXRTY2hlZHVsZXI6IChmbikgPT4ge1xuXHRcdFx0c2NoZWR1bGVGbiA9IGZuO1xuXHRcdH1cblx0fTtcbn1cbi8qKlxuKiBIYW5kbGVzIHNjaGVkdWxpbmcgYW5kIGJhdGNoaW5nIGNhbGxiYWNrcyBpbiBUYW5TdGFjayBRdWVyeS5cbiovXG5jb25zdCBub3RpZnlNYW5hZ2VyID0gY3JlYXRlTm90aWZ5TWFuYWdlcigpO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVOb3RpZnlNYW5hZ2VyLCBkZWZhdWx0U2NoZWR1bGVyLCBub3RpZnlNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vdGlmeU1hbmFnZXIuanMubWFwIiwiaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG4vLyNyZWdpb24gc3JjL29ubGluZU1hbmFnZXIudHNcbi8qKlxuKiBUaGUgYE9ubGluZU1hbmFnZXJgIG1hbmFnZXMgdGhlIG9ubGluZSBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuIEl0IGNhblxuKiBiZSB1c2VkIHRvIGNoYW5nZSB0aGUgZGVmYXVsdCBldmVudCBsaXN0ZW5lcnMgb3IgdG8gbWFudWFsbHkgY2hhbmdlIHRoZVxuKiBvbmxpbmUgc3RhdGUuXG4qXG4qIEJ5IGRlZmF1bHQsIHRoZSBgb25saW5lTWFuYWdlcmAgYXNzdW1lcyBhbiBhY3RpdmUgbmV0d29yayBjb25uZWN0aW9uLCBhbmRcbiogbGlzdGVucyB0byB0aGUgYG9ubGluZWAgYW5kIGBvZmZsaW5lYCBldmVudHMgb24gdGhlIGB3aW5kb3dgIG9iamVjdCB0b1xuKiBkZXRlY3QgY2hhbmdlcy5cbiovXG52YXIgT25saW5lTWFuYWdlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I29ubGluZSA9IHRydWU7XG5cdCNjbGVhbnVwO1xuXHQjc2V0dXA7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jc2V0dXAgPSAob25PbmxpbmUpID0+IHtcblx0XHRcdGlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKSB7XG5cdFx0XHRcdGNvbnN0IG9ubGluZUxpc3RlbmVyID0gKCkgPT4gb25PbmxpbmUodHJ1ZSk7XG5cdFx0XHRcdGNvbnN0IG9mZmxpbmVMaXN0ZW5lciA9ICgpID0+IG9uT25saW5lKGZhbHNlKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvbmxpbmVcIiwgb25saW5lTGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIG9mZmxpbmVMaXN0ZW5lciwgZmFsc2UpO1xuXHRcdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwib25saW5lXCIsIG9ubGluZUxpc3RlbmVyKTtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9mZmxpbmVcIiwgb2ZmbGluZUxpc3RlbmVyKTtcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy4jY2xlYW51cCkgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0XHR0aGlzLiNjbGVhbnVwID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgc2V0RXZlbnRMaXN0ZW5lcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGV2ZW50IGxpc3RlbmVyIHRoYXQgd2lsbFxuXHQqIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBvbmxpbmUgc3RhdGUuIFRoZSBwcm92aWRlZCBgc2V0dXBgIGZ1bmN0aW9uXG5cdCogcmVjZWl2ZXMgYSBgc2V0T25saW5lYCBjYWxsYmFjayB0aGF0IHNob3VsZCBiZSBjYWxsZWQgd2l0aCBhIGBib29sZWFuYFxuXHQqIHdoZW5ldmVyIHRoZSBvbmxpbmUgc3RhdGUgY2hhbmdlcy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgTmV0SW5mbyBmcm9tICdAcmVhY3QtbmF0aXZlLWNvbW11bml0eS9uZXRpbmZvJ1xuXHQqIGltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIG9ubGluZU1hbmFnZXIuc2V0RXZlbnRMaXN0ZW5lcigoc2V0T25saW5lKSA9PiB7XG5cdCogICByZXR1cm4gTmV0SW5mby5hZGRFdmVudExpc3RlbmVyKChzdGF0ZSkgPT4ge1xuXHQqICAgICBzZXRPbmxpbmUoISFzdGF0ZS5pc0Nvbm5lY3RlZClcblx0KiAgIH0pXG5cdCogfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0RXZlbnRMaXN0ZW5lcihzZXR1cCkge1xuXHRcdHRoaXMuI3NldHVwID0gc2V0dXA7XG5cdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0dGhpcy4jY2xlYW51cCA9IHNldHVwKHRoaXMuc2V0T25saW5lLmJpbmQodGhpcykpO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRPbmxpbmVgIGNhbiBiZSB1c2VkIHRvIG1hbnVhbGx5IHNldCB0aGUgb25saW5lIHN0YXRlLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIC8vIFNldCB0byBvbmxpbmVcblx0KiBvbmxpbmVNYW5hZ2VyLnNldE9ubGluZSh0cnVlKVxuXHQqXG5cdCogLy8gU2V0IHRvIG9mZmxpbmVcblx0KiBvbmxpbmVNYW5hZ2VyLnNldE9ubGluZShmYWxzZSlcblx0KiBgYGBcblx0Ki9cblx0c2V0T25saW5lKG9ubGluZSkge1xuXHRcdGlmICh0aGlzLiNvbmxpbmUgIT09IG9ubGluZSkge1xuXHRcdFx0dGhpcy4jb25saW5lID0gb25saW5lO1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIob25saW5lKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgaXNPbmxpbmVgIGNhbiBiZSB1c2VkIHRvIGdldCB0aGUgY3VycmVudCBvbmxpbmUgc3RhdGUuXG5cdCovXG5cdGlzT25saW5lKCkge1xuXHRcdHJldHVybiB0aGlzLiNvbmxpbmU7XG5cdH1cbn07XG4vKipcbiogU2luZ2xldG9uIGluc3RhbmNlIG9mIHtAbGluayBPbmxpbmVNYW5hZ2VyfSwgdXNlZCB0byBtYW5hZ2UgYW5kIG9ic2VydmUgdGhlIG9ubGluZSBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuXG4qL1xuY29uc3Qgb25saW5lTWFuYWdlciA9IG5ldyBPbmxpbmVNYW5hZ2VyKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE9ubGluZU1hbmFnZXIsIG9ubGluZU1hbmFnZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b25saW5lTWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyBub29wLCBzbGVlcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4vZm9jdXNNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBvbmxpbmVNYW5hZ2VyIH0gZnJvbSBcIi4vb25saW5lTWFuYWdlci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9yZXRyeWVyLnRzXG5mdW5jdGlvbiBkZWZhdWx0UmV0cnlEZWxheShmYWlsdXJlQ291bnQpIHtcblx0cmV0dXJuIE1hdGgubWluKDFlMyAqIDIgKiogZmFpbHVyZUNvdW50LCAzZTQpO1xufVxuZnVuY3Rpb24gY2FuRmV0Y2gobmV0d29ya01vZGUpIHtcblx0cmV0dXJuIChuZXR3b3JrTW9kZSA/PyBcIm9ubGluZVwiKSA9PT0gXCJvbmxpbmVcIiA/IG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSA6IHRydWU7XG59XG4vKipcbiogVGhlIGVycm9yIHRocm93biBieSBhIGBSZXRyeWVyYCAoYW5kIHN1cmZhY2VkIHRvIGBxdWVyeS5wcm9taXNlYC9gbXV0YXRpb25gKSB3aGVuIGEgZmV0Y2ggaXMgY2FuY2VsbGVkLCBlLmcuIHZpYVxuKiBgcXVlcnkuY2FuY2VsKClgLiBgcmV2ZXJ0YCwgaWYgYHRydWVgLCB0ZWxscyB0aGUgY2FsbGVyIHRvIHJlc3RvcmUgdGhlIHN0YXRlIHRoZSBxdWVyeSB3YXMgaW4gYmVmb3JlIHRoZSBmZXRjaFxuKiBzdGFydGVkIGluc3RlYWQgb2Ygc3VyZmFjaW5nIHRoZSBlcnJvci4gYHNpbGVudGAsIGlmIGB0cnVlYCwgdGVsbHMgdGhlIGNhbGxlciB0byBzdXBwcmVzcyB0aGlzIGVycm9yIGFuZCBpbnN0ZWFkXG4qIHJlc29sdmUgd2l0aCB0aGUgcHJvbWlzZSBvZiB0aGUgZmV0Y2ggdGhhdCB0cmlnZ2VyZWQgdGhlIGNhbmNlbGxhdGlvbi5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogcXVlcnkuY2FuY2VsKClcbipcbiogdHJ5IHtcbiogICBhd2FpdCBxdWVyeS5wcm9taXNlXG4qIH0gY2F0Y2ggKGVycm9yKSB7XG4qICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IpIHtcbiogICAgIC8vIHRoZSBmZXRjaCB3YXMgY2FuY2VsbGVkLCBlLmcuIHZpYSBgcXVlcnkuY2FuY2VsKClgXG4qICAgfVxuKiB9XG4qIGBgYFxuKi9cbnZhciBDYW5jZWxsZWRFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoXCJDYW5jZWxsZWRFcnJvclwiKTtcblx0XHR0aGlzLnJldmVydCA9IG9wdGlvbnM/LnJldmVydDtcblx0XHR0aGlzLnNpbGVudCA9IG9wdGlvbnM/LnNpbGVudDtcblx0fVxufTtcbi8qKlxuKiBAZGVwcmVjYXRlZCBVc2UgaW5zdGFuY2VvZiBgQ2FuY2VsbGVkRXJyb3JgIGluc3RlYWQuXG4qL1xuZnVuY3Rpb24gaXNDYW5jZWxsZWRFcnJvcih2YWx1ZSkge1xuXHRyZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvcjtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJldHJ5ZXIoY29uZmlnKSB7XG5cdGxldCBpc1JldHJ5Q2FuY2VsbGVkID0gZmFsc2U7XG5cdGxldCBmYWlsdXJlQ291bnQgPSAwO1xuXHRsZXQgY29udGludWVGbjtcblx0bGV0IHN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRsZXQgcHJvbWlzZVJlc29sdmU7XG5cdGxldCBwcm9taXNlUmVqZWN0O1xuXHRjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdHByb21pc2VSZXNvbHZlID0gcmVzb2x2ZTtcblx0XHRwcm9taXNlUmVqZWN0ID0gcmVqZWN0O1xuXHR9KTtcblx0cHJvbWlzZS5jYXRjaChub29wKTtcblx0Y29uc3QgaXNSZXNvbHZlZCA9ICgpID0+IHN0YXR1cyAhPT0gXCJwZW5kaW5nXCI7XG5cdGNvbnN0IGNhbmNlbCA9IChjYW5jZWxPcHRpb25zKSA9PiB7XG5cdFx0aWYgKCFpc1Jlc29sdmVkKCkpIHtcblx0XHRcdGNvbnN0IGVycm9yID0gbmV3IENhbmNlbGxlZEVycm9yKGNhbmNlbE9wdGlvbnMpO1xuXHRcdFx0cmVqZWN0KGVycm9yKTtcblx0XHRcdGNvbmZpZy5vbkNhbmNlbD8uKGVycm9yKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IGNhbmNlbFJldHJ5ID0gKCkgPT4ge1xuXHRcdGlzUmV0cnlDYW5jZWxsZWQgPSB0cnVlO1xuXHR9O1xuXHRjb25zdCBjb250aW51ZVJldHJ5ID0gKCkgPT4ge1xuXHRcdGlzUmV0cnlDYW5jZWxsZWQgPSBmYWxzZTtcblx0fTtcblx0Y29uc3QgY2FuQ29udGludWUgPSAoKSA9PiBmb2N1c01hbmFnZXIuaXNGb2N1c2VkKCkgJiYgKGNvbmZpZy5uZXR3b3JrTW9kZSA9PT0gXCJhbHdheXNcIiB8fCBvbmxpbmVNYW5hZ2VyLmlzT25saW5lKCkpICYmIGNvbmZpZy5jYW5SdW4oKTtcblx0Y29uc3QgY2FuU3RhcnQgPSAoKSA9PiBjYW5GZXRjaChjb25maWcubmV0d29ya01vZGUpICYmIGNvbmZpZy5jYW5SdW4oKTtcblx0Y29uc3QgcmVzb2x2ZSA9ICh2YWx1ZSkgPT4ge1xuXHRcdGlmICghaXNSZXNvbHZlZCgpKSB7XG5cdFx0XHRjb250aW51ZUZuPy4oKTtcblx0XHRcdHN0YXR1cyA9IFwicmVzb2x2ZWRcIjtcblx0XHRcdHByb21pc2VSZXNvbHZlKHZhbHVlKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IHJlamVjdCA9ICh2YWx1ZSkgPT4ge1xuXHRcdGlmICghaXNSZXNvbHZlZCgpKSB7XG5cdFx0XHRjb250aW51ZUZuPy4oKTtcblx0XHRcdHN0YXR1cyA9IFwicmVqZWN0ZWRcIjtcblx0XHRcdHByb21pc2VSZWplY3QodmFsdWUpO1xuXHRcdH1cblx0fTtcblx0Y29uc3QgcGF1c2UgPSAoKSA9PiB7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlKChjb250aW51ZVJlc29sdmUpID0+IHtcblx0XHRcdGNvbnRpbnVlRm4gPSAodmFsdWUpID0+IHtcblx0XHRcdFx0aWYgKGlzUmVzb2x2ZWQoKSB8fCBjYW5Db250aW51ZSgpKSBjb250aW51ZVJlc29sdmUodmFsdWUpO1xuXHRcdFx0fTtcblx0XHRcdGNvbmZpZy5vblBhdXNlPy4oKTtcblx0XHR9KS50aGVuKCgpID0+IHtcblx0XHRcdGNvbnRpbnVlRm4gPSB2b2lkIDA7XG5cdFx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkgY29uZmlnLm9uQ29udGludWU/LigpO1xuXHRcdH0pO1xuXHR9O1xuXHRjb25zdCBydW4gPSAoKSA9PiB7XG5cdFx0aWYgKGlzUmVzb2x2ZWQoKSkgcmV0dXJuO1xuXHRcdGxldCBwcm9taXNlT3JWYWx1ZTtcblx0XHRjb25zdCBpbml0aWFsUHJvbWlzZSA9IGZhaWx1cmVDb3VudCA9PT0gMCA/IGNvbmZpZy5pbml0aWFsUHJvbWlzZSA6IHZvaWQgMDtcblx0XHR0cnkge1xuXHRcdFx0cHJvbWlzZU9yVmFsdWUgPSBpbml0aWFsUHJvbWlzZSA/PyBjb25maWcuZm4oKTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0cHJvbWlzZU9yVmFsdWUgPSBQcm9taXNlLnJlamVjdChlcnJvcik7XG5cdFx0fVxuXHRcdFByb21pc2UucmVzb2x2ZShwcm9taXNlT3JWYWx1ZSkudGhlbihyZXNvbHZlKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdGlmIChpc1Jlc29sdmVkKCkpIHJldHVybjtcblx0XHRcdGNvbnN0IHJldHJ5ID0gY29uZmlnLnJldHJ5ID8/IChpc1NlcnZlcigpID8gMCA6IDMpO1xuXHRcdFx0Y29uc3QgcmV0cnlEZWxheSA9IGNvbmZpZy5yZXRyeURlbGF5ID8/IGRlZmF1bHRSZXRyeURlbGF5O1xuXHRcdFx0Y29uc3QgZGVsYXkgPSB0eXBlb2YgcmV0cnlEZWxheSA9PT0gXCJmdW5jdGlvblwiID8gcmV0cnlEZWxheShmYWlsdXJlQ291bnQsIGVycm9yKSA6IHJldHJ5RGVsYXk7XG5cdFx0XHRjb25zdCBzaG91bGRSZXRyeSA9IHJldHJ5ID09PSB0cnVlIHx8IHR5cGVvZiByZXRyeSA9PT0gXCJudW1iZXJcIiAmJiBmYWlsdXJlQ291bnQgPCByZXRyeSB8fCB0eXBlb2YgcmV0cnkgPT09IFwiZnVuY3Rpb25cIiAmJiByZXRyeShmYWlsdXJlQ291bnQsIGVycm9yKTtcblx0XHRcdGlmIChpc1JldHJ5Q2FuY2VsbGVkIHx8ICFzaG91bGRSZXRyeSkge1xuXHRcdFx0XHRyZWplY3QoZXJyb3IpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRmYWlsdXJlQ291bnQrKztcblx0XHRcdGNvbmZpZy5vbkZhaWw/LihmYWlsdXJlQ291bnQsIGVycm9yKTtcblx0XHRcdHNsZWVwKGRlbGF5KS50aGVuKCgpID0+IHtcblx0XHRcdFx0cmV0dXJuIGNhbkNvbnRpbnVlKCkgPyB2b2lkIDAgOiBwYXVzZSgpO1xuXHRcdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRcdGlmIChpc1JldHJ5Q2FuY2VsbGVkKSByZWplY3QoZXJyb3IpO1xuXHRcdFx0XHRlbHNlIHJ1bigpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH07XG5cdHJldHVybiB7XG5cdFx0cHJvbWlzZSxcblx0XHRzdGF0dXM6ICgpID0+IHN0YXR1cyxcblx0XHRjYW5jZWwsXG5cdFx0Y29udGludWU6ICgpID0+IHtcblx0XHRcdGNvbnRpbnVlRm4/LigpO1xuXHRcdFx0cmV0dXJuIHByb21pc2U7XG5cdFx0fSxcblx0XHRjYW5jZWxSZXRyeSxcblx0XHRjb250aW51ZVJldHJ5LFxuXHRcdGNhblN0YXJ0LFxuXHRcdHN0YXJ0OiAoKSA9PiB7XG5cdFx0XHRpZiAoY2FuU3RhcnQoKSkgcnVuKCk7XG5cdFx0XHRlbHNlIHBhdXNlKCkudGhlbihydW4pO1xuXHRcdFx0cmV0dXJuIHByb21pc2U7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBDYW5jZWxsZWRFcnJvciwgY2FuRmV0Y2gsIGNyZWF0ZVJldHJ5ZXIsIGlzQ2FuY2VsbGVkRXJyb3IgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmV0cnllci5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBpc1ZhbGlkVGltZW91dCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9yZW1vdmFibGUudHNcbi8qKlxuKiBUaGUgYmFzZSBjbGFzcyBmb3IgY2FjaGUgZW50cmllcyB0aGF0IGFyZSBnYXJiYWdlIGNvbGxlY3RlZCBvbmNlIG5vdGhpbmcgaXMgdXNpbmcgdGhlbSDigJRcbiogYFF1ZXJ5YCBhbmQgYE11dGF0aW9uYCBib3RoIGV4dGVuZCBpdC4gYGdjVGltZWAgY29udHJvbHMgaG93IGxvbmcgYW4gdW51c2VkIGVudHJ5IGlzIGtlcHQuXG4qL1xudmFyIFJlbW92YWJsZSA9IGNsYXNzIHtcblx0I2djVGltZW91dDtcblx0LyoqXG5cdCogQ2xlYXJzIHRoZSBwZW5kaW5nIGdhcmJhZ2UgY29sbGVjdGlvbiB0aW1lb3V0LCBzbyB0aGUgZW50cnkgaXMgbm8gbG9uZ2VyIHNjaGVkdWxlZCBmb3IgcmVtb3ZhbC5cblx0KiBBIHN1YmNsYXNzIG1heSBvdmVycmlkZSB0aGlzIHRvIHJlbGVhc2Ugd2hhdCBpdCBob2xkcyBvbiB0byBhcyB3ZWxsIOKAlCBgUXVlcnlgIGFsc28gY2FuY2VscyBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guXG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHR9XG5cdHNjaGVkdWxlR2MoKSB7XG5cdFx0dGhpcy5jbGVhckdjVGltZW91dCgpO1xuXHRcdGlmIChpc1ZhbGlkVGltZW91dCh0aGlzLmdjVGltZSkpIHRoaXMuI2djVGltZW91dCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0dGhpcy5vcHRpb25hbFJlbW92ZSgpO1xuXHRcdH0sIHRoaXMuZ2NUaW1lKTtcblx0fVxuXHR1cGRhdGVHY1RpbWUobmV3R2NUaW1lKSB7XG5cdFx0dGhpcy5nY1RpbWUgPSBNYXRoLm1heCh0aGlzLmdjVGltZSB8fCAwLCBuZXdHY1RpbWUgPz8gKGlzU2VydmVyKCkgPyBJbmZpbml0eSA6IDNlNSkpO1xuXHR9XG5cdGNsZWFyR2NUaW1lb3V0KCkge1xuXHRcdGlmICh0aGlzLiNnY1RpbWVvdXQgIT09IHZvaWQgMCkge1xuXHRcdFx0dGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRoaXMuI2djVGltZW91dCk7XG5cdFx0XHR0aGlzLiNnY1RpbWVvdXQgPSB2b2lkIDA7XG5cdFx0fVxuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBSZW1vdmFibGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVtb3ZhYmxlLmpzLm1hcCIsImltcG9ydCB7IGFkZENvbnN1bWVBd2FyZVNpZ25hbCwgYWRkVG9FbmQsIGFkZFRvU3RhcnQsIGVuc3VyZVF1ZXJ5Rm4gfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8jcmVnaW9uIHNyYy9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IudHNcbmZ1bmN0aW9uIGluZmluaXRlUXVlcnlCZWhhdmlvcihwYWdlcykge1xuXHRyZXR1cm4geyBvbkZldGNoOiAoY29udGV4dCwgcXVlcnkpID0+IHtcblx0XHRjb25zdCBvcHRpb25zID0gY29udGV4dC5vcHRpb25zO1xuXHRcdGNvbnN0IGRpcmVjdGlvbiA9IGNvbnRleHQuZmV0Y2hPcHRpb25zPy5tZXRhPy5mZXRjaE1vcmU/LmRpcmVjdGlvbjtcblx0XHRjb25zdCBvbGRQYWdlcyA9IGNvbnRleHQuc3RhdGUuZGF0YT8ucGFnZXMgfHwgW107XG5cdFx0Y29uc3Qgb2xkUGFnZVBhcmFtcyA9IGNvbnRleHQuc3RhdGUuZGF0YT8ucGFnZVBhcmFtcyB8fCBbXTtcblx0XHRsZXQgcmVzdWx0ID0ge1xuXHRcdFx0cGFnZXM6IFtdLFxuXHRcdFx0cGFnZVBhcmFtczogW11cblx0XHR9O1xuXHRcdGxldCBjdXJyZW50UGFnZSA9IDA7XG5cdFx0Y29uc3QgZmV0Y2hGbiA9IGFzeW5jICgpID0+IHtcblx0XHRcdGxldCBjYW5jZWxsZWQgPSBmYWxzZTtcblx0XHRcdGNvbnN0IGFkZFNpZ25hbFByb3BlcnR5ID0gKG9iamVjdCkgPT4ge1xuXHRcdFx0XHRhZGRDb25zdW1lQXdhcmVTaWduYWwob2JqZWN0LCAoKSA9PiBjb250ZXh0LnNpZ25hbCwgKCkgPT4gY2FuY2VsbGVkID0gdHJ1ZSk7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcXVlcnlGbiA9IGVuc3VyZVF1ZXJ5Rm4oY29udGV4dC5vcHRpb25zLCBjb250ZXh0LmZldGNoT3B0aW9ucyk7XG5cdFx0XHRjb25zdCBmZXRjaFBhZ2UgPSBhc3luYyAoZGF0YSwgcGFyYW0sIHByZXZpb3VzKSA9PiB7XG5cdFx0XHRcdGlmIChjYW5jZWxsZWQpIHJldHVybiBQcm9taXNlLnJlamVjdChjb250ZXh0LnNpZ25hbC5yZWFzb24pO1xuXHRcdFx0XHRpZiAocGFyYW0gPT0gbnVsbCAmJiBkYXRhLnBhZ2VzLmxlbmd0aCkgcmV0dXJuIFByb21pc2UucmVzb2x2ZShkYXRhKTtcblx0XHRcdFx0Y29uc3QgY3JlYXRlUXVlcnlGbkNvbnRleHQgPSAoKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSB7XG5cdFx0XHRcdFx0XHRjbGllbnQ6IGNvbnRleHQuY2xpZW50LFxuXHRcdFx0XHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRcdFx0XHRwYWdlUGFyYW06IHBhcmFtLFxuXHRcdFx0XHRcdFx0ZGlyZWN0aW9uOiBwcmV2aW91cyA/IFwiYmFja3dhcmRcIiA6IFwiZm9yd2FyZFwiLFxuXHRcdFx0XHRcdFx0bWV0YTogY29udGV4dC5vcHRpb25zLm1ldGFcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdGFkZFNpZ25hbFByb3BlcnR5KHF1ZXJ5Rm5Db250ZXh0KTtcblx0XHRcdFx0XHRyZXR1cm4gcXVlcnlGbkNvbnRleHQ7XG5cdFx0XHRcdH07XG5cdFx0XHRcdGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0gY3JlYXRlUXVlcnlGbkNvbnRleHQoKTtcblx0XHRcdFx0Y29uc3QgcGFnZSA9IGF3YWl0IHF1ZXJ5Rm4ocXVlcnlGbkNvbnRleHQpO1xuXHRcdFx0XHRjb25zdCB7IG1heFBhZ2VzIH0gPSBjb250ZXh0Lm9wdGlvbnM7XG5cdFx0XHRcdGNvbnN0IGFkZFRvID0gcHJldmlvdXMgPyBhZGRUb1N0YXJ0IDogYWRkVG9FbmQ7XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0cGFnZXM6IGFkZFRvKGRhdGEucGFnZXMsIHBhZ2UsIG1heFBhZ2VzKSxcblx0XHRcdFx0XHRwYWdlUGFyYW1zOiBhZGRUbyhkYXRhLnBhZ2VQYXJhbXMsIHBhcmFtLCBtYXhQYWdlcylcblx0XHRcdFx0fTtcblx0XHRcdH07XG5cdFx0XHRpZiAoZGlyZWN0aW9uICYmIG9sZFBhZ2VzLmxlbmd0aCkge1xuXHRcdFx0XHRjb25zdCBwcmV2aW91cyA9IGRpcmVjdGlvbiA9PT0gXCJiYWNrd2FyZFwiO1xuXHRcdFx0XHRjb25zdCBwYWdlUGFyYW1GbiA9IHByZXZpb3VzID8gZ2V0UHJldmlvdXNQYWdlUGFyYW0gOiBnZXROZXh0UGFnZVBhcmFtO1xuXHRcdFx0XHRjb25zdCBvbGREYXRhID0ge1xuXHRcdFx0XHRcdHBhZ2VzOiBvbGRQYWdlcyxcblx0XHRcdFx0XHRwYWdlUGFyYW1zOiBvbGRQYWdlUGFyYW1zXG5cdFx0XHRcdH07XG5cdFx0XHRcdHJlc3VsdCA9IGF3YWl0IGZldGNoUGFnZShvbGREYXRhLCBwYWdlUGFyYW1GbihvcHRpb25zLCBvbGREYXRhKSwgcHJldmlvdXMpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Y29uc3QgcmVtYWluaW5nUGFnZXMgPSBwYWdlcyA/PyBvbGRQYWdlcy5sZW5ndGg7XG5cdFx0XHRcdGRvIHtcblx0XHRcdFx0XHRjb25zdCBwYXJhbSA9IGN1cnJlbnRQYWdlID09PSAwID8gb2xkUGFnZVBhcmFtc1swXSA/PyBvcHRpb25zLmluaXRpYWxQYWdlUGFyYW0gOiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIHJlc3VsdCk7XG5cdFx0XHRcdFx0aWYgKGN1cnJlbnRQYWdlID4gMCAmJiBwYXJhbSA9PSBudWxsKSBicmVhaztcblx0XHRcdFx0XHRyZXN1bHQgPSBhd2FpdCBmZXRjaFBhZ2UocmVzdWx0LCBwYXJhbSk7XG5cdFx0XHRcdFx0Y3VycmVudFBhZ2UrKztcblx0XHRcdFx0fSB3aGlsZSAoY3VycmVudFBhZ2UgPCByZW1haW5pbmdQYWdlcyk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH07XG5cdFx0aWYgKGNvbnRleHQub3B0aW9ucy5wZXJzaXN0ZXIpIGNvbnRleHQuZmV0Y2hGbiA9ICgpID0+IHtcblx0XHRcdHJldHVybiBjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyPy4oZmV0Y2hGbiwge1xuXHRcdFx0XHRjbGllbnQ6IGNvbnRleHQuY2xpZW50LFxuXHRcdFx0XHRxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcblx0XHRcdFx0bWV0YTogY29udGV4dC5vcHRpb25zLm1ldGEsXG5cdFx0XHRcdHNpZ25hbDogY29udGV4dC5zaWduYWxcblx0XHRcdH0sIHF1ZXJ5KTtcblx0XHR9O1xuXHRcdGVsc2UgY29udGV4dC5mZXRjaEZuID0gZmV0Y2hGbjtcblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0TmV4dFBhZ2VQYXJhbShvcHRpb25zLCB7IHBhZ2VzLCBwYWdlUGFyYW1zIH0pIHtcblx0Y29uc3QgbGFzdEluZGV4ID0gcGFnZXMubGVuZ3RoIC0gMTtcblx0cmV0dXJuIHBhZ2VzLmxlbmd0aCA+IDAgPyBvcHRpb25zLmdldE5leHRQYWdlUGFyYW0ocGFnZXNbbGFzdEluZGV4XSwgcGFnZXMsIHBhZ2VQYXJhbXNbbGFzdEluZGV4XSwgcGFnZVBhcmFtcykgOiB2b2lkIDA7XG59XG5mdW5jdGlvbiBnZXRQcmV2aW91c1BhZ2VQYXJhbShvcHRpb25zLCB7IHBhZ2VzLCBwYWdlUGFyYW1zIH0pIHtcblx0cmV0dXJuIHBhZ2VzLmxlbmd0aCA+IDAgPyBvcHRpb25zLmdldFByZXZpb3VzUGFnZVBhcmFtPy4ocGFnZXNbMF0sIHBhZ2VzLCBwYWdlUGFyYW1zWzBdLCBwYWdlUGFyYW1zKSA6IHZvaWQgMDtcbn1cbi8qKlxuKiBDaGVja3MgaWYgdGhlcmUgaXMgYSBuZXh0IHBhZ2UuXG4qL1xuZnVuY3Rpb24gaGFzTmV4dFBhZ2Uob3B0aW9ucywgZGF0YSkge1xuXHRpZiAoIWRhdGEpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgZGF0YSkgIT0gbnVsbDtcbn1cbi8qKlxuKiBDaGVja3MgaWYgdGhlcmUgaXMgYSBwcmV2aW91cyBwYWdlLlxuKi9cbmZ1bmN0aW9uIGhhc1ByZXZpb3VzUGFnZShvcHRpb25zLCBkYXRhKSB7XG5cdGlmICghZGF0YSB8fCAhb3B0aW9ucy5nZXRQcmV2aW91c1BhZ2VQYXJhbSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gZ2V0UHJldmlvdXNQYWdlUGFyYW0ob3B0aW9ucywgZGF0YSkgIT0gbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaGFzTmV4dFBhZ2UsIGhhc1ByZXZpb3VzUGFnZSwgaW5maW5pdGVRdWVyeUJlaGF2aW9yIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlCZWhhdmlvci5qcy5tYXAiLCJpbXBvcnQgeyBlbnN1cmVRdWVyeUZuLCBub29wLCByZXBsYWNlRGF0YSwgcmVzb2x2ZVF1ZXJ5VmFsdWUsIHNraXBUb2tlbiwgdGltZVVudGlsU3RhbGUgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IENhbmNlbGxlZEVycm9yLCBjYW5GZXRjaCwgY3JlYXRlUmV0cnllciB9IGZyb20gXCIuL3JldHJ5ZXIuanNcIjtcbmltcG9ydCB7IFJlbW92YWJsZSB9IGZyb20gXCIuL3JlbW92YWJsZS5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeUJlaGF2aW9yIH0gZnJvbSBcIi4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzXCI7XG4vLyNyZWdpb24gc3JjL3F1ZXJ5LnRzXG4vKipcbiogUmVwcmVzZW50cyBhIHNpbmdsZSBjYWNoZWQgcXVlcnkuIEEgYFF1ZXJ5YCBob2xkcyB0aGUgcXVlcnkncyBrZXksIG9wdGlvbnMsXG4qIHN0YXRlIChkYXRhL2Vycm9yL3N0YXR1cyksIGFuZCB0aGUgb2JzZXJ2ZXJzIGN1cnJlbnRseSBzdWJzY3JpYmVkIHRvIGl0LlxuKlxuKiBJbnN0YW5jZXMgYXJlIGNyZWF0ZWQgYW5kIG1hbmFnZWQgaW50ZXJuYWxseSBieSBgUXVlcnlDYWNoZWA7IGFwcGxpY2F0aW9uXG4qIGNvZGUgdHlwaWNhbGx5IGludGVyYWN0cyB3aXRoIHF1ZXJpZXMgaW5kaXJlY3RseSB0aHJvdWdoIGBRdWVyeUNsaWVudGAgb3JcbiogYSBmcmFtZXdvcmsgaG9vayBsaWtlIGB1c2VRdWVyeWAuIERpcmVjdCBhY2Nlc3MgdG8gYSBgUXVlcnlgIGluc3RhbmNlIGlzXG4qIHBvc3NpYmxlIHZpYSBgcXVlcnlDYWNoZS5maW5kKClgL2BmaW5kQWxsKClgIGZvciBpbnNwZWN0aW5nIGNhY2hlIHN0YXRlLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG4qIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5maW5kKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuKlxuKiBpZiAocXVlcnkpIHtcbiogICBjb25zb2xlLmxvZyhxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0KVxuKiB9XG4qIGBgYFxuKi9cbnZhciBRdWVyeSA9IGNsYXNzIGV4dGVuZHMgUmVtb3ZhYmxlIHtcblx0I3F1ZXJ5VHlwZTtcblx0I2luaXRpYWxTdGF0ZTtcblx0I3JldmVydFN0YXRlO1xuXHQjY2FjaGU7XG5cdCNjbGllbnQ7XG5cdCNyZXRyeWVyO1xuXHQjZGVmYXVsdE9wdGlvbnM7XG5cdCNhYm9ydFNpZ25hbENvbnN1bWVkO1xuXHRjb25zdHJ1Y3Rvcihjb25maWcpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgPSBmYWxzZTtcblx0XHR0aGlzLiNkZWZhdWx0T3B0aW9ucyA9IGNvbmZpZy5kZWZhdWx0T3B0aW9ucztcblx0XHR0aGlzLnNldE9wdGlvbnMoY29uZmlnLm9wdGlvbnMpO1xuXHRcdHRoaXMub2JzZXJ2ZXJzID0gW107XG5cdFx0dGhpcy4jY2xpZW50ID0gY29uZmlnLmNsaWVudDtcblx0XHR0aGlzLiNjYWNoZSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG5cdFx0dGhpcy5xdWVyeUtleSA9IGNvbmZpZy5xdWVyeUtleTtcblx0XHR0aGlzLnF1ZXJ5SGFzaCA9IGNvbmZpZy5xdWVyeUhhc2g7XG5cdFx0dGhpcy4jaW5pdGlhbFN0YXRlID0gZ2V0RGVmYXVsdFN0YXRlKHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy5zdGF0ZSA9IGNvbmZpZy5zdGF0ZSA/PyB0aGlzLiNpbml0aWFsU3RhdGU7XG5cdFx0dGhpcy5zY2hlZHVsZUdjKCk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGBtZXRhYCBvYmplY3QgcGFzc2VkIGluIHRoZSBxdWVyeSdzIG9wdGlvbnMsIGlmIGFueS5cblx0Ki9cblx0Z2V0IG1ldGEoKSB7XG5cdFx0cmV0dXJuIHRoaXMub3B0aW9ucy5tZXRhO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0Z2V0IHF1ZXJ5VHlwZSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlUeXBlO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBwcm9taXNlIGZvciB0aGUgY3VycmVudGx5IGluLWZsaWdodCBmZXRjaCwgaWYgdGhlIHF1ZXJ5IGlzIGZldGNoaW5nLlxuXHQqIGB1bmRlZmluZWRgIHdoZW4gdGhlIHF1ZXJ5IGlzIG5vdCBmZXRjaGluZy5cblx0Ki9cblx0Z2V0IHByb21pc2UoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3JldHJ5ZXI/LnByb21pc2U7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHR0aGlzLm9wdGlvbnMgPSB7XG5cdFx0XHQuLi50aGlzLiNkZWZhdWx0T3B0aW9ucyxcblx0XHRcdC4uLm9wdGlvbnNcblx0XHR9O1xuXHRcdGlmIChvcHRpb25zPy5fdHlwZSkgdGhpcy4jcXVlcnlUeXBlID0gb3B0aW9ucy5fdHlwZTtcblx0XHR0aGlzLnVwZGF0ZUdjVGltZSh0aGlzLm9wdGlvbnMuZ2NUaW1lKTtcblx0XHRpZiAodGhpcy5zdGF0ZSAmJiB0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkge1xuXHRcdFx0Y29uc3QgZGVmYXVsdFN0YXRlID0gZ2V0RGVmYXVsdFN0YXRlKHRoaXMub3B0aW9ucyk7XG5cdFx0XHRpZiAoZGVmYXVsdFN0YXRlLmRhdGEgIT09IHZvaWQgMCkge1xuXHRcdFx0XHR0aGlzLnNldFN0YXRlKHN1Y2Nlc3NTdGF0ZShkZWZhdWx0U3RhdGUuZGF0YSwgZGVmYXVsdFN0YXRlLmRhdGFVcGRhdGVkQXQpKTtcblx0XHRcdFx0dGhpcy4jaW5pdGlhbFN0YXRlID0gZGVmYXVsdFN0YXRlO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRvcHRpb25hbFJlbW92ZSgpIHtcblx0XHRpZiAoIXRoaXMub2JzZXJ2ZXJzLmxlbmd0aCAmJiB0aGlzLnN0YXRlLmZldGNoU3RhdHVzID09PSBcImlkbGVcIikgdGhpcy4jY2FjaGUucmVtb3ZlKHRoaXMpO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0c2V0RGF0YShuZXdEYXRhLCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGF0YSA9IHJlcGxhY2VEYXRhKHRoaXMuc3RhdGUuZGF0YSwgbmV3RGF0YSwgdGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRkYXRhLFxuXHRcdFx0dHlwZTogXCJzdWNjZXNzXCIsXG5cdFx0XHRkYXRhVXBkYXRlZEF0OiBvcHRpb25zPy51cGRhdGVkQXQsXG5cdFx0XHRtYW51YWw6IG9wdGlvbnM/Lm1hbnVhbFxuXHRcdH0pO1xuXHRcdHJldHVybiBkYXRhO1xuXHR9XG5cdC8qKlxuXHQqIE1lcmdlcyB0aGUgZ2l2ZW4gcGFydGlhbCBzdGF0ZSBkaXJlY3RseSBpbnRvIHRoaXMgcXVlcnkncyBzdGF0ZSwgbm90aWZ5aW5nIG9ic2VydmVycy4gVXNlZFxuXHQqIGJ5IHBlcnNpc3RlbmNlIGFuZCBicm9hZGNhc3QgcGx1Z2lucyB0byByZXN0b3JlIGEgc3RhdGUgc25hcHNob3QsIGFuZCBieSBkZXZ0b29scyB0byBsZXQgYVxuXHQqIHVzZXIgbWFudWFsbHkgdHJpZ2dlciBhIGxvYWRpbmcvZXJyb3Igc3RhdGUgb3IgZWRpdCB0aGUgY2FjaGVkIGRhdGEuXG5cdCovXG5cdHNldFN0YXRlKHN0YXRlKSB7XG5cdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0dHlwZTogXCJzZXRTdGF0ZVwiLFxuXHRcdFx0c3RhdGVcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIHRoZSBxdWVyeSdzIGN1cnJlbnRseSBpbi1mbGlnaHQgZmV0Y2gsIGlmIGFueS5cblx0KiAtIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIC0gSWYgbm8gZmV0Y2ggaXMgaW4gcHJvZ3Jlc3MsIHJlc29sdmVzIGltbWVkaWF0ZWx5LlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IHF1ZXJ5LmNhbmNlbCgpXG5cdCogYGBgXG5cdCovXG5cdGNhbmNlbChvcHRpb25zKSB7XG5cdFx0Y29uc3QgcHJvbWlzZSA9IHRoaXMuI3JldHJ5ZXI/LnByb21pc2U7XG5cdFx0dGhpcy4jcmV0cnllcj8uY2FuY2VsKG9wdGlvbnMpO1xuXHRcdHJldHVybiBwcm9taXNlID8gcHJvbWlzZS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApIDogUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0LyoqXG5cdCogQ2xlYXJzIHRoZSBxdWVyeSdzIGdhcmJhZ2UgY29sbGVjdGlvbiB0aW1lb3V0IGFuZCBzaWxlbnRseSBjYW5jZWxzIGFueVxuXHQqIGluLWZsaWdodCBmZXRjaC4gQ2FsbGVkIGJ5IGBRdWVyeUNhY2hlYCB3aGVuIHRoZSBxdWVyeSBpcyByZW1vdmVkIGZyb21cblx0KiB0aGUgY2FjaGUuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeSNjYW5jZWx9XG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0c3VwZXIuZGVzdHJveSgpO1xuXHRcdHRoaXMuY2FuY2VsKHsgc2lsZW50OiB0cnVlIH0pO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0Z2V0IHJlc2V0U3RhdGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2luaXRpYWxTdGF0ZTtcblx0fVxuXHQvKipcblx0KiBSZXNldHMgdGhlIHF1ZXJ5IGJhY2sgdG8gaXRzIGluaXRpYWwgc3RhdGUgKHRoZSBzdGF0ZSBpdCBoYWQgd2hlbiBpdCB3YXNcblx0KiBmaXJzdCBjcmVhdGVkLCBlLmcuIGFueSBgaW5pdGlhbERhdGFgKSwgZGVzdHJveWluZyBpdCBmaXJzdCB0byBjYW5jZWwgYW55XG5cdCogaW4tZmxpZ2h0IGZldGNoLlxuXHQqL1xuXHRyZXNldCgpIHtcblx0XHR0aGlzLmRlc3Ryb3koKTtcblx0XHR0aGlzLnNldFN0YXRlKHRoaXMucmVzZXRTdGF0ZSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBhdCBsZWFzdCBvbmUgb2JzZXJ2ZXIgZm9yIHdoaWNoIGBlbmFibGVkYFxuXHQqIGRvZXMgbm90IHJlc29sdmUgdG8gYGZhbHNlYC5cblx0Ki9cblx0aXNBY3RpdmUoKSB7XG5cdFx0cmV0dXJuIHRoaXMub2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyKSA9PiByZXNvbHZlUXVlcnlWYWx1ZShvYnNlcnZlci5vcHRpb25zLmVuYWJsZWQsIHRoaXMpICE9PSBmYWxzZSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGlzIGRpc2FibGVkLCBtZWFuaW5nIGl0IHdpbGwgbm90IGZldGNoXG5cdCogYXV0b21hdGljYWxseS5cblx0KiAtIElmIHRoZSBxdWVyeSBoYXMgb2JzZXJ2ZXJzLCBpdCBpcyBkaXNhYmxlZCB3aGVuIG5vbmUgb2YgdGhlbSBhcmUgYWN0aXZlXG5cdCogICAoc2VlIGBpc0FjdGl2ZWApLlxuXHQqIC0gSWYgdGhlIHF1ZXJ5IGhhcyBubyBvYnNlcnZlcnMsIGl0IGlzIGRpc2FibGVkIHdoZW4gaXRzIGBxdWVyeUZuYCBpc1xuXHQqICAgYHNraXBUb2tlbmAgb3IgaXQgaGFzIG5ldmVyIGJlZW4gZmV0Y2hlZC5cblx0Ki9cblx0aXNEaXNhYmxlZCgpIHtcblx0XHRpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkgcmV0dXJuICF0aGlzLmlzQWN0aXZlKCk7XG5cdFx0cmV0dXJuIHRoaXMub3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4gfHwgIXRoaXMuaXNGZXRjaGVkKCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBiZWVuIGZldGNoZWQsIGkuZS4gaXQgaGFzIHJlc29sdmVkIHdpdGhcblx0KiBlaXRoZXIgZGF0YSBvciBhbiBlcnJvciBhdCBsZWFzdCBvbmNlLlxuXHQqL1xuXHRpc0ZldGNoZWQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuc3RhdGUuZGF0YVVwZGF0ZUNvdW50ICsgdGhpcy5zdGF0ZS5lcnJvclVwZGF0ZUNvdW50ID4gMDtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaGFzIGF0IGxlYXN0IG9uZSBvYnNlcnZlciBjb25maWd1cmVkIHdpdGhcblx0KiBgc3RhbGVUaW1lOiAnc3RhdGljJ2AsIG1lYW5pbmcgaXQgaXMgdHJlYXRlZCBhcyBuZXZlciBzdGFsZS5cblx0Ki9cblx0aXNTdGF0aWMoKSB7XG5cdFx0aWYgKHRoaXMuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA+IDApIHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKChvYnNlcnZlcikgPT4gcmVzb2x2ZVF1ZXJ5VmFsdWUob2JzZXJ2ZXIub3B0aW9ucy5zdGFsZVRpbWUsIHRoaXMpID09PSBcInN0YXRpY1wiKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGlzIHN0YWxlLlxuXHQqIC0gSWYgdGhlIHF1ZXJ5IGhhcyBvYnNlcnZlcnMsIGRlZmVycyB0byB3aGV0aGVyIGFueSBvYnNlcnZlcidzIGN1cnJlbnRcblx0KiAgIHJlc3VsdCByZXBvcnRzIGBpc1N0YWxlYCAod2hpY2ggYWNjb3VudHMgZm9yIGVhY2ggb2JzZXJ2ZXIncyBvd25cblx0KiAgIGBzdGFsZVRpbWVgIGFuZCBgZW5hYmxlZGAgc3RhdGUpLlxuXHQqIC0gSWYgdGhlIHF1ZXJ5IGhhcyBubyBvYnNlcnZlcnMsIGl0IGlzIGNvbnNpZGVyZWQgc3RhbGUgd2hlbiBpdCBoYXMgbm9cblx0KiAgIGRhdGEgb3IgaGFzIGJlZW4gaW52YWxpZGF0ZWQuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeSNpc1N0YWxlQnlUaW1lfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnkuaXNTdGFsZSgpKSB7XG5cdCogICAvLyByZWZldGNoIG9yIG90aGVyd2lzZSB0cmVhdCB0aGUgY2FjaGVkIGRhdGEgYXMgb3V0ZGF0ZWRcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzU3RhbGUoKSB7XG5cdFx0aWYgKHRoaXMuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA+IDApIHJldHVybiB0aGlzLm9ic2VydmVycy5zb21lKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLmlzU3RhbGUpO1xuXHRcdHJldHVybiB0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCB8fCB0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQ7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5J3MgZGF0YSBpcyBzdGFsZSByZWxhdGl2ZSB0byB0aGUgZ2l2ZW5cblx0KiBgc3RhbGVUaW1lYCAoZGVmYXVsdHMgdG8gYDBgKS5cblx0KiAtIEEgcXVlcnkgd2l0aCBubyBkYXRhIGlzIGFsd2F5cyBzdGFsZS5cblx0KiAtIGBzdGFsZVRpbWU6ICdzdGF0aWMnYCBpcyBuZXZlciBzdGFsZS5cblx0KiAtIEFuIGludmFsaWRhdGVkIHF1ZXJ5IGlzIGFsd2F5cyBzdGFsZS5cblx0KiAtIE90aGVyd2lzZSwgc3RhbGVuZXNzIGlzIGJhc2VkIG9uIGVsYXBzZWQgdGltZSBzaW5jZSBgZGF0YVVwZGF0ZWRBdGAuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeSNpc1N0YWxlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBpc1N0YWxlID0gcXVlcnkuaXNTdGFsZUJ5VGltZSgxMDAwICogNjApXG5cdCogYGBgXG5cdCovXG5cdGlzU3RhbGVCeVRpbWUoc3RhbGVUaW1lID0gMCkge1xuXHRcdGlmICh0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkgcmV0dXJuIHRydWU7XG5cdFx0aWYgKHN0YWxlVGltZSA9PT0gXCJzdGF0aWNcIikgcmV0dXJuIGZhbHNlO1xuXHRcdGlmICh0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQpIHJldHVybiB0cnVlO1xuXHRcdHJldHVybiAhdGltZVVudGlsU3RhbGUodGhpcy5zdGF0ZS5kYXRhVXBkYXRlZEF0LCBzdGFsZVRpbWUpO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0b25Gb2N1cygpIHtcblx0XHR0aGlzLm9ic2VydmVycy5maW5kKCh4KSA9PiB4LnNob3VsZEZldGNoT25XaW5kb3dGb2N1cygpKT8ucmVmZXRjaCh7IGNhbmNlbFJlZmV0Y2g6IGZhbHNlIH0pO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRvbk9ubGluZSgpIHtcblx0XHR0aGlzLm9ic2VydmVycy5maW5kKCh4KSA9PiB4LnNob3VsZEZldGNoT25SZWNvbm5lY3QoKSk/LnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KTtcblx0XHR0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0YWRkT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHRpZiAoIXRoaXMub2JzZXJ2ZXJzLmluY2x1ZGVzKG9ic2VydmVyKSkge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG5cdFx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdFx0XHR0aGlzLiNjYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyQWRkZWRcIixcblx0XHRcdFx0cXVlcnk6IHRoaXMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRyZW1vdmVPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdGNvbnN0IGluZGV4ID0gdGhpcy5vYnNlcnZlcnMuaW5kZXhPZihvYnNlcnZlcik7XG5cdFx0aWYgKGluZGV4ICE9PSAtMSkge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMuc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdGlmICghdGhpcy5vYnNlcnZlcnMubGVuZ3RoKSB7XG5cdFx0XHRcdGlmICh0aGlzLiNyZXRyeWVyKSB7XG5cdFx0XHRcdFx0aWYgKHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgfHwgdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJwYXVzZWRcIiAmJiB0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHRoaXMuI3JldHJ5ZXIuY2FuY2VsKHsgcmV2ZXJ0OiB0cnVlIH0pO1xuXHRcdFx0XHRcdGVsc2UgdGhpcy4jcmV0cnllci5jYW5jZWxSZXRyeSgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jY2FjaGUubm90aWZ5KHtcblx0XHRcdFx0dHlwZTogXCJvYnNlcnZlclJlbW92ZWRcIixcblx0XHRcdFx0cXVlcnk6IHRoaXMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIG9ic2VydmVycyBjdXJyZW50bHkgc3Vic2NyaWJlZCB0byB0aGlzIHF1ZXJ5LlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeS5nZXRPYnNlcnZlcnNDb3VudCgpID09PSAwKSB7XG5cdCogICAvLyBubyBjb21wb25lbnQgaXMgY3VycmVudGx5IHdhdGNoaW5nIHRoaXMgcXVlcnlcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGdldE9ic2VydmVyc0NvdW50KCkge1xuXHRcdHJldHVybiB0aGlzLm9ic2VydmVycy5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogTWFya3MgdGhlIHF1ZXJ5IGFzIGludmFsaWRhdGVkLCB1bmxlc3MgaXQgaXMgYWxyZWFkeSBpbnZhbGlkYXRlZC4gVGhpc1xuXHQqIHVwZGF0ZXMgYHN0YXRlLmlzSW52YWxpZGF0ZWRgIGFuZCBub3RpZmllcyBvYnNlcnZlcnMsIGJ1dCBkb2VzIG5vdCBieVxuXHQqIGl0c2VsZiB0cmlnZ2VyIGEgcmVmZXRjaC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeS5pbnZhbGlkYXRlKClcblx0KiBgYGBcblx0Ki9cblx0aW52YWxpZGF0ZSgpIHtcblx0XHRpZiAoIXRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZCkgdGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImludmFsaWRhdGVcIiB9KTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBxdWVyeSwgaS5lLiBydW5zIGl0cyBgcXVlcnlGbmAgKHRocm91Z2ggYW55IGNvbmZpZ3VyZWRcblx0KiByZXRyeWVyL2JlaGF2aW9yKSBhbmQgdXBkYXRlcyB0aGUgcXVlcnkncyBzdGF0ZSB3aXRoIHRoZSByZXN1bHQuXG5cdCogLSBJZiBhIGZldGNoIGlzIGFscmVhZHkgaW4gZmxpZ2h0LCByZXR1cm5zIGl0cyBwcm9taXNlIGluc3RlYWQgb2Zcblx0KiAgIHN0YXJ0aW5nIGEgbmV3IG9uZSwgdW5sZXNzIGBmZXRjaE9wdGlvbnMuY2FuY2VsUmVmZXRjaGAgaXMgc2V0IGFuZCB0aGVcblx0KiAgIHF1ZXJ5IGFscmVhZHkgaGFzIGRhdGEsIGluIHdoaWNoIGNhc2UgdGhlIGN1cnJlbnQgZmV0Y2ggaXMgc2lsZW50bHlcblx0KiAgIGNhbmNlbGxlZCBmaXJzdC5cblx0KiAtIElmIGBvcHRpb25zYCBpcyBwYXNzZWQsIGl0IHJlcGxhY2VzIHRoZSBxdWVyeSdzIGN1cnJlbnQgb3B0aW9uc1xuXHQqICAgYmVmb3JlIGZldGNoaW5nLlxuXHQqL1xuXHRhc3luYyBmZXRjaChvcHRpb25zLCBmZXRjaE9wdGlvbnMpIHtcblx0XHRpZiAodGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJpZGxlXCIgJiYgdGhpcy4jcmV0cnllcj8uc3RhdHVzKCkgIT09IFwicmVqZWN0ZWRcIikge1xuXHRcdFx0aWYgKHRoaXMuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIGZldGNoT3B0aW9ucz8uY2FuY2VsUmVmZXRjaCkgdGhpcy5jYW5jZWwoeyBzaWxlbnQ6IHRydWUgfSk7XG5cdFx0XHRlbHNlIGlmICh0aGlzLiNyZXRyeWVyKSB7XG5cdFx0XHRcdHRoaXMuI3JldHJ5ZXIuY29udGludWVSZXRyeSgpO1xuXHRcdFx0XHRyZXR1cm4gdGhpcy4jcmV0cnllci5wcm9taXNlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAob3B0aW9ucykgdGhpcy5zZXRPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmICghdGhpcy5vcHRpb25zLnF1ZXJ5Rm4pIHtcblx0XHRcdGNvbnN0IG9ic2VydmVyID0gdGhpcy5vYnNlcnZlcnMuZmluZCgoeCkgPT4geC5vcHRpb25zLnF1ZXJ5Rm4pO1xuXHRcdFx0aWYgKG9ic2VydmVyKSB0aGlzLnNldE9wdGlvbnMob2JzZXJ2ZXIub3B0aW9ucyk7XG5cdFx0fVxuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGlmICghQXJyYXkuaXNBcnJheSh0aGlzLm9wdGlvbnMucXVlcnlLZXkpKSBjb25zb2xlLmVycm9yKGBBcyBvZiB2NCwgcXVlcnlLZXkgbmVlZHMgdG8gYmUgYW4gQXJyYXkuIElmIHlvdSBhcmUgdXNpbmcgYSBzdHJpbmcgbGlrZSAncmVwb0RhdGEnLCBwbGVhc2UgY2hhbmdlIGl0IHRvIGFuIEFycmF5LCBlLmcuIFsncmVwb0RhdGEnXWApO1xuXHRcdH1cblx0XHRjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0Y29uc3QgYWRkU2lnbmFsUHJvcGVydHkgPSAob2JqZWN0KSA9PiB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkob2JqZWN0LCBcInNpZ25hbFwiLCB7XG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHRcdHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgPSB0cnVlO1xuXHRcdFx0XHRcdHJldHVybiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdGNvbnN0IGZldGNoRm4gPSAoKSA9PiB7XG5cdFx0XHRjb25zdCBxdWVyeUZuID0gZW5zdXJlUXVlcnlGbih0aGlzLm9wdGlvbnMsIGZldGNoT3B0aW9ucyk7XG5cdFx0XHRjb25zdCBjcmVhdGVRdWVyeUZuQ29udGV4dCA9ICgpID0+IHtcblx0XHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSB7XG5cdFx0XHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRcdFx0cXVlcnlLZXk6IHRoaXMucXVlcnlLZXksXG5cdFx0XHRcdFx0bWV0YTogdGhpcy5tZXRhXG5cdFx0XHRcdH07XG5cdFx0XHRcdGFkZFNpZ25hbFByb3BlcnR5KHF1ZXJ5Rm5Db250ZXh0KTtcblx0XHRcdFx0cmV0dXJuIHF1ZXJ5Rm5Db250ZXh0O1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0gY3JlYXRlUXVlcnlGbkNvbnRleHQoKTtcblx0XHRcdHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgPSBmYWxzZTtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMucGVyc2lzdGVyKSByZXR1cm4gdGhpcy5vcHRpb25zLnBlcnNpc3RlcihxdWVyeUZuLCBxdWVyeUZuQ29udGV4dCwgdGhpcyk7XG5cdFx0XHRyZXR1cm4gcXVlcnlGbihxdWVyeUZuQ29udGV4dCk7XG5cdFx0fTtcblx0XHRjb25zdCBjcmVhdGVGZXRjaENvbnRleHQgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCBjb250ZXh0ID0ge1xuXHRcdFx0XHRmZXRjaE9wdGlvbnMsXG5cdFx0XHRcdG9wdGlvbnM6IHRoaXMub3B0aW9ucyxcblx0XHRcdFx0cXVlcnlLZXk6IHRoaXMucXVlcnlLZXksXG5cdFx0XHRcdGNsaWVudDogdGhpcy4jY2xpZW50LFxuXHRcdFx0XHRzdGF0ZTogdGhpcy5zdGF0ZSxcblx0XHRcdFx0ZmV0Y2hGblxuXHRcdFx0fTtcblx0XHRcdGFkZFNpZ25hbFByb3BlcnR5KGNvbnRleHQpO1xuXHRcdFx0cmV0dXJuIGNvbnRleHQ7XG5cdFx0fTtcblx0XHRjb25zdCBjb250ZXh0ID0gY3JlYXRlRmV0Y2hDb250ZXh0KCk7XG5cdFx0KHRoaXMuI3F1ZXJ5VHlwZSA9PT0gXCJpbmZpbml0ZVwiID8gaW5maW5pdGVRdWVyeUJlaGF2aW9yKHRoaXMub3B0aW9ucy5wYWdlcykgOiB0aGlzLm9wdGlvbnMuYmVoYXZpb3IpPy5vbkZldGNoKGNvbnRleHQsIHRoaXMpO1xuXHRcdHRoaXMuI3JldmVydFN0YXRlID0gdGhpcy5zdGF0ZTtcblx0XHRpZiAodGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJpZGxlXCIgfHwgdGhpcy5zdGF0ZS5mZXRjaE1ldGEgIT09IGNvbnRleHQuZmV0Y2hPcHRpb25zPy5tZXRhKSB0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHR0eXBlOiBcImZldGNoXCIsXG5cdFx0XHRtZXRhOiBjb250ZXh0LmZldGNoT3B0aW9ucz8ubWV0YVxuXHRcdH0pO1xuXHRcdGNvbnN0IHJldHJ5ZXIgPSB0aGlzLiNyZXRyeWVyID0gY3JlYXRlUmV0cnllcih7XG5cdFx0XHRpbml0aWFsUHJvbWlzZTogZmV0Y2hPcHRpb25zPy5pbml0aWFsUHJvbWlzZSxcblx0XHRcdGZuOiBjb250ZXh0LmZldGNoRm4sXG5cdFx0XHRvbkNhbmNlbDogKGVycm9yKSA9PiB7XG5cdFx0XHRcdGlmIChlcnJvciBpbnN0YW5jZW9mIENhbmNlbGxlZEVycm9yICYmIGVycm9yLnJldmVydCkgdGhpcy5zZXRTdGF0ZSh7XG5cdFx0XHRcdFx0Li4udGhpcy4jcmV2ZXJ0U3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwiaWRsZVwiXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRcdH0sXG5cdFx0XHRvbkZhaWw6IChmYWlsdXJlQ291bnQsIGVycm9yKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcImZhaWxlZFwiLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRlcnJvclxuXHRcdFx0XHR9KTtcblx0XHRcdH0sXG5cdFx0XHRvblBhdXNlOiAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJwYXVzZVwiIH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uQ29udGludWU6ICgpID0+IHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goeyB0eXBlOiBcImNvbnRpbnVlXCIgfSk7XG5cdFx0XHR9LFxuXHRcdFx0cmV0cnk6IGNvbnRleHQub3B0aW9ucy5yZXRyeSxcblx0XHRcdHJldHJ5RGVsYXk6IGNvbnRleHQub3B0aW9ucy5yZXRyeURlbGF5LFxuXHRcdFx0bmV0d29ya01vZGU6IGNvbnRleHQub3B0aW9ucy5uZXR3b3JrTW9kZSxcblx0XHRcdGNhblJ1bjogKCkgPT4gdHJ1ZVxuXHRcdH0pO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBkYXRhID0gYXdhaXQgcmV0cnllci5zdGFydCgpO1xuXHRcdFx0aWYgKGRhdGEgPT09IHZvaWQgMCkge1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLmVycm9yKGBRdWVyeSBkYXRhIGNhbm5vdCBiZSB1bmRlZmluZWQuIFBsZWFzZSBtYWtlIHN1cmUgdG8gcmV0dXJuIGEgdmFsdWUgb3RoZXIgdGhhbiB1bmRlZmluZWQgZnJvbSB5b3VyIHF1ZXJ5IGZ1bmN0aW9uLiBBZmZlY3RlZCBxdWVyeSBrZXk6ICR7dGhpcy5xdWVyeUhhc2h9YCk7XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcihgJHt0aGlzLnF1ZXJ5SGFzaH0gZGF0YSBpcyB1bmRlZmluZWRgKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuc2V0RGF0YShkYXRhKTtcblx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vblN1Y2Nlc3M/LihkYXRhLCB0aGlzKTtcblx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vblNldHRsZWQ/LihkYXRhLCB0aGlzLnN0YXRlLmVycm9yLCB0aGlzKTtcblx0XHRcdHJldHVybiBkYXRhO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvcikge1xuXHRcdFx0XHRpZiAoZXJyb3Iuc2lsZW50KSByZXR1cm4gdGhpcy4jcmV0cnllci5wcm9taXNlO1xuXHRcdFx0XHRlbHNlIGlmIChlcnJvci5yZXZlcnQpIHtcblx0XHRcdFx0XHRpZiAodGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHRocm93IGVycm9yO1xuXHRcdFx0XHRcdHJldHVybiB0aGlzLnN0YXRlLmRhdGE7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0dHlwZTogXCJlcnJvclwiLFxuXHRcdFx0XHRlcnJvclxuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25FcnJvcj8uKGVycm9yLCB0aGlzKTtcblx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vblNldHRsZWQ/Lih0aGlzLnN0YXRlLmRhdGEsIGVycm9yLCB0aGlzKTtcblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRpZiAodGhpcy4jcmV0cnllciA9PT0gcmV0cnllcikgdGhpcy4jcmV0cnllciA9IHZvaWQgMDtcblx0XHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHRcdH1cblx0fVxuXHQjZGlzcGF0Y2goYWN0aW9uKSB7XG5cdFx0Y29uc3QgcmVkdWNlciA9IChzdGF0ZSkgPT4ge1xuXHRcdFx0c3dpdGNoIChhY3Rpb24udHlwZSkge1xuXHRcdFx0XHRjYXNlIFwiZmFpbGVkXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IGFjdGlvbi5mYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBhY3Rpb24uZXJyb3Jcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInBhdXNlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwicGF1c2VkXCJcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImNvbnRpbnVlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiZmV0Y2hcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHQuLi5mZXRjaFN0YXRlKHN0YXRlLmRhdGEsIHRoaXMub3B0aW9ucyksXG5cdFx0XHRcdFx0ZmV0Y2hNZXRhOiBhY3Rpb24ubWV0YSA/PyBudWxsXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJzdWNjZXNzXCI6XG5cdFx0XHRcdFx0Y29uc3QgbmV3U3RhdGUgPSB7XG5cdFx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRcdC4uLnN1Y2Nlc3NTdGF0ZShhY3Rpb24uZGF0YSwgYWN0aW9uLmRhdGFVcGRhdGVkQXQpLFxuXHRcdFx0XHRcdFx0ZGF0YVVwZGF0ZUNvdW50OiBzdGF0ZS5kYXRhVXBkYXRlQ291bnQgKyAxLFxuXHRcdFx0XHRcdFx0Li4uIWFjdGlvbi5tYW51YWwgJiYge1xuXHRcdFx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJpZGxlXCIsXG5cdFx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZUNvdW50OiAwLFxuXHRcdFx0XHRcdFx0XHRmZXRjaEZhaWx1cmVSZWFzb246IG51bGxcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdHRoaXMuI3JldmVydFN0YXRlID0gYWN0aW9uLm1hbnVhbCA/IG5ld1N0YXRlIDogdm9pZCAwO1xuXHRcdFx0XHRcdHJldHVybiBuZXdTdGF0ZTtcblx0XHRcdFx0Y2FzZSBcImVycm9yXCI6XG5cdFx0XHRcdFx0Y29uc3QgZXJyb3IgPSBhY3Rpb24uZXJyb3I7XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdFx0ZXJyb3IsXG5cdFx0XHRcdFx0XHRlcnJvclVwZGF0ZUNvdW50OiBzdGF0ZS5lcnJvclVwZGF0ZUNvdW50ICsgMSxcblx0XHRcdFx0XHRcdGVycm9yVXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IHN0YXRlLmZldGNoRmFpbHVyZUNvdW50ICsgMSxcblx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZVJlYXNvbjogZXJyb3IsXG5cdFx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJpZGxlXCIsXG5cdFx0XHRcdFx0XHRzdGF0dXM6IFwiZXJyb3JcIixcblx0XHRcdFx0XHRcdGlzSW52YWxpZGF0ZWQ6IHRydWVcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiaW52YWxpZGF0ZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzSW52YWxpZGF0ZWQ6IHRydWVcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInNldFN0YXRlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0Li4uYWN0aW9uLnN0YXRlXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fTtcblx0XHR0aGlzLnN0YXRlID0gcmVkdWNlcih0aGlzLnN0YXRlKTtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMub2JzZXJ2ZXJzLnNsaWNlKCkuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0b2JzZXJ2ZXIub25RdWVyeVVwZGF0ZSgpO1xuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNjYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHRxdWVyeTogdGhpcyxcblx0XHRcdFx0dHlwZTogXCJ1cGRhdGVkXCIsXG5cdFx0XHRcdGFjdGlvblxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG5mdW5jdGlvbiBmZXRjaFN0YXRlKGRhdGEsIG9wdGlvbnMpIHtcblx0cmV0dXJuIHtcblx0XHRmZXRjaEZhaWx1cmVDb3VudDogMCxcblx0XHRmZXRjaEZhaWx1cmVSZWFzb246IG51bGwsXG5cdFx0ZmV0Y2hTdGF0dXM6IGNhbkZldGNoKG9wdGlvbnMubmV0d29ya01vZGUpID8gXCJmZXRjaGluZ1wiIDogXCJwYXVzZWRcIixcblx0XHQuLi5kYXRhID09PSB2b2lkIDAgJiYge1xuXHRcdFx0ZXJyb3I6IG51bGwsXG5cdFx0XHRzdGF0dXM6IFwicGVuZGluZ1wiXG5cdFx0fVxuXHR9O1xufVxuZnVuY3Rpb24gc3VjY2Vzc1N0YXRlKGRhdGEsIGRhdGFVcGRhdGVkQXQpIHtcblx0cmV0dXJuIHtcblx0XHRkYXRhLFxuXHRcdGRhdGFVcGRhdGVkQXQ6IGRhdGFVcGRhdGVkQXQgPz8gRGF0ZS5ub3coKSxcblx0XHRlcnJvcjogbnVsbCxcblx0XHRpc0ludmFsaWRhdGVkOiBmYWxzZSxcblx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiXG5cdH07XG59XG5mdW5jdGlvbiBnZXREZWZhdWx0U3RhdGUob3B0aW9ucykge1xuXHRjb25zdCBkYXRhID0gdHlwZW9mIG9wdGlvbnMuaW5pdGlhbERhdGEgPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMuaW5pdGlhbERhdGEoKSA6IG9wdGlvbnMuaW5pdGlhbERhdGE7XG5cdGNvbnN0IGhhc0RhdGEgPSBkYXRhICE9PSB2b2lkIDA7XG5cdGNvbnN0IGluaXRpYWxEYXRhVXBkYXRlZEF0ID0gaGFzRGF0YSA/IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhVXBkYXRlZEF0ID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhVXBkYXRlZEF0KCkgOiBvcHRpb25zLmluaXRpYWxEYXRhVXBkYXRlZEF0IDogMDtcblx0cmV0dXJuIHtcblx0XHRkYXRhLFxuXHRcdGRhdGFVcGRhdGVDb3VudDogMCxcblx0XHRkYXRhVXBkYXRlZEF0OiBoYXNEYXRhID8gaW5pdGlhbERhdGFVcGRhdGVkQXQgPz8gRGF0ZS5ub3coKSA6IDAsXG5cdFx0ZXJyb3I6IG51bGwsXG5cdFx0ZXJyb3JVcGRhdGVDb3VudDogMCxcblx0XHRlcnJvclVwZGF0ZWRBdDogMCxcblx0XHRmZXRjaEZhaWx1cmVDb3VudDogMCxcblx0XHRmZXRjaEZhaWx1cmVSZWFzb246IG51bGwsXG5cdFx0ZmV0Y2hNZXRhOiBudWxsLFxuXHRcdGlzSW52YWxpZGF0ZWQ6IGZhbHNlLFxuXHRcdHN0YXR1czogaGFzRGF0YSA/IFwic3VjY2Vzc1wiIDogXCJwZW5kaW5nXCIsXG5cdFx0ZmV0Y2hTdGF0dXM6IFwiaWRsZVwiXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFF1ZXJ5LCBmZXRjaFN0YXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5LmpzLm1hcCIsImltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGlzVmFsaWRUaW1lb3V0LCBub29wLCByZXBsYWNlRGF0YSwgcmVzb2x2ZVF1ZXJ5VmFsdWUsIHNoYWxsb3dFcXVhbE9iamVjdHMsIHRpbWVVbnRpbFN0YWxlIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIi4vZW52aXJvbm1lbnRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGZldGNoU3RhdGUgfSBmcm9tIFwiLi9xdWVyeS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeU9ic2VydmVyLnRzXG4vKipcbiogQSBgUXVlcnlPYnNlcnZlcmAgd2F0Y2hlcyBhIHNpbmdsZSBxdWVyeSBpbiB0aGUgYFF1ZXJ5Q2FjaGVgIGFuZCBjb21wdXRlcyBhXG4qIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBmcm9tIGl0cyBzdGF0ZSwgcmVjb21wdXRpbmcgYW5kIG5vdGlmeWluZyBzdWJzY3JpYmVyc1xuKiB3aGVuZXZlciB0aGUgdW5kZXJseWluZyBxdWVyeSAob3IgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucykgY2hhbmdlcy4gSXQgaXNcbiogdGhlIHByaW1pdGl2ZSB0aGF0IGZyYW1ld29yayBhZGFwdGVycyAoZS5nLiBgdXNlUXVlcnlgKSBidWlsZCB0aGVpciBob29rc1xuKiBvbiB0b3Agb2YsIGJ1dCBpdCBjYW4gYWxzbyBiZSB1c2VkIGRpcmVjdGx5IHRvIG9ic2VydmUgYW5kIHN3aXRjaCBiZXR3ZWVuXG4qIHF1ZXJpZXMgb3V0c2lkZSBvZiBhbnkgZnJhbWV3b3JrLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICBxdWVyeUZuOiBmZXRjaFBvc3RzLFxuKiB9KVxuKlxuKiBjb25zdCB1bnN1YnNjcmliZSA9IG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG4qICAgY29uc29sZS5sb2cocmVzdWx0LmRhdGEpXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBRdWVyeU9ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjY2xpZW50O1xuXHQjY3VycmVudFF1ZXJ5ID0gdm9pZCAwO1xuXHQjY3VycmVudFF1ZXJ5SW5pdGlhbFN0YXRlID0gdm9pZCAwO1xuXHQjY3VycmVudFJlc3VsdCA9IHZvaWQgMDtcblx0I2N1cnJlbnRSZXN1bHRTdGF0ZTtcblx0I2N1cnJlbnRSZXN1bHRPcHRpb25zO1xuXHQjc2VsZWN0RXJyb3I7XG5cdCNzZWxlY3RGbjtcblx0I3NlbGVjdFJlc3VsdDtcblx0I2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YTtcblx0I3N0YWxlVGltZW91dElkO1xuXHQjcmVmZXRjaEludGVydmFsSWQ7XG5cdCNjdXJyZW50UmVmZXRjaEludGVydmFsO1xuXHQjdHJhY2tlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3RydWN0b3IoY2xpZW50LCBvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNsaWVudDtcblx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0dGhpcy5iaW5kTWV0aG9kcygpO1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fVxuXHRiaW5kTWV0aG9kcygpIHtcblx0XHR0aGlzLnJlZmV0Y2ggPSB0aGlzLnJlZmV0Y2guYmluZCh0aGlzKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkge1xuXHRcdFx0dGhpcy4jY3VycmVudFF1ZXJ5LmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdFx0aWYgKHNob3VsZEZldGNoT25Nb3VudCh0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucykpIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuXHRcdFx0ZWxzZSB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdFx0dGhpcy4jdXBkYXRlVGltZXJzKCk7XG5cdFx0fVxuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB0aGlzLmRlc3Ryb3koKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHdoZXRoZXIgdGhlIG9ic2VydmVkIHF1ZXJ5IGlzIGN1cnJlbnRseSBzdGFsZSBhbmQgY29uZmlndXJlZFxuXHQqICh2aWEgdGhlIGByZWZldGNoT25SZWNvbm5lY3RgIG9wdGlvbikgdG8gcmVmZXRjaCB3aGVuIHRoZSBuZXR3b3JrXG5cdCogcmVjb25uZWN0cy5cblx0Ki9cblx0c2hvdWxkRmV0Y2hPblJlY29ubmVjdCgpIHtcblx0XHRyZXR1cm4gc2hvdWxkRmV0Y2hPbih0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucywgdGhpcy5vcHRpb25zLnJlZmV0Y2hPblJlY29ubmVjdCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB3aGV0aGVyIHRoZSBvYnNlcnZlZCBxdWVyeSBpcyBjdXJyZW50bHkgc3RhbGUgYW5kIGNvbmZpZ3VyZWRcblx0KiAodmlhIHRoZSBgcmVmZXRjaE9uV2luZG93Rm9jdXNgIG9wdGlvbikgdG8gcmVmZXRjaCB3aGVuIHRoZSB3aW5kb3dcblx0KiByZWdhaW5zIGZvY3VzLlxuXHQqL1xuXHRzaG91bGRGZXRjaE9uV2luZG93Rm9jdXMoKSB7XG5cdFx0cmV0dXJuIHNob3VsZEZldGNoT24odGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHRoaXMub3B0aW9ucy5yZWZldGNoT25XaW5kb3dGb2N1cyk7XG5cdH1cblx0LyoqXG5cdCogU3RvcHMgb2JzZXJ2aW5nIHRoZSBjdXJyZW50IHF1ZXJ5OiBjbGVhcnMgYWxsIGxpc3RlbmVycywgY2FuY2VscyB0aGVcblx0KiBzdGFsZSBhbmQgcmVmZXRjaC1pbnRlcnZhbCB0aW1lcnMsIGFuZCByZW1vdmVzIHRoaXMgb2JzZXJ2ZXIgZnJvbSB0aGVcblx0KiBxdWVyeSBpdCB3YXMgb2JzZXJ2aW5nLlxuXHQqL1xuXHRkZXN0cm95KCkge1xuXHRcdHRoaXMubGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLiNjbGVhclN0YWxlVGltZW91dCgpO1xuXHRcdHRoaXMuI2NsZWFyUmVmZXRjaEludGVydmFsKCk7XG5cdFx0dGhpcy4jY3VycmVudFF1ZXJ5LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucy4gVGhpcyB3aWxsIHJlLXJlc29sdmUgdGhlIHF1ZXJ5IGJlaW5nXG5cdCogb2JzZXJ2ZWQgKHN3aXRjaGluZyB0byBhIGRpZmZlcmVudCBxdWVyeSBpZiB0aGUgYHF1ZXJ5S2V5YCBjaGFuZ2VkKSxcblx0KiB0cmlnZ2VyIGEgZmV0Y2ggaWYgdGhlIG5ldyBvcHRpb25zIHJlcXVpcmUgb25lIGFuZCB0aGUgb2JzZXJ2ZXIgaGFzXG5cdCogc3Vic2NyaWJlcnMsIHJlY29tcHV0ZSB0aGUgY3VycmVudCByZXN1bHQsIGFuZCByZXNjaGVkdWxlIHRoZSBzdGFsZSBhbmRcblx0KiByZWZldGNoLWludGVydmFsIHRpbWVycyBhcyBuZWVkZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIuc2V0T3B0aW9ucyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJywgMV0sIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdCgxKSB9KVxuXHQqIC8vIGxhdGVyOiBzd2l0Y2ggdG8gYSBkaWZmZXJlbnQgcXVlcnksIHJldXNpbmcgdGhlIHNhbWUgb2JzZXJ2ZXJcblx0KiBvYnNlcnZlci5zZXRPcHRpb25zKHsgcXVlcnlLZXk6IFsncG9zdHMnLCAyXSwgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0XHR0aGlzLm9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAodGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IHZvaWQgMCAmJiB0eXBlb2YgdGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IFwiYm9vbGVhblwiICYmIHR5cGVvZiB0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gXCJib29sZWFuXCIpIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIGVuYWJsZWQgdG8gYmUgYSBib29sZWFuIG9yIGEgY2FsbGJhY2sgdGhhdCByZXR1cm5zIGEgYm9vbGVhblwiKTtcblx0XHR0aGlzLiN1cGRhdGVRdWVyeSgpO1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeS5zZXRPcHRpb25zKHRoaXMub3B0aW9ucyk7XG5cdFx0aWYgKHByZXZPcHRpb25zLl9kZWZhdWx0ZWQgJiYgIXNoYWxsb3dFcXVhbE9iamVjdHModGhpcy5vcHRpb25zLCBwcmV2T3B0aW9ucykpIHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuXHRcdFx0cXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcblx0XHRcdG9ic2VydmVyOiB0aGlzXG5cdFx0fSk7XG5cdFx0Y29uc3QgbW91bnRlZCA9IHRoaXMuaGFzTGlzdGVuZXJzKCk7XG5cdFx0aWYgKG1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHRoaXMuI2N1cnJlbnRRdWVyeSwgcHJldlF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0dGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHRpZiAobW91bnRlZCAmJiAodGhpcy4jY3VycmVudFF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gcmVzb2x2ZVF1ZXJ5VmFsdWUocHJldk9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpKSkgdGhpcy4jdXBkYXRlU3RhbGVUaW1lb3V0KCk7XG5cdFx0Y29uc3QgbmV4dFJlZmV0Y2hJbnRlcnZhbCA9IHRoaXMuI2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKTtcblx0XHRpZiAobW91bnRlZCAmJiAodGhpcy4jY3VycmVudFF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgbmV4dFJlZmV0Y2hJbnRlcnZhbCAhPT0gdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHRoaXMuI3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0UmVmZXRjaEludGVydmFsKTtcblx0fVxuXHQvKipcblx0KiBDb21wdXRlcyB0aGUgcmVzdWx0IHRoZSBvYnNlcnZlciB3b3VsZCBwcm9kdWNlIGZvciB0aGUgZ2l2ZW4gKGFscmVhZHktZGVmYXVsdGVkKSBvcHRpb25zXG5cdCogcmlnaHQgbm93LCBidWlsZGluZyB0aGUgdW5kZXJseWluZyBgUXVlcnlgIGlmIGl0IGRvZXNuJ3QgZXhpc3QgeWV0LCB3aXRob3V0IHdhaXRpbmcgZm9yIGFcblx0KiBzdWJzY3JpcHRpb24gY2FsbGJhY2suIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgb24gZXZlcnkgcmVuZGVyIChlLmcuIGB1c2VRdWVyeWApIHNvIHRoZVxuXHQqIHJldHVybmVkIHZhbHVlIGlzIGF2YWlsYWJsZSBzeW5jaHJvbm91c2x5LCBhaGVhZCBvZiBgc2V0T3B0aW9uc2AgdHJpZ2dlcmluZyBhbiBhY3R1YWwgZmV0Y2guXG5cdCovXG5cdGdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucykge1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIG9wdGlvbnMpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IHRoaXMuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKTtcblx0XHRpZiAoIXNoYWxsb3dFcXVhbE9iamVjdHModGhpcy5nZXRDdXJyZW50UmVzdWx0KCksIHJlc3VsdCkpIHtcblx0XHRcdHRoaXMuI2N1cnJlbnRSZXN1bHQgPSByZXN1bHQ7XG5cdFx0XHR0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZSA9IHRoaXMuI2N1cnJlbnRRdWVyeS5zdGF0ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBtb3N0IHJlY2VudGx5IGNvbXB1dGVkIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBmb3IgdGhlXG5cdCogb2JzZXJ2ZWQgcXVlcnkuIFRoaXMgaXMgYSBwb2ludC1pbi10aW1lIHJlYWQ7IHRvIGJlIG5vdGlmaWVkIG9mIHVwZGF0ZXNcblx0KiBhcyB0aGV5IGhhcHBlbiwgc3Vic2NyaWJlIHRvIHRoZSBvYnNlcnZlciBpbnN0ZWFkIChpdHMgaW5oZXJpdGVkXG5cdCogYHN1YnNjcmliZWAgbWV0aG9kKS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCByZXN1bHQgPSBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KClcblx0KiBjb25zb2xlLmxvZyhyZXN1bHQuc3RhdHVzLCByZXN1bHQuZGF0YSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0Q3VycmVudFJlc3VsdCgpIHtcblx0XHRyZXR1cm4gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0fVxuXHQvKipcblx0KiBXcmFwcyBhIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBpbiBhIGBQcm94eWAgdGhhdCByZWNvcmRzIHdoaWNoIHByb3BlcnRpZXMgYXJlIHJlYWQsIHZpYVxuXHQqIHtAbGluayBRdWVyeU9ic2VydmVyI3RyYWNrUHJvcH0gKGFuZCBhbiBvcHRpb25hbCBgb25Qcm9wVHJhY2tlZGAgY2FsbGJhY2spLiBVc2VkIGJ5IGZyYW1ld29ya1xuXHQqIGFkYXB0ZXJzIHdoZW4gYG5vdGlmeU9uQ2hhbmdlUHJvcHNgIGlzIG5vdCBzZXQsIHRvIGltcGxlbWVudCBpdHMgZGVmYXVsdCBcIm9ubHkgcmUtcmVuZGVyIG9uXG5cdCogcHJvcGVydGllcyB5b3UgYWN0dWFsbHkgcmVhZFwiIGJlaGF2aW9yLlxuXHQqL1xuXHR0cmFja1Jlc3VsdChyZXN1bHQsIG9uUHJvcFRyYWNrZWQpIHtcblx0XHRyZXR1cm4gbmV3IFByb3h5KHJlc3VsdCwgeyBnZXQ6ICh0YXJnZXQsIGtleSkgPT4ge1xuXHRcdFx0dGhpcy50cmFja1Byb3Aoa2V5KTtcblx0XHRcdG9uUHJvcFRyYWNrZWQ/LihrZXkpO1xuXHRcdFx0cmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwga2V5KTtcblx0XHR9IH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJlY29yZHMgdGhhdCB0aGUgZ2l2ZW4gYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIHByb3BlcnR5IHdhcyByZWFkLCBzbyBhIHN1YnNlcXVlbnQgdXBkYXRlIG9ubHlcblx0KiBub3RpZmllcyB0aGlzIG9ic2VydmVyIGlmIGEgdHJhY2tlZCBwcm9wZXJ0eSBhY3R1YWxseSBjaGFuZ2VkLiBOb3JtYWxseSBjYWxsZWQgaW5kaXJlY3RseSB2aWFcblx0KiB7QGxpbmsgUXVlcnlPYnNlcnZlciN0cmFja1Jlc3VsdH0ncyBwcm94eTsgZXhwb3NlZCBkaXJlY3RseSBmb3IgYWRhcHRlcnMgdGhhdCB0cmFjayBwcm9wZXJ0eVxuXHQqIGFjY2VzcyB0aGVtc2VsdmVzIChlLmcuIHRocm91Z2ggdGhlaXIgb3duIHJlYWN0aXZpdHkgc3lzdGVtKSBpbnN0ZWFkIG9mIHZpYSB0aGUgcHJveHkuXG5cdCovXG5cdHRyYWNrUHJvcChrZXkpIHtcblx0XHR0aGlzLiN0cmFja2VkUHJvcHMuYWRkKGtleSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSB0aGlzIG9ic2VydmVyIGlzIGN1cnJlbnRseSBvYnNlcnZpbmcuXG5cdCovXG5cdGdldEN1cnJlbnRRdWVyeSgpIHtcblx0XHRyZXR1cm4gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHR9XG5cdC8qKlxuXHQqIFJlZmV0Y2hlcyB0aGUgb2JzZXJ2ZWQgcXVlcnkgYW5kIHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aFxuXHQqIHRoZSByZXN1bHRpbmcgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoKHsgLi4ub3B0aW9ucyB9ID0ge30pIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7IC4uLm9wdGlvbnMgfSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhIHF1ZXJ5IGRlZmluZWQgYnkgdGhlIGdpdmVuIG9wdGlvbnMgd2l0aG91dCBhZmZlY3RpbmcgdGhpc1xuXHQqIG9ic2VydmVyJ3Mgb3duIHRyYWNrZWQgcXVlcnkgb3IgcmVzdWx0LCBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdFxuXHQqIHJlc29sdmVzIHdpdGggdGhlIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBmb3IgdGhhdCBmZXRjaC4gVGhpcyBpcyB1c2VmdWxcblx0KiBmb3IgcHJlZmV0Y2hpbmcgZGF0YSB0aGF0IGFub3RoZXIgb2JzZXJ2ZXIgKGUuZy4gYSBxdWVyeSBhYm91dCB0byBiZVxuXHQqIG5hdmlnYXRlZCB0bykgd2lsbCBuZWVkLCBhaGVhZCBvZiB0aW1lLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLmZldGNoT3B0aW1pc3RpYyh7XG5cdCogICBxdWVyeUtleTogWydwb3N0cycsIDJdLFxuXHQqICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpLFxuXHQqIH0pXG5cdCogY29uc29sZS5sb2cocmVzdWx0LmRhdGEpXG5cdCogYGBgXG5cdCovXG5cdGZldGNoT3B0aW1pc3RpYyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdGxldCB1bnN1YnNjcmliZSA9ICgpID0+IHt9O1xuXHRcdGxldCByZXNvbHZlRWFybHk7XG5cdFx0Y29uc3QgY2FjaGVQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHJlc29sdmVFYXJseSA9IHJlc29sdmU7XG5cdFx0XHR1bnN1YnNjcmliZSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuXHRcdFx0XHRpZiAoZXZlbnQudHlwZSA9PT0gXCJ1cGRhdGVkXCIgJiYgZXZlbnQucXVlcnkucXVlcnlIYXNoID09PSBxdWVyeS5xdWVyeUhhc2ggJiYgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0dW5zdWJzY3JpYmUoKTtcblx0XHRcdFx0XHRyZXNvbHZlKHRoaXMuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBQcm9taXNlLnJhY2UoW3F1ZXJ5LmZldGNoKCkudGhlbigoKSA9PiB7XG5cdFx0XHRjb25zdCByZXN1bHQgPSB0aGlzLmNyZWF0ZVJlc3VsdChxdWVyeSwgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0XHRyZXNvbHZlRWFybHk/LihyZXN1bHQpO1xuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9KS5maW5hbGx5KCgpID0+IHtcblx0XHRcdHVuc3Vic2NyaWJlKCk7XG5cdFx0fSksIGNhY2hlUHJvbWlzZV0pO1xuXHR9XG5cdGZldGNoKGZldGNoT3B0aW9ucykge1xuXHRcdHJldHVybiB0aGlzLiNleGVjdXRlRmV0Y2goe1xuXHRcdFx0Li4uZmV0Y2hPcHRpb25zLFxuXHRcdFx0Y2FuY2VsUmVmZXRjaDogZmV0Y2hPcHRpb25zLmNhbmNlbFJlZmV0Y2ggPz8gdHJ1ZVxuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0dGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHRcdHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHRcdH0pO1xuXHR9XG5cdCNleGVjdXRlRmV0Y2goZmV0Y2hPcHRpb25zKSB7XG5cdFx0dGhpcy4jdXBkYXRlUXVlcnkoKTtcblx0XHRsZXQgcHJvbWlzZSA9IHRoaXMuI2N1cnJlbnRRdWVyeS5mZXRjaCh0aGlzLm9wdGlvbnMsIGZldGNoT3B0aW9ucyk7XG5cdFx0aWYgKCFmZXRjaE9wdGlvbnM/LnRocm93T25FcnJvcikgcHJvbWlzZSA9IHByb21pc2UuY2F0Y2gobm9vcCk7XG5cdFx0cmV0dXJuIHByb21pc2U7XG5cdH1cblx0I3Nob3VsZFNjaGVkdWxlVGltZXIodGltZW91dCkge1xuXHRcdHJldHVybiAhaXNTZXJ2ZXIoKSAmJiByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gZmFsc2UgJiYgaXNWYWxpZFRpbWVvdXQodGltZW91dCk7XG5cdH1cblx0I3VwZGF0ZVN0YWxlVGltZW91dCgpIHtcblx0XHR0aGlzLiNjbGVhclN0YWxlVGltZW91dCgpO1xuXHRcdGNvbnN0IHN0YWxlVGltZSA9IHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5zdGFsZVRpbWUsIHRoaXMuI2N1cnJlbnRRdWVyeSk7XG5cdFx0aWYgKHRoaXMuI2N1cnJlbnRSZXN1bHQuaXNTdGFsZSB8fCAhdGhpcy4jc2hvdWxkU2NoZWR1bGVUaW1lcihzdGFsZVRpbWUpKSByZXR1cm47XG5cdFx0Y29uc3QgdGltZW91dCA9IHRpbWVVbnRpbFN0YWxlKHRoaXMuI2N1cnJlbnRSZXN1bHQuZGF0YVVwZGF0ZWRBdCwgc3RhbGVUaW1lKSArIDE7XG5cdFx0dGhpcy4jc3RhbGVUaW1lb3V0SWQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdGlmICghdGhpcy4jY3VycmVudFJlc3VsdC5pc1N0YWxlKSB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdH0sIHRpbWVvdXQpO1xuXHR9XG5cdCNjb21wdXRlUmVmZXRjaEludGVydmFsKCkge1xuXHRcdHJldHVybiByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsLCB0aGlzLiNjdXJyZW50UXVlcnkpID8/IGZhbHNlO1xuXHR9XG5cdCN1cGRhdGVSZWZldGNoSW50ZXJ2YWwobmV4dEludGVydmFsKSB7XG5cdFx0dGhpcy4jY2xlYXJSZWZldGNoSW50ZXJ2YWwoKTtcblx0XHR0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsID0gbmV4dEludGVydmFsO1xuXHRcdGlmICh0aGlzLiNjdXJyZW50UmVmZXRjaEludGVydmFsID09PSAwIHx8ICF0aGlzLiNzaG91bGRTY2hlZHVsZVRpbWVyKHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwpKSByZXR1cm47XG5cdFx0dGhpcy4jcmVmZXRjaEludGVydmFsSWQgPSB0aW1lb3V0TWFuYWdlci5zZXRJbnRlcnZhbCgoKSA9PiB7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLnJlZmV0Y2hJbnRlcnZhbEluQmFja2dyb3VuZCB8fCBmb2N1c01hbmFnZXIuaXNGb2N1c2VkKCkpIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuXHRcdH0sIHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwpO1xuXHR9XG5cdCN1cGRhdGVUaW1lcnMoKSB7XG5cdFx0dGhpcy4jdXBkYXRlU3RhbGVUaW1lb3V0KCk7XG5cdFx0dGhpcy4jdXBkYXRlUmVmZXRjaEludGVydmFsKHRoaXMuI2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKSk7XG5cdH1cblx0I2NsZWFyU3RhbGVUaW1lb3V0KCkge1xuXHRcdGlmICh0aGlzLiNzdGFsZVRpbWVvdXRJZCAhPT0gdm9pZCAwKSB7XG5cdFx0XHR0aW1lb3V0TWFuYWdlci5jbGVhclRpbWVvdXQodGhpcy4jc3RhbGVUaW1lb3V0SWQpO1xuXHRcdFx0dGhpcy4jc3RhbGVUaW1lb3V0SWQgPSB2b2lkIDA7XG5cdFx0fVxuXHR9XG5cdCNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpIHtcblx0XHRpZiAodGhpcy4jcmVmZXRjaEludGVydmFsSWQgIT09IHZvaWQgMCkge1xuXHRcdFx0dGltZW91dE1hbmFnZXIuY2xlYXJJbnRlcnZhbCh0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCk7XG5cdFx0XHR0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0Y3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgcHJldlF1ZXJ5ID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHRcdGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdGNvbnN0IHByZXZSZXN1bHQgPSB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHRcdGNvbnN0IHByZXZSZXN1bHRTdGF0ZSA9IHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZTtcblx0XHRjb25zdCBwcmV2UmVzdWx0T3B0aW9ucyA9IHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zO1xuXHRcdGNvbnN0IHF1ZXJ5SW5pdGlhbFN0YXRlID0gcXVlcnkgIT09IHByZXZRdWVyeSA/IHF1ZXJ5LnN0YXRlIDogdGhpcy4jY3VycmVudFF1ZXJ5SW5pdGlhbFN0YXRlO1xuXHRcdGNvbnN0IHsgc3RhdGUgfSA9IHF1ZXJ5O1xuXHRcdGxldCBuZXdTdGF0ZSA9IHsgLi4uc3RhdGUgfTtcblx0XHRsZXQgaXNQbGFjZWhvbGRlckRhdGEgPSBmYWxzZTtcblx0XHRsZXQgZGF0YTtcblx0XHRpZiAob3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMpIHtcblx0XHRcdGNvbnN0IG1vdW50ZWQgPSB0aGlzLmhhc0xpc3RlbmVycygpO1xuXHRcdFx0Y29uc3QgZmV0Y2hPbk1vdW50ID0gIW1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKTtcblx0XHRcdGNvbnN0IGZldGNoT3B0aW9uYWxseSA9IG1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHF1ZXJ5LCBwcmV2UXVlcnksIG9wdGlvbnMsIHByZXZPcHRpb25zKTtcblx0XHRcdGlmIChmZXRjaE9uTW91bnQgfHwgZmV0Y2hPcHRpb25hbGx5KSBuZXdTdGF0ZSA9IHtcblx0XHRcdFx0Li4ubmV3U3RhdGUsXG5cdFx0XHRcdC4uLmZldGNoU3RhdGUoc3RhdGUuZGF0YSwgcXVlcnkub3B0aW9ucylcblx0XHRcdH07XG5cdFx0XHRpZiAob3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPT09IFwiaXNSZXN0b3JpbmdcIikgbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPSBcImlkbGVcIjtcblx0XHR9XG5cdFx0bGV0IHsgZXJyb3IsIGVycm9yVXBkYXRlZEF0LCBzdGF0dXMgfSA9IG5ld1N0YXRlO1xuXHRcdGRhdGEgPSBuZXdTdGF0ZS5kYXRhO1xuXHRcdGxldCBza2lwU2VsZWN0ID0gZmFsc2U7XG5cdFx0aWYgKG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhICE9PSB2b2lkIDAgJiYgZGF0YSA9PT0gdm9pZCAwICYmIHN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHtcblx0XHRcdGxldCBwbGFjZWhvbGRlckRhdGE7XG5cdFx0XHRpZiAocHJldlJlc3VsdD8uaXNQbGFjZWhvbGRlckRhdGEgJiYgb3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgPT09IHByZXZSZXN1bHRPcHRpb25zPy5wbGFjZWhvbGRlckRhdGEpIHtcblx0XHRcdFx0cGxhY2Vob2xkZXJEYXRhID0gcHJldlJlc3VsdC5kYXRhO1xuXHRcdFx0XHRza2lwU2VsZWN0ID0gdHJ1ZTtcblx0XHRcdH0gZWxzZSBwbGFjZWhvbGRlckRhdGEgPSB0eXBlb2Ygb3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhKHRoaXMuI2xhc3RRdWVyeVdpdGhEZWZpbmVkRGF0YT8uc3RhdGUuZGF0YSwgdGhpcy4jbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhKSA6IG9wdGlvbnMucGxhY2Vob2xkZXJEYXRhO1xuXHRcdFx0aWYgKHBsYWNlaG9sZGVyRGF0YSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdHN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRkYXRhID0gcmVwbGFjZURhdGEocHJldlJlc3VsdD8uZGF0YSwgcGxhY2Vob2xkZXJEYXRhLCBvcHRpb25zKTtcblx0XHRcdFx0aXNQbGFjZWhvbGRlckRhdGEgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAob3B0aW9ucy5zZWxlY3QgJiYgZGF0YSAhPT0gdm9pZCAwICYmICFza2lwU2VsZWN0KSB7XG5cdFx0XHRpZiAocHJldlJlc3VsdCAmJiBkYXRhID09PSBwcmV2UmVzdWx0U3RhdGU/LmRhdGEgJiYgb3B0aW9ucy5zZWxlY3QgPT09IHRoaXMuI3NlbGVjdEZuKSBkYXRhID0gdGhpcy4jc2VsZWN0UmVzdWx0O1xuXHRcdFx0ZWxzZSB0cnkge1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RGbiA9IG9wdGlvbnMuc2VsZWN0O1xuXHRcdFx0XHRkYXRhID0gb3B0aW9ucy5zZWxlY3QoZGF0YSk7XG5cdFx0XHRcdGRhdGEgPSByZXBsYWNlRGF0YShwcmV2UmVzdWx0Py5kYXRhLCBkYXRhLCBvcHRpb25zKTtcblx0XHRcdFx0dGhpcy4jc2VsZWN0UmVzdWx0ID0gZGF0YTtcblx0XHRcdFx0dGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuXHRcdFx0fSBjYXRjaCAoc2VsZWN0RXJyb3IpIHtcblx0XHRcdFx0dGhpcy4jc2VsZWN0RXJyb3IgPSBzZWxlY3RFcnJvcjtcblx0XHRcdH1cblx0XHR9IGVsc2UgaWYgKGRhdGEgPT09IHZvaWQgMCkgdGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuXHRcdGlmICh0aGlzLiNzZWxlY3RFcnJvcikge1xuXHRcdFx0ZXJyb3IgPSB0aGlzLiNzZWxlY3RFcnJvcjtcblx0XHRcdGRhdGEgPSB0aGlzLiNzZWxlY3RSZXN1bHQ7XG5cdFx0XHRlcnJvclVwZGF0ZWRBdCA9IERhdGUubm93KCk7XG5cdFx0XHRzdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSA9IGZhbHNlO1xuXHRcdH1cblx0XHRjb25zdCBpc0ZldGNoaW5nID0gbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiZmV0Y2hpbmdcIjtcblx0XHRjb25zdCBpc1BlbmRpbmcgPSBzdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGlzRXJyb3IgPSBzdGF0dXMgPT09IFwiZXJyb3JcIjtcblx0XHRjb25zdCBpc0xvYWRpbmcgPSBpc1BlbmRpbmcgJiYgaXNGZXRjaGluZztcblx0XHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRcdHJldHVybiB7XG5cdFx0XHRzdGF0dXMsXG5cdFx0XHRmZXRjaFN0YXR1czogbmV3U3RhdGUuZmV0Y2hTdGF0dXMsXG5cdFx0XHRpc1BlbmRpbmcsXG5cdFx0XHRpc1N1Y2Nlc3M6IHN0YXR1cyA9PT0gXCJzdWNjZXNzXCIsXG5cdFx0XHRpc0Vycm9yLFxuXHRcdFx0aXNJbml0aWFsTG9hZGluZzogaXNMb2FkaW5nLFxuXHRcdFx0aXNMb2FkaW5nLFxuXHRcdFx0ZGF0YSxcblx0XHRcdGRhdGFVcGRhdGVkQXQ6IG5ld1N0YXRlLmRhdGFVcGRhdGVkQXQsXG5cdFx0XHRlcnJvcixcblx0XHRcdGVycm9yVXBkYXRlZEF0LFxuXHRcdFx0ZmFpbHVyZUNvdW50OiBuZXdTdGF0ZS5mZXRjaEZhaWx1cmVDb3VudCxcblx0XHRcdGZhaWx1cmVSZWFzb246IG5ld1N0YXRlLmZldGNoRmFpbHVyZVJlYXNvbixcblx0XHRcdGVycm9yVXBkYXRlQ291bnQ6IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQsXG5cdFx0XHRpc0ZldGNoZWQ6IHF1ZXJ5LmlzRmV0Y2hlZCgpLFxuXHRcdFx0aXNGZXRjaGVkQWZ0ZXJNb3VudDogbmV3U3RhdGUuZGF0YVVwZGF0ZUNvdW50ID4gcXVlcnlJbml0aWFsU3RhdGUuZGF0YVVwZGF0ZUNvdW50IHx8IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQgPiBxdWVyeUluaXRpYWxTdGF0ZS5lcnJvclVwZGF0ZUNvdW50LFxuXHRcdFx0aXNGZXRjaGluZyxcblx0XHRcdGlzUmVmZXRjaGluZzogaXNGZXRjaGluZyAmJiAhaXNQZW5kaW5nLFxuXHRcdFx0aXNMb2FkaW5nRXJyb3I6IGlzRXJyb3IgJiYgIWhhc0RhdGEsXG5cdFx0XHRpc1BhdXNlZDogbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIsXG5cdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSxcblx0XHRcdGlzUmVmZXRjaEVycm9yOiBpc0Vycm9yICYmIGhhc0RhdGEsXG5cdFx0XHRpc1N0YWxlOiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSxcblx0XHRcdHJlZmV0Y2g6IHRoaXMucmVmZXRjaCxcblx0XHRcdGlzRW5hYmxlZDogcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlXG5cdFx0fTtcblx0fVxuXHQvKipcblx0KiBSZWNvbXB1dGVzIGFuZCBzdG9yZXMgdGhlIGN1cnJlbnQgcmVzdWx0IGZyb20gdGhlIGN1cnJlbnQgcXVlcnkvb3B0aW9ucywgbm90aWZ5aW5nIGxpc3RlbmVyc1xuXHQqIGlmIGl0IGNoYW5nZWQuIEZyYW1ld29yayBhZGFwdGVycyBjYWxsIHRoaXMgcmlnaHQgYWZ0ZXIgc3Vic2NyaWJpbmcgdG8gbWFrZSBzdXJlIG5vIHF1ZXJ5XG5cdCogdXBkYXRlIHdhcyBtaXNzZWQgaW4gdGhlIGdhcCBiZXR3ZWVuIGNyZWF0aW5nIHRoZSBvYnNlcnZlciBhbmQgc3Vic2NyaWJpbmcgdG8gaXQuXG5cdCovXG5cdHVwZGF0ZVJlc3VsdCgpIHtcblx0XHRjb25zdCBwcmV2UmVzdWx0ID0gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0XHRjb25zdCBuZXh0UmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQodGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZSA9IHRoaXMuI2N1cnJlbnRRdWVyeS5zdGF0ZTtcblx0XHR0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRpZiAodGhpcy4jY3VycmVudFJlc3VsdFN0YXRlLmRhdGEgIT09IHZvaWQgMCkgdGhpcy4jbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHRcdGlmIChzaGFsbG93RXF1YWxPYmplY3RzKG5leHRSZXN1bHQsIHByZXZSZXN1bHQpKSByZXR1cm47XG5cdFx0dGhpcy4jY3VycmVudFJlc3VsdCA9IG5leHRSZXN1bHQ7XG5cdFx0Y29uc3Qgc2hvdWxkTm90aWZ5TGlzdGVuZXJzID0gKCkgPT4ge1xuXHRcdFx0aWYgKCFwcmV2UmVzdWx0KSByZXR1cm4gdHJ1ZTtcblx0XHRcdGNvbnN0IHsgbm90aWZ5T25DaGFuZ2VQcm9wcyB9ID0gdGhpcy5vcHRpb25zO1xuXHRcdFx0Y29uc3Qgbm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID0gdHlwZW9mIG5vdGlmeU9uQ2hhbmdlUHJvcHMgPT09IFwiZnVuY3Rpb25cIiA/IG5vdGlmeU9uQ2hhbmdlUHJvcHMoKSA6IG5vdGlmeU9uQ2hhbmdlUHJvcHM7XG5cdFx0XHRpZiAobm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID09PSBcImFsbFwiIHx8ICFub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgJiYgIXRoaXMuI3RyYWNrZWRQcm9wcy5zaXplKSByZXR1cm4gdHJ1ZTtcblx0XHRcdGNvbnN0IGluY2x1ZGVkUHJvcHMgPSBuZXcgU2V0KG5vdGlmeU9uQ2hhbmdlUHJvcHNWYWx1ZSA/PyB0aGlzLiN0cmFja2VkUHJvcHMpO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy50aHJvd09uRXJyb3IpIGluY2x1ZGVkUHJvcHMuYWRkKFwiZXJyb3JcIik7XG5cdFx0XHRyZXR1cm4gT2JqZWN0LmtleXModGhpcy4jY3VycmVudFJlc3VsdCkuc29tZSgoa2V5KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHR5cGVkS2V5ID0ga2V5O1xuXHRcdFx0XHRyZXR1cm4gdGhpcy4jY3VycmVudFJlc3VsdFt0eXBlZEtleV0gIT09IHByZXZSZXN1bHRbdHlwZWRLZXldICYmIGluY2x1ZGVkUHJvcHMuaGFzKHR5cGVkS2V5KTtcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0Y29uc3Qgbm90aWZ5TGlzdGVuZXJzID0gc2hvdWxkTm90aWZ5TGlzdGVuZXJzKCk7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRpZiAobm90aWZ5TGlzdGVuZXJzKSB0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcih0aGlzLiNjdXJyZW50UmVzdWx0KTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5ub3RpZnkoe1xuXHRcdFx0XHRxdWVyeTogdGhpcy4jY3VycmVudFF1ZXJ5LFxuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyUmVzdWx0c1VwZGF0ZWRcIlxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0I3VwZGF0ZVF1ZXJ5KCkge1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIHRoaXMub3B0aW9ucyk7XG5cdFx0aWYgKHF1ZXJ5ID09PSB0aGlzLiNjdXJyZW50UXVlcnkpIHJldHVybjtcblx0XHRjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0dGhpcy4jY3VycmVudFF1ZXJ5ID0gcXVlcnk7XG5cdFx0dGhpcy4jY3VycmVudFF1ZXJ5SW5pdGlhbFN0YXRlID0gcXVlcnkuc3RhdGU7XG5cdFx0aWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdHByZXZRdWVyeT8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdFx0XHRxdWVyeS5hZGRPYnNlcnZlcih0aGlzKTtcblx0XHR9XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRvblF1ZXJ5VXBkYXRlKCkge1xuXHRcdHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0aWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHRoaXMuI3VwZGF0ZVRpbWVycygpO1xuXHR9XG59O1xuZnVuY3Rpb24gc2hvdWxkTG9hZE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHtcblx0cmV0dXJuIHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZSAmJiBxdWVyeS5zdGF0ZS5kYXRhID09PSB2b2lkIDAgJiYgIShxdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiAmJiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLnJldHJ5T25Nb3VudCwgcXVlcnkpID09PSBmYWxzZSk7XG59XG5mdW5jdGlvbiBzaG91bGRGZXRjaE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHtcblx0cmV0dXJuIHNob3VsZExvYWRPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB8fCBxdWVyeS5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgc2hvdWxkRmV0Y2hPbihxdWVyeSwgb3B0aW9ucywgb3B0aW9ucy5yZWZldGNoT25Nb3VudCk7XG59XG5mdW5jdGlvbiBzaG91bGRGZXRjaE9uKHF1ZXJ5LCBvcHRpb25zLCBmaWVsZCkge1xuXHRpZiAocmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkgIT09IFwic3RhdGljXCIpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHJlc29sdmVRdWVyeVZhbHVlKGZpZWxkLCBxdWVyeSk7XG5cdFx0cmV0dXJuIHZhbHVlID09PSBcImFsd2F5c1wiIHx8IHZhbHVlICE9PSBmYWxzZSAmJiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKTtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBzaG91bGRGZXRjaE9wdGlvbmFsbHkocXVlcnksIHByZXZRdWVyeSwgb3B0aW9ucywgcHJldk9wdGlvbnMpIHtcblx0cmV0dXJuIChxdWVyeSAhPT0gcHJldlF1ZXJ5IHx8IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSA9PT0gZmFsc2UpICYmICghb3B0aW9ucy5zdXNwZW5zZSB8fCBxdWVyeS5zdGF0ZS5zdGF0dXMgIT09IFwiZXJyb3JcIikgJiYgaXNTdGFsZShxdWVyeSwgb3B0aW9ucyk7XG59XG5mdW5jdGlvbiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSB7XG5cdHJldHVybiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlPYnNlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IGhhc05leHRQYWdlLCBoYXNQcmV2aW91c1BhZ2UgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiLi9xdWVyeU9ic2VydmVyLmpzXCI7XG4vLyNyZWdpb24gc3JjL2luZmluaXRlUXVlcnlPYnNlcnZlci50c1xuLyoqXG4qIEFuIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJgIGV4dGVuZHMgYFF1ZXJ5T2JzZXJ2ZXJgIHRvIG9ic2VydmUgYW5kIHN3aXRjaFxuKiBiZXR3ZWVuIGluZmluaXRlIHF1ZXJpZXMuIEl0IGF1Z21lbnRzIHRoZSBiYXNlIGBRdWVyeU9ic2VydmVyUmVzdWx0YCB3aXRoXG4qIGluZmluaXRlLXF1ZXJ5LXNwZWNpZmljIGZpZWxkcyBhbmQgbWV0aG9kcywgc3VjaCBhcyBgaGFzTmV4dFBhZ2VgIGFuZFxuKiBgZmV0Y2hOZXh0UGFnZWAsIGFuZCBpcyB0aGUgcHJpbWl0aXZlIHRoYXQgZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuXG4qIGB1c2VJbmZpbml0ZVF1ZXJ5YCkgYnVpbGQgdGhlaXIgaG9va3Mgb24gdG9wIG9mLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBxdWVyeUtleTogWydwcm9qZWN0cyddLFxuKiAgIHF1ZXJ5Rm46ICh7IHBhZ2VQYXJhbSB9KSA9PiBmZXRjaFByb2plY3RzKHBhZ2VQYXJhbSksXG4qICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICBnZXROZXh0UGFnZVBhcmFtOiAobGFzdFBhZ2UpID0+IGxhc3RQYWdlLm5leHRDdXJzb3IsXG4qIH0pXG4qXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gb2JzZXJ2ZXIuc3Vic2NyaWJlKChyZXN1bHQpID0+IGNvbnNvbGUubG9nKHJlc3VsdCkpXG4qIGBgYFxuKi9cbnZhciBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFF1ZXJ5T2JzZXJ2ZXIge1xuXHRjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcblx0XHRzdXBlcihjbGllbnQsIG9wdGlvbnMpO1xuXHR9XG5cdGJpbmRNZXRob2RzKCkge1xuXHRcdHN1cGVyLmJpbmRNZXRob2RzKCk7XG5cdFx0dGhpcy5mZXRjaE5leHRQYWdlID0gdGhpcy5mZXRjaE5leHRQYWdlLmJpbmQodGhpcyk7XG5cdFx0dGhpcy5mZXRjaFByZXZpb3VzUGFnZSA9IHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UuYmluZCh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBVcGRhdGVzIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMuIEJlaGF2ZXMgdGhlIHNhbWUgYXNcblx0KiBgUXVlcnlPYnNlcnZlci5zZXRPcHRpb25zYCwgYWRkaXRpb25hbGx5IG1hcmtpbmcgdGhlIG9wdGlvbnMgYXNcblx0KiBiZWxvbmdpbmcgdG8gYW4gaW5maW5pdGUgcXVlcnkgYmVmb3JlIGRlbGVnYXRpbmcgdG8gdGhlIGJhc2Vcblx0KiBpbXBsZW1lbnRhdGlvbi5cblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRzdXBlci5zZXRPcHRpb25zKG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBpbmZpbml0ZS1xdWVyeSBjb3VudGVycGFydCBvZiB7QGxpbmsgUXVlcnlPYnNlcnZlciNnZXRPcHRpbWlzdGljUmVzdWx0fSwgbWFya2luZyB0aGVcblx0KiBvcHRpb25zIGFzIGFuIGluZmluaXRlIHF1ZXJ5IGJlZm9yZSBkZWxlZ2F0aW5nIHRvIGl0LiBDYWxsZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuXG5cdCogYHVzZUluZmluaXRlUXVlcnlgKSBhaGVhZCBvZiBzdWJzY3JpYmluZywgdG8gY29tcHV0ZSB0aGUgY3VycmVudCBgSW5maW5pdGVRdWVyeU9ic2VydmVyUmVzdWx0YFxuXHQqIHN5bmNocm9ub3VzbHkuXG5cdCovXG5cdGdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0cmV0dXJuIHN1cGVyLmdldE9wdGltaXN0aWNSZXN1bHQob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyB0aGUgbmV4dCBwYWdlIG9mIHRoZSBpbmZpbml0ZSBxdWVyeSBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdFxuXHQqIHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdGluZyBgSW5maW5pdGVRdWVyeU9ic2VydmVyUmVzdWx0YC4gVGhlIHBhZ2Vcblx0KiBwYXJhbSB1c2VkIGZvciB0aGUgZmV0Y2ggaXMgZGV0ZXJtaW5lZCBieSBgZ2V0TmV4dFBhZ2VQYXJhbWAsIHdoaWNoXG5cdCogcmVjZWl2ZXMgdGhlIGN1cnJlbnQgcGFnZXMvcGFnZSBwYXJhbXMgYW5kIHdob3NlIHJlc3VsdCBhbHNvIGRldGVybWluZXNcblx0KiBgaGFzTmV4dFBhZ2VgLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHsgaGFzTmV4dFBhZ2UgfSA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqXG5cdCogaWYgKGhhc05leHRQYWdlKSB7XG5cdCogICBhd2FpdCBvYnNlcnZlci5mZXRjaE5leHRQYWdlKClcblx0KiB9XG5cdCogYGBgXG5cdCpcblx0KiBAc2VlIHtAbGluayBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIjZmV0Y2hQcmV2aW91c1BhZ2V9XG5cdCovXG5cdGZldGNoTmV4dFBhZ2Uob3B0aW9ucykge1xuXHRcdHJldHVybiB0aGlzLmZldGNoKHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRtZXRhOiB7IGZldGNoTW9yZTogeyBkaXJlY3Rpb246IFwiZm9yd2FyZFwiIH0gfVxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIEZldGNoZXMgdGhlIHByZXZpb3VzIHBhZ2Ugb2YgdGhlIGluZmluaXRlIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZVxuXHQqIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0aW5nIGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgLiBUaGUgcGFnZVxuXHQqIHBhcmFtIHVzZWQgZm9yIHRoZSBmZXRjaCBpcyBkZXRlcm1pbmVkIGJ5IGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAsIHdoaWNoXG5cdCogcmVjZWl2ZXMgdGhlIGN1cnJlbnQgcGFnZXMvcGFnZSBwYXJhbXMgYW5kIHdob3NlIHJlc3VsdCBhbHNvIGRldGVybWluZXNcblx0KiBgaGFzUHJldmlvdXNQYWdlYC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCB7IGhhc1ByZXZpb3VzUGFnZSB9ID0gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG5cdCpcblx0KiBpZiAoaGFzUHJldmlvdXNQYWdlKSB7XG5cdCogICBhd2FpdCBvYnNlcnZlci5mZXRjaFByZXZpb3VzUGFnZSgpXG5cdCogfVxuXHQqIGBgYFxuXHQqXG5cdCogQHNlZSB7QGxpbmsgSW5maW5pdGVRdWVyeU9ic2VydmVyI2ZldGNoTmV4dFBhZ2V9XG5cdCovXG5cdGZldGNoUHJldmlvdXNQYWdlKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0bWV0YTogeyBmZXRjaE1vcmU6IHsgZGlyZWN0aW9uOiBcImJhY2t3YXJkXCIgfSB9XG5cdFx0fSk7XG5cdH1cblx0Y3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgeyBzdGF0ZSB9ID0gcXVlcnk7XG5cdFx0Y29uc3QgcGFyZW50UmVzdWx0ID0gc3VwZXIuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBvcHRpb25zKTtcblx0XHRjb25zdCB7IGlzRmV0Y2hpbmcsIGlzUmVmZXRjaGluZywgaXNFcnJvciwgaXNSZWZldGNoRXJyb3IgfSA9IHBhcmVudFJlc3VsdDtcblx0XHRjb25zdCBmZXRjaERpcmVjdGlvbiA9IHN0YXRlLmZldGNoTWV0YT8uZmV0Y2hNb3JlPy5kaXJlY3Rpb247XG5cdFx0Y29uc3QgaXNGZXRjaE5leHRQYWdlRXJyb3IgPSBpc0Vycm9yICYmIGZldGNoRGlyZWN0aW9uID09PSBcImZvcndhcmRcIjtcblx0XHRjb25zdCBpc0ZldGNoaW5nTmV4dFBhZ2UgPSBpc0ZldGNoaW5nICYmIGZldGNoRGlyZWN0aW9uID09PSBcImZvcndhcmRcIjtcblx0XHRjb25zdCBpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IgPSBpc0Vycm9yICYmIGZldGNoRGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0Y29uc3QgaXNGZXRjaGluZ1ByZXZpb3VzUGFnZSA9IGlzRmV0Y2hpbmcgJiYgZmV0Y2hEaXJlY3Rpb24gPT09IFwiYmFja3dhcmRcIjtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Li4ucGFyZW50UmVzdWx0LFxuXHRcdFx0ZmV0Y2hOZXh0UGFnZTogdGhpcy5mZXRjaE5leHRQYWdlLFxuXHRcdFx0ZmV0Y2hQcmV2aW91c1BhZ2U6IHRoaXMuZmV0Y2hQcmV2aW91c1BhZ2UsXG5cdFx0XHRoYXNOZXh0UGFnZTogaGFzTmV4dFBhZ2Uob3B0aW9ucywgc3RhdGUuZGF0YSksXG5cdFx0XHRoYXNQcmV2aW91c1BhZ2U6IGhhc1ByZXZpb3VzUGFnZShvcHRpb25zLCBzdGF0ZS5kYXRhKSxcblx0XHRcdGlzRmV0Y2hOZXh0UGFnZUVycm9yLFxuXHRcdFx0aXNGZXRjaGluZ05leHRQYWdlLFxuXHRcdFx0aXNGZXRjaFByZXZpb3VzUGFnZUVycm9yLFxuXHRcdFx0aXNGZXRjaGluZ1ByZXZpb3VzUGFnZSxcblx0XHRcdGlzUmVmZXRjaEVycm9yOiBpc1JlZmV0Y2hFcnJvciAmJiAhaXNGZXRjaE5leHRQYWdlRXJyb3IgJiYgIWlzRmV0Y2hQcmV2aW91c1BhZ2VFcnJvcixcblx0XHRcdGlzUmVmZXRjaGluZzogaXNSZWZldGNoaW5nICYmICFpc0ZldGNoaW5nTmV4dFBhZ2UgJiYgIWlzRmV0Y2hpbmdQcmV2aW91c1BhZ2Vcblx0XHR9O1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeU9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSZXRyeWVyIH0gZnJvbSBcIi4vcmV0cnllci5qc1wiO1xuaW1wb3J0IHsgUmVtb3ZhYmxlIH0gZnJvbSBcIi4vcmVtb3ZhYmxlLmpzXCI7XG4vLyNyZWdpb24gc3JjL211dGF0aW9uLnRzXG4vKipcbiogUmVwcmVzZW50cyBhIHNpbmdsZSBtdXRhdGlvbiBhdHRlbXB0LiBBIGBNdXRhdGlvbmAgaG9sZHMgdGhlIG11dGF0aW9uJ3Ncbiogb3B0aW9ucywgc3RhdGUgKGRhdGEvZXJyb3Ivc3RhdHVzKSwgYW5kIHRoZSBgTXV0YXRpb25PYnNlcnZlcmBzIGN1cnJlbnRseVxuKiBzdWJzY3JpYmVkIHRvIGl0LlxuKlxuKiBJbnN0YW5jZXMgYXJlIGNyZWF0ZWQgYW5kIG1hbmFnZWQgaW50ZXJuYWxseSBieSBgTXV0YXRpb25DYWNoZWA7IGFwcGxpY2F0aW9uXG4qIGNvZGUgdHlwaWNhbGx5IGludGVyYWN0cyB3aXRoIG11dGF0aW9ucyBpbmRpcmVjdGx5IHRocm91Z2ggYFF1ZXJ5Q2xpZW50YCBvclxuKiBhIGZyYW1ld29yayBob29rIGxpa2UgYHVzZU11dGF0aW9uYC4gRGlyZWN0IGFjY2VzcyB0byBhIGBNdXRhdGlvbmAgaW5zdGFuY2VcbiogaXMgcG9zc2libGUgdmlhIGBtdXRhdGlvbkNhY2hlLmZpbmQoKWAvYGdldEFsbCgpYCBmb3IgaW5zcGVjdGluZyBjYWNoZSBzdGF0ZS5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuKlxuKiBjb25zdCBtdXRhdGlvbiA9IG11dGF0aW9uQ2FjaGUuZmluZCh7IG11dGF0aW9uS2V5OiBbJ2FkZFBvc3QnXSB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb24gPSBjbGFzcyBleHRlbmRzIFJlbW92YWJsZSB7XG5cdCNjbGllbnQ7XG5cdCNvYnNlcnZlcnM7XG5cdCNtdXRhdGlvbkNhY2hlO1xuXHQjcmV0cnllcjtcblx0Y29uc3RydWN0b3IoY29uZmlnKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNjbGllbnQgPSBjb25maWcuY2xpZW50O1xuXHRcdHRoaXMubXV0YXRpb25JZCA9IGNvbmZpZy5tdXRhdGlvbklkO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZTtcblx0XHR0aGlzLiNvYnNlcnZlcnMgPSBbXTtcblx0XHR0aGlzLnN0YXRlID0gY29uZmlnLnN0YXRlIHx8IGdldERlZmF1bHRTdGF0ZSgpO1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhjb25maWcub3B0aW9ucyk7XG5cdFx0dGhpcy5zY2hlZHVsZUdjKCk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMudXBkYXRlR2NUaW1lKHRoaXMub3B0aW9ucy5nY1RpbWUpO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBgbWV0YWAgb2JqZWN0IHBhc3NlZCBpbiB0aGUgbXV0YXRpb24ncyBvcHRpb25zLCBpZiBhbnkuXG5cdCovXG5cdGdldCBtZXRhKCkge1xuXHRcdHJldHVybiB0aGlzLm9wdGlvbnMubWV0YTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdGFkZE9ic2VydmVyKG9ic2VydmVyKSB7XG5cdFx0aWYgKCF0aGlzLiNvYnNlcnZlcnMuaW5jbHVkZXMob2JzZXJ2ZXIpKSB7XG5cdFx0XHR0aGlzLiNvYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG5cdFx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJBZGRlZFwiLFxuXHRcdFx0XHRtdXRhdGlvbjogdGhpcyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdHJlbW92ZU9ic2VydmVyKG9ic2VydmVyKSB7XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzID0gdGhpcy4jb2JzZXJ2ZXJzLmZpbHRlcigoeCkgPT4geCAhPT0gb2JzZXJ2ZXIpO1xuXHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJSZW1vdmVkXCIsXG5cdFx0XHRtdXRhdGlvbjogdGhpcyxcblx0XHRcdG9ic2VydmVyXG5cdFx0fSk7XG5cdH1cblx0b3B0aW9uYWxSZW1vdmUoKSB7XG5cdFx0aWYgKCF0aGlzLiNvYnNlcnZlcnMubGVuZ3RoKSB7XG5cdFx0XHRpZiAodGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB0aGlzLnNjaGVkdWxlR2MoKTtcblx0XHRcdGVsc2UgdGhpcy4jbXV0YXRpb25DYWNoZS5yZW1vdmUodGhpcyk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFJlc3VtZXMgYSBtdXRhdGlvbiB0aGF0IGlzIGN1cnJlbnRseSBwYXVzZWQgb3Igd2FzIHJlc3RvcmVkIGZyb20gYVxuXHQqIGRlaHlkcmF0ZWQsIHN0aWxsLWBwZW5kaW5nYCBzdGF0ZS5cblx0KlxuXHQqIC0gSWYgdGhpcyBtdXRhdGlvbiBoYXMgYW4gYWN0aXZlIHJldHJ5ZXIgKGl0IHBhdXNlZCBtaWQtYXR0ZW1wdCwgZS5nLiBkdWVcblx0KiAgIHRvIHRoZSBuZXR3b3JrIG1vZGUgb3Igc2NvcGUtYmFzZWQgcXVldWluZyksIGl0cyByZXRyeWVyIGlzIHJlc3VtZWQuXG5cdCogLSBPdGhlcndpc2UsIGlmIHRoZSBtdXRhdGlvbidzIHN0YXR1cyBpcyBzdGlsbCBgcGVuZGluZ2AgKGUuZy4gaXQgd2FzXG5cdCogICBkZWh5ZHJhdGVkIHdoaWxlIGFuIGF0dGVtcHQgd2FzIGluIGZsaWdodCBhbmQgbmV2ZXIgZ290IGEgcmV0cnllciBpblxuXHQqICAgdGhpcyBpbnN0YW5jZSksIGBleGVjdXRlYCBpcyBjYWxsZWQgYWdhaW4gd2l0aCB0aGUgbGFzdCBrbm93biB2YXJpYWJsZXMuXG5cdCogLSBPdGhlcndpc2UgdGhlIG11dGF0aW9uIGhhcyBhbHJlYWR5IHNldHRsZWQgYW5kIHRoaXMgcmVzb2x2ZXMgaW1tZWRpYXRlbHlcblx0KiAgIHdpdGhvdXQgcnVubmluZyBhbnl0aGluZyBhZ2Fpbi5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyB0eXBpY2FsbHkgZHJpdmVuIGJ5IHJlY29ubmVjdCBoYW5kbGluZywgZS5nLiBxdWVyeUNsaWVudC5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKVxuXHQqIGNvbnN0IG11dGF0aW9uID0gbXV0YXRpb25DYWNoZS5maW5kKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYXdhaXQgbXV0YXRpb24/LmNvbnRpbnVlKClcblx0KiBgYGBcblx0KlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uI2V4ZWN1dGV9XG5cdCovXG5cdGNvbnRpbnVlKCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpID8/ICh0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgPyB0aGlzLmV4ZWN1dGUodGhpcy5zdGF0ZS52YXJpYWJsZXMpIDogUHJvbWlzZS5yZXNvbHZlKCkpO1xuXHR9XG5cdC8qKlxuXHQqIFJ1bnMgdGhlIG11dGF0aW9uIGZ1bmN0aW9uIGZvciB0aGUgZ2l2ZW4gdmFyaWFibGVzIHRocm91Z2ggYSByZXRyeWVyLCBhbmRcblx0KiBkcml2ZXMgdGhlIG11dGF0aW9uJ3Mgc3RhdGUgYW5kIGxpZmVjeWNsZSBjYWxsYmFja3MgdGhyb3VnaCB0byBzZXR0bGVtZW50LlxuXHQqXG5cdCogSWYgdGhpcyBtdXRhdGlvbidzIHN0YXRlIGlzIGFscmVhZHkgYHBlbmRpbmdgIHdoZW4gYGV4ZWN1dGVgIGlzIGNhbGxlZFxuXHQqIChpLmUuIGl0IHdhcyByZXN0b3JlZCwgc3RpbGwgaW4tZmxpZ2h0LCBmcm9tIGEgZGVoeWRyYXRlZCBzdGF0ZSksIHRoZVxuXHQqIGBvbk11dGF0ZWAgc3RlcCBpcyBza2lwcGVkIGFuZCBhIGBjb250aW51ZWAgYWN0aW9uIGlzIGRpc3BhdGNoZWQgdG9cblx0KiB1bnBhdXNlIGl0OyBvdGhlcndpc2UgYSBgcGVuZGluZ2AgYWN0aW9uIGlzIGRpc3BhdGNoZWQgZmlyc3QsIHRoZW4gdGhlXG5cdCogbXV0YXRpb24gY2FjaGUncyBgb25NdXRhdGVgIGFuZCB0aGUgbXV0YXRpb24ncyBvd24gYG9uTXV0YXRlYCBvcHRpb24gYXJlXG5cdCogYXdhaXRlZCBpbiB0aGF0IG9yZGVyLCBhbmQgdGhlIHJlc3VsdGluZyBjb250ZXh0IGlzIHN0b3JlZC5cblx0KlxuXHQqIFRoZSBtdXRhdGlvbiBmdW5jdGlvbiBpcyB0aGVuIHJ1biAoc3ViamVjdCB0byBgcmV0cnlgL2ByZXRyeURlbGF5YC9cblx0KiBgbmV0d29ya01vZGVgLCBhbmQgdG8gdGhlIG11dGF0aW9uIGNhY2hlJ3Mgc2NvcGUtYmFzZWQgc2VyaWFsaXphdGlvbikuXG5cdCogT24gc3VjY2VzcywgdGhlIGNhY2hlJ3MgYG9uU3VjY2Vzc2AvYG9uU2V0dGxlZGAgY2FsbGJhY2tzIHJ1biBiZWZvcmUgdGhlXG5cdCogbXV0YXRpb24ncyBvd24gYG9uU3VjY2Vzc2AvYG9uU2V0dGxlZGAgb3B0aW9ucywgYSBgc3VjY2Vzc2AgYWN0aW9uIGlzXG5cdCogZGlzcGF0Y2hlZCwgYW5kIHRoZSByZXNvbHZlZCBkYXRhIGlzIHJldHVybmVkLiBPbiBmYWlsdXJlLCB0aGUgc2FtZVxuXHQqIGNhY2hlLXRoZW4tb3B0aW9uIG9yZGVyaW5nIGlzIHVzZWQgZm9yIGBvbkVycm9yYC9gb25TZXR0bGVkYCwgYnV0IGVhY2ggb2Zcblx0KiB0aG9zZSBmb3VyIGNhbGxiYWNrcyBpcyBpbmRpdmlkdWFsbHkgY2F1Z2h0IHNvIHRoYXQgYSB0aHJvd2luZyBjYWxsYmFja1xuXHQqIGNhbm5vdCBtYXNrIHRoZSBvcmlnaW5hbCBlcnJvcjsgYW4gYGVycm9yYCBhY3Rpb24gaXMgdGhlbiBkaXNwYXRjaGVkIGFuZFxuXHQqIHRoZSBvcmlnaW5hbCBlcnJvciBpcyByZS10aHJvd24uXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogLy8gQ2FsbGVkIGludGVybmFsbHkgYnkgYE11dGF0aW9uT2JzZXJ2ZXIubXV0YXRlYCBhbmQgYE11dGF0aW9uLmNvbnRpbnVlYCDigJRcblx0KiAvLyBhcHBsaWNhdGlvbnMgbm9ybWFsbHkgdHJpZ2dlciBtdXRhdGlvbnMgdGhyb3VnaCB0aG9zZSwgbm90IHRoaXMgbWV0aG9kLlxuXHQqIGNvbnN0IGRhdGEgPSBhd2FpdCBtdXRhdGlvbi5leGVjdXRlKHZhcmlhYmxlcylcblx0KiBgYGBcblx0KlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uI2NvbnRpbnVlfVxuXHQqL1xuXHRhc3luYyBleGVjdXRlKHZhcmlhYmxlcykge1xuXHRcdGNvbnN0IG9uQ29udGludWUgPSAoKSA9PiB7XG5cdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiY29udGludWVcIiB9KTtcblx0XHR9O1xuXHRcdGNvbnN0IG11dGF0aW9uRm5Db250ZXh0ID0ge1xuXHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRtZXRhOiB0aGlzLm9wdGlvbnMubWV0YSxcblx0XHRcdG11dGF0aW9uS2V5OiB0aGlzLm9wdGlvbnMubXV0YXRpb25LZXlcblx0XHR9O1xuXHRcdGNvbnN0IHJldHJ5ZXIgPSB0aGlzLiNyZXRyeWVyID0gY3JlYXRlUmV0cnllcih7XG5cdFx0XHRmbjogKCkgPT4ge1xuXHRcdFx0XHRpZiAoIXRoaXMub3B0aW9ucy5tdXRhdGlvbkZuKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIk5vIG11dGF0aW9uRm4gZm91bmRcIikpO1xuXHRcdFx0XHRyZXR1cm4gdGhpcy5vcHRpb25zLm11dGF0aW9uRm4odmFyaWFibGVzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9LFxuXHRcdFx0b25GYWlsOiAoZmFpbHVyZUNvdW50LCBlcnJvcikgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJmYWlsZWRcIixcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZXJyb3Jcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0b25QYXVzZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwicGF1c2VcIiB9KTtcblx0XHRcdH0sXG5cdFx0XHRvbkNvbnRpbnVlLFxuXHRcdFx0cmV0cnk6IHRoaXMub3B0aW9ucy5yZXRyeSA/PyAwLFxuXHRcdFx0cmV0cnlEZWxheTogdGhpcy5vcHRpb25zLnJldHJ5RGVsYXksXG5cdFx0XHRuZXR3b3JrTW9kZTogdGhpcy5vcHRpb25zLm5ldHdvcmtNb2RlLFxuXHRcdFx0Y2FuUnVuOiAoKSA9PiB0aGlzLiNtdXRhdGlvbkNhY2hlLmNhblJ1bih0aGlzKVxuXHRcdH0pO1xuXHRcdGNvbnN0IHJlc3RvcmVkID0gdGhpcy5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGlzUGF1c2VkID0gIXJldHJ5ZXIuY2FuU3RhcnQoKTtcblx0XHR0cnkge1xuXHRcdFx0aWYgKHJlc3RvcmVkKSBvbkNvbnRpbnVlKCk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwicGVuZGluZ1wiLFxuXHRcdFx0XHRcdHZhcmlhYmxlcyxcblx0XHRcdFx0XHRpc1BhdXNlZFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0aWYgKHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uTXV0YXRlKSBhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbk11dGF0ZSh2YXJpYWJsZXMsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdFx0Y29uc3QgY29udGV4dCA9IGF3YWl0IHRoaXMub3B0aW9ucy5vbk11dGF0ZT8uKHZhcmlhYmxlcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0XHRpZiAoY29udGV4dCAhPT0gdGhpcy5zdGF0ZS5jb250ZXh0KSB0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0Y29udGV4dCxcblx0XHRcdFx0XHR2YXJpYWJsZXMsXG5cdFx0XHRcdFx0aXNQYXVzZWRcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBkYXRhID0gYXdhaXQgcmV0cnllci5zdGFydCgpO1xuXHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TdWNjZXNzPy4oZGF0YSwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblN1Y2Nlc3M/LihkYXRhLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TZXR0bGVkPy4oZGF0YSwgbnVsbCwgdGhpcy5zdGF0ZS52YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0YXdhaXQgdGhpcy5vcHRpb25zLm9uU2V0dGxlZD8uKGRhdGEsIG51bGwsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdHR5cGU6IFwic3VjY2Vzc1wiLFxuXHRcdFx0XHRkYXRhXG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBkYXRhO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vbkVycm9yPy4oZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5vcHRpb25zLm9uRXJyb3I/LihlcnJvciwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHR9XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLiNtdXRhdGlvbkNhY2hlLmNvbmZpZy5vblNldHRsZWQ/Lih2b2lkIDAsIGVycm9yLCB0aGlzLnN0YXRlLnZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy5vcHRpb25zLm9uU2V0dGxlZD8uKHZvaWQgMCwgZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHR0eXBlOiBcImVycm9yXCIsXG5cdFx0XHRcdGVycm9yXG5cdFx0XHR9KTtcblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRpZiAodGhpcy4jcmV0cnllciA9PT0gcmV0cnllcikgdGhpcy4jcmV0cnllciA9IHZvaWQgMDtcblx0XHRcdHRoaXMuI211dGF0aW9uQ2FjaGUucnVuTmV4dCh0aGlzKTtcblx0XHR9XG5cdH1cblx0I2Rpc3BhdGNoKGFjdGlvbikge1xuXHRcdGNvbnN0IHJlZHVjZXIgPSAoc3RhdGUpID0+IHtcblx0XHRcdHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcblx0XHRcdFx0Y2FzZSBcImZhaWxlZFwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudDogYWN0aW9uLmZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRmYWlsdXJlUmVhc29uOiBhY3Rpb24uZXJyb3Jcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInBhdXNlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNQYXVzZWQ6IHRydWVcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImNvbnRpbnVlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNQYXVzZWQ6IGZhbHNlXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJwZW5kaW5nXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0Y29udGV4dDogYWN0aW9uLmNvbnRleHQsXG5cdFx0XHRcdFx0ZGF0YTogdm9pZCAwLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudDogMCxcblx0XHRcdFx0XHRmYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdFx0XHRcdGVycm9yOiBudWxsLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBhY3Rpb24uaXNQYXVzZWQsXG5cdFx0XHRcdFx0c3RhdHVzOiBcInBlbmRpbmdcIixcblx0XHRcdFx0XHR2YXJpYWJsZXM6IGFjdGlvbi52YXJpYWJsZXMsXG5cdFx0XHRcdFx0c3VibWl0dGVkQXQ6IERhdGUubm93KClcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInN1Y2Nlc3NcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRkYXRhOiBhY3Rpb24uZGF0YSxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRcdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdFx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiZXJyb3JcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRkYXRhOiB2b2lkIDAsXG5cdFx0XHRcdFx0ZXJyb3I6IGFjdGlvbi5lcnJvcixcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IHN0YXRlLmZhaWx1cmVDb3VudCArIDEsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZSxcblx0XHRcdFx0XHRzdGF0dXM6IFwiZXJyb3JcIlxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0dGhpcy5zdGF0ZSA9IHJlZHVjZXIodGhpcy5zdGF0ZSk7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0b2JzZXJ2ZXIub25NdXRhdGlvblVwZGF0ZShhY3Rpb24pO1xuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdG11dGF0aW9uOiB0aGlzLFxuXHRcdFx0XHR0eXBlOiBcInVwZGF0ZWRcIixcblx0XHRcdFx0YWN0aW9uXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbmZ1bmN0aW9uIGdldERlZmF1bHRTdGF0ZSgpIHtcblx0cmV0dXJuIHtcblx0XHRjb250ZXh0OiB2b2lkIDAsXG5cdFx0ZGF0YTogdm9pZCAwLFxuXHRcdGVycm9yOiBudWxsLFxuXHRcdGZhaWx1cmVDb3VudDogMCxcblx0XHRmYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGlzUGF1c2VkOiBmYWxzZSxcblx0XHRzdGF0dXM6IFwiaWRsZVwiLFxuXHRcdHZhcmlhYmxlczogdm9pZCAwLFxuXHRcdHN1Ym1pdHRlZEF0OiAwXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE11dGF0aW9uLCBnZXREZWZhdWx0U3RhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb24uanMubWFwIiwiaW1wb3J0IHsgbWF0Y2hNdXRhdGlvbiwgbm9vcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBNdXRhdGlvbiB9IGZyb20gXCIuL211dGF0aW9uLmpzXCI7XG4vLyNyZWdpb24gc3JjL211dGF0aW9uQ2FjaGUudHNcbi8qKlxuKiBUaGUgYE11dGF0aW9uQ2FjaGVgIGlzIHRoZSBzdG9yYWdlIGZvciBtdXRhdGlvbnMuXG4qXG4qIE5vcm1hbGx5LCB5b3Ugd2lsbCBub3QgaW50ZXJhY3Qgd2l0aCB0aGUgYE11dGF0aW9uQ2FjaGVgIGRpcmVjdGx5IGFuZCBpbnN0ZWFkIHVzZSBhXG4qIGBRdWVyeUNsaWVudGAuIFlvdSBjYW4gc3Vic2NyaWJlIHRvIGl0IChpbmhlcml0ZWQgZnJvbSBgU3Vic2NyaWJhYmxlYCkgdG8gYmUgaW5mb3JtZWQgb2Zcbiogc2FmZS9rbm93biB1cGRhdGVzIHRvIHRoZSBjYWNoZSwgc3VjaCBhcyBtdXRhdGlvbnMgYmVpbmcgYWRkZWQsIHJlbW92ZWQsIG9yIHVwZGF0ZWQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gbXV0YXRpb25DYWNoZS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XG4qICAgY29uc29sZS5sb2coZXZlbnQudHlwZSwgZXZlbnQubXV0YXRpb24pXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBNdXRhdGlvbkNhY2hlID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjbXV0YXRpb25zO1xuXHQjc2NvcGVzO1xuXHQjbXV0YXRpb25JZDtcblx0Y29uc3RydWN0b3IoY29uZmlnID0ge30pIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnO1xuXHRcdHRoaXMuI211dGF0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy4jc2NvcGVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLiNtdXRhdGlvbklkID0gMDtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdGJ1aWxkKGNsaWVudCwgb3B0aW9ucywgc3RhdGUpIHtcblx0XHRjb25zdCBtdXRhdGlvbiA9IG5ldyBNdXRhdGlvbih7XG5cdFx0XHRjbGllbnQsXG5cdFx0XHRtdXRhdGlvbkNhY2hlOiB0aGlzLFxuXHRcdFx0bXV0YXRpb25JZDogKyt0aGlzLiNtdXRhdGlvbklkLFxuXHRcdFx0b3B0aW9uczogY2xpZW50LmRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucyksXG5cdFx0XHRzdGF0ZVxuXHRcdH0pO1xuXHRcdHRoaXMuYWRkKG11dGF0aW9uKTtcblx0XHRyZXR1cm4gbXV0YXRpb247XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRhZGQobXV0YXRpb24pIHtcblx0XHR0aGlzLiNtdXRhdGlvbnMuYWRkKG11dGF0aW9uKTtcblx0XHRjb25zdCBzY29wZSA9IHNjb3BlRm9yKG11dGF0aW9uKTtcblx0XHRpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCBzY29wZWRNdXRhdGlvbnMgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcblx0XHRcdGlmIChzY29wZWRNdXRhdGlvbnMpIHNjb3BlZE11dGF0aW9ucy5wdXNoKG11dGF0aW9uKTtcblx0XHRcdGVsc2UgdGhpcy4jc2NvcGVzLnNldChzY29wZSwgW211dGF0aW9uXSk7XG5cdFx0fVxuXHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwiYWRkZWRcIixcblx0XHRcdG11dGF0aW9uXG5cdFx0fSk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRyZW1vdmUobXV0YXRpb24pIHtcblx0XHRpZiAodGhpcy4jbXV0YXRpb25zLmRlbGV0ZShtdXRhdGlvbikpIHtcblx0XHRcdGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuXHRcdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0XHRjb25zdCBzY29wZWRNdXRhdGlvbnMgPSB0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKTtcblx0XHRcdFx0aWYgKHNjb3BlZE11dGF0aW9ucykge1xuXHRcdFx0XHRcdGlmIChzY29wZWRNdXRhdGlvbnMubGVuZ3RoID4gMSkge1xuXHRcdFx0XHRcdFx0Y29uc3QgaW5kZXggPSBzY29wZWRNdXRhdGlvbnMuaW5kZXhPZihtdXRhdGlvbik7XG5cdFx0XHRcdFx0XHRpZiAoaW5kZXggIT09IC0xKSBzY29wZWRNdXRhdGlvbnMuc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdFx0XHR9IGVsc2UgaWYgKHNjb3BlZE11dGF0aW9uc1swXSA9PT0gbXV0YXRpb24pIHRoaXMuI3Njb3Blcy5kZWxldGUoc2NvcGUpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHRoaXMubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0bXV0YXRpb25cblx0XHR9KTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdGNhblJ1bihtdXRhdGlvbikge1xuXHRcdGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuXHRcdGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGNvbnN0IGZpcnN0UGVuZGluZ011dGF0aW9uID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk/LmZpbmQoKG0pID0+IG0uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIik7XG5cdFx0XHRyZXR1cm4gIWZpcnN0UGVuZGluZ011dGF0aW9uIHx8IGZpcnN0UGVuZGluZ011dGF0aW9uID09PSBtdXRhdGlvbjtcblx0XHR9IGVsc2UgcmV0dXJuIHRydWU7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRydW5OZXh0KG11dGF0aW9uKSB7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuICh0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKT8uZmluZCgobSkgPT4gbSAhPT0gbXV0YXRpb24gJiYgbS5zdGF0ZS5pc1BhdXNlZCkpPy5jb250aW51ZSgpID8/IFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdGVsc2UgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYWxsIG11dGF0aW9ucyBmcm9tIHRoZSBjYWNoZS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCpcblx0KiBtdXRhdGlvbkNhY2hlLmNsZWFyKClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXIoKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbnMuZm9yRWFjaCgobXV0YXRpb24pID0+IHtcblx0XHRcdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0XHRcdG11dGF0aW9uXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbnMuY2xlYXIoKTtcblx0XHRcdHRoaXMuI3Njb3Blcy5jbGVhcigpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYWxsIG11dGF0aW9ucyB3aXRoaW4gdGhlIGNhY2hlLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IGEgbXV0YXRpb24gaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogY29uc3QgbXV0YXRpb25zID0gbXV0YXRpb25DYWNoZS5nZXRBbGwoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRBbGwoKSB7XG5cdFx0cmV0dXJuIEFycmF5LmZyb20odGhpcy4jbXV0YXRpb25zKTtcblx0fVxuXHQvKipcblx0KiBBIHNsaWdodGx5IG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGFuIGV4aXN0aW5nIG11dGF0aW9uIGluc3RhbmNlIGZyb21cblx0KiB0aGUgY2FjaGUuIElmIHRoZSBtdXRhdGlvbiBkb2VzIG5vdCBleGlzdCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgYSBtdXRhdGlvbiBpbiByYXJlIHNjZW5hcmlvcy5cblx0KlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uQ2FjaGUjZmluZEFsbH1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogY29uc3QgbXV0YXRpb24gPSBtdXRhdGlvbkNhY2hlLmZpbmQoeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSlcblx0KiBgYGBcblx0Ki9cblx0ZmluZChmaWx0ZXJzKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkRmlsdGVycyA9IHtcblx0XHRcdGV4YWN0OiB0cnVlLFxuXHRcdFx0Li4uZmlsdGVyc1xuXHRcdH07XG5cdFx0cmV0dXJuIHRoaXMuZ2V0QWxsKCkuZmluZCgobXV0YXRpb24pID0+IG1hdGNoTXV0YXRpb24oZGVmYXVsdGVkRmlsdGVycywgbXV0YXRpb24pKTtcblx0fVxuXHQvKipcblx0KiBBbiBldmVuIG1vcmUgYWR2YW5jZWQgbWV0aG9kIHRoYXQgY2FuIGJlIHVzZWQgdG8gZ2V0IGV4aXN0aW5nIG11dGF0aW9uIGluc3RhbmNlcyBmcm9tIHRoZVxuXHQqIGNhY2hlIHRoYXQgbWF0Y2ggdGhlIGdpdmVuIGZpbHRlcnMuIElmIG5vIG11dGF0aW9ucyBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgbXV0YXRpb25zIGluIHJhcmUgc2NlbmFyaW9zLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb25DYWNoZSNmaW5kfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCpcblx0KiBjb25zdCBtdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlLmZpbmRBbGwoeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSlcblx0KiBgYGBcblx0Ki9cblx0ZmluZEFsbChmaWx0ZXJzID0ge30pIHtcblx0XHRyZXR1cm4gdGhpcy5nZXRBbGwoKS5maWx0ZXIoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKGZpbHRlcnMsIG11dGF0aW9uKSk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRub3RpZnkoZXZlbnQpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKGV2ZW50KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0cmVzdW1lUGF1c2VkTXV0YXRpb25zKCkge1xuXHRcdGNvbnN0IHBhdXNlZE11dGF0aW9ucyA9IHRoaXMuZ2V0QWxsKCkuZmlsdGVyKCh4KSA9PiB4LnN0YXRlLmlzUGF1c2VkKTtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiBQcm9taXNlLmFsbChwYXVzZWRNdXRhdGlvbnMubWFwKChtdXRhdGlvbikgPT4gbXV0YXRpb24uY29udGludWUoKS5jYXRjaChub29wKSkpKTtcblx0fVxufTtcbmZ1bmN0aW9uIHNjb3BlRm9yKG11dGF0aW9uKSB7XG5cdHJldHVybiBtdXRhdGlvbi5vcHRpb25zLnNjb3BlPy5pZDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTXV0YXRpb25DYWNoZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbkNhY2hlLmpzLm1hcCIsImltcG9ydCB7IGhhc2hLZXksIHNoYWxsb3dFcXVhbE9iamVjdHMgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgZ2V0RGVmYXVsdFN0YXRlIH0gZnJvbSBcIi4vbXV0YXRpb24uanNcIjtcbi8vI3JlZ2lvbiBzcmMvbXV0YXRpb25PYnNlcnZlci50c1xuLyoqXG4qIE9ic2VydmVzIGEgc2luZ2xlIG11dGF0aW9uIGFuZCBkZXJpdmVzIGEgYE11dGF0aW9uT2JzZXJ2ZXJSZXN1bHRgIGZyb20gaXQuXG4qIEEgZnJhbWV3b3JrIGhvb2sgbGlrZSBgdXNlTXV0YXRpb25gIGNyZWF0ZXMgb25lIGBNdXRhdGlvbk9ic2VydmVyYCBwZXIgaG9va1xuKiBjYWxsLCBrZWVwcyBpdCBzdGFibGUgYWNyb3NzIHJlLXJlbmRlcnMsIGNhbGxzIGBzZXRPcHRpb25zYCB3aGVuIHRoZSBvcHRpb25zXG4qIHBhc3NlZCB0byB0aGUgaG9vayBjaGFuZ2UsIHN1YnNjcmliZXMgdG8gaXQgdG8gcmUtcmVuZGVyIG9uIHVwZGF0ZXMsIGFuZFxuKiByZWFkcyBgZ2V0Q3VycmVudFJlc3VsdCgpYCBmb3IgdGhlIHZhbHVlIHRvIHJldHVybi4gQ2FsbGluZyBgbXV0YXRlKClgXG4qIGJ1aWxkcyBhIG5ldyB1bmRlcmx5aW5nIGBNdXRhdGlvbmAgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYCBhbmQgZXhlY3V0ZXMgaXQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBtdXRhdGlvbkZuOiAodmFyaWFibGVzOiB7IHRpdGxlOiBzdHJpbmcgfSkgPT4gYWRkUG9zdCh2YXJpYWJsZXMpLFxuKiB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb25PYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG5cdCNjdXJyZW50TXV0YXRpb247XG5cdCNtdXRhdGVPcHRpb25zO1xuXHRjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNsaWVudDtcblx0XHR0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdFx0dGhpcy5iaW5kTWV0aG9kcygpO1xuXHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHR9XG5cdGJpbmRNZXRob2RzKCkge1xuXHRcdHRoaXMubXV0YXRlID0gdGhpcy5tdXRhdGUuYmluZCh0aGlzKTtcblx0XHR0aGlzLnJlc2V0ID0gdGhpcy5yZXNldC5iaW5kKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucy5cblx0KlxuXHQqIElmIHRoZSBuZXcgYG11dGF0aW9uS2V5YCBkaWZmZXJzIGZyb20gdGhlIHByZXZpb3VzIG9uZSAoYW5kIGJvdGggd2VyZVxuXHQqIGRlZmluZWQpLCB0aGUgb2JzZXJ2ZXIgaXMgcmVzZXQsIGRldGFjaGluZyBpdCBmcm9tIHRoZSBtdXRhdGlvbiBpdCB3YXNcblx0KiBvYnNlcnZpbmcuIE90aGVyd2lzZSwgaWYgdGhlIGN1cnJlbnRseSBvYnNlcnZlZCBtdXRhdGlvbiBpcyBzdGlsbFxuXHQqIGBwZW5kaW5nYCwgaXRzIG9wdGlvbnMgYXJlIHVwZGF0ZWQgaW4gcGxhY2UgYXMgd2VsbC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5zZXRPcHRpb25zKHtcblx0KiAgIG11dGF0aW9uRm46ICh2YXJpYWJsZXM6IHsgdGl0bGU6IHN0cmluZyB9KSA9PiBhZGRQb3N0KHZhcmlhYmxlcyksXG5cdCogICBvblN1Y2Nlc3M6IChkYXRhKSA9PiBjb25zb2xlLmxvZyhkYXRhKSxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHR0aGlzLm9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAoIXNoYWxsb3dFcXVhbE9iamVjdHModGhpcy5vcHRpb25zLCBwcmV2T3B0aW9ucykpIHRoaXMuI2NsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCkubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuXHRcdFx0bXV0YXRpb246IHRoaXMuI2N1cnJlbnRNdXRhdGlvbixcblx0XHRcdG9ic2VydmVyOiB0aGlzXG5cdFx0fSk7XG5cdFx0aWYgKHByZXZPcHRpb25zPy5tdXRhdGlvbktleSAmJiB0aGlzLm9wdGlvbnMubXV0YXRpb25LZXkgJiYgaGFzaEtleShwcmV2T3B0aW9ucy5tdXRhdGlvbktleSkgIT09IGhhc2hLZXkodGhpcy5vcHRpb25zLm11dGF0aW9uS2V5KSkgdGhpcy5yZXNldCgpO1xuXHRcdGVsc2UgaWYgKHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhpcy4jY3VycmVudE11dGF0aW9uLnNldE9wdGlvbnModGhpcy5vcHRpb25zKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSAmJiB0aGlzLiNjdXJyZW50TXV0YXRpb24pIHtcblx0XHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5hZGRPYnNlcnZlcih0aGlzKTtcblx0XHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHRcdH1cblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkgdGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0fVxuXHQvKiogQGludGVybmFsICovXG5cdG9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKSB7XG5cdFx0dGhpcy4jdXBkYXRlUmVzdWx0KCk7XG5cdFx0dGhpcy4jbm90aWZ5KGFjdGlvbik7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgb2JzZXJ2ZXIncyBjdXJyZW50IHJlc3VsdCwgZGVyaXZlZCBmcm9tIHRoZSBvYnNlcnZlZFxuXHQqIG11dGF0aW9uJ3Mgc3RhdGUgKG9yIHRoZSBkZWZhdWx0LCBgaWRsZWAgc3RhdGUgaWYgbm8gbXV0YXRpb24gaGFzIGJlZW5cblx0KiBidWlsdCB5ZXQsIGUuZy4gYmVmb3JlIHRoZSBmaXJzdCBgbXV0YXRlKClgIGNhbGwgb3IgYWZ0ZXIgYHJlc2V0KClgKS5cblx0Ki9cblx0Z2V0Q3VycmVudFJlc3VsdCgpIHtcblx0XHRyZXR1cm4gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0fVxuXHQvKipcblx0KiBEZXRhY2hlcyB0aGUgb2JzZXJ2ZXIgZnJvbSB0aGUgbXV0YXRpb24gaXQgaXMgY3VycmVudGx5IG9ic2VydmluZyAoaWZcblx0KiBhbnkpIGFuZCByZXNldHMgdGhlIG9ic2VydmVkIHJlc3VsdCBiYWNrIHRvIGl0cyBkZWZhdWx0LCBgaWRsZWAgc3RhdGUuXG5cdCpcblx0KiBUaGlzIGRvZXMgbm90IGNhbmNlbCBhbiBpbi1mbGlnaHQgbXV0YXRpb247IHRoZSBtdXRhdGlvbiBpdHNlbGYga2VlcHNcblx0KiBydW5uaW5nIHRvIGNvbXBsZXRpb24gYW5kIGl0cyBvd24gY2FsbGJhY2tzIHN0aWxsIGZpcmUsIGJ1dCB0aGlzXG5cdCogb2JzZXJ2ZXIgc3RvcHMgcmVmbGVjdGluZyBpdHMgc3RhdGUgYW5kIGEgc3Vic2VxdWVudCBgbXV0YXRlKClgIGNhbGxcblx0KiB3aWxsIGJ1aWxkIGEgYnJhbmQgbmV3IG11dGF0aW9uLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIG9ic2VydmVyLnJlc2V0KClcblx0KiBgYGBcblx0KlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uT2JzZXJ2ZXIjbXV0YXRlfVxuXHQqL1xuXHRyZXNldCgpIHtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbiA9IHZvaWQgMDtcblx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0XHR0aGlzLiNub3RpZnkoKTtcblx0fVxuXHQvKipcblx0KiBCdWlsZHMgYSBuZXcgYE11dGF0aW9uYCBpbiB0aGUgYE11dGF0aW9uQ2FjaGVgIHVzaW5nIHRoZSBvYnNlcnZlcidzXG5cdCogY3VycmVudCBvcHRpb25zLCBkZXRhY2hlcyB0aGlzIG9ic2VydmVyIGZyb20gYW55IHByZXZpb3VzbHkgb2JzZXJ2ZWRcblx0KiBtdXRhdGlvbiwgYXR0YWNoZXMgaXQgdG8gdGhlIG5ldyBvbmUsIGFuZCBleGVjdXRlcyBpdCB3aXRoIHRoZSBnaXZlblxuXHQqIHZhcmlhYmxlcy5cblx0KlxuXHQqIFRoZSBvcHRpb25hbCBwZXItY2FsbCBgb3B0aW9uc2AgKGBvblN1Y2Nlc3NgL2BvbkVycm9yYC9gb25TZXR0bGVkYCkgYXJlXG5cdCogaW52b2tlZCBvbmNlIHRoZSBtdXRhdGlvbiBzZXR0bGVzLCBpbiBhZGRpdGlvbiB0byBhbnkgY2FsbGJhY2tzIGRlZmluZWRcblx0KiBvbiB0aGUgb2JzZXJ2ZXIncyBvd24gb3B0aW9ucy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBvYnNlcnZlci5tdXRhdGUoXG5cdCogICB7IHRpdGxlOiAnTmV3IHBvc3QnIH0sXG5cdCogICB7IG9uU3VjY2VzczogKGRhdGEpID0+IGNvbnNvbGUubG9nKGRhdGEpIH0sXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRtdXRhdGUodmFyaWFibGVzLCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jbXV0YXRlT3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uPy5yZW1vdmVPYnNlcnZlcih0aGlzKTtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24gPSB0aGlzLiNjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgdGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24uYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5leGVjdXRlKHZhcmlhYmxlcyk7XG5cdH1cblx0I3VwZGF0ZVJlc3VsdCgpIHtcblx0XHRjb25zdCBzdGF0ZSA9IHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8uc3RhdGUgPz8gZ2V0RGVmYXVsdFN0YXRlKCk7XG5cdFx0dGhpcy4jY3VycmVudFJlc3VsdCA9IHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0aXNQZW5kaW5nOiBzdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiLFxuXHRcdFx0aXNTdWNjZXNzOiBzdGF0ZS5zdGF0dXMgPT09IFwic3VjY2Vzc1wiLFxuXHRcdFx0aXNFcnJvcjogc3RhdGUuc3RhdHVzID09PSBcImVycm9yXCIsXG5cdFx0XHRpc0lkbGU6IHN0YXRlLnN0YXR1cyA9PT0gXCJpZGxlXCIsXG5cdFx0XHRtdXRhdGU6IHRoaXMubXV0YXRlLFxuXHRcdFx0cmVzZXQ6IHRoaXMucmVzZXRcblx0XHR9O1xuXHR9XG5cdCNub3RpZnkoYWN0aW9uKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRpZiAodGhpcy4jbXV0YXRlT3B0aW9ucyAmJiB0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHRcdGNvbnN0IHZhcmlhYmxlcyA9IHRoaXMuI2N1cnJlbnRSZXN1bHQudmFyaWFibGVzO1xuXHRcdFx0XHRjb25zdCBvbk11dGF0ZVJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQuY29udGV4dDtcblx0XHRcdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdFx0XHRtZXRhOiB0aGlzLm9wdGlvbnMubWV0YSxcblx0XHRcdFx0XHRtdXRhdGlvbktleTogdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5XG5cdFx0XHRcdH07XG5cdFx0XHRcdGlmIChhY3Rpb24/LnR5cGUgPT09IFwic3VjY2Vzc1wiKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuI211dGF0ZU9wdGlvbnMub25TdWNjZXNzPy4oYWN0aW9uLmRhdGEsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0dGhpcy4jbXV0YXRlT3B0aW9ucy5vblNldHRsZWQ/LihhY3Rpb24uZGF0YSwgbnVsbCwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9IGVsc2UgaWYgKGFjdGlvbj8udHlwZSA9PT0gXCJlcnJvclwiKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuI211dGF0ZU9wdGlvbnMub25FcnJvcj8uKGFjdGlvbi5lcnJvciwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHR0aGlzLiNtdXRhdGVPcHRpb25zLm9uU2V0dGxlZD8uKHZvaWQgMCwgYWN0aW9uLmVycm9yLCB2YXJpYWJsZXMsIG9uTXV0YXRlUmVzdWx0LCBjb250ZXh0KTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKHRoaXMuI2N1cnJlbnRSZXN1bHQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE11dGF0aW9uT2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PYnNlcnZlci5qcy5tYXAiLCJpbXBvcnQgeyByZXBsYWNlRXF1YWxEZWVwLCBzaGFsbG93RXF1YWxPYmplY3RzIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiLi9xdWVyeU9ic2VydmVyLmpzXCI7XG4vLyNyZWdpb24gc3JjL3F1ZXJpZXNPYnNlcnZlci50c1xuZnVuY3Rpb24gZGlmZmVyZW5jZShhcnJheTEsIGFycmF5Mikge1xuXHRjb25zdCBleGNsdWRlU2V0ID0gbmV3IFNldChhcnJheTIpO1xuXHRyZXR1cm4gYXJyYXkxLmZpbHRlcigoeCkgPT4gIWV4Y2x1ZGVTZXQuaGFzKHgpKTtcbn1cbi8qKlxuKiBBIGBRdWVyaWVzT2JzZXJ2ZXJgIHdhdGNoZXMgYW4gYXJyYXkgb2YgcXVlcmllcyBhdCBvbmNlLCBleHBvc2luZyB0aGVtIGFzXG4qIGEgc2luZ2xlIGFycmF5IG9mIGBRdWVyeU9ic2VydmVyUmVzdWx0YHMgKG9yLCB3aGVuIGEgYGNvbWJpbmVgIG9wdGlvbiBpc1xuKiBnaXZlbiwgYXMgYSBjb21iaW5lZCB2YWx1ZSBkZXJpdmVkIGZyb20gdGhhdCBhcnJheSkuIEl0IG1hbmFnZXMgb25lXG4qIGludGVybmFsIGBRdWVyeU9ic2VydmVyYCBwZXIgcXVlcnksIGFuZCBpcyB0aGUgcHJpbWl0aXZlIHRoYXQgZnJhbWV3b3JrXG4qIGFkYXB0ZXJzIChlLmcuIGB1c2VRdWVyaWVzYCkgYnVpbGQgdGhlaXIgaG9va3Mgb24gdG9wIG9mLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBvYnNlcnZlciA9IG5ldyBRdWVyaWVzT2JzZXJ2ZXIocXVlcnlDbGllbnQsIFtcbiogICB7IHF1ZXJ5S2V5OiBbJ3Bvc3QnLCAxXSwgcXVlcnlGbjogZmV0Y2hQb3N0IH0sXG4qICAgeyBxdWVyeUtleTogWydwb3N0JywgMl0sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuKiBdKVxuKlxuKiBjb25zdCB1bnN1YnNjcmliZSA9IG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG4qICAgY29uc29sZS5sb2cocmVzdWx0KVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcmllc09ic2VydmVyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjY2xpZW50O1xuXHQjcmVzdWx0O1xuXHQjcXVlcmllcztcblx0I29wdGlvbnM7XG5cdCNvYnNlcnZlcnM7XG5cdCNjb21iaW5lZFJlc3VsdDtcblx0I2xhc3RDb21iaW5lO1xuXHQjbGFzdFJlc3VsdDtcblx0I2xhc3RRdWVyeUhhc2hlcztcblx0I29ic2VydmVyTWF0Y2hlcyA9IFtdO1xuXHRjb25zdHJ1Y3RvcihjbGllbnQsIHF1ZXJpZXMsIG9wdGlvbnMpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNsaWVudDtcblx0XHR0aGlzLiNvcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLiNxdWVyaWVzID0gW107XG5cdFx0dGhpcy4jb2JzZXJ2ZXJzID0gW107XG5cdFx0dGhpcy4jcmVzdWx0ID0gW107XG5cdFx0dGhpcy5zZXRRdWVyaWVzKHF1ZXJpZXMpO1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICh0aGlzLmxpc3RlbmVycy5zaXplID09PSAxKSB0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG5cdFx0XHRcdHRoaXMuI29uVXBkYXRlKG9ic2VydmVyLCByZXN1bHQpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMubGlzdGVuZXJzLnNpemUpIHRoaXMuZGVzdHJveSgpO1xuXHR9XG5cdC8qKlxuXHQqIFN0b3BzIG9ic2VydmluZyBhbGwgcXVlcmllczogY2xlYXJzIGFsbCBsaXN0ZW5lcnMgYW5kIGRlc3Ryb3lzIGV2ZXJ5XG5cdCogdW5kZXJseWluZyBgUXVlcnlPYnNlcnZlcmAgdGhpcyBvYnNlcnZlciBtYW5hZ2VzLlxuXHQqL1xuXHRkZXN0cm95KCkge1xuXHRcdHRoaXMubGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdG9ic2VydmVyLmRlc3Ryb3koKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXBsYWNlcyB0aGUgc2V0IG9mIHF1ZXJpZXMgYmVpbmcgb2JzZXJ2ZWQuIEV4aXN0aW5nIGBRdWVyeU9ic2VydmVyYHNcblx0KiBhcmUgcmV1c2VkIGZvciBxdWVyaWVzIHRoYXQgbWF0Y2ggYW4gYWxyZWFkeS1vYnNlcnZlZCBxdWVyeSBoYXNoO1xuXHQqIG9ic2VydmVycyBmb3IgcXVlcmllcyB0aGF0IGFyZSBubyBsb25nZXIgcHJlc2VudCBhcmUgZGVzdHJveWVkLCBhbmQgbmV3XG5cdCogb2JzZXJ2ZXJzIGFyZSBjcmVhdGVkIGFuZCBzdWJzY3JpYmVkIHRvIGZvciBuZXdseSBhZGRlZCBxdWVyaWVzLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIG9ic2VydmVyLnNldFF1ZXJpZXMoW1xuXHQqICAgeyBxdWVyeUtleTogWydwb3N0JywgMV0sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuXHQqICAgeyBxdWVyeUtleTogWydwb3N0JywgM10sIHF1ZXJ5Rm46IGZldGNoUG9zdCB9LFxuXHQqIF0pXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJpZXMocXVlcmllcywgb3B0aW9ucykge1xuXHRcdHRoaXMuI3F1ZXJpZXMgPSBxdWVyaWVzO1xuXHRcdHRoaXMuI29wdGlvbnMgPSBvcHRpb25zO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGNvbnN0IHF1ZXJ5SGFzaGVzID0gcXVlcmllcy5tYXAoKHF1ZXJ5KSA9PiB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhxdWVyeSkucXVlcnlIYXNoKTtcblx0XHRcdGlmIChuZXcgU2V0KHF1ZXJ5SGFzaGVzKS5zaXplICE9PSBxdWVyeUhhc2hlcy5sZW5ndGgpIGNvbnNvbGUud2FybihcIltRdWVyaWVzT2JzZXJ2ZXJdOiBEdXBsaWNhdGUgUXVlcmllcyBmb3VuZC4gVGhpcyBtaWdodCByZXN1bHQgaW4gdW5leHBlY3RlZCBiZWhhdmlvci5cIik7XG5cdFx0fVxuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0Y29uc3QgcHJldk9ic2VydmVycyA9IHRoaXMuI29ic2VydmVycztcblx0XHRcdGNvbnN0IG5ld09ic2VydmVyTWF0Y2hlcyA9IHRoaXMuI2ZpbmRNYXRjaGluZ09ic2VydmVycyh0aGlzLiNxdWVyaWVzKTtcblx0XHRcdG5ld09ic2VydmVyTWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIuc2V0T3B0aW9ucyhtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMpKTtcblx0XHRcdGNvbnN0IG5ld09ic2VydmVycyA9IG5ld09ic2VydmVyTWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5vYnNlcnZlcik7XG5cdFx0XHRjb25zdCBuZXdSZXN1bHQgPSBuZXdPYnNlcnZlcnMubWFwKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0XHRcdGNvbnN0IGhhc0xlbmd0aENoYW5nZSA9IHByZXZPYnNlcnZlcnMubGVuZ3RoICE9PSBuZXdPYnNlcnZlcnMubGVuZ3RoO1xuXHRcdFx0Y29uc3QgaGFzSW5kZXhDaGFuZ2UgPSBuZXdPYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIsIGluZGV4KSA9PiBvYnNlcnZlciAhPT0gcHJldk9ic2VydmVyc1tpbmRleF0pO1xuXHRcdFx0Y29uc3QgaGFzU3RydWN0dXJhbENoYW5nZSA9IGhhc0xlbmd0aENoYW5nZSB8fCBoYXNJbmRleENoYW5nZTtcblx0XHRcdGNvbnN0IGhhc1Jlc3VsdENoYW5nZSA9IGhhc1N0cnVjdHVyYWxDaGFuZ2UgPyB0cnVlIDogbmV3UmVzdWx0LnNvbWUoKHJlc3VsdCwgaW5kZXgpID0+IHtcblx0XHRcdFx0Y29uc3QgcHJldiA9IHRoaXMuI3Jlc3VsdFtpbmRleF07XG5cdFx0XHRcdHJldHVybiAhcHJldiB8fCAhc2hhbGxvd0VxdWFsT2JqZWN0cyhyZXN1bHQsIHByZXYpO1xuXHRcdFx0fSk7XG5cdFx0XHRpZiAoIWhhc1N0cnVjdHVyYWxDaGFuZ2UgJiYgIWhhc1Jlc3VsdENoYW5nZSkgcmV0dXJuO1xuXHRcdFx0aWYgKGhhc1N0cnVjdHVyYWxDaGFuZ2UpIHtcblx0XHRcdFx0dGhpcy4jb2JzZXJ2ZXJNYXRjaGVzID0gbmV3T2JzZXJ2ZXJNYXRjaGVzO1xuXHRcdFx0XHR0aGlzLiNvYnNlcnZlcnMgPSBuZXdPYnNlcnZlcnM7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLiNyZXN1bHQgPSBuZXdSZXN1bHQ7XG5cdFx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHJldHVybjtcblx0XHRcdGlmIChoYXNTdHJ1Y3R1cmFsQ2hhbmdlKSB7XG5cdFx0XHRcdGRpZmZlcmVuY2UocHJldk9ic2VydmVycywgbmV3T2JzZXJ2ZXJzKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRcdG9ic2VydmVyLmRlc3Ryb3koKTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGRpZmZlcmVuY2UobmV3T2JzZXJ2ZXJzLCBwcmV2T2JzZXJ2ZXJzKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRcdG9ic2VydmVyLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLiNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLiNub3RpZnkoKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBtb3N0IHJlY2VudGx5IGNvbXB1dGVkIGFycmF5IG9mIGBRdWVyeU9ic2VydmVyUmVzdWx0YHMsIG9uZVxuXHQqIHBlciBvYnNlcnZlZCBxdWVyeSwgaW4gdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZVxuXHQqIGNvbnN0cnVjdG9yIG9yIGBzZXRRdWVyaWVzYC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCByZXN1bHRzID0gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG5cdCogY29uc3QgZGF0YSA9IHJlc3VsdHMubWFwKChyZXN1bHQpID0+IHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRDdXJyZW50UmVzdWx0KCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgdW5kZXJseWluZyBgUXVlcnlgIGluc3RhbmNlcyBjdXJyZW50bHkgYmVpbmcgb2JzZXJ2ZWQsIGluXG5cdCogdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZSBjb25zdHJ1Y3RvciBvciBgc2V0UXVlcmllc2AuXG5cdCovXG5cdGdldFF1ZXJpZXMoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI29ic2VydmVycy5tYXAoKG9ic2VydmVyKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UXVlcnkoKSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgdW5kZXJseWluZyBgUXVlcnlPYnNlcnZlcmAgaW5zdGFuY2VzIHRoaXMgb2JzZXJ2ZXIgbWFuYWdlcyxcblx0KiBpbiB0aGUgc2FtZSBvcmRlciBhcyB0aGUgcXVlcmllcyBwYXNzZWQgdG8gdGhlIGNvbnN0cnVjdG9yIG9yXG5cdCogYHNldFF1ZXJpZXNgLlxuXHQqL1xuXHRnZXRPYnNlcnZlcnMoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI29ic2VydmVycztcblx0fVxuXHQvKipcblx0KiBUaGUgYFF1ZXJpZXNPYnNlcnZlcmAgY291bnRlcnBhcnQgb2Yge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjZ2V0T3B0aW1pc3RpY1Jlc3VsdH0g4oCUIGNvbXB1dGVzXG5cdCogdGhlIHJlc3VsdCBmb3IgdGhlIGdpdmVuIChhbHJlYWR5LWRlZmF1bHRlZCkgcXVlcmllcyByaWdodCBub3csIHN5bmNocm9ub3VzbHkuIENhbGxlZCBieVxuXHQqIGZyYW1ld29yayBhZGFwdGVycyAoZS5nLiBgdXNlUXVlcmllc2ApIGFoZWFkIG9mIHN1YnNjcmliaW5nLCByZXR1cm5pbmcgYSB0dXBsZSBvZiB0aGUgcmF3XG5cdCogcGVyLXF1ZXJ5IHJlc3VsdHMsIGEgZnVuY3Rpb24gdG8gY29tcHV0ZSB0aGUgY29tYmluZWQgcmVzdWx0IGZyb20gdGhlbSwgYW5kIGEgZnVuY3Rpb24gdG9cblx0KiB3cmFwIHRoZSByZXN1bHRzIGZvciBwcm9wZXJ0eS1hY2Nlc3MgdHJhY2tpbmcuXG5cdCovXG5cdGdldE9wdGltaXN0aWNSZXN1bHQocXVlcmllcywgY29tYmluZSkge1xuXHRcdGNvbnN0IG1hdGNoZXMgPSB0aGlzLiNmaW5kTWF0Y2hpbmdPYnNlcnZlcnMocXVlcmllcyk7XG5cdFx0Y29uc3QgcmVzdWx0ID0gbWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5vYnNlcnZlci5nZXRPcHRpbWlzdGljUmVzdWx0KG1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucykpO1xuXHRcdGNvbnN0IHF1ZXJ5SGFzaGVzID0gbWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMucXVlcnlIYXNoKTtcblx0XHRyZXR1cm4gW1xuXHRcdFx0cmVzdWx0LFxuXHRcdFx0KHIpID0+IHtcblx0XHRcdFx0cmV0dXJuIHRoaXMuI2NvbWJpbmVSZXN1bHQociA/PyByZXN1bHQsIGNvbWJpbmUsIHF1ZXJ5SGFzaGVzKTtcblx0XHRcdH0sXG5cdFx0XHQoKSA9PiB7XG5cdFx0XHRcdHJldHVybiB0aGlzLiN0cmFja1Jlc3VsdChyZXN1bHQsIG1hdGNoZXMpO1xuXHRcdFx0fVxuXHRcdF07XG5cdH1cblx0I3RyYWNrUmVzdWx0KHJlc3VsdCwgbWF0Y2hlcykge1xuXHRcdGNvbnN0IHRyYWNrZWRQcm9wcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0cmV0dXJuIG1hdGNoZXMubWFwKChtYXRjaCwgaW5kZXgpID0+IHtcblx0XHRcdGNvbnN0IG9ic2VydmVyUmVzdWx0ID0gcmVzdWx0W2luZGV4XTtcblx0XHRcdHJldHVybiAhbWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zLm5vdGlmeU9uQ2hhbmdlUHJvcHMgPyBtYXRjaC5vYnNlcnZlci50cmFja1Jlc3VsdChvYnNlcnZlclJlc3VsdCwgKGFjY2Vzc2VkUHJvcCkgPT4ge1xuXHRcdFx0XHRpZiAoIXRyYWNrZWRQcm9wcy5oYXMoYWNjZXNzZWRQcm9wKSkge1xuXHRcdFx0XHRcdHRyYWNrZWRQcm9wcy5hZGQoYWNjZXNzZWRQcm9wKTtcblx0XHRcdFx0XHRtYXRjaGVzLmZvckVhY2goKG0pID0+IHtcblx0XHRcdFx0XHRcdG0ub2JzZXJ2ZXIudHJhY2tQcm9wKGFjY2Vzc2VkUHJvcCk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pIDogb2JzZXJ2ZXJSZXN1bHQ7XG5cdFx0fSk7XG5cdH1cblx0I2NvbWJpbmVSZXN1bHQoaW5wdXQsIGNvbWJpbmUsIHF1ZXJ5SGFzaGVzKSB7XG5cdFx0aWYgKGNvbWJpbmUpIHtcblx0XHRcdGNvbnN0IGxhc3RIYXNoZXMgPSB0aGlzLiNsYXN0UXVlcnlIYXNoZXM7XG5cdFx0XHRjb25zdCBxdWVyeUhhc2hlc0NoYW5nZWQgPSBxdWVyeUhhc2hlcyAhPT0gdm9pZCAwICYmIGxhc3RIYXNoZXMgIT09IHZvaWQgMCAmJiAobGFzdEhhc2hlcy5sZW5ndGggIT09IHF1ZXJ5SGFzaGVzLmxlbmd0aCB8fCBxdWVyeUhhc2hlcy5zb21lKChoYXNoLCBpKSA9PiBoYXNoICE9PSBsYXN0SGFzaGVzW2ldKSk7XG5cdFx0XHRpZiAodGhpcy4jcmVzdWx0ICE9PSB0aGlzLiNsYXN0UmVzdWx0IHx8IHF1ZXJ5SGFzaGVzQ2hhbmdlZCB8fCBjb21iaW5lICE9PSB0aGlzLiNsYXN0Q29tYmluZSkge1xuXHRcdFx0XHR0aGlzLiNsYXN0Q29tYmluZSA9IGNvbWJpbmU7XG5cdFx0XHRcdHRoaXMuI2xhc3RSZXN1bHQgPSB0aGlzLiNyZXN1bHQ7XG5cdFx0XHRcdGlmIChxdWVyeUhhc2hlcyAhPT0gdm9pZCAwKSB0aGlzLiNsYXN0UXVlcnlIYXNoZXMgPSBxdWVyeUhhc2hlcztcblx0XHRcdFx0dGhpcy4jY29tYmluZWRSZXN1bHQgPSByZXBsYWNlRXF1YWxEZWVwKHRoaXMuI2NvbWJpbmVkUmVzdWx0LCBjb21iaW5lKGlucHV0KSk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gdGhpcy4jY29tYmluZWRSZXN1bHQ7XG5cdFx0fVxuXHRcdHJldHVybiBpbnB1dDtcblx0fVxuXHQjc2hvdWxkU2tpcENvbWJpbmUoKSB7XG5cdFx0cmV0dXJuICF0aGlzLiNvcHRpb25zPy5jb21iaW5lIHx8IHRoaXMuI29ic2VydmVycy5zb21lKChvYnNlcnZlciwgaW5kZXgpID0+IHtcblx0XHRcdHJldHVybiBvYnNlcnZlci5vcHRpb25zLnN1c3BlbnNlICYmIHRoaXMuI3Jlc3VsdFtpbmRleF0/LmRhdGEgPT09IHZvaWQgMDtcblx0XHR9KTtcblx0fVxuXHQjZmluZE1hdGNoaW5nT2JzZXJ2ZXJzKHF1ZXJpZXMpIHtcblx0XHRjb25zdCBwcmV2T2JzZXJ2ZXJzTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLiNvYnNlcnZlcnMuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdGNvbnN0IGtleSA9IG9ic2VydmVyLm9wdGlvbnMucXVlcnlIYXNoO1xuXHRcdFx0aWYgKCFrZXkpIHJldHVybjtcblx0XHRcdGNvbnN0IHByZXZpb3VzT2JzZXJ2ZXJzID0gcHJldk9ic2VydmVyc01hcC5nZXQoa2V5KTtcblx0XHRcdGlmIChwcmV2aW91c09ic2VydmVycykgcHJldmlvdXNPYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG5cdFx0XHRlbHNlIHByZXZPYnNlcnZlcnNNYXAuc2V0KGtleSwgW29ic2VydmVyXSk7XG5cdFx0fSk7XG5cdFx0Y29uc3Qgb2JzZXJ2ZXJzID0gW107XG5cdFx0cXVlcmllcy5mb3JFYWNoKChvcHRpb25zKSA9PiB7XG5cdFx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG5cdFx0XHRjb25zdCBvYnNlcnZlciA9IHByZXZPYnNlcnZlcnNNYXAuZ2V0KGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKT8uc2hpZnQoKSA/PyBuZXcgUXVlcnlPYnNlcnZlcih0aGlzLiNjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdFx0b2JzZXJ2ZXJzLnB1c2goe1xuXHRcdFx0XHRkZWZhdWx0ZWRRdWVyeU9wdGlvbnM6IGRlZmF1bHRlZE9wdGlvbnMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRyZXR1cm4gb2JzZXJ2ZXJzO1xuXHR9XG5cdCNvblVwZGF0ZShvYnNlcnZlciwgcmVzdWx0KSB7XG5cdFx0Y29uc3QgaW5kZXggPSB0aGlzLiNvYnNlcnZlcnMuaW5kZXhPZihvYnNlcnZlcik7XG5cdFx0aWYgKGluZGV4ICE9PSAtMSkge1xuXHRcdFx0dGhpcy4jcmVzdWx0ID0gdGhpcy4jcmVzdWx0LnNsaWNlKCk7XG5cdFx0XHR0aGlzLiNyZXN1bHRbaW5kZXhdID0gcmVzdWx0O1xuXHRcdFx0dGhpcy4jbm90aWZ5KCk7XG5cdFx0fVxuXHR9XG5cdCNub3RpZnkoKSB7XG5cdFx0aWYgKHRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdGNvbnN0IHNob3VsZFNraXBDb21iaW5lID0gdGhpcy4jc2hvdWxkU2tpcENvbWJpbmUoKTtcblx0XHRcdGNvbnN0IHByZXZpb3VzUmVzdWx0ID0gdGhpcy4jY29tYmluZWRSZXN1bHQ7XG5cdFx0XHRjb25zdCBuZXdSZXN1bHQgPSBzaG91bGRTa2lwQ29tYmluZSA/IHByZXZpb3VzUmVzdWx0IDogdGhpcy4jY29tYmluZVJlc3VsdCh0aGlzLiN0cmFja1Jlc3VsdCh0aGlzLiNyZXN1bHQsIHRoaXMuI29ic2VydmVyTWF0Y2hlcyksIHRoaXMuI29wdGlvbnM/LmNvbWJpbmUpO1xuXHRcdFx0aWYgKHNob3VsZFNraXBDb21iaW5lIHx8IHByZXZpb3VzUmVzdWx0ICE9PSBuZXdSZXN1bHQpIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRcdGxpc3RlbmVyKHRoaXMuI3Jlc3VsdCk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBRdWVyaWVzT2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcmllc09ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IGhhc2hRdWVyeUtleUJ5T3B0aW9ucywgbWF0Y2hRdWVyeSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBRdWVyeSB9IGZyb20gXCIuL3F1ZXJ5LmpzXCI7XG4vLyNyZWdpb24gc3JjL3F1ZXJ5Q2FjaGUudHNcbi8qKlxuKiBUaGUgYFF1ZXJ5Q2FjaGVgIGlzIHRoZSBzdG9yYWdlIG1lY2hhbmlzbSBmb3IgVGFuU3RhY2sgUXVlcnkuIEl0IHN0b3JlcyBhbGwgdGhlIGRhdGEsIG1ldGFcbiogaW5mb3JtYXRpb24sIGFuZCBzdGF0ZSBvZiB0aGUgcXVlcmllcyBpdCBjb250YWlucy5cbipcbiogTm9ybWFsbHksIHlvdSB3aWxsIG5vdCBpbnRlcmFjdCB3aXRoIHRoZSBgUXVlcnlDYWNoZWAgZGlyZWN0bHkgYW5kIGluc3RlYWQgdXNlIGEgYFF1ZXJ5Q2xpZW50YFxuKiBmb3IgYSBzcGVjaWZpYyBjYWNoZS4gWW91IGNhbiBzdWJzY3JpYmUgdG8gaXQgKGluaGVyaXRlZCBmcm9tIGBTdWJzY3JpYmFibGVgKSB0byBiZSBpbmZvcm1lZCBvZlxuKiBzYWZlL2tub3duIHVwZGF0ZXMgdG8gdGhlIGNhY2hlLCBzdWNoIGFzIHF1ZXJpZXMgYmVpbmcgYWRkZWQsIHJlbW92ZWQsIG9yIHVwZGF0ZWQg4oCUIHVwZGF0ZXMgbWFkZVxuKiBvdXRzaWRlIG9mIHRoZSBjYWNoZSdzIG93biB0cmFja2VkIG1lY2hhbmlzbXMgKGUuZy4gbXV0YXRpbmcgYSBxdWVyeSdzIHN0YXRlIG9iamVjdCBkaXJlY3RseSkgZG9cbiogbm90IG5vdGlmeSBzdWJzY3JpYmVycy5cbipcbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBxdWVyeUNhY2hlLnN1YnNjcmliZSgoZXZlbnQpID0+IHtcbiogICBjb25zb2xlLmxvZyhldmVudC50eXBlLCBldmVudC5xdWVyeSlcbiogfSlcbiogYGBgXG4qL1xudmFyIFF1ZXJ5Q2FjaGUgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNxdWVyaWVzO1xuXHRjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWc7XG5cdFx0dGhpcy4jcXVlcmllcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgZXhpc3RpbmcgYFF1ZXJ5YCBpbnN0YW5jZSBmb3IgdGhlIGdpdmVuIG9wdGlvbnMnIGBxdWVyeUtleWAvYHF1ZXJ5SGFzaGAsIG9yXG5cdCogYnVpbGRzIGFuZCBhZGRzIGEgbmV3IG9uZSB0byB0aGUgY2FjaGUgaWYgbm9uZSBleGlzdHMgeWV0LiBVc2VkIGJ5IGZyYW1ld29yayBhZGFwdGVycyBhbmRcblx0KiBwbHVnaW5zIChlLmcuIGJyb2FkY2FzdC9wZXJzaXN0ZW5jZSkgdGhhdCBuZWVkIHRvIGdldC1vci1jcmVhdGUgYSBgUXVlcnlgIGRpcmVjdGx5LCBieXBhc3Npbmdcblx0KiB0aGUgcmVhY3RpdmUgYFF1ZXJ5T2JzZXJ2ZXJgIG1hY2hpbmVyeS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBxdWVyeUNhY2hlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlDYWNoZSgpXG5cdCpcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuYnVpbGQocXVlcnlDbGllbnQsIHtcblx0KiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG5cdCogICBxdWVyeUZuOiBmZXRjaFBvc3RzLFxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdGJ1aWxkKGNsaWVudCwgb3B0aW9ucywgc3RhdGUpIHtcblx0XHRjb25zdCBxdWVyeUtleSA9IG9wdGlvbnMucXVlcnlLZXk7XG5cdFx0Y29uc3QgcXVlcnlIYXNoID0gb3B0aW9ucy5xdWVyeUhhc2ggPz8gaGFzaFF1ZXJ5S2V5QnlPcHRpb25zKHF1ZXJ5S2V5LCBvcHRpb25zKTtcblx0XHRsZXQgcXVlcnkgPSB0aGlzLmdldChxdWVyeUhhc2gpO1xuXHRcdGlmICghcXVlcnkpIHtcblx0XHRcdHF1ZXJ5ID0gbmV3IFF1ZXJ5KHtcblx0XHRcdFx0Y2xpZW50LFxuXHRcdFx0XHRxdWVyeUtleSxcblx0XHRcdFx0cXVlcnlIYXNoLFxuXHRcdFx0XHRvcHRpb25zOiBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKSxcblx0XHRcdFx0c3RhdGUsXG5cdFx0XHRcdGRlZmF1bHRPcHRpb25zOiBjbGllbnQuZ2V0UXVlcnlEZWZhdWx0cyhxdWVyeUtleSlcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy5hZGQocXVlcnkpO1xuXHRcdH1cblx0XHRyZXR1cm4gcXVlcnk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRhZGQocXVlcnkpIHtcblx0XHRpZiAoIXRoaXMuI3F1ZXJpZXMuaGFzKHF1ZXJ5LnF1ZXJ5SGFzaCkpIHtcblx0XHRcdHRoaXMuI3F1ZXJpZXMuc2V0KHF1ZXJ5LnF1ZXJ5SGFzaCwgcXVlcnkpO1xuXHRcdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcImFkZGVkXCIsXG5cdFx0XHRcdHF1ZXJ5XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogRGVzdHJveXMgdGhlIGdpdmVuIGBRdWVyeWAgYW5kIHJlbW92ZXMgaXQgZnJvbSB0aGUgY2FjaGUsIG5vdGlmeWluZyBzdWJzY3JpYmVycyB3aXRoIGFcblx0KiBgJ3JlbW92ZWQnYCBldmVudC4gQSBuby1vcCBpZiB0aGUgcXVlcnkgaXMgbm8gbG9uZ2VyIHRoZSBvbmUgY3VycmVudGx5IHN0b3JlZCB1bmRlciBpdHMgaGFzaFxuXHQqIChlLmcuIGl0IHdhcyBhbHJlYWR5IHJlcGxhY2VkKS4gVXNlZCBieSBwbHVnaW5zIChlLmcuIHRoZSBicm9hZGNhc3QgY2xpZW50KSB0aGF0IG1pcnJvclxuXHQqIHJlbW92YWxzIGFjcm9zcyBgUXVlcnlDYWNoZWAgaW5zdGFuY2VzLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZmluZCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KlxuXHQqIGlmIChxdWVyeSkge1xuXHQqICAgcXVlcnlDYWNoZS5yZW1vdmUocXVlcnkpXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRyZW1vdmUocXVlcnkpIHtcblx0XHRpZiAodGhpcy4jcXVlcmllcy5nZXQocXVlcnkucXVlcnlIYXNoKSA9PT0gcXVlcnkpIHtcblx0XHRcdHF1ZXJ5LmRlc3Ryb3koKTtcblx0XHRcdHRoaXMuI3F1ZXJpZXMuZGVsZXRlKHF1ZXJ5LnF1ZXJ5SGFzaCk7XG5cdFx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0XHRxdWVyeVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYWxsIHF1ZXJpZXMgZnJvbSB0aGUgY2FjaGUuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogcXVlcnlDYWNoZS5jbGVhcigpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFyKCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5nZXRBbGwoKS5mb3JFYWNoKChxdWVyeSkgPT4ge1xuXHRcdFx0XHR0aGlzLnJlbW92ZShxdWVyeSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBgUXVlcnlgIGluc3RhbmNlIHN0b3JlZCB1bmRlciB0aGUgZ2l2ZW4gYHF1ZXJ5SGFzaGAsIG9yIGB1bmRlZmluZWRgIGlmIG5vbmVcblx0KiBleGlzdHMuIFVubGlrZSB7QGxpbmsgUXVlcnlDYWNoZSNmaW5kfSwgdGhpcyBsb29rcyB1cCBieSB0aGUgYWxyZWFkeS1jb21wdXRlZCBoYXNoIHJhdGhlclxuXHQqIHRoYW4gYnkgYFF1ZXJ5RmlsdGVyc2AuIFVzZWQgYnkgcGx1Z2lucyAoZS5nLiBicm9hZGNhc3QvaHlkcmF0aW9uKSB0aGF0IGFscmVhZHkgaGF2ZSBhIGhhc2hcblx0KiB0byBsb29rIHVwIGRpcmVjdGx5LlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyeUhhc2ggPSBoYXNoS2V5KFsncG9zdHMnXSlcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQocXVlcnlIYXNoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXQocXVlcnlIYXNoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJpZXMuZ2V0KHF1ZXJ5SGFzaCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBhbGwgcXVlcmllcyB3aXRoaW4gdGhlIGNhY2hlLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJpZXMgPSBxdWVyeUNhY2hlLmdldEFsbCgpXG5cdCogYGBgXG5cdCovXG5cdGdldEFsbCgpIHtcblx0XHRyZXR1cm4gWy4uLnRoaXMuI3F1ZXJpZXMudmFsdWVzKCldO1xuXHR9XG5cdC8qKlxuXHQqIEEgc2xpZ2h0bHkgbW9yZSBhZHZhbmNlZCBtZXRob2QgdGhhdCBjYW4gYmUgdXNlZCB0byBnZXQgYW4gZXhpc3RpbmcgcXVlcnkgaW5zdGFuY2UgZnJvbSB0aGVcblx0KiBjYWNoZS4gVGhpcyBpbnN0YW5jZSBub3Qgb25seSBjb250YWlucyBhbGwgdGhlIHN0YXRlIGZvciB0aGUgcXVlcnksIGJ1dCBhbGwgb2YgdGhlIGluc3RhbmNlcyxcblx0KiBhbmQgdW5kZXJseWluZyBndXRzIG9mIHRoZSBxdWVyeSBhcyB3ZWxsLiBJZiB0aGUgcXVlcnkgZG9lcyBub3QgZXhpc3QsIGB1bmRlZmluZWRgIGlzXG5cdCogcmV0dXJuZWQuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgYSBxdWVyeSBpbiByYXJlIHNjZW5hcmlvcyAoZS5nLiBsb29raW5nIGF0IGBxdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0YCB0b1xuXHQqIGRlY2lkZSB3aGV0aGVyIGEgcXVlcnkgaXMgZnJlc2ggZW5vdWdoIHRvIGJlIHVzZWQgYXMgYW4gaW5pdGlhbCB2YWx1ZSkuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeUNhY2hlI2ZpbmRBbGx9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5maW5kKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRmaW5kKGZpbHRlcnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRGaWx0ZXJzID0ge1xuXHRcdFx0ZXhhY3Q6IHRydWUsXG5cdFx0XHQuLi5maWx0ZXJzXG5cdFx0fTtcblx0XHRyZXR1cm4gdGhpcy5nZXRBbGwoKS5maW5kKChxdWVyeSkgPT4gbWF0Y2hRdWVyeShkZWZhdWx0ZWRGaWx0ZXJzLCBxdWVyeSkpO1xuXHR9XG5cdC8qKlxuXHQqIEFuIGV2ZW4gbW9yZSBhZHZhbmNlZCBtZXRob2QgdGhhdCBjYW4gYmUgdXNlZCB0byBnZXQgZXhpc3RpbmcgcXVlcnkgaW5zdGFuY2VzIGZyb20gdGhlIGNhY2hlXG5cdCogdGhhdCBwYXJ0aWFsbHkgbWF0Y2ggYSBxdWVyeSBrZXkuIElmIG5vIHF1ZXJpZXMgbWF0Y2gsIGFuIGVtcHR5IGFycmF5IGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IHF1ZXJpZXMgaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCpcblx0KiBAc2VlIHtAbGluayBRdWVyeUNhY2hlI2ZpbmR9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJpZXMgPSBxdWVyeUNhY2hlLmZpbmRBbGwoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG5cdFx0Y29uc3QgcXVlcmllcyA9IHRoaXMuZ2V0QWxsKCk7XG5cdFx0cmV0dXJuIE9iamVjdC5rZXlzKGZpbHRlcnMpLmxlbmd0aCA+IDAgPyBxdWVyaWVzLmZpbHRlcigocXVlcnkpID0+IG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpKSA6IHF1ZXJpZXM7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRub3RpZnkoZXZlbnQpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKGV2ZW50KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKiBAaW50ZXJuYWwgKi9cblx0b25Gb2N1cygpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkub25Gb2N1cygpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqIEBpbnRlcm5hbCAqL1xuXHRvbk9ubGluZSgpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkub25PbmxpbmUoKTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBRdWVyeUNhY2hlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5Q2FjaGUuanMubWFwIiwiaW1wb3J0IHsgZnVuY3Rpb25hbFVwZGF0ZSwgaGFzaEtleSwgaGFzaFF1ZXJ5S2V5QnlPcHRpb25zLCBub29wLCBwYXJ0aWFsTWF0Y2hLZXksIHJlc29sdmVRdWVyeVZhbHVlLCBza2lwVG9rZW4gfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4vZm9jdXNNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IE11dGF0aW9uQ2FjaGUgfSBmcm9tIFwiLi9tdXRhdGlvbkNhY2hlLmpzXCI7XG5pbXBvcnQgeyBRdWVyeUNhY2hlIH0gZnJvbSBcIi4vcXVlcnlDYWNoZS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9xdWVyeUNsaWVudC50c1xuLyoqXG4qIGBRdWVyeUNsaWVudGAgaXMgdXNlZCB0byBpbnRlcmFjdCB3aXRoIGEgY2FjaGUgb2YgcXVlcmllcyBhbmQgbXV0YXRpb25zLiBJdCBvd25zIGFcbiogYFF1ZXJ5Q2FjaGVgIGFuZCBhIGBNdXRhdGlvbkNhY2hlYCAoY3JlYXRpbmcgZGVmYXVsdCBvbmVzIGlmIG5vbmUgYXJlIHBhc3NlZCBpbikgYW5kIGhvbGRzXG4qIHRoZSBkZWZhdWx0IG9wdGlvbnMgdGhhdCBhcmUgYXBwbGllZCB0byBxdWVyaWVzIGFuZCBtdXRhdGlvbnMgY3JlYXRlZCB0aHJvdWdoIGl0LlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCh7XG4qICAgZGVmYXVsdE9wdGlvbnM6IHtcbiogICAgIHF1ZXJpZXM6IHtcbiogICAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcbiogICAgIH0sXG4qICAgfSxcbiogfSlcbipcbiogYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleTogWydwb3N0cyddLCBxdWVyeUZuOiBmZXRjaFBvc3RzIH0pXG4qIGBgYFxuKi9cbnZhciBRdWVyeUNsaWVudCA9IGNsYXNzIHtcblx0I3F1ZXJ5Q2FjaGU7XG5cdCNtdXRhdGlvbkNhY2hlO1xuXHQjZGVmYXVsdE9wdGlvbnM7XG5cdCNxdWVyeURlZmF1bHRzO1xuXHQjbXV0YXRpb25EZWZhdWx0cztcblx0I21vdW50Q291bnQ7XG5cdCN1bnN1YnNjcmliZUZvY3VzO1xuXHQjdW5zdWJzY3JpYmVPbmxpbmU7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0dGhpcy4jcXVlcnlDYWNoZSA9IGNvbmZpZy5xdWVyeUNhY2hlIHx8IG5ldyBRdWVyeUNhY2hlKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25DYWNoZSA9IGNvbmZpZy5tdXRhdGlvbkNhY2hlIHx8IG5ldyBNdXRhdGlvbkNhY2hlKCk7XG5cdFx0dGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBjb25maWcuZGVmYXVsdE9wdGlvbnMgfHwge307XG5cdFx0dGhpcy4jcXVlcnlEZWZhdWx0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25EZWZhdWx0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbW91bnRDb3VudCA9IDA7XG5cdH1cblx0LyoqXG5cdCogQ2FsbGVkIGJ5IGEgZnJhbWV3b3JrIGFkYXB0ZXIncyBgUXVlcnlDbGllbnRQcm92aWRlcmAtZXF1aXZhbGVudCB3aGVuIGl0IG1vdW50cywgdG8gc3RhcnRcblx0KiBsaXN0ZW5pbmcgZm9yIGZvY3VzL29ubGluZSBldmVudHMgYW5kIHJlc3VtZSBwYXVzZWQgbXV0YXRpb25zLiBSZWYtY291bnRlZCB2aWEgYW4gaW50ZXJuYWxcblx0KiBtb3VudCBjb3VudCwgc28gbmVzdGVkIG9yIG11bHRpcGxlIHByb3ZpZGVycyBzaGFyaW5nIHRoZSBzYW1lIGBRdWVyeUNsaWVudGAgZG9uJ3QgdGVhciBkb3duXG5cdCogdGhlIHNoYXJlZCBsaXN0ZW5lcnMgdW50aWwgdGhlIGxhc3Qgb25lIHVubW91bnRzLlxuXHQqL1xuXHRtb3VudCgpIHtcblx0XHR0aGlzLiNtb3VudENvdW50Kys7XG5cdFx0aWYgKHRoaXMuI21vdW50Q291bnQgIT09IDEpIHJldHVybjtcblx0XHR0aGlzLiN1bnN1YnNjcmliZUZvY3VzID0gZm9jdXNNYW5hZ2VyLnN1YnNjcmliZShhc3luYyAoZm9jdXNlZCkgPT4ge1xuXHRcdFx0aWYgKGZvY3VzZWQpIHtcblx0XHRcdFx0YXdhaXQgdGhpcy5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKTtcblx0XHRcdFx0dGhpcy4jcXVlcnlDYWNoZS5vbkZvY3VzKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmUgPSBvbmxpbmVNYW5hZ2VyLnN1YnNjcmliZShhc3luYyAob25saW5lKSA9PiB7XG5cdFx0XHRpZiAob25saW5lKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0XHRcdHRoaXMuI3F1ZXJ5Q2FjaGUub25PbmxpbmUoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBUaGUgaW52ZXJzZSBvZiB7QGxpbmsgUXVlcnlDbGllbnQjbW91bnR9IOKAlCBjYWxsZWQgYnkgYSBmcmFtZXdvcmsgYWRhcHRlcidzXG5cdCogYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLWVxdWl2YWxlbnQgd2hlbiBpdCB1bm1vdW50cy4gT25seSB0ZWFycyBkb3duIHRoZSBmb2N1cy9vbmxpbmVcblx0KiBsaXN0ZW5lcnMgb25jZSB0aGUgbW91bnQgY291bnQgcmV0dXJucyB0byBgMGAuXG5cdCovXG5cdHVubW91bnQoKSB7XG5cdFx0dGhpcy4jbW91bnRDb3VudC0tO1xuXHRcdGlmICh0aGlzLiNtb3VudENvdW50ICE9PSAwKSByZXR1cm47XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cz8uKCk7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cyA9IHZvaWQgMDtcblx0XHR0aGlzLiN1bnN1YnNjcmliZU9ubGluZT8uKCk7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmUgPSB2b2lkIDA7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIHF1ZXJpZXMgaW4gdGhlIGNhY2hlIHRoYXQgYXJlIGN1cnJlbnRseSBmZXRjaGluZywgb3B0aW9uYWxseVxuXHQqIG1hdGNoaW5nIGEgc2V0IG9mIGZpbHRlcnMuIFRoaXMgaW5jbHVkZXMgYmFja2dyb3VuZC1mZXRjaGluZywgbG9hZGluZyBuZXcgcGFnZXMsIGFuZFxuXHQqIGxvYWRpbmcgbW9yZSBpbmZpbml0ZSBxdWVyeSByZXN1bHRzLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeUNsaWVudC5pc0ZldGNoaW5nKCkpIHtcblx0KiAgIGNvbnNvbGUubG9nKCdBdCBsZWFzdCBvbmUgcXVlcnkgaXMgZmV0Y2hpbmchJylcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzRmV0Y2hpbmcoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoe1xuXHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCJcblx0XHR9KS5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIG11dGF0aW9ucyBpbiB0aGUgY2FjaGUgdGhhdCBhcmUgY3VycmVudGx5IHBlbmRpbmcsIG9wdGlvbmFsbHlcblx0KiBtYXRjaGluZyBhIHNldCBvZiBmaWx0ZXJzLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeUNsaWVudC5pc011dGF0aW5nKCkpIHtcblx0KiAgIGNvbnNvbGUubG9nKCdBdCBsZWFzdCBvbmUgbXV0YXRpb24gaXMgcGVuZGluZyEnKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aXNNdXRhdGluZyhmaWx0ZXJzKSB7XG5cdFx0cmV0dXJuIHRoaXMuI211dGF0aW9uQ2FjaGUuZmluZEFsbCh7XG5cdFx0XHQuLi5maWx0ZXJzLFxuXHRcdFx0c3RhdHVzOiBcInBlbmRpbmdcIlxuXHRcdH0pLmxlbmd0aDtcblx0fVxuXHQvKipcblx0KiBJbXBlcmF0aXZlIChub24tcmVhY3RpdmUpIHdheSB0byByZXRyaWV2ZSBkYXRhIGZvciBhIFF1ZXJ5S2V5LlxuXHQqIFNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FsbGJhY2tzIG9yIGZ1bmN0aW9ucyB3aGVyZSByZWFkaW5nIHRoZSBsYXRlc3QgZGF0YSBpcyBuZWNlc3NhcnksIGUuZy4gZm9yIG9wdGltaXN0aWMgdXBkYXRlcy5cblx0KlxuXHQqIEhpbnQ6IERvIG5vdCB1c2UgdGhpcyBmdW5jdGlvbiBpbnNpZGUgYSBjb21wb25lbnQsIGJlY2F1c2UgaXQgd29uJ3QgcmVjZWl2ZSB1cGRhdGVzLlxuXHQqIFVzZSBgdXNlUXVlcnlgIHRvIGNyZWF0ZSBhIGBRdWVyeU9ic2VydmVyYCB0aGF0IHN1YnNjcmliZXMgdG8gY2hhbmdlcy5cblx0KlxuXHQqIEByZXR1cm5zIFRoZSBjYWNoZWQgZGF0YSBmb3IgdGhlIHF1ZXJ5LCBvciBgdW5kZWZpbmVkYCBpZiBubyBxdWVyeSB3aXRoIHRoaXMga2V5IGhhcyBiZWVuIG9ic2VydmVkIHlldC5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyaWVzRGF0YX1cblx0Ki9cblx0Z2V0UXVlcnlEYXRhKHF1ZXJ5S2V5KSB7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyh7IHF1ZXJ5S2V5IH0pO1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmdldChvcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG5cdH1cblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgLi4ub3B0aW9ucywgc3RhbGVUaW1lOiAnc3RhdGljJyB9KSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRjb25zdCBjYWNoZWREYXRhID0gcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRpZiAoY2FjaGVkRGF0YSA9PT0gdm9pZCAwKSByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuXHRcdGlmIChvcHRpb25zLnJldmFsaWRhdGVJZlN0YWxlICYmIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkpIHRoaXMucHJlZmV0Y2hRdWVyeShkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNhY2hlZERhdGEpO1xuXHR9XG5cdC8qKlxuXHQqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UuXG5cdCogT25seSBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGFyZSByZXR1cm5lZDsgaWYgbm9uZSBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXNcblx0KiByZXR1cm5lZC5cblx0KlxuXHQqIEJlY2F1c2UgdGhlIG1hdGNoZWQgcXVlcmllcyBjYW4gaG9sZCBkYXRhIG9mIGRpZmZlcmVudCBzaGFwZXMgKGUuZy4gYSBicm9hZCBmaWx0ZXIgY2FuIG1hdGNoXG5cdCogcXVlcmllcyB3aXRoIHVucmVsYXRlZCBkYXRhIHR5cGVzKSwgdGhlIGBUUXVlcnlGbkRhdGFgIGdlbmVyaWMgZGVmYXVsdHMgdG8gYHVua25vd25gIHJhdGhlclxuXHQqIHRoYW4gYmVpbmcgaW5mZXJyZWQuIFBhc3NpbmcgYSBtb3JlIHNwZWNpZmljIHR5cGUgaXMgYSBjb252ZW5pZW5jZSBmb3IgY2FsbCBzaXRlcyB0aGF0IGtub3dcblx0KiBldmVyeSBtYXRjaGVkIHF1ZXJ5IGhvbGRzIHRoZSBzYW1lIHNoYXBlIOKAlCBpdCBpcyBub3QgY2hlY2tlZCBhZ2FpbnN0IHRoZSBhY3R1YWwgY2FjaGVcblx0KiBjb250ZW50cy5cblx0KlxuXHQqIEByZXR1cm5zIEFuIGFycmF5IG9mIHF1ZXJ5IGtleSBhbmQgZGF0YSBwYWlycy4gVGhlIGRhdGEgaXMgYHVuZGVmaW5lZGAgZm9yIGEgcXVlcnkgd2l0aCBubyBjYWNoZWQgZGF0YS5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyeURhdGF9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRhdGEgPSBxdWVyeUNsaWVudC5nZXRRdWVyaWVzRGF0YSh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0UXVlcmllc0RhdGEoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKCh7IHF1ZXJ5S2V5LCBzdGF0ZSB9KSA9PiB7XG5cdFx0XHRyZXR1cm4gW3F1ZXJ5S2V5LCBzdGF0ZS5kYXRhXTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBTeW5jaHJvbm91cyB3YXkgdG8gaW1tZWRpYXRlbHkgdXBkYXRlIGEgcXVlcnkncyBjYWNoZWQgZGF0YS4gSWYgdGhlIHVwZGF0ZXIgKG9yIHRoZSB2YWx1ZVxuXHQqIHBhc3NlZCkgcmVzb2x2ZXMgdG8gYHVuZGVmaW5lZGAsIHRoZSBjYWNoZSBpcyBsZWZ0IHVudG91Y2hlZCBhbmQgbm8gcXVlcnkgaXMgY3JlYXRlZDtcblx0KiBvdGhlcndpc2UsIGlmIHRoZSBxdWVyeSBkb2VzIG5vdCBleGlzdCB5ZXQsIGl0IHdpbGwgYmUgY3JlYXRlZC4gVG8gdXBkYXRlIG11bHRpcGxlIHF1ZXJpZXNcblx0KiBhdCBvbmNlIGJ5IHBhcnRpYWxseSBtYXRjaGluZyBxdWVyeSBrZXlzLCB1c2Uge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJpZXNEYXRhfSBpbnN0ZWFkLlxuXHQqXG5cdCogVXBkYXRlcyBtdXN0IGJlIHBlcmZvcm1lZCBpbW11dGFibHk6IGRvIG5vdCBtdXRhdGUgYG9sZERhdGFgLCBvciBkYXRhIHByZXZpb3VzbHkgcmV0cmlldmVkXG5cdCogdmlhIHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyeURhdGF9LCBpbiBwbGFjZS5cblx0KlxuXHQqIEBwYXJhbSBxdWVyeUtleSAtIFRoZSBxdWVyeSBrZXkgdG8gc2V0IGRhdGEgZm9yLlxuXHQqIEBwYXJhbSB1cGRhdGVyIC0gRWl0aGVyIHRoZSBuZXcgZGF0YSwgb3IgYSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHRoZSBjdXJyZW50IGRhdGEgKHdoaWNoXG5cdCogbWF5IGJlIGB1bmRlZmluZWRgKSBhbmQgcmV0dXJucyB0aGUgbmV3IGRhdGEuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYHVwZGF0ZWRBdGAgdG8gb3ZlcnJpZGUgdGhlIHRpbWVzdGFtcCB0aGUgd3JpdHRlbiBkYXRhIGlzIHJlY29yZGVkIHdpdGguXG5cdCogQHJldHVybnMgVGhlIGRhdGEgdGhhdCB3YXMgd3JpdHRlbiwgb3IgYHVuZGVmaW5lZGAgaWYgdGhlIHVwZGF0ZXIgcmV0dXJuZWQgYHVuZGVmaW5lZGAg4oCUIGluIHRoYXQgY2FzZVxuXHQqIHRoZSB3cml0ZSBpcyBza2lwcGVkIGFuZCB0aGUgY2FjaGUgaXMgbGVmdCB1bmNoYW5nZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsncG9zdHMnXSwgbmV3UG9zdHMpXG5cdCpcblx0KiAvLyBPciwgdXNpbmcgYW4gdXBkYXRlciBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHRoZSBjdXJyZW50IGRhdGE6XG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsncG9zdHMnXSwgKG9sZFBvc3RzKSA9PiBbLi4ub2xkUG9zdHMsIG5ld1Bvc3RdKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG5cdFx0Y29uc3QgcHJldkRhdGEgPSB0aGlzLiNxdWVyeUNhY2hlLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG5cdFx0Y29uc3QgZGF0YSA9IGZ1bmN0aW9uYWxVcGRhdGUodXBkYXRlciwgcHJldkRhdGEpO1xuXHRcdGlmIChkYXRhID09PSB2b2lkIDApIHJldHVybjtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKS5zZXREYXRhKGRhdGEsIHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRtYW51YWw6IHRydWVcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBTeW5jaHJvbm91cyB3YXkgdG8gaW1tZWRpYXRlbHkgdXBkYXRlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UsIHVzaW5nXG5cdCogZmlsdGVycyBvciBwYXJ0aWFsIHF1ZXJ5IGtleSBtYXRjaGluZy4gT25seSBxdWVyaWVzIHRoYXQgYWxyZWFkeSBleGlzdCBhbmQgbWF0Y2ggdGhlIGdpdmVuXG5cdCogZmlsdGVycyBhcmUgdXBkYXRlZDsgbm8gbmV3IGNhY2hlIGVudHJpZXMgYXJlIGNyZWF0ZWQuIEludGVybmFsbHkgdGhpcyBjYWxsc1xuXHQqIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURhdGF9IGZvciBlYWNoIG1hdGNoaW5nIHF1ZXJ5LlxuXHQqXG5cdCogQHJldHVybnMgT25lIGBbcXVlcnlLZXksIGRhdGFdYCB0dXBsZSBwZXIgbWF0Y2hlZCBxdWVyeSwgaW4gdGhlIHNhbWUgc2hhcGUgYW5kIHdpdGggdGhlIHNhbWVcblx0KiBgdW5kZWZpbmVkYCBjYXNlIGFzIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURhdGF9LlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5zZXRRdWVyaWVzRGF0YSh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSwgKG9sZFBvc3RzKSA9PlxuXHQqICAgb2xkUG9zdHMgPyBvbGRQb3N0cy5maWx0ZXIoKHBvc3QpID0+IHBvc3QuaWQgIT09IGRlbGV0ZWRJZCkgOiBvbGRQb3N0cyxcblx0KiApXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJpZXNEYXRhKGZpbHRlcnMsIHVwZGF0ZXIsIG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKCh7IHF1ZXJ5S2V5IH0pID0+IFtxdWVyeUtleSwgdGhpcy5zZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpXSkpO1xuXHR9XG5cdC8qKlxuXHQqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIGFuIGV4aXN0aW5nIHF1ZXJ5J3Mgc3RhdGUuIElmIHRoZSBxdWVyeSBkb2VzIG5vdFxuXHQqIGV4aXN0LCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBzdGF0ZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5U3RhdGUoWydwb3N0cyddKVxuXHQqIGNvbnNvbGUubG9nKHN0YXRlPy5kYXRhVXBkYXRlZEF0KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyeVN0YXRlKHF1ZXJ5S2V5KSB7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyh7IHF1ZXJ5S2V5IH0pO1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmdldChvcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlO1xuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgcXVlcmllcyBmcm9tIHRoZSBjYWNoZSB0aGF0IG1hdGNoIHRoZSBnaXZlbiBmaWx0ZXJzLiBVbmxpa2Vcblx0KiB7QGxpbmsgUXVlcnlDbGllbnQjaW52YWxpZGF0ZVF1ZXJpZXN9IG9yIHtAbGluayBRdWVyeUNsaWVudCNyZWZldGNoUXVlcmllc30sIHRoaXMgcmVtb3Zlc1xuXHQqIG1hdGNoaW5nIHF1ZXJpZXMgZnJvbSB0aGUgY2FjaGUgaW5zdGVhZCBvZiByZWZldGNoaW5nIHRoZW0uIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnkgaW5cblx0KiB0aGUgY2FjaGUgaXMgcmVtb3ZlZC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5yZW1vdmVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgZXhhY3Q6IHRydWUgfSlcblx0KiBgYGBcblx0Ki9cblx0cmVtb3ZlUXVlcmllcyhmaWx0ZXJzKSB7XG5cdFx0Y29uc3QgcXVlcnlDYWNoZSA9IHRoaXMuI3F1ZXJ5Q2FjaGU7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnlDYWNoZS5yZW1vdmUocXVlcnkpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVzZXRzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMgYmFjayB0byB0aGVpciBpbml0aWFsIHN0YXRlIChlLmcuIGFueVxuXHQqIGBpbml0aWFsRGF0YWApLCBub3RpZnlpbmcgc3Vic2NyaWJlcnMgcmF0aGVyIHRoYW4gcmVtb3ZpbmcgdGhlbS4gQWN0aXZlIHF1ZXJpZXMgYW1vbmcgdGhlXG5cdCogbWF0Y2hlZCBzZXQgYXJlIHRoZW4gcmVmZXRjaGVkLCBhbmQgdGhlIHJldHVybmVkIHByb21pc2UgcmVzb2x2ZXMgb25jZSB0aGF0IHJlZmV0Y2ggc2V0dGxlcy5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZXNldFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCBleGFjdDogdHJ1ZSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZXNldFF1ZXJpZXMoZmlsdGVycywgb3B0aW9ucykge1xuXHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSB0aGlzLiNxdWVyeUNhY2hlO1xuXHRcdHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IG1hdGNoZWQgPSBxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycyk7XG5cdFx0XHRjb25zdCBxdWVyaWVzVG9SZWZldGNoID0gbmV3IFNldChtYXRjaGVkKTtcblx0XHRcdG1hdGNoZWQuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkucmVzZXQoKTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIHRoaXMucmVmZXRjaFF1ZXJpZXMoe1xuXHRcdFx0XHR0eXBlOiBcImFjdGl2ZVwiLFxuXHRcdFx0XHRwcmVkaWNhdGU6IChxdWVyeSkgPT4gcXVlcmllc1RvUmVmZXRjaC5oYXMocXVlcnkpXG5cdFx0XHR9LCBvcHRpb25zKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIG91dGdvaW5nIGZldGNoZXMgZm9yIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMuIE1vc3QgdXNlZnVsIHdoZW4gcGVyZm9ybWluZ1xuXHQqIG9wdGltaXN0aWMgdXBkYXRlcywgc2luY2UgYW55IG91dGdvaW5nIHJlZmV0Y2ggdGhhdCByZXNvbHZlcyBhZnRlcndhcmRzIHdvdWxkIG90aGVyd2lzZVxuXHQqIG92ZXJ3cml0ZSB0aGUgb3B0aW1pc3RpYyB1cGRhdGUuIEJ5IGRlZmF1bHQgKGByZXZlcnQ6IHRydWVgKSwgYSBjYW5jZWxsZWQgcXVlcnkncyBkYXRhIGlzXG5cdCogcmV2ZXJ0ZWQgdG8gaXRzIHN0YXRlIGJlZm9yZSB0aGUgb3V0Z29pbmcgZmV0Y2ggc3RhcnRlZC5cblx0KlxuXHQqIFRoZSByZXR1cm5lZCBwcm9taXNlIG5ldmVyIHJlamVjdHMsIGV2ZW4gaWYgaW5kaXZpZHVhbCBjYW5jZWxsYXRpb25zIGZhaWwuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogYXdhaXQgcXVlcnlDbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIGV4YWN0OiB0cnVlIH0pXG5cdCogYGBgXG5cdCovXG5cdGNhbmNlbFF1ZXJpZXMoZmlsdGVycywgY2FuY2VsT3B0aW9ucyA9IHt9KSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkQ2FuY2VsT3B0aW9ucyA9IHtcblx0XHRcdHJldmVydDogdHJ1ZSxcblx0XHRcdC4uLmNhbmNlbE9wdGlvbnNcblx0XHR9O1xuXHRcdGNvbnN0IHByb21pc2VzID0gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykubWFwKChxdWVyeSkgPT4gcXVlcnkuY2FuY2VsKGRlZmF1bHRlZENhbmNlbE9wdGlvbnMpKSk7XG5cdFx0cmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIE1hcmtzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMgYXMgaW52YWxpZGF0ZWQuIFVubGlrZVxuXHQqIHtAbGluayBRdWVyeUNsaWVudCNyZW1vdmVRdWVyaWVzfSwgaW52YWxpZGF0ZWQgcXVlcmllcyBzdGF5IGluIHRoZSBjYWNoZS5cblx0KlxuXHQqIFVubGVzcyBgZmlsdGVycy5yZWZldGNoVHlwZWAgaXMgYCdub25lJ2AsIG1hdGNoaW5nIHF1ZXJpZXMgYXJlIHRoZW4gcmVmZXRjaGVkIHZpYVxuXHQqIHtAbGluayBRdWVyeUNsaWVudCNyZWZldGNoUXVlcmllc30sIHVzaW5nIGBmaWx0ZXJzLnJlZmV0Y2hUeXBlYCBpZiBzZXQsIG90aGVyd2lzZVxuXHQqIGBmaWx0ZXJzLnR5cGVgLCBvdGhlcndpc2UgYCdhY3RpdmUnYC5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIHJlZmV0Y2hUeXBlOiAnYWN0aXZlJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRpbnZhbGlkYXRlUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkuaW52YWxpZGF0ZSgpO1xuXHRcdFx0fSk7XG5cdFx0XHRpZiAoZmlsdGVycz8ucmVmZXRjaFR5cGUgPT09IFwibm9uZVwiKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHRyZXR1cm4gdGhpcy5yZWZldGNoUXVlcmllcyh7XG5cdFx0XHRcdC4uLmZpbHRlcnMsXG5cdFx0XHRcdHR5cGU6IGZpbHRlcnM/LnJlZmV0Y2hUeXBlID8/IGZpbHRlcnM/LnR5cGUgPz8gXCJhY3RpdmVcIlxuXHRcdFx0fSwgb3B0aW9ucyk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVmZXRjaGVzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMsIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGV5IGFyZSBzdGFsZS4gV2l0aG91dFxuXHQqIGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGluIHRoZSBjYWNoZSBpcyByZWZldGNoZWQuIFF1ZXJpZXMgdGhhdCBhcmUgZGlzYWJsZWQsIG9yIHN0YXRpYyAob25seVxuXHQqIGhhdmUgb2JzZXJ2ZXJzIHdpdGggYSBzdGF0aWMgYHN0YWxlVGltZWApLCBhcmUgbmV2ZXIgcmVmZXRjaGVkLlxuXHQqXG5cdCogQnkgZGVmYXVsdCAoYGNhbmNlbFJlZmV0Y2g6IHRydWVgKSwgYSBjdXJyZW50bHkgcnVubmluZyBmZXRjaCBpcyBjYW5jZWxsZWQgYmVmb3JlIHRoZSBuZXdcblx0KiBvbmUgc3RhcnRzLiBUaGUgcmV0dXJuZWQgcHJvbWlzZSByZXNvbHZlcyBvbmNlIGFsbCBtYXRjaGluZyBxdWVyaWVzIGhhdmUgc2V0dGxlZDsgaXQgZG9lc1xuXHQqIG5vdCByZWplY3Qgb24gaW5kaXZpZHVhbCBxdWVyeSBmYWlsdXJlcyB1bmxlc3MgYHRocm93T25FcnJvcmAgaXMgc2V0LlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIC8vIHJlZmV0Y2ggYWxsIGFjdGl2ZSBxdWVyaWVzIHBhcnRpYWxseSBtYXRjaGluZyBhIHF1ZXJ5IGtleTpcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZWZldGNoUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIHR5cGU6ICdhY3RpdmUnIH0pXG5cdCogYGBgXG5cdCovXG5cdHJlZmV0Y2hRdWVyaWVzKGZpbHRlcnMsIG9wdGlvbnMgPSB7fSkge1xuXHRcdGNvbnN0IGZldGNoT3B0aW9ucyA9IHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRjYW5jZWxSZWZldGNoOiBvcHRpb25zLmNhbmNlbFJlZmV0Y2ggPz8gdHJ1ZVxuXHRcdH07XG5cdFx0Y29uc3QgcHJvbWlzZXMgPSBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5maWx0ZXIoKHF1ZXJ5KSA9PiAhcXVlcnkuaXNEaXNhYmxlZCgpICYmICFxdWVyeS5pc1N0YXRpYygpKS5tYXAoKHF1ZXJ5KSA9PiB7XG5cdFx0XHRsZXQgcHJvbWlzZSA9IHF1ZXJ5LmZldGNoKHZvaWQgMCwgZmV0Y2hPcHRpb25zKTtcblx0XHRcdGlmICghZmV0Y2hPcHRpb25zLnRocm93T25FcnJvcikgcHJvbWlzZSA9IHByb21pc2UuY2F0Y2gobm9vcCk7XG5cdFx0XHRyZXR1cm4gcXVlcnkuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIgPyBQcm9taXNlLnJlc29sdmUoKSA6IHByb21pc2U7XG5cdFx0fSkpO1xuXHRcdHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbihub29wKTtcblx0fVxuXHQvKipcblx0KiBBc3luY2hyb25vdXMgbWV0aG9kIHRvIGZldGNoIGFuZCBjYWNoZSBhIHF1ZXJ5LCByZXNvbHZpbmcgd2l0aCB0aGUgZGF0YSBvciB0aHJvd2luZyB3aXRoXG5cdCogdGhlIGVycm9yLlxuXHQqXG5cdCogSWYgdGhlIHF1ZXJ5IGFscmVhZHkgZXhpc3RzIGluIHRoZSBjYWNoZSBhbmQgaXRzIGRhdGEgaXMgbm90IHN0YWxlIChwZXIgdGhlIGdpdmVuXG5cdCogYHN0YWxlVGltZWApLCB0aGUgY2FjaGVkIGRhdGEgaXMgcmV0dXJuZWQgd2l0aG91dCBmZXRjaGluZy4gT3RoZXJ3aXNlLCB0aGUgcXVlcnkgaXMgZmV0Y2hlZFxuXHQqIGFuZCB0aGUgcHJvbWlzZSByZXNvbHZlcyBvbmNlIHRoZSBmZXRjaCBzZXR0bGVzLiBJZiBhIGBzZWxlY3RgIGZ1bmN0aW9uIGlzIHByb3ZpZGVkLCBpdCBpc1xuXHQqIGFwcGxpZWQgdG8gdGhlIGRhdGEgaW4gYm90aCBjYXNlcyAoY2FjaGVkIG9yIGZyZXNobHkgZmV0Y2hlZCkgYmVmb3JlIGl0IGlzIHJldHVybmVkLlxuXHQqXG5cdCogVW5saWtlIGEgcmVhY3RpdmUgb2JzZXJ2ZXIsIHJldHJpZXMgYXJlIGRpc2FibGVkIGJ5IGRlZmF1bHQgaGVyZSAoYHJldHJ5OiBmYWxzZWApIHVubGVzc1xuXHQqIGV4cGxpY2l0bHkgY29uZmlndXJlZCwgc2luY2UgdGhlcmUgaXMgbm8gY29tcG9uZW50IHRvIGNhdGNoIGEgdGhyb3duIGVycm9yIGFuZCByZXRyeSB0aHJvdWdoXG5cdCogcmUtcmVuZGVyLlxuXHQqXG5cdCogVGhlIGFjY2VwdGVkIG9wdGlvbnMgYXJlIGBRdWVyeU9ic2VydmVyT3B0aW9uc2AgbWludXMgdGhlIGZpZWxkcyB0aGF0IG9ubHkgbWFrZSBzZW5zZSBmb3IgYVxuXHQqIHJlYWN0aXZlIG9ic2VydmVyIOKAlCBgZW5hYmxlZGAsIGByZWZldGNoSW50ZXJ2YWxgLCBgcmVmZXRjaEludGVydmFsSW5CYWNrZ3JvdW5kYCxcblx0KiBgcmVmZXRjaE9uV2luZG93Rm9jdXNgLCBgcmVmZXRjaE9uUmVjb25uZWN0YCwgYHJlZmV0Y2hPbk1vdW50YCwgYHJldHJ5T25Nb3VudGAsXG5cdCogYG5vdGlmeU9uQ2hhbmdlUHJvcHNgLCBgdGhyb3dPbkVycm9yYCwgYHN1c3BlbnNlYCwgYW5kIGBwbGFjZWhvbGRlckRhdGFgIGFyZSBub3QgcGFydCBvZiB0aGlzXG5cdCogbWV0aG9kJ3Mgb3B0aW9ucy5cblx0KlxuXHQqIFRoaXMgbWV0aG9kIHJlcGxhY2VzIHRoZSBkZXByZWNhdGVkIGBmZXRjaFF1ZXJ5YCwgYW5kIOKAlCBjb21iaW5lZCB3aXRoXG5cdCogYHsgc3RhbGVUaW1lOiAnc3RhdGljJyB9YCDigJQgdGhlIGRlcHJlY2F0ZWQgYGVuc3VyZVF1ZXJ5RGF0YWAuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogdHJ5IHtcblx0KiAgIGNvbnN0IGRhdGEgPSBhd2FpdCBxdWVyeUNsaWVudC5xdWVyeSh7IHF1ZXJ5S2V5LCBxdWVyeUZuLCBzdGFsZVRpbWU6IDEwMDAwIH0pXG5cdCogfSBjYXRjaCAoZXJyb3IpIHtcblx0KiAgIGNvbnNvbGUubG9nKGVycm9yKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0YXN5bmMgcXVlcnkob3B0aW9ucykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy5yZXRyeSA9IGZhbHNlO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRjb25zdCBxdWVyeURhdGEgPSBxdWVyeS5pc1N0YWxlQnlUaW1lKHJlc29sdmVRdWVyeVZhbHVlKGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkpID8gYXdhaXQgcXVlcnkuZmV0Y2goZGVmYXVsdGVkT3B0aW9ucykgOiBxdWVyeS5zdGF0ZS5kYXRhO1xuXHRcdGNvbnN0IHNlbGVjdCA9IGRlZmF1bHRlZE9wdGlvbnMuc2VsZWN0O1xuXHRcdGlmIChzZWxlY3QpIHJldHVybiBzZWxlY3QocXVlcnlEYXRhKTtcblx0XHRyZXR1cm4gcXVlcnlEYXRhO1xuXHR9XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5xdWVyeShvcHRpb25zKSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZmV0Y2hRdWVyeShvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5yZXRyeSA9PT0gdm9pZCAwKSBkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID0gZmFsc2U7XG5cdFx0Y29uc3QgcXVlcnkgPSB0aGlzLiNxdWVyeUNhY2hlLmJ1aWxkKHRoaXMsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdHJldHVybiBxdWVyeS5pc1N0YWxlQnlUaW1lKHJlc29sdmVRdWVyeVZhbHVlKGRlZmF1bHRlZE9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkpID8gcXVlcnkuZmV0Y2goZGVmYXVsdGVkT3B0aW9ucykgOiBQcm9taXNlLnJlc29sdmUocXVlcnkuc3RhdGUuZGF0YSk7XG5cdH1cblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFlvdSBjYW4gc3dhbGxvdyBlcnJvcnMgd2l0aCBgLmNhdGNoKG5vb3ApYC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdHByZWZldGNoUXVlcnkob3B0aW9ucykge1xuXHRcdHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucykudGhlbihub29wKS5jYXRjaChub29wKTtcblx0fVxuXHQvKipcblx0KiBBc3luY2hyb25vdXMgbWV0aG9kIHRvIGZldGNoIGFuZCBjYWNoZSBhbiBpbmZpbml0ZSBxdWVyeSwgcmVzb2x2aW5nIHdpdGggYW5cblx0KiB7QGxpbmsgSW5maW5pdGVEYXRhfSBvYmplY3Qgb3IgdGhyb3dpbmcgd2l0aCB0aGUgZXJyb3IuXG5cdCpcblx0KiBCZWhhdmVzIGxpa2Uge0BsaW5rIFF1ZXJ5Q2xpZW50I3F1ZXJ5fSwgYWNjZXB0aW5nIHRoZSBzYW1lIG9wdGlvbnMgKG1pbnVzXG5cdCogYGluaXRpYWxQYWdlUGFyYW1gKSwgcGx1cyB0aGUgcmVxdWlyZWQgYGluaXRpYWxQYWdlUGFyYW1gLCBhbmQgYW4gb3B0aW9uYWwgYHBhZ2VzYCAvXG5cdCogYGdldE5leHRQYWdlUGFyYW1gIHBhaXIgdXNlZCB0byByZWZldGNoIGEgZml4ZWQgbnVtYmVyIG9mIHBhZ2VzIGZyb20gdGhlIHN0YXJ0LlxuXHQqXG5cdCogVGhpcyBtZXRob2QgcmVwbGFjZXMgdGhlIGRlcHJlY2F0ZWQgYGZldGNoSW5maW5pdGVRdWVyeWAsIGFuZCDigJQgY29tYmluZWQgd2l0aFxuXHQqIGB7IHN0YWxlVGltZTogJ3N0YXRpYycgfWAg4oCUIHRoZSBkZXByZWNhdGVkIGBlbnN1cmVJbmZpbml0ZVF1ZXJ5RGF0YWAuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogdHJ5IHtcblx0KiAgIGNvbnN0IGRhdGEgPSBhd2FpdCBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KHsgcXVlcnlLZXksIHF1ZXJ5Rm4sIGluaXRpYWxQYWdlUGFyYW06IDAgfSlcblx0KiAgIGNvbnNvbGUubG9nKGRhdGEucGFnZXMpXG5cdCogfSBjYXRjaCAoZXJyb3IpIHtcblx0KiAgIGNvbnNvbGUubG9nKGVycm9yKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gdGhpcy5xdWVyeShvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeShvcHRpb25zKSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LmluZmluaXRlUXVlcnkob3B0aW9ucykgaW5zdGVhZC4gWW91IGNhbiBzd2FsbG93IGVycm9ycyB3aXRoIGAuY2F0Y2gobm9vcClgLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0cHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaEluZmluaXRlUXVlcnkob3B0aW9ucykudGhlbihub29wKS5jYXRjaChub29wKTtcblx0fVxuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeSh7IC4uLm9wdGlvbnMsIHN0YWxlVGltZTogJ3N0YXRpYycgfSkgaW5zdGVhZC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdGVuc3VyZUluZmluaXRlUXVlcnlEYXRhKG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiB0aGlzLmVuc3VyZVF1ZXJ5RGF0YShvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBSZXN1bWVzIG11dGF0aW9ucyB0aGF0IHdlcmUgcGF1c2VkIGJlY2F1c2UgdGhlcmUgd2FzIG5vIG5ldHdvcmsgY29ubmVjdGlvbi4gRG9lcyBub3RoaW5nXG5cdCogKHJlc29sdmluZyBpbW1lZGlhdGVseSkgaWYgdGhlIGNsaWVudCBpcyBjdXJyZW50bHkgb2ZmbGluZS5cblx0KlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LnJlc3VtZVBhdXNlZE11dGF0aW9ucygpXG5cdCogYGBgXG5cdCovXG5cdHJlc3VtZVBhdXNlZE11dGF0aW9ucygpIHtcblx0XHRpZiAob25saW5lTWFuYWdlci5pc09ubGluZSgpKSByZXR1cm4gdGhpcy4jbXV0YXRpb25DYWNoZS5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgcXVlcnkgY2FjaGUgdGhpcyBjbGllbnQgaXMgY29ubmVjdGVkIHRvLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqIGNvbnN0IHF1ZXJpZXMgPSBxdWVyeUNhY2hlLmZpbmRBbGwoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJ5Q2FjaGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGU7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbXV0YXRpb24gY2FjaGUgdGhpcyBjbGllbnQgaXMgY29ubmVjdGVkIHRvLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqIGNvbnN0IG11dGF0aW9ucyA9IG11dGF0aW9uQ2FjaGUuZmluZEFsbCh7IHN0YXR1czogJ3BlbmRpbmcnIH0pXG5cdCogYGBgXG5cdCovXG5cdGdldE11dGF0aW9uQ2FjaGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI211dGF0aW9uQ2FjaGU7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgZGVmYXVsdCBvcHRpb25zIHRoYXQgd2VyZSBzZXQgd2hlbiBjcmVhdGluZyB0aGUgY2xpZW50LCBvciB2aWFcblx0KiB7QGxpbmsgUXVlcnlDbGllbnQjc2V0RGVmYXVsdE9wdGlvbnN9LlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogY29uc3QgZGVmYXVsdE9wdGlvbnMgPSBxdWVyeUNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpXG5cdCogYGBgXG5cdCovXG5cdGdldERlZmF1bHRPcHRpb25zKCkge1xuXHRcdHJldHVybiB0aGlzLiNkZWZhdWx0T3B0aW9ucztcblx0fVxuXHQvKipcblx0KiBEeW5hbWljYWxseSBzZXRzIHRoZSBkZWZhdWx0IG9wdGlvbnMgZm9yIHRoaXMgY2xpZW50LCBvdmVyd3JpdGluZyBhbnkgcHJldmlvdXNseSBkZWZpbmVkXG5cdCogZGVmYXVsdCBvcHRpb25zLlxuXHQqXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0RGVmYXVsdE9wdGlvbnN9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogcXVlcnlDbGllbnQuc2V0RGVmYXVsdE9wdGlvbnMoe1xuXHQqICAgcXVlcmllczoge1xuXHQqICAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuXHQqICAgfSxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXREZWZhdWx0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy4jZGVmYXVsdE9wdGlvbnMgPSBvcHRpb25zO1xuXHR9XG5cdC8qKlxuXHQqIFNldHMgZGVmYXVsdCBvcHRpb25zIGZvciBxdWVyaWVzIHdob3NlIHF1ZXJ5IGtleSBwYXJ0aWFsbHkgbWF0Y2hlcyB0aGUgZ2l2ZW4gYHF1ZXJ5S2V5YC5cblx0KlxuXHQqIElmIHNldmVyYWwgcmVnaXN0ZXJlZCBxdWVyeSBkZWZhdWx0cyBtYXRjaCBhIGdpdmVuIHF1ZXJ5IGtleSwgdGhleSBhcmUgbWVyZ2VkIHRvZ2V0aGVyIGluXG5cdCogcmVnaXN0cmF0aW9uIG9yZGVyIGJ5IHtAbGluayBRdWVyeUNsaWVudCNnZXRRdWVyeURlZmF1bHRzfSwgc28gcmVnaXN0ZXIgZGVmYXVsdHMgZnJvbSB0aGVcblx0KiBtb3N0IGdlbmVyaWMga2V5IHRvIHRoZSBsZWFzdCBnZW5lcmljIG9uZSDigJQgbW9yZSBzcGVjaWZpYyBkZWZhdWx0cyBzaG91bGQgYmUgcmVnaXN0ZXJlZFxuXHQqIGFmdGVyIG1vcmUgZ2VuZXJpYyBvbmVzIHNvIHRoZXkgdGFrZSBwcmVjZWRlbmNlLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGVmYXVsdHMoWydwb3N0cyddLCB7IHF1ZXJ5Rm46IGZldGNoUG9zdHMgfSlcblx0KlxuXHQqIGF3YWl0IHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyeURlZmF1bHRzKHF1ZXJ5S2V5LCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jcXVlcnlEZWZhdWx0cy5zZXQoaGFzaEtleShxdWVyeUtleSksIHtcblx0XHRcdHF1ZXJ5S2V5LFxuXHRcdFx0ZGVmYXVsdE9wdGlvbnM6IG9wdGlvbnNcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBkZWZhdWx0IG9wdGlvbnMgcmVnaXN0ZXJlZCBmb3IgcXVlcmllcyB3aG9zZSBxdWVyeSBrZXkgcGFydGlhbGx5IG1hdGNoZXMgdGhlXG5cdCogZ2l2ZW4gYHF1ZXJ5S2V5YCwgdmlhIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURlZmF1bHRzfS4gSWYgbXVsdGlwbGUgcmVnaXN0ZXJlZCBkZWZhdWx0c1xuXHQqIG1hdGNoLCB0aGV5IGFyZSBtZXJnZWQgdG9nZXRoZXIgaW4gcmVnaXN0cmF0aW9uIG9yZGVyLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlEZWZhdWx0cyhbJ3Bvc3RzJ10pXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpIHtcblx0XHRjb25zdCBkZWZhdWx0cyA9IFsuLi50aGlzLiNxdWVyeURlZmF1bHRzLnZhbHVlcygpXTtcblx0XHRjb25zdCByZXN1bHQgPSB7fTtcblx0XHRkZWZhdWx0cy5mb3JFYWNoKChxdWVyeURlZmF1bHQpID0+IHtcblx0XHRcdGlmIChwYXJ0aWFsTWF0Y2hLZXkocXVlcnlLZXksIHF1ZXJ5RGVmYXVsdC5xdWVyeUtleSkpIE9iamVjdC5hc3NpZ24ocmVzdWx0LCBxdWVyeURlZmF1bHQuZGVmYXVsdE9wdGlvbnMpO1xuXHRcdH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogU2V0cyBkZWZhdWx0IG9wdGlvbnMgZm9yIG11dGF0aW9ucyB3aG9zZSBtdXRhdGlvbiBrZXkgcGFydGlhbGx5IG1hdGNoZXMgdGhlIGdpdmVuXG5cdCogYG11dGF0aW9uS2V5YC4gQXMgd2l0aCB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcnlEZWZhdWx0c30sIHRoZSBvcmRlciBvZiByZWdpc3RyYXRpb25cblx0KiBtYXR0ZXJzIHdoZW4gc2V2ZXJhbCByZWdpc3RlcmVkIGRlZmF1bHRzIG1hdGNoIHRoZSBzYW1lIG11dGF0aW9uIGtleS5cblx0KlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldE11dGF0aW9uRGVmYXVsdHN9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHF1ZXJ5Q2xpZW50LnNldE11dGF0aW9uRGVmYXVsdHMoWydhZGRQb3N0J10sIHsgbXV0YXRpb25GbjogYWRkUG9zdCB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5LCBvcHRpb25zKSB7XG5cdFx0dGhpcy4jbXV0YXRpb25EZWZhdWx0cy5zZXQoaGFzaEtleShtdXRhdGlvbktleSksIHtcblx0XHRcdG11dGF0aW9uS2V5LFxuXHRcdFx0ZGVmYXVsdE9wdGlvbnM6IG9wdGlvbnNcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBkZWZhdWx0IG9wdGlvbnMgcmVnaXN0ZXJlZCBmb3IgbXV0YXRpb25zIHdob3NlIG11dGF0aW9uIGtleSBwYXJ0aWFsbHkgbWF0Y2hlc1xuXHQqIHRoZSBnaXZlbiBgbXV0YXRpb25LZXlgLCB2aWEge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldE11dGF0aW9uRGVmYXVsdHN9LiBJZiBtdWx0aXBsZSByZWdpc3RlcmVkXG5cdCogZGVmYXVsdHMgbWF0Y2gsIHRoZXkgYXJlIG1lcmdlZCB0b2dldGhlciBpbiByZWdpc3RyYXRpb24gb3JkZXIuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgZGVmYXVsdE9wdGlvbnMgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkRlZmF1bHRzKFsnYWRkUG9zdCddKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5KSB7XG5cdFx0Y29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jbXV0YXRpb25EZWZhdWx0cy52YWx1ZXMoKV07XG5cdFx0Y29uc3QgcmVzdWx0ID0ge307XG5cdFx0ZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG5cdFx0XHRpZiAocGFydGlhbE1hdGNoS2V5KG11dGF0aW9uS2V5LCBxdWVyeURlZmF1bHQubXV0YXRpb25LZXkpKSBPYmplY3QuYXNzaWduKHJlc3VsdCwgcXVlcnlEZWZhdWx0LmRlZmF1bHRPcHRpb25zKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gaW5zaWRlIGB1c2VRdWVyeWApIHRvIHJlc29sdmUgdGhlIG9wdGlvbnMgcGFzc2VkIGJ5IHRoZVxuXHQqIGNhbGxlciBpbnRvIHRoZWlyIGZpbmFsLCBkZWZhdWx0ZWQgZm9ybTogbWVyZ2luZyBgcXVlcnlDbGllbnQuc2V0UXVlcnlEZWZhdWx0c2AgZm9yIHRoZVxuXHQqIGdpdmVuIGBxdWVyeUtleWAsIHRoZW4gdGhlIGNsaWVudCdzIG93biBgZGVmYXVsdE9wdGlvbnMucXVlcmllc2AsIHRoZW4gdGhlIGNhbGxlcidzIG9wdGlvbnNcblx0KiBvbiB0b3AuIEEgbm8tb3AgaWYgdGhlIG9wdGlvbnMgYXJlIGFscmVhZHkgZGVmYXVsdGVkIChgX2RlZmF1bHRlZDogdHJ1ZWApLlxuXHQqL1xuXHRkZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRpZiAob3B0aW9ucy5fZGVmYXVsdGVkKSByZXR1cm4gb3B0aW9ucztcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMucXVlcmllcyxcblx0XHRcdC4uLnRoaXMuZ2V0UXVlcnlEZWZhdWx0cyhvcHRpb25zLnF1ZXJ5S2V5KSxcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRfZGVmYXVsdGVkOiB0cnVlXG5cdFx0fTtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKSBkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCA9IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5S2V5LCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPSBkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlICE9PSBcImFsd2F5c1wiO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvciA9PT0gdm9pZCAwKSBkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvciA9ICEhZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZTtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgJiYgZGVmYXVsdGVkT3B0aW9ucy5wZXJzaXN0ZXIpIGRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgPSBcIm9mZmxpbmVGaXJzdFwiO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgZGVmYXVsdGVkT3B0aW9ucy5lbmFibGVkID0gZmFsc2U7XG5cdFx0cmV0dXJuIGRlZmF1bHRlZE9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogVGhlIG11dGF0aW9uIGNvdW50ZXJwYXJ0IG9mIHtAbGluayBRdWVyeUNsaWVudCNkZWZhdWx0UXVlcnlPcHRpb25zfS4gQ2FsbGVkIGJ5IGZyYW1ld29ya1xuXHQqIGFkYXB0ZXJzIChlLmcuIGluc2lkZSBgdXNlTXV0YXRpb25gKSB0byBtZXJnZSBgcXVlcnlDbGllbnQuc2V0TXV0YXRpb25EZWZhdWx0c2AgZm9yIHRoZVxuXHQqIGdpdmVuIGBtdXRhdGlvbktleWAsIHRoZW4gdGhlIGNsaWVudCdzIGBkZWZhdWx0T3B0aW9ucy5tdXRhdGlvbnNgLCB0aGVuIHRoZSBjYWxsZXIncyBvcHRpb25zXG5cdCogb24gdG9wLiBBIG5vLW9wIGlmIHRoZSBvcHRpb25zIGFyZSBhbHJlYWR5IGRlZmF1bHRlZCAoYF9kZWZhdWx0ZWQ6IHRydWVgKS5cblx0Ki9cblx0ZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0aWYgKG9wdGlvbnM/Ll9kZWZhdWx0ZWQpIHJldHVybiBvcHRpb25zO1xuXHRcdHJldHVybiB7XG5cdFx0XHQuLi50aGlzLiNkZWZhdWx0T3B0aW9ucy5tdXRhdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zPy5tdXRhdGlvbktleSAmJiB0aGlzLmdldE11dGF0aW9uRGVmYXVsdHMob3B0aW9ucy5tdXRhdGlvbktleSksXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0X2RlZmF1bHRlZDogdHJ1ZVxuXHRcdH07XG5cdH1cblx0LyoqXG5cdCogQ2xlYXJzIGJvdGggdGhlIHF1ZXJ5IGNhY2hlIGFuZCB0aGUgbXV0YXRpb24gY2FjaGUgdGhpcyBjbGllbnQgaXMgY29ubmVjdGVkIHRvLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogcXVlcnlDbGllbnQuY2xlYXIoKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHR0aGlzLiNxdWVyeUNhY2hlLmNsZWFyKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5jbGVhcigpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBRdWVyeUNsaWVudCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeUNsaWVudC5qcy5tYXAiLCJpbXBvcnQgeyBhZGRDb25zdW1lQXdhcmVTaWduYWwsIGFkZFRvRW5kIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvc3RyZWFtZWRRdWVyeS50c1xuLyoqXG4qIFRoaXMgaXMgYSBoZWxwZXIgZnVuY3Rpb24gdG8gY3JlYXRlIGEgcXVlcnkgZnVuY3Rpb24gdGhhdCBzdHJlYW1zIGRhdGEgZnJvbSBhbiBBc3luY0l0ZXJhYmxlLlxuKiBEYXRhIHdpbGwgYmUgYW4gQXJyYXkgb2YgYWxsIHRoZSBjaHVua3MgcmVjZWl2ZWQuXG4qIFRoZSBxdWVyeSB3aWxsIGJlIGluIGEgJ3BlbmRpbmcnIHN0YXRlIHVudGlsIHRoZSBmaXJzdCBjaHVuayBvZiBkYXRhIGlzIHJlY2VpdmVkLCBidXQgd2lsbCBnbyB0byAnc3VjY2VzcycgYWZ0ZXIgdGhhdC5cbiogVGhlIHF1ZXJ5IHdpbGwgc3RheSBpbiBmZXRjaFN0YXR1cyAnZmV0Y2hpbmcnIHVudGlsIHRoZSBzdHJlYW0gZW5kcy5cbiogQHBhcmFtIHN0cmVhbUZuIC0gVGhlIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhbiBBc3luY0l0ZXJhYmxlIHRvIHN0cmVhbSBkYXRhIGZyb20uXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGF3YWl0IHF1ZXJ5Q2xpZW50LnF1ZXJ5KHtcbiogICBxdWVyeUtleTogWydkYXRhJ10sXG4qICAgcXVlcnlGbjogc3RyZWFtZWRRdWVyeSh7XG4qICAgICBzdHJlYW1GbjogZmV0Y2hEYXRhSW5DaHVua3MsXG4qICAgfSksXG4qIH0pXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHN0cmVhbWVkUXVlcnkoeyBzdHJlYW1GbiwgcmVmZXRjaE1vZGUgPSBcInJlc2V0XCIsIHJlZHVjZXIgPSAoaXRlbXMsIGNodW5rKSA9PiBhZGRUb0VuZChpdGVtcywgY2h1bmspLCBpbml0aWFsVmFsdWUgPSBbXSB9KSB7XG5cdHJldHVybiBhc3luYyAoY29udGV4dCkgPT4ge1xuXHRcdGNvbnN0IHF1ZXJ5ID0gY29udGV4dC5jbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmZpbmQoe1xuXHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRleGFjdDogdHJ1ZVxuXHRcdH0pO1xuXHRcdGNvbnN0IGlzUmVmZXRjaCA9ICEhcXVlcnkgJiYgcXVlcnkuaXNGZXRjaGVkKCk7XG5cdFx0aWYgKGlzUmVmZXRjaCAmJiByZWZldGNoTW9kZSA9PT0gXCJyZXNldFwiKSBxdWVyeS5zZXRTdGF0ZSh7XG5cdFx0XHQuLi5xdWVyeS5yZXNldFN0YXRlLFxuXHRcdFx0ZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuXHRcdH0pO1xuXHRcdGxldCByZXN1bHQgPSBpbml0aWFsVmFsdWU7XG5cdFx0bGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuXHRcdGNvbnN0IHN0cmVhbSA9IGF3YWl0IHN0cmVhbUZuKGFkZENvbnN1bWVBd2FyZVNpZ25hbCh7XG5cdFx0XHRjbGllbnQ6IGNvbnRleHQuY2xpZW50LFxuXHRcdFx0bWV0YTogY29udGV4dC5tZXRhLFxuXHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRwYWdlUGFyYW06IGNvbnRleHQucGFnZVBhcmFtLFxuXHRcdFx0ZGlyZWN0aW9uOiBjb250ZXh0LmRpcmVjdGlvblxuXHRcdH0sICgpID0+IGNvbnRleHQuc2lnbmFsLCAoKSA9PiBjYW5jZWxsZWQgPSB0cnVlKSk7XG5cdFx0Y29uc3QgaXNSZXBsYWNlUmVmZXRjaCA9IGlzUmVmZXRjaCAmJiByZWZldGNoTW9kZSA9PT0gXCJyZXBsYWNlXCI7XG5cdFx0Zm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiBzdHJlYW0pIHtcblx0XHRcdGlmIChjYW5jZWxsZWQpIGJyZWFrO1xuXHRcdFx0aWYgKGlzUmVwbGFjZVJlZmV0Y2gpIHJlc3VsdCA9IHJlZHVjZXIocmVzdWx0LCBjaHVuayk7XG5cdFx0XHRlbHNlIGNvbnRleHQuY2xpZW50LnNldFF1ZXJ5RGF0YShjb250ZXh0LnF1ZXJ5S2V5LCAocHJldikgPT4gcmVkdWNlcihwcmV2ID09PSB2b2lkIDAgPyBpbml0aWFsVmFsdWUgOiBwcmV2LCBjaHVuaykpO1xuXHRcdH1cblx0XHRpZiAoaXNSZXBsYWNlUmVmZXRjaCAmJiAhY2FuY2VsbGVkKSBjb250ZXh0LmNsaWVudC5zZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSwgcmVzdWx0KTtcblx0XHRjb25zdCBkYXRhID0gY29udGV4dC5jbGllbnQuZ2V0UXVlcnlEYXRhKGNvbnRleHQucXVlcnlLZXkpO1xuXHRcdHJldHVybiBkYXRhID09PSB2b2lkIDAgPyBpbml0aWFsVmFsdWUgOiBkYXRhO1xuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBzdHJlYW1lZFF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0cmVhbWVkUXVlcnkuanMubWFwIiwiLy8jcmVnaW9uIHNyYy90eXBlcy50c1xuLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbmNvbnN0IGRhdGFUYWdTeW1ib2wgPSBTeW1ib2woKTtcbmNvbnN0IGRhdGFUYWdFcnJvclN5bWJvbCA9IFN5bWJvbCgpO1xuY29uc3QgdW5zZXRNYXJrZXIgPSBTeW1ib2woKTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGF0YVRhZ0Vycm9yU3ltYm9sLCBkYXRhVGFnU3ltYm9sLCB1bnNldE1hcmtlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD10eXBlcy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBoeWRyYXRlIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL0h5ZHJhdGlvbkJvdW5kYXJ5LnRzeFxuLyoqXG4qIGBIeWRyYXRpb25Cb3VuZGFyeWAgYWRkcyBhIHByZXZpb3VzbHkgZGVoeWRyYXRlZCBzdGF0ZSBpbnRvIHRoZSBgcXVlcnlDbGllbnRgIHRoYXQgd291bGQgYmUgcmV0dXJuZWQgYnlcbiogYHVzZVF1ZXJ5Q2xpZW50KClgLiBJZiB0aGUgY2xpZW50IGFscmVhZHkgY29udGFpbnMgZGF0YSwgdGhlIG5ldyBxdWVyaWVzIHdpbGwgYmUgaW50ZWxsaWdlbnRseSBtZXJnZWQgYmFzZWQgb25cbiogdXBkYXRlIHRpbWVzdGFtcC5cbipcbiogTm90ZTogT25seSBgcXVlcmllc2AgY2FuIGJlIGRlaHlkcmF0ZWQgd2l0aCBhbiBgSHlkcmF0aW9uQm91bmRhcnlgLlxuKlxuKiBAcmV0dXJucyBUaGUgcHJvdmlkZWQgYGNoaWxkcmVuYCwgcmVuZGVyZWQgdW5jb25kaXRpb25hbGx5LiBOZXcgcXVlcmllcyBpbiBgc3RhdGVgIGFyZSBoeWRyYXRlZCBpbnRvIHRoZVxuKiBjYWNoZSBkdXJpbmcgcmVuZGVyOyBmb3IgcXVlcmllcyBhbHJlYWR5IGluIHRoZSBjYWNoZSwgb25seSBuZXdlciBkZWh5ZHJhdGVkIGRhdGEgaXMgaHlkcmF0ZWQsIGluIGFuIGVmZmVjdFxuKiBhZnRlciBjb21taXQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBIeWRyYXRpb25Cb3VuZGFyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiA8SHlkcmF0aW9uQm91bmRhcnkgc3RhdGU9e2RlaHlkcmF0ZWRTdGF0ZX0+Li4uPC9IeWRyYXRpb25Cb3VuZGFyeT5cbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogU2VydmVyLXNpZGUgcHJlZmV0Y2ggaGFuZGVkIG9mZiB0byB0aGUgY2xpZW50IHZpYSBgZGVoeWRyYXRlYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5LCBkZWh5ZHJhdGUsIG5vb3AgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGFzeW5jIGZ1bmN0aW9uIFNlcnZlckNvbXBvbmVudCgpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IGdldFF1ZXJ5Q2xpZW50KClcbipcbiogICBhd2FpdCBxdWVyeUNsaWVudFxuKiAgICAgLnF1ZXJ5KHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogICAgIH0pXG4qICAgICAuY2F0Y2gobm9vcClcbipcbiogICByZXR1cm4gKFxuKiAgICAgPEh5ZHJhdGlvbkJvdW5kYXJ5IHN0YXRlPXtkZWh5ZHJhdGUocXVlcnlDbGllbnQpfT5cbiogICAgICAgPFBvc3RzIC8+XG4qICAgICA8L0h5ZHJhdGlvbkJvdW5kYXJ5PlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5jb25zdCBIeWRyYXRpb25Cb3VuZGFyeSA9ICh7IGNoaWxkcmVuLCBvcHRpb25zID0ge30sIHN0YXRlLCBxdWVyeUNsaWVudCB9KSA9PiB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3Qgb3B0aW9uc1JlZiA9IFJlYWN0LnVzZVJlZihvcHRpb25zKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvcHRpb25zUmVmLmN1cnJlbnQgPSBvcHRpb25zO1xuXHR9KTtcblx0Y29uc3QgaHlkcmF0aW9uUXVldWUgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcblx0XHRpZiAoc3RhdGUpIHtcblx0XHRcdGlmICh0eXBlb2Ygc3RhdGUgIT09IFwib2JqZWN0XCIpIHJldHVybjtcblx0XHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRcdFx0Y29uc3QgcXVlcmllcyA9IHN0YXRlLnF1ZXJpZXMgfHwgW107XG5cdFx0XHRjb25zdCBuZXdRdWVyaWVzID0gW107XG5cdFx0XHRjb25zdCBleGlzdGluZ1F1ZXJpZXMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgZGVoeWRyYXRlZFF1ZXJ5IG9mIHF1ZXJpZXMpIHtcblx0XHRcdFx0Y29uc3QgZXhpc3RpbmdRdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KGRlaHlkcmF0ZWRRdWVyeS5xdWVyeUhhc2gpO1xuXHRcdFx0XHRpZiAoIWV4aXN0aW5nUXVlcnkpIG5ld1F1ZXJpZXMucHVzaChkZWh5ZHJhdGVkUXVlcnkpO1xuXHRcdFx0XHRlbHNlIGlmIChkZWh5ZHJhdGVkUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCA+IGV4aXN0aW5nUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBkZWh5ZHJhdGVkUXVlcnkucHJvbWlzZSAmJiBleGlzdGluZ1F1ZXJ5LnN0YXRlLnN0YXR1cyAhPT0gXCJwZW5kaW5nXCIgJiYgZXhpc3RpbmdRdWVyeS5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJmZXRjaGluZ1wiICYmIGRlaHlkcmF0ZWRRdWVyeS5kZWh5ZHJhdGVkQXQgPiBleGlzdGluZ1F1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpIGV4aXN0aW5nUXVlcmllcy5wdXNoKGRlaHlkcmF0ZWRRdWVyeSk7XG5cdFx0XHR9XG5cdFx0XHRpZiAobmV3UXVlcmllcy5sZW5ndGggPiAwKSBoeWRyYXRlKGNsaWVudCwgeyBxdWVyaWVzOiBuZXdRdWVyaWVzIH0sIG9wdGlvbnNSZWYuY3VycmVudCk7XG5cdFx0XHRpZiAoZXhpc3RpbmdRdWVyaWVzLmxlbmd0aCA+IDApIHJldHVybiBleGlzdGluZ1F1ZXJpZXM7XG5cdFx0fVxuXHR9LCBbY2xpZW50LCBzdGF0ZV0pO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmIChoeWRyYXRpb25RdWV1ZSkgaHlkcmF0ZShjbGllbnQsIHsgcXVlcmllczogaHlkcmF0aW9uUXVldWUgfSwgb3B0aW9uc1JlZi5jdXJyZW50KTtcblx0fSwgW2NsaWVudCwgaHlkcmF0aW9uUXVldWVdKTtcblx0cmV0dXJuIGNoaWxkcmVuO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSHlkcmF0aW9uQm91bmRhcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SHlkcmF0aW9uQm91bmRhcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvSXNSZXN0b3JpbmdQcm92aWRlci50c1xuY29uc3QgSXNSZXN0b3JpbmdDb250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChmYWxzZSk7XG4vKipcbiogSWYgeW91IGFyZSB1c2luZyBgUGVyc2lzdFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLCB5b3UgY2FuIGFsc28gdXNlIHRoZSBgdXNlSXNSZXN0b3JpbmdgIGhvb2sgYWxvbmdzaWRlIGl0IHRvXG4qIGNoZWNrIGlmIGEgcmVzdG9yZSBpcyBjdXJyZW50bHkgaW4gcHJvZ3Jlc3MuIGB1c2VRdWVyeWAgYW5kIGZyaWVuZHMgYWxzbyBjaGVjayB0aGlzIGludGVybmFsbHkgdG8gYXZvaWRcbiogcmFjZSBjb25kaXRpb25zIGJldHdlZW4gdGhlIHJlc3RvcmUgYW5kIG1vdW50aW5nIHF1ZXJpZXMuXG4qXG4qIEByZXR1cm5zIGB0cnVlYCB3aGlsZSBhIHBlcnNpc3RlZCBjbGllbnQgaXMgYmVpbmcgcmVzdG9yZWQsIGBmYWxzZWAgb3RoZXJ3aXNlLlxuKi9cbmNvbnN0IHVzZUlzUmVzdG9yaW5nID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChJc1Jlc3RvcmluZ0NvbnRleHQpO1xuLyoqXG4qIFRoZSBQcm92aWRlciB0aGF0IGBQZXJzaXN0UXVlcnlDbGllbnRQcm92aWRlcmAgdXNlcyB0byBzaWduYWwgd2hldGhlciBhIHBlcnNpc3RlZCBjbGllbnQgaXMgY3VycmVudGx5XG4qIGJlaW5nIHJlc3RvcmVkLCByZWFkIGJ5IGB1c2VJc1Jlc3RvcmluZ2AuXG4qL1xuY29uc3QgSXNSZXN0b3JpbmdQcm92aWRlciA9IElzUmVzdG9yaW5nQ29udGV4dC5Qcm92aWRlcjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSXNSZXN0b3JpbmdQcm92aWRlciwgdXNlSXNSZXN0b3JpbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SXNSZXN0b3JpbmdQcm92aWRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL1F1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LnRzeFxuLyoqXG4qIFJlc2V0cyBhbnkgcXVlcnkgZXJyb3JzIHdpdGhpbiB0aGUgYm91bmRhcnksIHNvIHF1ZXJpZXMga25vdyB0aGV5IGNhbiB0cnkgYWdhaW4uXG4qL1xuZnVuY3Rpb24gY3JlYXRlVmFsdWUoKSB7XG5cdGxldCBpc1Jlc2V0ID0gZmFsc2U7XG5cdHJldHVybiB7XG5cdFx0LyoqXG5cdFx0KiBDbGVhcnMgdGhlIHJlc2V0IHN0YXRlLCBzbyBxdWVyaWVzIGtub3cgbm90IHRvIHRyeSBhZ2FpbiB1bnRpbCB0aGUgYm91bmRhcnkgaXMgcmVzZXQgYWdhaW4uXG5cdFx0Ki9cblx0XHRjbGVhclJlc2V0OiAoKSA9PiB7XG5cdFx0XHRpc1Jlc2V0ID0gZmFsc2U7XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIFJlc2V0cyBhbnkgcXVlcnkgZXJyb3JzIHdpdGhpbiB0aGUgYm91bmRhcnksIHNvIHF1ZXJpZXMga25vdyB0aGV5IGNhbiB0cnkgYWdhaW4uXG5cdFx0Ki9cblx0XHRyZXNldDogKCkgPT4ge1xuXHRcdFx0aXNSZXNldCA9IHRydWU7XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIFJldHVybnMgd2hldGhlciB0aGUgYm91bmRhcnkgaGFzIGJlZW4gcmVzZXQgYW5kIG5vdCB5ZXQgY2xlYXJlZC5cblx0XHQqL1xuXHRcdGlzUmVzZXQ6ICgpID0+IHtcblx0XHRcdHJldHVybiBpc1Jlc2V0O1xuXHRcdH1cblx0fTtcbn1cbmNvbnN0IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5Q29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoY3JlYXRlVmFsdWUoKSk7XG4vKipcbiogVGhpcyBob29rIHdpbGwgcmVzZXQgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGNsb3Nlc3QgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YC4gSWYgdGhlcmUgaXMgbm8gYm91bmRhcnlcbiogZGVmaW5lZCBpdCB3aWxsIHJlc2V0IHRoZW0gZ2xvYmFsbHkuXG4qXG4qIEByZXR1cm5zIFRoZSBib3VuZGFyeSdzIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeVZhbHVlfS5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tICdyZWFjdC1lcnJvci1ib3VuZGFyeSdcbiogaW1wb3J0IHsgdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4qICAgY29uc3QgeyByZXNldCB9ID0gdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkoKVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICBvblJlc2V0PXtyZXNldH1cbiogICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgPGRpdj5cbiogICAgICAgICAgIFRoZXJlIHdhcyBhbiBlcnJvciFcbiogICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgIDwvZGl2PlxuKiAgICAgICApfVxuKiAgICAgPlxuKiAgICAgICB7Y2hpbGRyZW59XG4qICAgICA8L0Vycm9yQm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmNvbnN0IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQpO1xuLyoqXG4qIFdoZW4gdXNpbmcgYHN1c3BlbnNlYCBvciBgdGhyb3dPbkVycm9yYCBpbiB5b3VyIHF1ZXJpZXMsIHlvdSBuZWVkIGEgd2F5IHRvIGxldCBxdWVyaWVzIGtub3cgdGhhdCB5b3Ugd2FudCB0b1xuKiB0cnkgYWdhaW4gd2hlbiByZS1yZW5kZXJpbmcgYWZ0ZXIgc29tZSBlcnJvciBvY2N1cnJlZC4gV2l0aCB0aGUgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YCBjb21wb25lbnQgeW91IGNhblxuKiByZXNldCBhbnkgcXVlcnkgZXJyb3JzIHdpdGhpbiB0aGUgYm91bmRhcmllcyBvZiB0aGUgY29tcG9uZW50LlxuKlxuKiBAcmV0dXJucyBUaGUgYGNoaWxkcmVuYCwgcmVuZGVyZWQgYXMtaXMsIG9yIGNhbGxlZCB3aXRoIHRoZSBib3VuZGFyeSdzIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeVZhbHVlfVxuKiBpZiBgY2hpbGRyZW5gIGlzIGEgZnVuY3Rpb24uXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIChcbiogICAgIDxRdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICAgICAgeyh7IHJlc2V0IH0pID0+IChcbiogICAgICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgICAgICBmYWxsYmFja1JlbmRlcj17KHsgcmVzZXRFcnJvckJvdW5kYXJ5IH0pID0+IChcbiogICAgICAgICAgICAgPGRpdj5cbiogICAgICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZXNldEVycm9yQm91bmRhcnkoKX0+VHJ5IGFnYWluPC9idXR0b24+XG4qICAgICAgICAgICAgIDwvZGl2PlxuKiAgICAgICAgICAgKX1cbiogICAgICAgICA+XG4qICAgICAgICAgICA8UGFnZSAvPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmNvbnN0IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuXHRjb25zdCBbdmFsdWVdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gY3JlYXRlVmFsdWUoKSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5Q29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlLFxuXHRcdGNoaWxkcmVuOiB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHZhbHVlKSA6IGNoaWxkcmVuXG5cdH0pO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzaG91bGRUaHJvd0Vycm9yIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL2Vycm9yQm91bmRhcnlVdGlscy50c1xuY29uc3QgZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeSA9IChvcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KSA9PiB7XG5cdGNvbnN0IHRocm93T25FcnJvciA9IHF1ZXJ5Py5zdGF0ZS5lcnJvciAmJiB0eXBlb2Ygb3B0aW9ucy50aHJvd09uRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IHNob3VsZFRocm93RXJyb3Iob3B0aW9ucy50aHJvd09uRXJyb3IsIFtxdWVyeS5zdGF0ZS5lcnJvciwgcXVlcnldKSA6IG9wdGlvbnMudGhyb3dPbkVycm9yO1xuXHRpZiAob3B0aW9ucy5zdXNwZW5zZSB8fCB0aHJvd09uRXJyb3IpIHtcblx0XHRpZiAoIWVycm9yUmVzZXRCb3VuZGFyeS5pc1Jlc2V0KCkpIG9wdGlvbnMucmV0cnlPbk1vdW50ID0gZmFsc2U7XG5cdH1cbn07XG5jb25zdCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSA9IChlcnJvclJlc2V0Qm91bmRhcnkpID0+IHtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRlcnJvclJlc2V0Qm91bmRhcnkuY2xlYXJSZXNldCgpO1xuXHR9LCBbZXJyb3JSZXNldEJvdW5kYXJ5XSk7XG59O1xuY29uc3QgZ2V0SGFzRXJyb3IgPSAoeyByZXN1bHQsIGVycm9yUmVzZXRCb3VuZGFyeSwgdGhyb3dPbkVycm9yLCBxdWVyeSwgc3VzcGVuc2UgfSkgPT4ge1xuXHRyZXR1cm4gcmVzdWx0LmlzRXJyb3IgJiYgIWVycm9yUmVzZXRCb3VuZGFyeS5pc1Jlc2V0KCkgJiYgIXJlc3VsdC5pc0ZldGNoaW5nICYmIHF1ZXJ5ICYmIChzdXNwZW5zZSAmJiByZXN1bHQuZGF0YSA9PT0gdm9pZCAwIHx8IHNob3VsZFRocm93RXJyb3IodGhyb3dPbkVycm9yLCBbcmVzdWx0LmVycm9yLCBxdWVyeV0pKTtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1lcnJvckJvdW5kYXJ5VXRpbHMuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zdXNwZW5zZS50c1xuY29uc3QgZGVmYXVsdFRocm93T25FcnJvciA9IChfZXJyb3IsIHF1ZXJ5KSA9PiBxdWVyeS5zdGF0ZS5kYXRhID09PSB2b2lkIDA7XG5jb25zdCBlbnN1cmVTdXNwZW5zZVRpbWVycyA9IChkZWZhdWx0ZWRPcHRpb25zKSA9PiB7XG5cdGlmIChkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlKSB7XG5cdFx0Y29uc3QgTUlOX1NVU1BFTlNFX1RJTUVfTVMgPSAxZTM7XG5cdFx0Y29uc3QgY2xhbXAgPSAodmFsdWUpID0+IHZhbHVlID09PSBcInN0YXRpY1wiID8gdmFsdWUgOiBNYXRoLm1heCh2YWx1ZSA/PyBNSU5fU1VTUEVOU0VfVElNRV9NUywgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuXHRcdGNvbnN0IG9yaWdpbmFsU3RhbGVUaW1lID0gZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWU7XG5cdFx0ZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUgPSB0eXBlb2Ygb3JpZ2luYWxTdGFsZVRpbWUgPT09IFwiZnVuY3Rpb25cIiA/ICguLi5hcmdzKSA9PiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSguLi5hcmdzKSkgOiBjbGFtcChvcmlnaW5hbFN0YWxlVGltZSk7XG5cdFx0aWYgKHR5cGVvZiBkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSA9PT0gXCJudW1iZXJcIikgZGVmYXVsdGVkT3B0aW9ucy5nY1RpbWUgPSBNYXRoLm1heChkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSwgTUlOX1NVU1BFTlNFX1RJTUVfTVMpO1xuXHR9XG59O1xuY29uc3Qgc2hvdWxkU3VzcGVuZCA9IChkZWZhdWx0ZWRPcHRpb25zLCByZXN1bHQpID0+IGRlZmF1bHRlZE9wdGlvbnM/LnN1c3BlbnNlICYmIHJlc3VsdC5pc1BlbmRpbmc7XG5jb25zdCBmZXRjaE9wdGltaXN0aWMgPSAoZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSkgPT4gb2JzZXJ2ZXIuZmV0Y2hPcHRpbWlzdGljKGRlZmF1bHRlZE9wdGlvbnMpLmNhdGNoKCgpID0+IHtcblx0ZXJyb3JSZXNldEJvdW5kYXJ5LmNsZWFyUmVzZXQoKTtcbn0pO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yLCBlbnN1cmVTdXNwZW5zZVRpbWVycywgZmV0Y2hPcHRpbWlzdGljLCBzaG91bGRTdXNwZW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN1c3BlbnNlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFF1ZXJpZXNPYnNlcnZlciwgUXVlcnlPYnNlcnZlciwgbm9vcCwgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VRdWVyaWVzLnRzXG4vKipcbiogVGhlIGB1c2VRdWVyaWVzYCBob29rIGNhbiBiZSB1c2VkIHRvIGZldGNoIGEgdmFyaWFibGUgbnVtYmVyIG9mIHF1ZXJpZXMuXG4qXG4qIFRoZSBgcXVlcmllc2Aga2V5IGFjY2VwdHMgYW4gYXJyYXkgd2l0aCBxdWVyeSBvcHRpb24gb2JqZWN0cyBtb3N0bHkgaWRlbnRpY2FsIHRvIGB1c2VRdWVyeWAg4oCUIHRoZSB0b3AtbGV2ZWxcbiogYHN1YnNjcmliZWRgIG9wdGlvbiBpc24ndCBhY2NlcHRlZCBwZXIgcXVlcnkgKHNlZSBgcGxhY2Vob2xkZXJEYXRhYCBiZWxvdyBmb3IgYW5vdGhlciBkaWZmZXJlbmNlKS4gQSBjdXN0b21cbiogYFF1ZXJ5Q2xpZW50YCBpcyBzdXBwbGllZCBvbmNlLCBhcyBgdXNlUXVlcmllc2AnIG93biB0b3AtbGV2ZWwgc2Vjb25kIGFyZ3VtZW50LCByYXRoZXIgdGhhbiBwZXIgcXVlcnkuXG4qXG4qIEhhdmluZyB0aGUgc2FtZSBxdWVyeSBrZXkgbW9yZSB0aGFuIG9uY2UgaW4gdGhlIGFycmF5IG9mIHF1ZXJ5IG9iamVjdHMgbWF5IGNhdXNlIHNvbWUgZGF0YSB0byBiZSBzaGFyZWRcbiogYmV0d2VlbiBxdWVyaWVzLiBUbyBhdm9pZCB0aGlzLCBjb25zaWRlciBkZS1kdXBsaWNhdGluZyB0aGUgcXVlcmllcyBhbmQgbWFwIHRoZSByZXN1bHRzIGJhY2sgdG8gdGhlIGRlc2lyZWRcbiogc3RydWN0dXJlLlxuKlxuKiBUaGUgYGNvbWJpbmVgIG9wdGlvbiBjYW4gYmUgdXNlZCB0byBjb21iaW5lIHRoZSByZXN1bHRzIG9mIHRoZSBxdWVyaWVzIGludG8gYSBzaW5nbGUgdmFsdWUuIFRoZSByZXN1bHQgd2lsbFxuKiBiZSBzdHJ1Y3R1cmFsbHkgc2hhcmVkIHRvIGJlIGFzIHJlZmVyZW50aWFsbHkgc3RhYmxlIGFzIHBvc3NpYmxlLlxuKlxuKiBAcmVtYXJrcyBUaGUgYGNvbWJpbmVgIGZ1bmN0aW9uIG9ubHkgcmUtcnVucyBpZiBpdCBjaGFuZ2VkIHJlZmVyZW50aWFsbHksIG9yIGlmIGFueSBvZiB0aGUgcXVlcnkgcmVzdWx0c1xuKiBjaGFuZ2VkLiBBbiBpbmxpbmVkIGBjb21iaW5lYCBmdW5jdGlvbiwgYXMgc2hvd24gaW4gdGhlIGV4YW1wbGUgYmVsb3csIHRoZXJlZm9yZSBydW5zIG9uIGV2ZXJ5IHJlbmRlciDigJQgd3JhcFxuKiBpdCBpbiBgdXNlQ2FsbGJhY2tgLCBvciBleHRyYWN0IGl0IHRvIGEgc3RhYmxlIGZ1bmN0aW9uIHJlZmVyZW5jZSBpZiBpdCBkb2Vzbid0IGhhdmUgYW55IGRlcGVuZGVuY2llcywgdG9cbiogYXZvaWQgdGhhdC5cbipcbiogVW5saWtlIGB1c2VRdWVyeWAsIGB1c2VRdWVyaWVzYCBjYW5ub3QgaW5mZXIgdGhlIGBkYXRhYCBhcmd1bWVudCBvZiBhbiBfaW5saW5lXyBgc2VsZWN0YCBmcm9tIGl0cyBzaWJsaW5nXG4qIGBxdWVyeUZuYC4gQmVjYXVzZSBgdXNlUXVlcmllc2AgaW5mZXJzIHRoZSB0eXBlIG9mIHRoZSB3aG9sZSBgcXVlcmllc2AgYXJyYXkgYXQgb25jZSwgdGhlIGBzZWxlY3RgIHBhcmFtZXRlclxuKiBvZiBhIHF1ZXJ5IG9iamVjdCB3cml0dGVuIGlubGluZSBjYW5ub3QgYmUgY29udGV4dHVhbGx5IHR5cGVkIGZyb20gdGhhdCBzYW1lIG9iamVjdCdzIGBxdWVyeUZuYCwgc28gaXQgZmFsbHNcbiogYmFjayB0byBgdW5rbm93bmAg4oCUIGEgW2tub3duIFR5cGVTY3JpcHQgbGltaXRhdGlvbl0oaHR0cHM6Ly9naXRodWIuY29tL1RhblN0YWNrL3F1ZXJ5L2lzc3Vlcy82NTU2KS4gQW5ub3RhdGVcbiogdGhlIGBzZWxlY3RgIHBhcmFtZXRlciBleHBsaWNpdGx5LCBvciBkZWZpbmUgdGhlIHF1ZXJ5IHdpdGgge0BsaW5rIHF1ZXJ5T3B0aW9uc30sIHdoaWNoIHJlc29sdmVzIGl0cyB0eXBlcyBpblxuKiBhIHNpbmdsZSBvYmplY3QgX2JlZm9yZV8gaXQgcmVhY2hlcyBgdXNlUXVlcmllc2AsIHRvIHdvcmsgYXJvdW5kIHRoaXMg4oCUIHNlZSB0aGUgZXhhbXBsZSBiZWxvdy4gVGhlIHNhbWVcbiogbGltaXRhdGlvbiBhcHBsaWVzIHRvIHtAbGluayB1c2VTdXNwZW5zZVF1ZXJpZXN9LlxuKlxuKiBgcGxhY2Vob2xkZXJEYXRhYCBpcyBzdXBwb3J0ZWQgaGVyZSB0b28sIGJ1dCB1bmxpa2UgYHVzZVF1ZXJ5YCwgaXQgZG9lc24ndCByZWNlaXZlIGluZm9ybWF0aW9uIGZyb21cbiogcHJldmlvdXNseSByZW5kZXJlZCBxdWVyaWVzLCBiZWNhdXNlIHRoZSBudW1iZXIgb2YgcXVlcmllcyBjYW4gZGlmZmVyIGJldHdlZW4gcmVuZGVycy5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gcHJvdmlkZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0XG4qIHdpbGwgYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIGNvbWJpbmVkIHJlc3VsdC4gV2l0aG91dCBgY29tYmluZWAsIHRoaXMgaXMgYW4gYXJyYXkgd2l0aCBhbGwgdGhlIHF1ZXJ5IHJlc3VsdHMsIGluIHRoZSBzYW1lXG4qIG9yZGVyIGFzIHRoZSBpbnB1dC4gV2hlbiBgY29tYmluZWAgaXMgcHJvdmlkZWQsIHRoaXMgaXMgdGhlIHZhbHVlIHJldHVybmVkIGJ5IGBjb21iaW5lYCBpbnN0ZWFkLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoeyBpZHMgfTogeyBpZHM6IEFycmF5PG51bWJlcj4gfSkge1xuKiAgIGNvbnN0IHBvc3RRdWVyaWVzID0gdXNlUXVlcmllcyh7XG4qICAgICBxdWVyaWVzOiBpZHMubWFwKChpZCkgPT4gKHtcbiogICAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KGlkKSxcbiogICAgICAgc3RhbGVUaW1lOiBJbmZpbml0eSxcbiogICAgIH0pKSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8dWw+XG4qICAgICAgIHtwb3N0UXVlcmllcy5tYXAoKHF1ZXJ5LCBpbmRleCkgPT4ge1xuKiAgICAgICAgIGlmIChxdWVyeS5pc1BlbmRpbmcpIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT5Mb2FkaW5nLi4uPC9saT5cbiogICAgICAgICBpZiAocXVlcnkuaXNFcnJvcikgcmV0dXJuIDxsaSBrZXk9e2lkc1tpbmRleF19PkVycm9yOiB7cXVlcnkuZXJyb3IubWVzc2FnZX08L2xpPlxuKiAgICAgICAgIHJldHVybiA8bGkga2V5PXtpZHNbaW5kZXhdfT57cXVlcnkuZGF0YS50aXRsZX08L2xpPlxuKiAgICAgICB9KX1cbiogICAgIDwvdWw+XG4qICAgKVxuKiB9XG4qIGBgYFxuKlxuKiBAZXhhbXBsZVxuKiBDb21iaW5pbmcgcmVzdWx0cyBpbnRvIGEgc2luZ2xlIHZhbHVlOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUG9zdHMoeyBpZHMgfTogeyBpZHM6IEFycmF5PG51bWJlcj4gfSkge1xuKiAgIGNvbnN0IHsgZGF0YSwgaXNQZW5kaW5nLCBpc0Vycm9yIH0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IGlkcy5tYXAoKGlkKSA9PiAoe1xuKiAgICAgICBxdWVyeUtleTogWydwb3N0JywgaWRdLFxuKiAgICAgICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoaWQpLFxuKiAgICAgfSkpLFxuKiAgICAgY29tYmluZTogKHBvc3RRdWVyaWVzKSA9PiB7XG4qICAgICAgIHJldHVybiB7XG4qICAgICAgICAgZGF0YTogcG9zdFF1ZXJpZXMubWFwKChxdWVyeSkgPT4gcXVlcnkuZGF0YSksXG4qICAgICAgICAgaXNQZW5kaW5nOiBwb3N0UXVlcmllcy5zb21lKChxdWVyeSkgPT4gcXVlcnkuaXNQZW5kaW5nKSxcbiogICAgICAgICBpc0Vycm9yOiBwb3N0UXVlcmllcy5zb21lKChxdWVyeSkgPT4gcXVlcnkuaXNFcnJvciksXG4qICAgICAgIH1cbiogICAgIH0sXG4qICAgfSlcbipcbiogICBpZiAoaXNQZW5kaW5nKSByZXR1cm4gJ0xvYWRpbmcuLi4nXG4qICAgaWYgKGlzRXJyb3IpIHJldHVybiAnRXJyb3IgbG9hZGluZyBwb3N0cydcbipcbiogICByZXR1cm4gKFxuKiAgICAgPHVsPlxuKiAgICAgICB7ZGF0YS5tYXAoKHBvc3QpID0+IChcbiogICAgICAgICA8bGkga2V5PXtwb3N0Py5pZH0+e3Bvc3Q/LnRpdGxlfTwvbGk+XG4qICAgICAgICkpfVxuKiAgICAgPC91bD5cbiogICApXG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIFR5cGluZyBgc2VsZWN0YCB2aWEge0BsaW5rIHF1ZXJ5T3B0aW9uc30uIE5vdGUgdGhhdCBzcHJlYWRpbmcgYSBgcXVlcnlPcHRpb25zYCByZXN1bHQgYW5kIG92ZXJyaWRpbmdcbiogYHNlbGVjdGAgaW5saW5lIHN0aWxsIGZhbGxzIGJhY2sgdG8gYHVua25vd25gIOKAlCB3cmFwIHRoZSBzcHJlYWQgaW4gYHF1ZXJ5T3B0aW9uc2AgYWdhaW4gc28gdGhlIG92ZXJyaWRlIGlzXG4qIHJlc29sdmVkIGJlZm9yZSBpdCByZWFjaGVzIGB1c2VRdWVyaWVzYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHF1ZXJ5T3B0aW9ucywgdXNlUXVlcmllcyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgcG9zdE9wdGlvbnMgPSAoaWQ6IG51bWJlcikgPT5cbiogICBxdWVyeU9wdGlvbnMoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdCcsIGlkXSxcbiogICAgIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdChpZCksXG4qICAgfSlcbipcbiogZnVuY3Rpb24gUG9zdFRpdGxlKHsgaWQgfTogeyBpZDogbnVtYmVyIH0pIHtcbiogICBjb25zdCBbeyBkYXRhOiBicm9rZW4gfV0gPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IFtcbiogICAgICAge1xuKiAgICAgICAgIC4uLnBvc3RPcHRpb25zKGlkKSxcbiogICAgICAgICAvLyDinYwgYGRhdGFgIGlzIGB1bmtub3duYCBoZXJlXG4qICAgICAgICAgc2VsZWN0OiAoZGF0YSkgPT4gZGF0YS50aXRsZSxcbiogICAgICAgfSxcbiogICAgIF0sXG4qICAgfSlcbipcbiogICBjb25zdCBbeyBkYXRhOiBmaXhlZCB9XSA9IHVzZVF1ZXJpZXMoe1xuKiAgICAgcXVlcmllczogW1xuKiAgICAgICBxdWVyeU9wdGlvbnMoe1xuKiAgICAgICAgIC4uLnBvc3RPcHRpb25zKGlkKSxcbiogICAgICAgICAvLyDinIUgYGRhdGFgIGlzIGBQb3N0YFxuKiAgICAgICAgIHNlbGVjdDogKGRhdGEpID0+IGRhdGEudGl0bGUsXG4qICAgICAgIH0pLFxuKiAgICAgXSxcbiogICB9KVxuKlxuKiAgIHJldHVybiA8aDE+e2ZpeGVkfTwvaDE+XG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlUXVlcmllcyh7IHF1ZXJpZXMsIC4uLm9wdGlvbnMgfSwgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBpc1Jlc3RvcmluZyA9IHVzZUlzUmVzdG9yaW5nKCk7XG5cdGNvbnN0IGVycm9yUmVzZXRCb3VuZGFyeSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KCk7XG5cdGNvbnN0IHN1YnNjcmliZWQgPSBvcHRpb25zLnN1YnNjcmliZWQgIT09IGZhbHNlO1xuXHRjb25zdCBkZWZhdWx0ZWRRdWVyaWVzID0gUmVhY3QudXNlTWVtbygoKSA9PiBxdWVyaWVzLm1hcCgob3B0cykgPT4ge1xuXHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRzKTtcblx0XHRkZWZhdWx0ZWRPcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9IGlzUmVzdG9yaW5nID8gXCJpc1Jlc3RvcmluZ1wiIDogc3Vic2NyaWJlZCA/IFwib3B0aW1pc3RpY1wiIDogdm9pZCAwO1xuXHRcdHJldHVybiBkZWZhdWx0ZWRPcHRpb25zO1xuXHR9KSwgW1xuXHRcdHF1ZXJpZXMsXG5cdFx0Y2xpZW50LFxuXHRcdGlzUmVzdG9yaW5nLFxuXHRcdHN1YnNjcmliZWRcblx0XSk7XG5cdGRlZmF1bHRlZFF1ZXJpZXMuZm9yRWFjaCgocXVlcnlPcHRpb25zKSA9PiB7XG5cdFx0ZW5zdXJlU3VzcGVuc2VUaW1lcnMocXVlcnlPcHRpb25zKTtcblx0XHRjb25zdCBxdWVyeSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KHF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2gpO1xuXHRcdGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkocXVlcnlPcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KTtcblx0fSk7XG5cdHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgUXVlcmllc09ic2VydmVyKGNsaWVudCwgZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucykpO1xuXHRjb25zdCBbb3B0aW1pc3RpY1Jlc3VsdCwgZ2V0Q29tYmluZWRSZXN1bHQsIHRyYWNrUmVzdWx0XSA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucy5jb21iaW5lKTtcblx0Y29uc3Qgc2hvdWxkU3Vic2NyaWJlID0gIWlzUmVzdG9yaW5nICYmIHN1YnNjcmliZWQ7XG5cdFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBzaG91bGRTdWJzY3JpYmUgPyBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSA6IG5vb3AsIFtvYnNlcnZlciwgc2hvdWxkU3Vic2NyaWJlXSksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvYnNlcnZlci5zZXRRdWVyaWVzKGRlZmF1bHRlZFF1ZXJpZXMsIG9wdGlvbnMpO1xuXHR9LCBbXG5cdFx0ZGVmYXVsdGVkUXVlcmllcyxcblx0XHRvcHRpb25zLFxuXHRcdG9ic2VydmVyXG5cdF0pO1xuXHRjb25zdCBzdXNwZW5zZVByb21pc2VzID0gb3B0aW1pc3RpY1Jlc3VsdC5zb21lKChyZXN1bHQsIGluZGV4KSA9PiBzaG91bGRTdXNwZW5kKGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdLCByZXN1bHQpKSA/IG9wdGltaXN0aWNSZXN1bHQuZmxhdE1hcCgocmVzdWx0LCBpbmRleCkgPT4ge1xuXHRcdGNvbnN0IG9wdHMgPSBkZWZhdWx0ZWRRdWVyaWVzW2luZGV4XTtcblx0XHRpZiAob3B0cyAmJiBzaG91bGRTdXNwZW5kKG9wdHMsIHJlc3VsdCkpIHtcblx0XHRcdGNvbnN0IHF1ZXJ5T2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihjbGllbnQsIG9wdHMpO1xuXHRcdFx0cmV0dXJuIGZldGNoT3B0aW1pc3RpYyhvcHRzLCBxdWVyeU9ic2VydmVyLCBlcnJvclJlc2V0Qm91bmRhcnkpO1xuXHRcdH1cblx0XHRyZXR1cm4gW107XG5cdH0pIDogW107XG5cdGlmIChzdXNwZW5zZVByb21pc2VzLmxlbmd0aCA+IDApIHRocm93IFByb21pc2UuYWxsKHN1c3BlbnNlUHJvbWlzZXMpO1xuXHRjb25zdCBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cgPSBvcHRpbWlzdGljUmVzdWx0LmZpbmQoKHJlc3VsdCwgaW5kZXgpID0+IHtcblx0XHRjb25zdCBxdWVyeSA9IGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdO1xuXHRcdHJldHVybiBxdWVyeSAmJiBnZXRIYXNFcnJvcih7XG5cdFx0XHRyZXN1bHQsXG5cdFx0XHRlcnJvclJlc2V0Qm91bmRhcnksXG5cdFx0XHR0aHJvd09uRXJyb3I6IHF1ZXJ5LnRocm93T25FcnJvcixcblx0XHRcdHF1ZXJ5OiBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChxdWVyeS5xdWVyeUhhc2gpLFxuXHRcdFx0c3VzcGVuc2U6IHF1ZXJ5LnN1c3BlbnNlXG5cdFx0fSk7XG5cdH0pO1xuXHRpZiAoZmlyc3RTaW5nbGVSZXN1bHRXaGljaFNob3VsZFRocm93KSB0aHJvdyBmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cuZXJyb3I7XG5cdHJldHVybiBnZXRDb21iaW5lZFJlc3VsdCh0cmFja1Jlc3VsdCgpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUXVlcmllcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyaWVzLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vb3AsIG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlQmFzZVF1ZXJ5LnRzXG5mdW5jdGlvbiB1c2VCYXNlUXVlcnkob3B0aW9ucywgT2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAodHlwZW9mIG9wdGlvbnMgIT09IFwib2JqZWN0XCIgfHwgQXJyYXkuaXNBcnJheShvcHRpb25zKSkgdGhyb3cgbmV3IEVycm9yKFwiQmFkIGFyZ3VtZW50IHR5cGUuIFN0YXJ0aW5nIHdpdGggdjUsIG9ubHkgdGhlIFxcXCJPYmplY3RcXFwiIGZvcm0gaXMgYWxsb3dlZCB3aGVuIGNhbGxpbmcgcXVlcnkgcmVsYXRlZCBmdW5jdGlvbnMuIFBsZWFzZSB1c2UgdGhlIGVycm9yIHN0YWNrIHRvIGZpbmQgdGhlIGN1bHByaXQgY2FsbC4gTW9yZSBpbmZvIGhlcmU6IGh0dHBzOi8vdGFuc3RhY2suY29tL3F1ZXJ5L2xhdGVzdC9kb2NzL3JlYWN0L2d1aWRlcy9taWdyYXRpbmctdG8tdjUjc3VwcG9ydHMtYS1zaW5nbGUtc2lnbmF0dXJlLW9uZS1vYmplY3RcIik7XG5cdH1cblx0Y29uc3QgaXNSZXN0b3JpbmcgPSB1c2VJc1Jlc3RvcmluZygpO1xuXHRjb25zdCBlcnJvclJlc2V0Qm91bmRhcnkgPSB1c2VRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSgpO1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSBjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0Y29uc3QgcXVlcnkgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlGbikgY29uc29sZS5lcnJvcihgWyR7ZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2h9XTogTm8gcXVlcnlGbiB3YXMgcGFzc2VkIGFzIGFuIG9wdGlvbiwgYW5kIG5vIGRlZmF1bHQgcXVlcnlGbiB3YXMgZm91bmQuIFRoZSBxdWVyeUZuIHBhcmFtZXRlciBpcyBvbmx5IG9wdGlvbmFsIHdoZW4gdXNpbmcgYSBkZWZhdWx0IHF1ZXJ5Rm4uIE1vcmUgaW5mbyBoZXJlOiBodHRwczovL3RhbnN0YWNrLmNvbS9xdWVyeS9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGVzL2RlZmF1bHQtcXVlcnktZnVuY3Rpb25gKTtcblx0fVxuXHRjb25zdCBzdWJzY3JpYmVkID0gb3B0aW9ucy5zdWJzY3JpYmVkICE9PSBmYWxzZTtcblx0ZGVmYXVsdGVkT3B0aW9ucy5fb3B0aW1pc3RpY1Jlc3VsdHMgPSBpc1Jlc3RvcmluZyA/IFwiaXNSZXN0b3JpbmdcIiA6IHN1YnNjcmliZWQgPyBcIm9wdGltaXN0aWNcIiA6IHZvaWQgMDtcblx0ZW5zdXJlU3VzcGVuc2VUaW1lcnMoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnkoZGVmYXVsdGVkT3B0aW9ucywgZXJyb3JSZXNldEJvdW5kYXJ5LCBxdWVyeSk7XG5cdHVzZUNsZWFyUmVzZXRFcnJvckJvdW5kYXJ5KGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgT2JzZXJ2ZXIoY2xpZW50LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdGNvbnN0IHNob3VsZFN1YnNjcmliZSA9ICFpc1Jlc3RvcmluZyAmJiBzdWJzY3JpYmVkO1xuXHRSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4ge1xuXHRcdGNvbnN0IHVuc3Vic2NyaWJlID0gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wO1xuXHRcdG9ic2VydmVyLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdHJldHVybiB1bnN1YnNjcmliZTtcblx0fSwgW29ic2VydmVyLCBzaG91bGRTdWJzY3JpYmVdKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkpO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdG9ic2VydmVyLnNldE9wdGlvbnMoZGVmYXVsdGVkT3B0aW9ucyk7XG5cdH0sIFtkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlcl0pO1xuXHRpZiAoc2hvdWxkU3VzcGVuZChkZWZhdWx0ZWRPcHRpb25zLCByZXN1bHQpKSB0aHJvdyBmZXRjaE9wdGltaXN0aWMoZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdGlmIChnZXRIYXNFcnJvcih7XG5cdFx0cmVzdWx0LFxuXHRcdGVycm9yUmVzZXRCb3VuZGFyeSxcblx0XHR0aHJvd09uRXJyb3I6IGRlZmF1bHRlZE9wdGlvbnMudGhyb3dPbkVycm9yLFxuXHRcdHF1ZXJ5LFxuXHRcdHN1c3BlbnNlOiBkZWZhdWx0ZWRPcHRpb25zLnN1c3BlbnNlXG5cdH0pKSB0aHJvdyByZXN1bHQuZXJyb3I7XG5cdHJldHVybiAhZGVmYXVsdGVkT3B0aW9ucy5ub3RpZnlPbkNoYW5nZVByb3BzID8gb2JzZXJ2ZXIudHJhY2tSZXN1bHQocmVzdWx0KSA6IHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlQmFzZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUJhc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VRdWVyeS50c1xuZnVuY3Rpb24gdXNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0cmV0dXJuIHVzZUJhc2VRdWVyeShvcHRpb25zLCBRdWVyeU9ic2VydmVyLCBxdWVyeUNsaWVudCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VTdXNwZW5zZVF1ZXJ5LnRzXG4vKipcbiogVGhlIG9wdGlvbnMgZm9yIGB1c2VTdXNwZW5zZVF1ZXJ5YCBhcmUgdGhlIHNhbWUgYXMgZm9yIGB1c2VRdWVyeWAsIGV4Y2VwdCBmb3IgYHRocm93T25FcnJvcmAsIGBlbmFibGVkYCwgYW5kXG4qIGBwbGFjZWhvbGRlckRhdGFgIOKAlCBhbmQgYHF1ZXJ5Rm5gIG1heSBub3QgYmUgYHNraXBUb2tlbmAsIHNpbmNlIFN1c3BlbnNlIGhvb2tzIGNhbid0IHJlbmRlciBhIFwiZGlzYWJsZWRcIiBzdGF0ZS5cbipcbiogQ2F2ZWF0OiBjYW5jZWxsYXRpb24gZG9lcyBub3Qgd29yay5cbipcbiogQHJlbWFya3MgTXVsdGlwbGUgYHVzZVN1c3BlbnNlUXVlcnlgIGNhbGxzIGluIHRoZSBzYW1lIGNvbXBvbmVudCBzdXNwZW5kIHNlcmlhbGx5LCBjYXVzaW5nIGEgcmVxdWVzdFxuKiB3YXRlcmZhbGwg4oCUIGVhY2ggb25lIGJsb2NrcyByZW5kZXJpbmcgdW50aWwgaXQgcmVzb2x2ZXMsIHNvIHRoZSBuZXh0IGRvZXNuJ3QgZXZlbiBzdGFydCBmZXRjaGluZyB1bnRpbCB0aGVuLlxuKiBVc2Uge0BsaW5rIHVzZVN1c3BlbnNlUXVlcmllc30gaW5zdGVhZCB3aGVuIHlvdSBoYXZlIG1vcmUgdGhhbiBvbmUgc3VzcGVuc2VmdWwgcXVlcnkgaW4gYSBjb21wb25lbnQsIHNvIHRoZXlcbiogZmV0Y2ggaW4gcGFyYWxsZWwuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VTdXNwZW5zZVF1ZXJ5T3B0aW9uc30gdG8gdXNlIOKAlCB0aGUgc2FtZSBvcHRpb25zIGFzIGB1c2VRdWVyeWAsIG1pbnVzIHRoZSBvbmVzIGxpc3RlZCBhYm92ZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBvYmplY3QgYXMgYHVzZVF1ZXJ5YCwgZXhjZXB0IHRoYXQgYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCwgYGlzUGxhY2Vob2xkZXJEYXRhYFxuKiBpcyBtaXNzaW5nLCBhbmQgYHN0YXR1c2AgaXMgZWl0aGVyIGBzdWNjZXNzYCBvciBgZXJyb3JgICh3aXRoIHRoZSBkZXJpdmVkIGZsYWdzIHNldCBhY2NvcmRpbmdseSkuXG4qXG4qIEBleGFtcGxlXG4qIFRoZSBxdWVyeSBlcnJvciBpcyB0aHJvd24gaWYgdGhlIGZldGNoIGZhaWxzIGFuZCBubyBjYWNoZWQgZGF0YSBleGlzdHMgeWV0LCBzbyBhbiBlcnJvciBib3VuZGFyeSBpc1xuKiByZXF1aXJlZCBhcm91bmQgYDxTdXNwZW5zZT5gLiBBIGZhaWxlZCBiYWNrZ3JvdW5kIHJlZmV0Y2ggaW5zdGVhZCBjb250aW51ZXMgdG8gcmVuZGVyIHRoZSBjYWNoZWQgZGF0YS5cbiogVXNlIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeX0gdG8gbGV0IHRoZSB1c2VyIHJldHJ5IGFmdGVyIHN1Y2ggYW4gZXJyb3I6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0cygpIHtcbiogICAvLyBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkIGhlcmUg4oCUIG5vIGBpc1BlbmRpbmdgIGNoZWNrIG5lZWRlZC5cbiogICBjb25zdCB7IGRhdGEsIGlzRmV0Y2hpbmcgfSA9IHVzZVN1c3BlbnNlUXVlcnkoe1xuKiAgICAgcXVlcnlLZXk6IFsncG9zdHMnXSxcbiogICAgIHF1ZXJ5Rm46IGZldGNoUG9zdHMsXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGRpdj5cbiogICAgICAgPGgxPlBvc3RzIHtpc0ZldGNoaW5nID8gJyhyZWZyZXNoaW5nLi4uKScgOiBudWxsfTwvaDE+XG4qICAgICAgIDx1bD5cbiogICAgICAgICB7ZGF0YS5tYXAoKHBvc3QpID0+IChcbiogICAgICAgICAgIDxsaSBrZXk9e3Bvc3QuaWR9Pntwb3N0LnRpdGxlfTwvbGk+XG4qICAgICAgICAgKSl9XG4qICAgICAgIDwvdWw+XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwb3N0cy4uLjwvaDE+fT5cbiogICAgICAgICAgICAgPFBvc3RzIC8+XG4qICAgICAgICAgICA8L1N1c3BlbnNlPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmIChvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgY29uc29sZS5lcnJvcihcInNraXBUb2tlbiBpcyBub3QgYWxsb3dlZCBmb3IgdXNlU3VzcGVuc2VRdWVyeVwiKTtcblx0fVxuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGVuYWJsZWQ6IHRydWUsXG5cdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0dGhyb3dPbkVycm9yOiBkZWZhdWx0VGhyb3dPbkVycm9yLFxuXHRcdHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG5cdH0sIFF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU3VzcGVuc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IEluZmluaXRlUXVlcnlPYnNlcnZlciwgc2tpcFRva2VuIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS50c1xuLyoqXG4qIFRoZSBvcHRpb25zIGZvciBgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5YCBhcmUgdGhlIHNhbWUgYXMgZm9yIGB1c2VJbmZpbml0ZVF1ZXJ5YCwgZXhjZXB0IGZvciBgdGhyb3dPbkVycm9yYCxcbiogYGVuYWJsZWRgLCBhbmQgYHBsYWNlaG9sZGVyRGF0YWAuXG4qXG4qIENhdmVhdDogY2FuY2VsbGF0aW9uIGRvZXMgbm90IHdvcmsuXG4qXG4qIEByZW1hcmtzIE11bHRpcGxlIHN1c3BlbnNlZnVsIHF1ZXJ5IGNhbGxzIGluIHRoZSBzYW1lIGNvbXBvbmVudCBzdXNwZW5kIHNlcmlhbGx5LCBjYXVzaW5nIGEgcmVxdWVzdFxuKiB3YXRlcmZhbGwg4oCUIGVhY2ggb25lIGJsb2NrcyByZW5kZXJpbmcgdW50aWwgaXQgcmVzb2x2ZXMsIHNvIHRoZSBuZXh0IGRvZXNuJ3QgZXZlbiBzdGFydCBmZXRjaGluZyB1bnRpbFxuKiB0aGVuLiBUaGVyZSdzIG5vIHdheSB0byBwYXJhbGxlbGl6ZSBtdWx0aXBsZSBpbmZpbml0ZSBxdWVyaWVzIHVuZGVyIFN1c3BlbnNlLiBBbHNvIGtlZXAgaW4gbWluZCB0aGF0XG4qIGltcGVyYXRpdmUgZmV0Y2ggY2FsbHMsIHN1Y2ggYXMgYGZldGNoTmV4dFBhZ2VgLCBtYXkgaW50ZXJmZXJlIHdpdGggdGhlIGRlZmF1bHQgcmVmZXRjaCBiZWhhdmlvcixcbiogcmVzdWx0aW5nIGluIG91dGRhdGVkIGRhdGEuIE1ha2Ugc3VyZSB0byBjYWxsIHRoZXNlIGZ1bmN0aW9ucyBvbmx5IGluIHJlc3BvbnNlIHRvIHVzZXIgYWN0aW9ucywgb3IgYWRkXG4qIGNvbmRpdGlvbnMgbGlrZSBgaGFzTmV4dFBhZ2UgJiYgIWlzRmV0Y2hpbmdgLlxuKiBAc2VlIHtAbGluayB1c2VJbmZpbml0ZVF1ZXJ5fSBmb3IgdGhlIG5vbi1TdXNwZW5zZSB2ZXJzaW9uIG9mIHRoaXMgaG9vay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeU9wdGlvbnN9IHRvIHVzZSDigJQgdGhlIHNhbWUgb3B0aW9ucyBhcyBgdXNlSW5maW5pdGVRdWVyeWAsIG1pbnVzIHRoZSBvbmVzIGxpc3RlZCBhYm92ZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBvYmplY3QgYXMgYHVzZUluZmluaXRlUXVlcnlgLCBleGNlcHQgdGhhdCBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkLFxuKiBgaXNQbGFjZWhvbGRlckRhdGFgIGlzIG1pc3NpbmcsIGFuZCBgc3RhdHVzYCBpcyBlaXRoZXIgYHN1Y2Nlc3NgIG9yIGBlcnJvcmAgKHdpdGggdGhlIGRlcml2ZWQgZmxhZ3Mgc2V0XG4qIGFjY29yZGluZ2x5KS5cbipcbiogQGV4YW1wbGVcbiogVGhlIHF1ZXJ5IGVycm9yIGlzIHRocm93biBpZiBhIGZldGNoIGZhaWxzIGFuZCBubyBjYWNoZWQgZGF0YSBleGlzdHMgeWV0LCBzbyBhbiBlcnJvciBib3VuZGFyeSBpc1xuKiByZXF1aXJlZCBhcm91bmQgYDxTdXNwZW5zZT5gLiBBIGZhaWxlZCBiYWNrZ3JvdW5kIHJlZmV0Y2ggaW5zdGVhZCBjb250aW51ZXMgdG8gcmVuZGVyIHRoZSBjYWNoZWQgZGF0YS5cbiogVXNlIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeX0gdG8gbGV0IHRoZSB1c2VyIHJldHJ5IGFmdGVyIHN1Y2ggYW4gZXJyb3I6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBFcnJvckJvdW5kYXJ5IH0gZnJvbSAncmVhY3QtZXJyb3ItYm91bmRhcnknXG4qIGltcG9ydCB7XG4qICAgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksXG4qICAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LFxuKiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUHJvamVjdHMoKSB7XG4qICAgLy8gYGRhdGFgIGlzIGd1YXJhbnRlZWQgdG8gYmUgZGVmaW5lZCBoZXJlIOKAlCBubyBgaXNQZW5kaW5nYCBjaGVjayBuZWVkZWQuXG4qICAgY29uc3QgeyBkYXRhLCBmZXRjaE5leHRQYWdlLCBoYXNOZXh0UGFnZSwgaXNGZXRjaGluZywgaXNGZXRjaGluZ05leHRQYWdlIH0gPVxuKiAgICAgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5KHtcbiogICAgICAgcXVlcnlLZXk6IFsncHJvamVjdHMnXSxcbiogICAgICAgcXVlcnlGbjogKHsgcGFnZVBhcmFtIH0pID0+IGZldGNoUHJvamVjdHMocGFnZVBhcmFtKSxcbiogICAgICAgaW5pdGlhbFBhZ2VQYXJhbTogMCxcbiogICAgICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0SWQsXG4qICAgICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICA8dWw+XG4qICAgICAgICAge2RhdGEucGFnZXMubWFwKChwYWdlKSA9PlxuKiAgICAgICAgICAgcGFnZS5wcm9qZWN0cy5tYXAoKHByb2plY3QpID0+IDxsaSBrZXk9e3Byb2plY3QuaWR9Pntwcm9qZWN0Lm5hbWV9PC9saT4pLFxuKiAgICAgICAgICl9XG4qICAgICAgIDwvdWw+XG4qICAgICAgIDxidXR0b25cbiogICAgICAgICBvbkNsaWNrPXsoKSA9PiBmZXRjaE5leHRQYWdlKCl9XG4qICAgICAgICAgZGlzYWJsZWQ9eyFoYXNOZXh0UGFnZSB8fCBpc0ZldGNoaW5nfVxuKiAgICAgICA+XG4qICAgICAgICAge2lzRmV0Y2hpbmdOZXh0UGFnZVxuKiAgICAgICAgICAgPyAnTG9hZGluZyBtb3JlLi4uJ1xuKiAgICAgICAgICAgOiBoYXNOZXh0UGFnZVxuKiAgICAgICAgICAgICA/ICdMb2FkIE1vcmUnXG4qICAgICAgICAgICAgIDogJ05vdGhpbmcgbW9yZSB0byBsb2FkJ31cbiogICAgICAgPC9idXR0b24+XG4qICAgICA8L2Rpdj5cbiogICApXG4qIH1cbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIHJldHVybiAoXG4qICAgICA8UXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgICAgIHsoeyByZXNldCB9KSA9PiAoXG4qICAgICAgICAgPEVycm9yQm91bmRhcnlcbiogICAgICAgICAgIG9uUmVzZXQ9e3Jlc2V0fVxuKiAgICAgICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgICAgIDxkaXY+XG4qICAgICAgICAgICAgICAgVGhlcmUgd2FzIGFuIGVycm9yIVxuKiAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgICAgICA8L2Rpdj5cbiogICAgICAgICAgICl9XG4qICAgICAgICAgPlxuKiAgICAgICAgICAgPFN1c3BlbnNlIGZhbGxiYWNrPXs8aDE+TG9hZGluZyBwcm9qZWN0cy4uLjwvaDE+fT5cbiogICAgICAgICAgICAgPFByb2plY3RzIC8+XG4qICAgICAgICAgICA8L1N1c3BlbnNlPlxuKiAgICAgICAgIDwvRXJyb3JCb3VuZGFyeT5cbiogICAgICAgKX1cbiogICAgIDwvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlcIik7XG5cdH1cblx0cmV0dXJuIHVzZUJhc2VRdWVyeSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRlbmFibGVkOiB0cnVlLFxuXHRcdHN1c3BlbnNlOiB0cnVlLFxuXHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRwbGFjZWhvbGRlckRhdGE6IHZvaWQgMFxuXHR9LCBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gXCIuL3VzZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VTdXNwZW5zZVF1ZXJpZXMudHNcbmZ1bmN0aW9uIHVzZVN1c3BlbnNlUXVlcmllcyhvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlUXVlcmllcyh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRxdWVyaWVzOiBvcHRpb25zLnF1ZXJpZXMubWFwKChxdWVyeSkgPT4ge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAocXVlcnkucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZVF1ZXJpZXNcIik7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHQuLi5xdWVyeSxcblx0XHRcdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0XHRcdHRocm93T25FcnJvcjogZGVmYXVsdFRocm93T25FcnJvcixcblx0XHRcdFx0ZW5hYmxlZDogdHJ1ZSxcblx0XHRcdFx0cGxhY2Vob2xkZXJEYXRhOiB2b2lkIDBcblx0XHRcdH07XG5cdFx0fSlcblx0fSwgcXVlcnlDbGllbnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VRdWVyaWVzLmpzLm1hcCIsImltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VQcmVmZXRjaFF1ZXJ5LnRzeFxuLyoqXG4qIGB1c2VQcmVmZXRjaFF1ZXJ5YCBkb2VzIG5vdCByZXR1cm4gYW55dGhpbmcsIGl0IHNob3VsZCBiZSB1c2VkIGp1c3QgdG8gZmlyZSBhIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZVxuKiBhIHN1c3BlbnNlIGJvdW5kYXJ5IHRoYXQgd3JhcHMgYSBjb21wb25lbnQgdGhhdCB1c2VzIGB1c2VTdXNwZW5zZVF1ZXJ5YC4gWW91IGNhbiBwYXNzIGV2ZXJ5dGhpbmcgdG9cbiogYHVzZVByZWZldGNoUXVlcnlgIHRoYXQgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5xdWVyeWAsIHRob3VnaCBgcXVlcnlLZXlgIGlzIGFsd2F5cyByZXF1aXJlZCwgYW5kXG4qIGBxdWVyeUZuYCBpcyByZXF1aXJlZCB1bmxlc3MgYSBkZWZhdWx0IHF1ZXJ5IGZ1bmN0aW9uIGhhcyBiZWVuIGRlZmluZWQuXG4qXG4qIFRoZSBwcmVmZXRjaCBpcyBza2lwcGVkIGlmIHRoZSBxdWVyeSBhbHJlYWR5IGhhcyBhbnkgY2FjaGVkIHN0YXRlIOKAlCBpbmNsdWRpbmcgYSBgcGVuZGluZ2AvYGVycm9yYCBzdGF0ZSBsZWZ0XG4qIG92ZXIgZnJvbSBhIHByZXZpb3VzIGF0dGVtcHQg4oCUIHNvIGNhbGxpbmcgdGhpcyBvbiBldmVyeSByZW5kZXIgaXMgY2hlYXAgYW5kIHdvbid0IHJlZmV0Y2ggZGF0YSB0aGF0J3NcbiogYWxyZWFkeSB0aGVyZSBvciBhbHJlYWR5IGluIGZsaWdodC5cbipcbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVByZWZldGNoUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5xdWVyeWAuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgYHZvaWRgIOKAlCBub3RoaW5nIGlzIHJldHVybmVkLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCdcbiogaW1wb3J0IHsgdXNlUHJlZmV0Y2hRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIC8vIEZpcmUgdGhlIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZSB0aGUgc3VzcGVuc2UgYm91bmRhcnkgYmVsb3cuXG4qICAgdXNlUHJlZmV0Y2hRdWVyeSh7XG4qICAgICBxdWVyeUtleTogWydwb3N0cyddLFxuKiAgICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxoMT5Mb2FkaW5nIHBvc3RzLi4uPC9oMT59PlxuKiAgICAgICA8UG9zdHMgLz5cbiogICAgIDwvU3VzcGVuc2U+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVByZWZldGNoUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRpZiAoIWNsaWVudC5nZXRRdWVyeVN0YXRlKG9wdGlvbnMucXVlcnlLZXkpKSBjbGllbnQucXVlcnkob3B0aW9ucykuY2F0Y2gobm9vcCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUHJlZmV0Y2hRdWVyeS5qcy5tYXAiLCJpbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IG5vb3AgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LnRzeFxuLyoqXG4qIGB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnlgIGRvZXMgbm90IHJldHVybiBhbnl0aGluZywgaXQgc2hvdWxkIGJlIHVzZWQganVzdCB0byBmaXJlIGEgcHJlZmV0Y2ggZHVyaW5nIHJlbmRlcixcbiogYmVmb3JlIGEgc3VzcGVuc2UgYm91bmRhcnkgdGhhdCB3cmFwcyBhIGNvbXBvbmVudCB0aGF0IHVzZXMgYHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeWAuIFlvdSBjYW4gcGFzc1xuKiBldmVyeXRoaW5nIHRvIGB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnlgIHRoYXQgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YCwgdGhvdWdoXG4qIGBxdWVyeUtleWAsIGBpbml0aWFsUGFnZVBhcmFtYCwgYW5kIGBnZXROZXh0UGFnZVBhcmFtYCBhcmUgYWx3YXlzIHJlcXVpcmVkLCBhbmQgYHF1ZXJ5Rm5gIGlzIHJlcXVpcmVkIHVubGVzc1xuKiBhIGRlZmF1bHQgcXVlcnkgZnVuY3Rpb24gaGFzIGJlZW4gZGVmaW5lZC5cbipcbiogYGdldE5leHRQYWdlUGFyYW1gIHJlY2VpdmVzIGJvdGggdGhlIGxhc3QgcGFnZSBvZiB0aGUgaW5maW5pdGUgbGlzdCBvZiBkYXRhIGFuZCB0aGUgZnVsbCBhcnJheSBvZiBhbGwgcGFnZXMsXG4qIGFzIHdlbGwgYXMgcGFnZVBhcmFtIGluZm9ybWF0aW9uLCBhbmQgc2hvdWxkIHJldHVybiBhIHNpbmdsZSB2YXJpYWJsZSB0aGF0IHdpbGwgYmUgcGFzc2VkIHRvIHlvdXIgcXVlcnlcbiogZnVuY3Rpb24gYXMgYGNvbnRleHQucGFnZVBhcmFtYC4gUmV0dXJuIGB1bmRlZmluZWRgIG9yIGBudWxsYCB0byBpbmRpY2F0ZSB0aGVyZSBpcyBubyBuZXh0IHBhZ2UgYXZhaWxhYmxlLlxuKlxuKiBUaGUgcHJlZmV0Y2ggaXMgc2tpcHBlZCBpZiB0aGUgcXVlcnkgYWxyZWFkeSBoYXMgYW55IGNhY2hlZCBzdGF0ZSDigJQgaW5jbHVkaW5nIGEgYHBlbmRpbmdgL2BlcnJvcmAgc3RhdGUgbGVmdFxuKiBvdmVyIGZyb20gYSBwcmV2aW91cyBhdHRlbXB0IOKAlCBzbyBjYWxsaW5nIHRoaXMgb24gZXZlcnkgcmVuZGVyIGlzIGNoZWFwIGFuZCB3b24ndCByZWZldGNoIGRhdGEgdGhhdCdzXG4qIGFscmVhZHkgdGhlcmUgb3IgYWxyZWFkeSBpbiBmbGlnaHQuXG4qXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VQcmVmZXRjaEluZmluaXRlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YC5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBgdm9pZGAg4oCUIG5vdGhpbmcgaXMgcmV0dXJuZWQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBTdXNwZW5zZSB9IGZyb20gJ3JlYWN0J1xuKiBpbXBvcnQgeyBpbmZpbml0ZVF1ZXJ5T3B0aW9ucywgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBjb25zdCBwcm9qZWN0c09wdGlvbnMgPSBpbmZpbml0ZVF1ZXJ5T3B0aW9ucyh7XG4qICAgcXVlcnlLZXk6IFsncHJvamVjdHMnXSxcbiogICBxdWVyeUZuOiAoeyBwYWdlUGFyYW0gfSkgPT4gZmV0Y2hQcm9qZWN0cyhwYWdlUGFyYW0pLFxuKiAgIGluaXRpYWxQYWdlUGFyYW06IDAsXG4qICAgZ2V0TmV4dFBhZ2VQYXJhbTogKGxhc3RQYWdlKSA9PiBsYXN0UGFnZS5uZXh0SWQsXG4qIH0pXG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICAvLyBGaXJlIHRoZSBwcmVmZXRjaCBkdXJpbmcgcmVuZGVyLCBiZWZvcmUgdGhlIHN1c3BlbnNlIGJvdW5kYXJ5IGJlbG93LlxuKiAgIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeShwcm9qZWN0c09wdGlvbnMpXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxTdXNwZW5zZSBmYWxsYmFjaz17PGgxPkxvYWRpbmcgcHJvamVjdHMuLi48L2gxPn0+XG4qICAgICAgIDxQcm9qZWN0cyAvPlxuKiAgICAgPC9TdXNwZW5zZT5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0aWYgKCFjbGllbnQuZ2V0UXVlcnlTdGF0ZShvcHRpb25zLnF1ZXJ5S2V5KSkgY2xpZW50LmluZmluaXRlUXVlcnkob3B0aW9ucykuY2F0Y2gobm9vcCk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVByZWZldGNoSW5maW5pdGVRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9xdWVyeU9wdGlvbnMudHNcbmZ1bmN0aW9uIHF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBxdWVyeU9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlPcHRpb25zLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvaW5maW5pdGVRdWVyeU9wdGlvbnMudHNcbmZ1bmN0aW9uIGluZmluaXRlUXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcblx0cmV0dXJuIG9wdGlvbnM7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGluZmluaXRlUXVlcnlPcHRpb25zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZmluaXRlUXVlcnlPcHRpb25zLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlSXNGZXRjaGluZy50c1xuLyoqXG4qIFRoZSBgdXNlSXNGZXRjaGluZ2AgaG9vayByZXR1cm5zIHRoZSBgbnVtYmVyYCBvZiB0aGUgcXVlcmllcyB0aGF0IHlvdXIgYXBwbGljYXRpb24gaXMgbG9hZGluZyBvciBmZXRjaGluZyBpblxuKiB0aGUgYmFja2dyb3VuZCAodXNlZnVsIGZvciBhcHAtd2lkZSBsb2FkaW5nIGluZGljYXRvcnMpLlxuKlxuKiBAcGFyYW0gZmlsdGVycyAtIFRoZSB7QGxpbmsgUXVlcnlGaWx0ZXJzfSB0byBuYXJyb3cgZG93biB0aGUgbWF0Y2hlZCBxdWVyaWVzLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIFdpbGwgYmUgdGhlIGBudW1iZXJgIG9mIHRoZSBxdWVyaWVzIHRoYXQgeW91ciBhcHBsaWNhdGlvbiBpcyBjdXJyZW50bHkgbG9hZGluZyBvciBmZXRjaGluZyBpbiB0aGVcbiogYmFja2dyb3VuZC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZUlzRmV0Y2hpbmcgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBvc3RzRmV0Y2hpbmdJbmRpY2F0b3IoKSB7XG4qICAgLy8gSG93IG1hbnkgcXVlcmllcyBtYXRjaGluZyB0aGUgcG9zdHMgcHJlZml4IGFyZSBmZXRjaGluZz9cbiogICBjb25zdCBpc0ZldGNoaW5nUG9zdHMgPSB1c2VJc0ZldGNoaW5nKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuKlxuKiAgIHJldHVybiBpc0ZldGNoaW5nUG9zdHMgPyA8c3Bhbj5SZWZyZXNoaW5nIHBvc3RzLi4uPC9zcGFuPiA6IG51bGxcbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogQSBnbG9iYWwgbG9hZGluZyBpbmRpY2F0b3IgZm9yIGFueSBxdWVyeSBmZXRjaGluZyBpbiB0aGUgYmFja2dyb3VuZCwgbm90IGp1c3QgdGhlIG9uZXMgb24gc2NyZWVuOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlSXNGZXRjaGluZyB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gR2xvYmFsTG9hZGluZ0luZGljYXRvcigpIHtcbiogICBjb25zdCBpc0ZldGNoaW5nID0gdXNlSXNGZXRjaGluZygpXG4qXG4qICAgcmV0dXJuIGlzRmV0Y2hpbmcgPyAoXG4qICAgICA8ZGl2PlF1ZXJpZXMgYXJlIGZldGNoaW5nIGluIHRoZSBiYWNrZ3JvdW5kLi4uPC9kaXY+XG4qICAgKSA6IG51bGxcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VJc0ZldGNoaW5nKGZpbHRlcnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3QgcXVlcnlDYWNoZSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG5cdHJldHVybiBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4gcXVlcnlDYWNoZS5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSwgW3F1ZXJ5Q2FjaGVdKSwgKCkgPT4gY2xpZW50LmlzRmV0Y2hpbmcoZmlsdGVycyksICgpID0+IGNsaWVudC5pc0ZldGNoaW5nKGZpbHRlcnMpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlSXNGZXRjaGluZyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VJc0ZldGNoaW5nLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIsIHJlcGxhY2VFcXVhbERlZXAgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTXV0YXRpb25TdGF0ZS50c1xuLyoqXG4qIFRoZSBgdXNlSXNNdXRhdGluZ2AgaG9vayByZXR1cm5zIHRoZSBgbnVtYmVyYCBvZiBtdXRhdGlvbnMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGN1cnJlbnRseSBoYXMgYHBlbmRpbmdgXG4qICh1c2VmdWwgZm9yIGFwcC13aWRlIGxvYWRpbmcgaW5kaWNhdG9ycykuXG4qXG4qIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIHtAbGluayBNdXRhdGlvbkZpbHRlcnN9IHRvIG5hcnJvdyBkb3duIHRoZSBtYXRjaGVkIG11dGF0aW9ucy5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBXaWxsIGJlIHRoZSBgbnVtYmVyYCBvZiB0aGUgbXV0YXRpb25zIHRoYXQgeW91ciBhcHBsaWNhdGlvbiBjdXJyZW50bHkgaGFzIGBwZW5kaW5nYC5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZUlzTXV0YXRpbmcgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBvc3RzTXV0YXRpbmdJbmRpY2F0b3IoKSB7XG4qICAgLy8gSG93IG1hbnkgbXV0YXRpb25zIG1hdGNoaW5nIHRoZSBwb3N0cyBwcmVmaXggYXJlIGluIHByb2dyZXNzP1xuKiAgIGNvbnN0IGlzTXV0YXRpbmdQb3N0cyA9IHVzZUlzTXV0YXRpbmcoeyBtdXRhdGlvbktleTogWydwb3N0cyddIH0pXG4qXG4qICAgcmV0dXJuIGlzTXV0YXRpbmdQb3N0cyA/IDxzcGFuPlNhdmluZyBwb3N0cy4uLjwvc3Bhbj4gOiBudWxsXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlSXNNdXRhdGluZyhmaWx0ZXJzLCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdHJldHVybiB1c2VNdXRhdGlvblN0YXRlKHsgZmlsdGVyczoge1xuXHRcdC4uLmZpbHRlcnMsXG5cdFx0c3RhdHVzOiBcInBlbmRpbmdcIlxuXHR9IH0sIGNsaWVudCkubGVuZ3RoO1xufVxuZnVuY3Rpb24gZ2V0UmVzdWx0KG11dGF0aW9uQ2FjaGUsIG9wdGlvbnMpIHtcblx0cmV0dXJuIG11dGF0aW9uQ2FjaGUuZmluZEFsbChvcHRpb25zLmZpbHRlcnMpLm1hcCgobXV0YXRpb24pID0+IG9wdGlvbnMuc2VsZWN0ID8gb3B0aW9ucy5zZWxlY3QobXV0YXRpb24pIDogbXV0YXRpb24uc3RhdGUpO1xufVxuLyoqXG4qIGB1c2VNdXRhdGlvblN0YXRlYCBpcyBhIGhvb2sgdGhhdCBnaXZlcyB5b3UgYWNjZXNzIHRvIGFsbCBtdXRhdGlvbnMgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYC4gWW91IGNhbiBwYXNzXG4qIGBmaWx0ZXJzYCAoe0BsaW5rIE11dGF0aW9uRmlsdGVyc30pIHRvIG5hcnJvdyBkb3duIHlvdXIgbXV0YXRpb25zLCBhbmQgYHNlbGVjdGAgdG8gdHJhbnNmb3JtIHRoZSBtdXRhdGlvblxuKiBzdGF0ZS5cbipcbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgYGZpbHRlcnNgIHRvIG5hcnJvdyBkb3duIG1hdGNoZWQgbXV0YXRpb25zLCBhbmQgYW4gb3B0aW9uYWwgYHNlbGVjdGAgdG8gdHJhbnNmb3JtIHRoZVxuKiBtdXRhdGlvbiBzdGF0ZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBXaWxsIGJlIGFuIEFycmF5IG9mIHdoYXRldmVyIGBzZWxlY3RgIHJldHVybnMgZm9yIGVhY2ggbWF0Y2hpbmcgbXV0YXRpb24uXG4qXG4qIEBleGFtcGxlXG4qIEdldCBhbGwgdmFyaWFibGVzIG9mIGFsbCBydW5uaW5nIG11dGF0aW9uczpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBlbmRpbmdQb3N0cygpIHtcbiogICBjb25zdCBwZW5kaW5nVmFyaWFibGVzID0gdXNlTXV0YXRpb25TdGF0ZSh7XG4qICAgICBmaWx0ZXJzOiB7IHN0YXR1czogJ3BlbmRpbmcnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUudmFyaWFibGVzLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIDw+e3BlbmRpbmdWYXJpYWJsZXMubGVuZ3RofSBwb3N0cyBzYXZpbmcuLi48Lz5cbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogR2V0IGFsbCBkYXRhIGZvciBzcGVjaWZpYyBtdXRhdGlvbnMgdmlhIHRoZSBgbXV0YXRpb25LZXlgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGNvbnN0IG11dGF0aW9uS2V5ID0gWydwb3N0cyddXG4qXG4qIGZ1bmN0aW9uIFBvc3RzKCkge1xuKiAgIC8vIFNvbWUgbXV0YXRpb24gdGhhdCB3ZSB3YW50IHRvIGdldCB0aGUgc3RhdGUgZm9yXG4qICAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbktleSxcbiogICAgIG11dGF0aW9uRm46IGNyZWF0ZVBvc3RzLFxuKiAgIH0pXG4qXG4qICAgY29uc3Qgc2F2ZWRQb3N0cyA9IHVzZU11dGF0aW9uU3RhdGUoe1xuKiAgICAgLy8gdGhpcyBtdXRhdGlvbiBrZXkgbmVlZHMgdG8gbWF0Y2ggdGhlIG11dGF0aW9uIGtleSBvZiB0aGUgZ2l2ZW4gbXV0YXRpb24gKHNlZSBhYm92ZSlcbiogICAgIGZpbHRlcnM6IHsgbXV0YXRpb25LZXksIHN0YXR1czogJ3N1Y2Nlc3MnIH0sXG4qICAgICBzZWxlY3Q6IChtdXRhdGlvbikgPT4gbXV0YXRpb24uc3RhdGUuZGF0YSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG11dGF0aW9uLm11dGF0ZShbJ05ldyBQb3N0J10pfT5cbiogICAgICAgQ3JlYXRlIHBvc3QgKHtzYXZlZFBvc3RzLmxlbmd0aH0gc2F2ZWQgc28gZmFyKVxuKiAgICAgPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKlxuKiBAZXhhbXBsZVxuKiBBY2Nlc3MgdGhlIGxhdGVzdCBzdWNjZXNzZnVsIG11dGF0aW9uIGRhdGEgdmlhIHRoZSBgbXV0YXRpb25LZXlgLiBFYWNoIGludm9jYXRpb24gb2YgYG11dGF0ZWAgYWRkcyBhIG5ld1xuKiBlbnRyeSB0byB0aGUgbXV0YXRpb24gY2FjaGUgZm9yIGBnY1RpbWVgIG1pbGxpc2Vjb25kcyDigJQgd2l0aCB0aGUgYHN0YXR1czogJ3N1Y2Nlc3MnYCBmaWx0ZXIgYmVsb3csIGNoZWNrIHRoZVxuKiBsYXN0IGl0ZW0gdGhhdCBgdXNlTXV0YXRpb25TdGF0ZWAgcmV0dXJucyB0byBnZXQgdGhlIGxhdGVzdCBzdWNjZXNzZnVsIGludm9jYXRpb246XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvblN0YXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBMYXRlc3RQb3N0KCkge1xuKiAgIGNvbnN0IHNhdmVkUG9zdHMgPSB1c2VNdXRhdGlvblN0YXRlKHtcbiogICAgIGZpbHRlcnM6IHsgbXV0YXRpb25LZXk6IFsncG9zdHMnXSwgc3RhdHVzOiAnc3VjY2VzcycgfSxcbiogICAgIHNlbGVjdDogKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5zdGF0ZS5kYXRhLFxuKiAgIH0pXG4qXG4qICAgY29uc3QgbGF0ZXN0U2F2ZWRQb3N0ID0gc2F2ZWRQb3N0c1tzYXZlZFBvc3RzLmxlbmd0aCAtIDFdXG4qXG4qICAgcmV0dXJuIDw+e2xhdGVzdFNhdmVkUG9zdCA/ICdTYXZlZCcgOiAnTm90aGluZyBzYXZlZCB5ZXQnfTwvPlxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZU11dGF0aW9uU3RhdGUob3B0aW9ucyA9IHt9LCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBtdXRhdGlvbkNhY2hlID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpLmdldE11dGF0aW9uQ2FjaGUoKTtcblx0Y29uc3Qgb3B0aW9uc1JlZiA9IFJlYWN0LnVzZVJlZihvcHRpb25zKTtcblx0Y29uc3QgcmVzdWx0UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuXHRpZiAocmVzdWx0UmVmLmN1cnJlbnQgPT09IG51bGwpIHJlc3VsdFJlZi5jdXJyZW50ID0gZ2V0UmVzdWx0KG11dGF0aW9uQ2FjaGUsIG9wdGlvbnMpO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdG9wdGlvbnNSZWYuY3VycmVudCA9IG9wdGlvbnM7XG5cdH0pO1xuXHRyZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IG11dGF0aW9uQ2FjaGUuc3Vic2NyaWJlKCgpID0+IHtcblx0XHRjb25zdCBuZXh0UmVzdWx0ID0gcmVwbGFjZUVxdWFsRGVlcChyZXN1bHRSZWYuY3VycmVudCwgZ2V0UmVzdWx0KG11dGF0aW9uQ2FjaGUsIG9wdGlvbnNSZWYuY3VycmVudCkpO1xuXHRcdGlmIChyZXN1bHRSZWYuY3VycmVudCAhPT0gbmV4dFJlc3VsdCkge1xuXHRcdFx0cmVzdWx0UmVmLmN1cnJlbnQgPSBuZXh0UmVzdWx0O1xuXHRcdFx0bm90aWZ5TWFuYWdlci5zY2hlZHVsZShvblN0b3JlQ2hhbmdlKTtcblx0XHR9XG5cdH0pLCBbbXV0YXRpb25DYWNoZV0pLCAoKSA9PiByZXN1bHRSZWYuY3VycmVudCwgKCkgPT4gcmVzdWx0UmVmLmN1cnJlbnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VJc011dGF0aW5nLCB1c2VNdXRhdGlvblN0YXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU11dGF0aW9uU3RhdGUuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTXV0YXRpb25PYnNlcnZlciwgbm9vcCwgbm90aWZ5TWFuYWdlciwgc2hvdWxkVGhyb3dFcnJvciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VNdXRhdGlvbi50c1xuLyoqXG4qIFVubGlrZSBxdWVyaWVzLCBtdXRhdGlvbnMgYXJlIHR5cGljYWxseSB1c2VkIHRvIGNyZWF0ZS91cGRhdGUvZGVsZXRlIGRhdGEgb3IgcGVyZm9ybSBzZXJ2ZXIgc2lkZS1lZmZlY3RzLlxuKiBgdXNlTXV0YXRpb25gIGlzIHRoZSBob29rIGZvciB0aGF0LlxuKlxuKiBAc2VlIHtAbGluayBtdXRhdGlvbk9wdGlvbnN9IHRvIHNoYXJlIHRoZXNlIG9wdGlvbnMgYWNyb3NzIG11bHRpcGxlIGB1c2VNdXRhdGlvbmAgY2FsbCBzaXRlcywgb3IgdG8gbG9va1xuKiB0aGUgbXV0YXRpb24gdXAgZWxzZXdoZXJlIHZpYSBpdHMgYG11dGF0aW9uS2V5YCAoZS5nLiB3aXRoIGB1c2VNdXRhdGlvblN0YXRlYCkuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VNdXRhdGlvbk9wdGlvbnN9IHRvIHVzZSDigJQgZXZlcnl0aGluZyB5b3UgY2FuIHBhc3MgdG8gYHVzZU11dGF0aW9uYC5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBgbXV0YXRlYC9gbXV0YXRlQXN5bmNgIGFsc28gYWNjZXB0IHBlci1jYWxsIGBvblN1Y2Nlc3NgL2BvbkVycm9yYC9gb25TZXR0bGVkYCBjYWxsYmFja3MgYXMgYSBzZWNvbmRcbiogYXJndW1lbnQsIHVzZWZ1bCBmb3IgdHJpZ2dlcmluZyBjYWxsLXNpdGUgc2lkZSBlZmZlY3RzIChlLmcuIG5hdmlnYXRpb24pIHdpdGhvdXQgY291cGxpbmcgdGhlbSB0byB0aGUgc2hhcmVkXG4qIG11dGF0aW9uIGRlZmluaXRpb24uIEhvb2stbGV2ZWwgY2FsbGJhY2tzIChwYXNzZWQgdG8gYG9wdGlvbnNgKSBmaXJlIGZvciBldmVyeSBtdXRhdGlvbjsgcGVyLWNhbGwgY2FsbGJhY2tzXG4qIGZpcmUgb25seSBmb3IgdGhlIGxhdGVzdCBjYWxsIHlvdSd2ZSBtYWRlLCBhbmQgb25seSB3aGlsZSB0aGUgY29tcG9uZW50IGlzIHN0aWxsIG1vdW50ZWQg4oCUIHVubW91bnRpbmcgYmVmb3JlXG4qIHRoZSBtdXRhdGlvbiBzZXR0bGVzIHJlbW92ZXMgdGhlIHN1YnNjcmlwdGlvbiBhbmQgcHJldmVudHMgdGhlbSBmcm9tIGZpcmluZy5cbipcbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uXG4qICAgICAgIG9uQ2xpY2s9eygpID0+XG4qICAgICAgICAgYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJywge1xuKiAgICAgICAgICAgb25FcnJvcjogKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gYWRkIGl0ZW06JywgZXJyb3IpLFxuKiAgICAgICAgIH0pXG4qICAgICAgIH1cbiogICAgID5cbiogICAgICAgQWRkXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIFJlbmRlcmluZyB0aGUgbXV0YXRpb24ncyBvd24gc3RhdGUsIHJhdGhlciB0aGFuIGp1c3QgZmlyaW5nIGl0IG9mZjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICB7YWRkTXV0YXRpb24uaXNQZW5kaW5nID8gKFxuKiAgICAgICAgICdBZGRpbmcgdG9kby4uLidcbiogICAgICAgKSA6IChcbiogICAgICAgICA8PlxuKiAgICAgICAgICAge2FkZE11dGF0aW9uLmlzRXJyb3IgPyAoXG4qICAgICAgICAgICAgIDxkaXY+QW4gZXJyb3Igb2NjdXJyZWQ6IHthZGRNdXRhdGlvbi5lcnJvci5tZXNzYWdlfTwvZGl2PlxuKiAgICAgICAgICAgKSA6IG51bGx9XG4qICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGFkZE11dGF0aW9uLm11dGF0ZSgnSXRlbScpfT5BZGQ8L2J1dHRvbj5cbiogICAgICAgICA8Lz5cbiogICAgICAgKX1cbiogICAgIDwvZGl2PlxuKiAgIClcbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogT3B0aW1pc3RpYyB1cGRhdGUgdmlhIGBvbk11dGF0ZWAsIHJvbGxpbmcgYmFjayBvbiBgb25FcnJvcmA6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG8oKSB7XG4qICAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4qXG4qICAgY29uc3QgYWRkTXV0YXRpb24gPSB1c2VNdXRhdGlvbih7XG4qICAgICBtdXRhdGlvbkZuOiBhZGRUb2RvLFxuKiAgICAgb25NdXRhdGU6IGFzeW5jIChuZXdUb2RvKSA9PiB7XG4qICAgICAgIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pXG4qICAgICAgIGNvbnN0IHByZXZpb3VzVG9kb3MgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8QXJyYXk8c3RyaW5nPj4oWyd0b2RvcyddKVxuKlxuKiAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8QXJyYXk8c3RyaW5nPj4oWyd0b2RvcyddLCAob2xkKSA9PiBbXG4qICAgICAgICAgLi4uKG9sZCA/PyBbXSksXG4qICAgICAgICAgbmV3VG9kbyxcbiogICAgICAgXSlcbipcbiogICAgICAgLy8gUGFzc2VkIHRvIGBvbkVycm9yYCBhcyBgb25NdXRhdGVSZXN1bHRgIGlmIHRoZSBtdXRhdGlvbiBmYWlscy5cbiogICAgICAgcmV0dXJuIHsgcHJldmlvdXNUb2RvcyB9XG4qICAgICB9LFxuKiAgICAgb25FcnJvcjogKF9lcnIsIF9uZXdUb2RvLCBvbk11dGF0ZVJlc3VsdCkgPT4ge1xuKiAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoWyd0b2RvcyddLCBvbk11dGF0ZVJlc3VsdD8ucHJldmlvdXNUb2RvcylcbiogICAgIH0sXG4qICAgICBvblNldHRsZWQ6ICgpID0+IHtcbiogICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pXG4qICAgICB9LFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJyl9PkFkZDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogQ2FsbGJhY2tzIHBhc3NlZCBwZXIgY2FsbCB0byBgbXV0YXRlYCBvbmx5IGZpcmUgZm9yIHRoZSBsYXN0IGNhbGwg4oCUIGBtdXRhdGVBc3luY2AgZ2l2ZXMgeW91IGFcbiogcHJvbWlzZSBwZXIgY2FsbCBpbnN0ZWFkLCBzbyB5b3UgY2FuIHdhaXQgZm9yIGFsbCBvZiB0aGVtIHdoZW4gdGhleSBzdWNjZWVkOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvcygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZEFsbCh0b2RvczogQXJyYXk8c3RyaW5nPikge1xuKiAgICAgdHJ5IHtcbiogICAgICAgYXdhaXQgUHJvbWlzZS5hbGwodG9kb3MubWFwKCh0b2RvKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGVBc3luYyh0b2RvKSkpXG4qICAgICB9IGNhdGNoIChlcnJvcikge1xuKiAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gYWRkIHRvZG9zOicsIGVycm9yKVxuKiAgICAgfVxuKiAgIH1cbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBZGRBbGwoWydUb2RvIDEnLCAnVG9kbyAyJywgJ1RvZG8gMyddKX0+XG4qICAgICAgIEFkZCBhbGxcbiogICAgIDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbipcbiogQGV4YW1wbGVcbiogSWYgc29tZSBvZiB0aGUgbXV0YXRpb25zIGFib3ZlIGNhbiBmYWlsIGluZGVwZW5kZW50bHkgb2YgdGhlIG90aGVycywgYW5kIHlvdSB3YW50IHRvIGtub3cgd2hpY2ggb25lc1xuKiBkaWQg4oCUIHJhdGhlciB0aGFuIGxvc2luZyB0aGF0IGluZm9ybWF0aW9uIHRoZSBtb21lbnQgdGhlIGZpcnN0IG9uZSByZWplY3RzIOKAlCBzd2FwIGBQcm9taXNlLmFsbGAgZm9yXG4qIGBQcm9taXNlLmFsbFNldHRsZWRgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvcygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvblN1Y2Nlc3M6ICgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsndG9kb3MnXSB9KSxcbiogICB9KVxuKlxuKiAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFkZEFsbCh0b2RvczogQXJyYXk8c3RyaW5nPikge1xuKiAgICAgY29uc3QgYWRkUmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsU2V0dGxlZChcbiogICAgICAgdG9kb3MubWFwKCh0b2RvKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGVBc3luYyh0b2RvKSksXG4qICAgICApXG4qXG4qICAgICBhZGRSZXN1bHRzLmZvckVhY2goKGFkZFJlc3VsdCwgaW5kZXgpID0+IHtcbiogICAgICAgaWYgKGFkZFJlc3VsdC5zdGF0dXMgPT09ICdyZWplY3RlZCcpIHtcbiogICAgICAgICBjb25zb2xlLmVycm9yKGBGYWlsZWQgdG8gYWRkIFwiJHt0b2Rvc1tpbmRleF19XCI6YCwgYWRkUmVzdWx0LnJlYXNvbilcbiogICAgICAgfVxuKiAgICAgfSlcbiogICB9XG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlQWRkQWxsKFsnVG9kbyAxJywgJ1RvZG8gMicsICdUb2RvIDMnXSl9PlxuKiAgICAgICBBZGQgYWxsXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlTXV0YXRpb24ob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBbb2JzZXJ2ZXJdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoY2xpZW50LCBvcHRpb25zKSk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0b2JzZXJ2ZXIuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0fSwgW29ic2VydmVyLCBvcHRpb25zXSk7XG5cdGNvbnN0IHJlc3VsdCA9IFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSwgW29ic2VydmVyXSksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpKTtcblx0Y29uc3QgbXV0YXRlID0gUmVhY3QudXNlQ2FsbGJhY2soKC4uLmFyZ3MpID0+IHtcblx0XHRvYnNlcnZlci5tdXRhdGUoYXJnc1swXSwgYXJnc1sxXSkuY2F0Y2gobm9vcCk7XG5cdH0sIFtvYnNlcnZlcl0pO1xuXHRpZiAocmVzdWx0LmVycm9yICYmIHNob3VsZFRocm93RXJyb3Iob2JzZXJ2ZXIub3B0aW9ucy50aHJvd09uRXJyb3IsIFtyZXN1bHQuZXJyb3JdKSkgdGhyb3cgcmVzdWx0LmVycm9yO1xuXHRyZXR1cm4ge1xuXHRcdC4uLnJlc3VsdCxcblx0XHRtdXRhdGUsXG5cdFx0bXV0YXRlQXN5bmM6IHJlc3VsdC5tdXRhdGVcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTXV0YXRpb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTXV0YXRpb24uanMubWFwIiwiLy8jcmVnaW9uIHNyYy9tdXRhdGlvbk9wdGlvbnMudHNcbmZ1bmN0aW9uIG11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSB7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBtdXRhdGlvbk9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PcHRpb25zLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlSW5maW5pdGVRdWVyeS50c1xuZnVuY3Rpb24gdXNlSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIEluZmluaXRlUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUluZmluaXRlUXVlcnkuanMubWFwIiwiaW1wb3J0IHsgUXVlcnlDbGllbnRDb250ZXh0LCBRdWVyeUNsaWVudFByb3ZpZGVyLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH0gZnJvbSBcIi4vSHlkcmF0aW9uQm91bmRhcnkuanNcIjtcbmltcG9ydCB7IElzUmVzdG9yaW5nUHJvdmlkZXIsIHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCIuL3VzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VTdXNwZW5zZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaFF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanNcIjtcbmltcG9ydCB7IHF1ZXJ5T3B0aW9ucyB9IGZyb20gXCIuL3F1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgdXNlSXNGZXRjaGluZyB9IGZyb20gXCIuL3VzZUlzRmV0Y2hpbmcuanNcIjtcbmltcG9ydCB7IHVzZUlzTXV0YXRpbmcsIHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tIFwiLi91c2VNdXRhdGlvblN0YXRlLmpzXCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gXCIuL3VzZU11dGF0aW9uLmpzXCI7XG5pbXBvcnQgeyBtdXRhdGlvbk9wdGlvbnMgfSBmcm9tIFwiLi9tdXRhdGlvbk9wdGlvbnMuanNcIjtcbmltcG9ydCB7IHVzZUluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5LCBJc1Jlc3RvcmluZ1Byb3ZpZGVyLCBRdWVyeUNsaWVudENvbnRleHQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIsIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCBpbmZpbml0ZVF1ZXJ5T3B0aW9ucywgbXV0YXRpb25PcHRpb25zLCBxdWVyeU9wdGlvbnMsIHVzZUluZmluaXRlUXVlcnksIHVzZUlzRmV0Y2hpbmcsIHVzZUlzTXV0YXRpbmcsIHVzZUlzUmVzdG9yaW5nLCB1c2VNdXRhdGlvbiwgdXNlTXV0YXRpb25TdGF0ZSwgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LCB1c2VQcmVmZXRjaFF1ZXJ5LCB1c2VRdWVyaWVzLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQsIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnksIHVzZVN1c3BlbnNlUXVlcmllcywgdXNlU3VzcGVuc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQU9BLElBQU0scUJBQUEsYUFBMkIsY0FBYyxLQUFLLENBQUM7Ozs7Ozs7OztBQVNyRCxJQUFNLGtCQUFrQixnQkFBZ0I7Q0FDdkMsTUFBTSxTQUFBLGFBQWUsV0FBVyxrQkFBa0I7Q0FDbEQsSUFBSSxhQUFhLE9BQU87Q0FDeEIsSUFBSSxDQUFDLFFBQVEsTUFBTSxJQUFJLE1BQU0sd0RBQXdEO0NBQ3JGLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEsSUFBTSx1QkFBdUIsRUFBRSxRQUFRLGVBQWU7Q0FDckQsYUFBTSxnQkFBZ0I7RUFDckIsT0FBTyxNQUFNO0VBQ2IsYUFBYTtHQUNaLE9BQU8sUUFBUTtFQUNoQjtDQUNELEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDWCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxtQkFBbUIsVUFBVTtFQUN2RCxPQUFPO0VBQ1A7Q0FDRCxDQUFDO0FBQ0Y7OztBQ25EQSxJQUFNLHlCQUF5QjtDQUM5QixhQUFhLFVBQVUsVUFBVSxXQUFXLFVBQVUsS0FBSztDQUMzRCxlQUFlLGNBQWMsYUFBYSxTQUFTO0NBQ25ELGNBQWMsVUFBVSxVQUFVLFlBQVksVUFBVSxLQUFLO0NBQzdELGdCQUFnQixlQUFlLGNBQWMsVUFBVTtBQUN4RDs7Ozs7Ozs7Ozs7O0FBWUEsSUFBSSxpQkFBaUIsTUFBTTtDQUMxQixZQUFZO0NBQ1osa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBCbEIsbUJBQW1CLFVBQVU7RUFFM0IsSUFBSSxLQUFLLG1CQUFtQixhQUFhLEtBQUssV0FBVyxRQUFRLE1BQU0sOEdBQThHO0dBQ3BMLFVBQVUsS0FBSztHQUNmO0VBQ0QsQ0FBQztFQUVGLEtBQUssWUFBWTtFQUMwQixLQUFLLGtCQUFrQjtDQUNuRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLFdBQVcsVUFBVSxPQUFPO0VBQ2dCLEtBQUssa0JBQWtCO0VBQ2xFLE9BQU8sS0FBSyxVQUFVLFdBQVcsVUFBVSxLQUFLO0NBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsYUFBYSxXQUFXO0VBQ3ZCLEtBQUssVUFBVSxhQUFhLFNBQVM7Q0FDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxZQUFZLFVBQVUsT0FBTztFQUNlLEtBQUssa0JBQWtCO0VBQ2xFLE9BQU8sS0FBSyxVQUFVLFlBQVksVUFBVSxLQUFLO0NBQ2xEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsY0FBYyxZQUFZO0VBQ3pCLEtBQUssVUFBVSxjQUFjLFVBQVU7Q0FDeEM7QUFDRDs7OztBQUlBLElBQU0saUJBQWlCLElBQUksZUFBZTs7Ozs7Ozs7QUFRMUMsU0FBUyxxQkFBcUIsVUFBVTtDQUN2QyxXQUFXLFVBQVUsQ0FBQztBQUN2Qjs7Ozs7O0FDdEpBLElBQU0sV0FBVyxPQUFPLFdBQVcsZUFBZSxVQUFVO0FBQzVELFNBQVMsT0FBTyxDQUFDO0FBQ2pCLFNBQVMsaUJBQWlCLFNBQVMsT0FBTztDQUN6QyxPQUFPLE9BQU8sWUFBWSxhQUFhLFFBQVEsS0FBSyxJQUFJO0FBQ3pEO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDOUIsT0FBTyxPQUFPLFVBQVUsWUFBWSxTQUFTLEtBQUssVUFBVTtBQUM3RDtBQUNBLFNBQVMsZUFBZSxXQUFXLFdBQVc7Q0FDN0MsT0FBTyxLQUFLLElBQUksYUFBYSxhQUFhLEtBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUM3RDtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sT0FBTztDQUN4QyxPQUFPLE9BQU8sVUFBVSxhQUFhLE1BQU0sS0FBSyxJQUFJO0FBQ3JEOzs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsV0FBVyxTQUFTLE9BQU87Q0FDbkMsTUFBTSxFQUFFLE9BQU8sT0FBTyxPQUFPLGFBQWEsV0FBVyxVQUFVLFVBQVU7Q0FDekUsSUFBSSxVQUFVO0VBQ2IsSUFBSSxPQUNDO09BQUEsTUFBTSxjQUFjLHNCQUFzQixVQUFVLE1BQU0sT0FBTyxHQUFHLE9BQU87RUFBQSxPQUN6RSxJQUFJLENBQUMsZ0JBQWdCLE1BQU0sVUFBVSxRQUFRLEdBQUcsT0FBTztDQUMvRDtDQUNBLElBQUksU0FBUyxPQUFPO0VBQ25CLE1BQU0sV0FBVyxNQUFNLFNBQVM7RUFDaEMsSUFBSSxTQUFTLFlBQVksQ0FBQyxVQUFVLE9BQU87RUFDM0MsSUFBSSxTQUFTLGNBQWMsVUFBVSxPQUFPO0NBQzdDO0NBQ0EsSUFBSSxPQUFPLFVBQVUsYUFBYSxNQUFNLFFBQVEsTUFBTSxPQUFPLE9BQU87Q0FDcEUsSUFBSSxlQUFlLGdCQUFnQixNQUFNLE1BQU0sYUFBYSxPQUFPO0NBQ25FLElBQUksYUFBYSxDQUFDLFVBQVUsS0FBSyxHQUFHLE9BQU87Q0FDM0MsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7QUFlQSxTQUFTLGNBQWMsU0FBUyxVQUFVO0NBQ3pDLE1BQU0sRUFBRSxPQUFPLFFBQVEsV0FBVyxnQkFBZ0I7Q0FDbEQsSUFBSSxhQUFhO0VBQ2hCLElBQUksQ0FBQyxTQUFTLFFBQVEsYUFBYSxPQUFPO0VBQzFDLElBQUksT0FDQztPQUFBLFFBQVEsU0FBUyxRQUFRLFdBQVcsTUFBTSxRQUFRLFdBQVcsR0FBRyxPQUFPO0VBQUEsT0FDckUsSUFBSSxDQUFDLGdCQUFnQixTQUFTLFFBQVEsYUFBYSxXQUFXLEdBQUcsT0FBTztDQUNoRjtDQUNBLElBQUksVUFBVSxTQUFTLE1BQU0sV0FBVyxRQUFRLE9BQU87Q0FDdkQsSUFBSSxhQUFhLENBQUMsVUFBVSxRQUFRLEdBQUcsT0FBTztDQUM5QyxPQUFPO0FBQ1I7QUFDQSxTQUFTLHNCQUFzQixVQUFVLFNBQVM7Q0FDakQsUUFBUSxTQUFTLGtCQUFrQixRQUFBLENBQVMsUUFBUTtBQUNyRDs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLFFBQVEsVUFBVTtDQUMxQixPQUFPLEtBQUssVUFBVSxXQUFXLEdBQUcsUUFBUSxjQUFjLEdBQUcsSUFBSSxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxRQUFRLFFBQVE7RUFDaEgsT0FBTyxPQUFPLElBQUk7RUFDbEIsT0FBTztDQUNSLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRztBQUNiO0FBQ0EsU0FBUyxnQkFBZ0IsR0FBRyxHQUFHO0NBQzlCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxPQUFPLE1BQU0sT0FBTyxHQUFHLE9BQU87Q0FDbEMsSUFBSSxLQUFLLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVU7RUFDN0QsSUFBSSxNQUFNLFFBQVEsQ0FBQyxLQUFLLE1BQU0sUUFBUSxDQUFDLEdBQUc7R0FDekMsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLE9BQU87R0FDaEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsRUFBRSxHQUFHLE9BQU87R0FDNUUsT0FBTztFQUNSO0VBQ0EsTUFBTSxRQUFRLE9BQU8sS0FBSyxDQUFDO0VBQzNCLEtBQUssTUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxJQUFJLEdBQUcsT0FBTztFQUN0RSxPQUFPO0NBQ1I7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxJQUFNLFNBQVMsT0FBTyxVQUFVO0FBQ2hDLFNBQVMsaUJBQWlCLEdBQUcsR0FBRyxRQUFRLEdBQUc7Q0FDMUMsSUFBSSxNQUFNLEdBQUcsT0FBTztDQUNwQixJQUFJLFFBQVEsS0FBSyxPQUFPO0NBQ3hCLE1BQU0sUUFBUSxhQUFhLENBQUMsS0FBSyxhQUFhLENBQUM7Q0FDL0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxjQUFjLENBQUMsS0FBSyxjQUFjLENBQUMsSUFBSSxPQUFPO0NBQzlELE1BQU0sU0FBUyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUMsRUFBQSxDQUFHO0NBQzNDLE1BQU0sU0FBUyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUM7Q0FDeEMsTUFBTSxRQUFRLE9BQU87Q0FDckIsTUFBTSxPQUFPLFFBQVEsSUFBSSxNQUFNLEtBQUssSUFBSSxDQUFDO0NBQ3pDLElBQUksYUFBYTtDQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0VBQy9CLE1BQU0sTUFBTSxRQUFRLElBQUksT0FBTztFQUMvQixNQUFNLFFBQVEsRUFBRTtFQUNoQixNQUFNLFFBQVEsRUFBRTtFQUNoQixJQUFJLFVBQVUsT0FBTztHQUNwQixLQUFLLE9BQU87R0FDWixJQUFJLFFBQVEsSUFBSSxRQUFRLE9BQU8sS0FBSyxHQUFHLEdBQUcsR0FBRztHQUM3QztFQUNEO0VBQ0EsSUFBSSxVQUFVLFFBQVEsVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxVQUFVO0dBQy9GLEtBQUssT0FBTztHQUNaO0VBQ0Q7RUFDQSxNQUFNLElBQUksaUJBQWlCLE9BQU8sT0FBTyxRQUFRLENBQUM7RUFDbEQsS0FBSyxPQUFPO0VBQ1osSUFBSSxNQUFNLE9BQU87Q0FDbEI7Q0FDQSxPQUFPLFVBQVUsU0FBUyxlQUFlLFFBQVEsSUFBSTtBQUN0RDs7OztBQUlBLFNBQVMsb0JBQW9CLEdBQUcsR0FBRztDQUNsQyxJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxPQUFPO0NBQ2xFLEtBQUssTUFBTSxPQUFPLEdBQUcsSUFBSSxFQUFFLFNBQVMsRUFBRSxNQUFNLE9BQU87Q0FDbkQsT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDNUIsT0FBTyxNQUFNLFFBQVEsS0FBSyxLQUFLLE1BQU0sV0FBVyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7QUFDcEU7QUFDQSxTQUFTLGNBQWMsR0FBRztDQUN6QixJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxPQUFPO0NBQ25DLE1BQU0sa0JBQWtCLE9BQU8sZUFBZSxDQUFDO0NBQy9DLE1BQU0sT0FBTyxpQkFBaUI7Q0FDOUIsSUFBSSxTQUFTLEtBQUssR0FBRyxPQUFPO0NBQzVCLElBQUksT0FBTyxTQUFTLFlBQVksT0FBTztDQUN2QyxNQUFNLE9BQU8sS0FBSztDQUNsQixJQUFJLENBQUMsbUJBQW1CLElBQUksR0FBRyxPQUFPO0NBQ3RDLElBQUksQ0FBQyxLQUFLLGVBQWUsZUFBZSxHQUFHLE9BQU87Q0FDbEQsSUFBSSxvQkFBb0IsT0FBTyxXQUFXLE9BQU87Q0FDakQsT0FBTztBQUNSO0FBQ0EsU0FBUyxtQkFBbUIsR0FBRztDQUM5QixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNO0FBQzlDO0FBQ0EsU0FBUyxNQUFNLFNBQVM7Q0FDdkIsT0FBTyxJQUFJLFNBQVMsWUFBWTtFQUMvQixlQUFlLFdBQVcsU0FBUyxPQUFPO0NBQzNDLENBQUM7QUFDRjtBQUNBLFNBQVMsWUFBWSxVQUFVLE1BQU0sU0FBUztDQUM3QyxJQUFJLE9BQU8sUUFBUSxzQkFBc0IsWUFBWSxPQUFPLFFBQVEsa0JBQWtCLFVBQVUsSUFBSTtNQUMvRixJQUFJLFFBQVEsc0JBQXNCLE9BQ0ssSUFBSTtFQUM5QyxPQUFPLGlCQUFpQixVQUFVLElBQUk7Q0FDdkMsU0FBUyxPQUFPO0VBQ2YsUUFBUSxNQUFNLDBKQUEwSixRQUFRLFVBQVUsS0FBSyxPQUFPO0VBQ3RNLE1BQU07Q0FDUDtDQUdELE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyxpQkFBaUIsY0FBYztDQUN2QyxPQUFPO0FBQ1I7QUFDQSxTQUFTLFNBQVMsT0FBTyxNQUFNLE1BQU0sR0FBRztDQUN2QyxNQUFNLFdBQVcsQ0FBQyxHQUFHLE9BQU8sSUFBSTtDQUNoQyxPQUFPLE9BQU8sU0FBUyxTQUFTLE1BQU0sU0FBUyxNQUFNLENBQUMsSUFBSTtBQUMzRDtBQUNBLFNBQVMsV0FBVyxPQUFPLE1BQU0sTUFBTSxHQUFHO0NBQ3pDLE1BQU0sV0FBVyxDQUFDLE1BQU0sR0FBRyxLQUFLO0NBQ2hDLE9BQU8sT0FBTyxTQUFTLFNBQVMsTUFBTSxTQUFTLE1BQU0sR0FBRyxFQUFFLElBQUk7QUFDL0Q7Ozs7Ozs7Ozs7Ozs7O0FBY0EsSUFBTSxZQUFZLE9BQU87QUFDekIsU0FBUyxjQUFjLFNBQVMsY0FBYztDQUU1QyxJQUFJLFFBQVEsWUFBWSxXQUFXLFFBQVEsTUFBTSx5R0FBeUcsUUFBUSxVQUFVLEVBQUU7Q0FFL0ssSUFBSSxDQUFDLFFBQVEsV0FBVyxjQUFjLGdCQUFnQixhQUFhLGFBQWE7Q0FDaEYsSUFBSSxDQUFDLFFBQVEsV0FBVyxRQUFRLFlBQVksV0FBVyxhQUFhLFFBQVEsdUJBQXVCLElBQUksTUFBTSxxQkFBcUIsUUFBUSxVQUFVLEVBQUUsQ0FBQztDQUN2SixPQUFPLFFBQVE7QUFDaEI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkEsU0FBUyxpQkFBaUIsY0FBYyxRQUFRO0NBQy9DLElBQUksT0FBTyxpQkFBaUIsWUFBWSxPQUFPLGFBQWEsR0FBRyxNQUFNO0NBQ3JFLE9BQU8sQ0FBQyxDQUFDO0FBQ1Y7QUFDQSxTQUFTLHNCQUFzQixRQUFRLFdBQVcsYUFBYTtDQUM5RCxJQUFJLFdBQVc7Q0FDZixJQUFJO0NBQ0osT0FBTyxlQUFlLFFBQVEsVUFBVTtFQUN2QyxZQUFZO0VBQ1osV0FBVztHQUNWLFdBQVcsVUFBVTtHQUNyQixJQUFJLFVBQVUsT0FBTztHQUNyQixXQUFXO0dBQ1gsSUFBSSxPQUFPLFNBQVMsWUFBWTtRQUMzQixPQUFPLGlCQUFpQixTQUFTLGFBQWEsRUFBRSxNQUFNLEtBQUssQ0FBQztHQUNqRSxPQUFPO0VBQ1I7Q0FDRCxDQUFDO0NBQ0QsT0FBTztBQUNSOzs7QUN0UUEsSUFBSSxtQkFBbUJBOzs7O0FBSXZCLElBQU1DLG1CQUFpQixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQmxDLElBQU0scUJBQXFCO0NBQzFCLFVBQUE7Ozs7Q0FJQSxZQUFZLGVBQWU7RUFDMUIsYUFBYTtDQUNkO0FBQ0Q7Ozs7Ozs7O0FDMUJBLElBQUksZUFBZSxNQUFNO0NBQ3hCLGNBQWM7RUFDYixLQUFLLDRCQUE0QixJQUFJLElBQUk7RUFDekMsS0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLElBQUk7Q0FDMUM7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFVBQVUsVUFBVTtFQUNuQixLQUFLLFVBQVUsSUFBSSxRQUFRO0VBQzNCLEtBQUssWUFBWTtFQUNqQixhQUFhO0dBQ1osS0FBSyxVQUFVLE9BQU8sUUFBUTtHQUM5QixLQUFLLGNBQWM7RUFDcEI7Q0FDRDs7OztDQUlBLGVBQWU7RUFDZCxPQUFPLEtBQUssVUFBVSxPQUFPO0NBQzlCO0NBQ0EsY0FBYyxDQUFDO0NBQ2YsZ0JBQWdCLENBQUM7QUFDbEI7Ozs7Ozs7O0FDbENBLElBQUksZUFBZSxjQUFjLGFBQWE7Q0FDN0M7Q0FDQTtDQUNBO0NBQ0EsY0FBYztFQUNiLE1BQU07RUFDTixLQUFLLFVBQVUsWUFBWTtHQUMxQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sa0JBQWtCO0lBQzdELE1BQU0saUJBQWlCLFFBQVE7SUFDL0IsT0FBTyxpQkFBaUIsb0JBQW9CLFVBQVUsS0FBSztJQUMzRCxhQUFhO0tBQ1osT0FBTyxvQkFBb0Isb0JBQW9CLFFBQVE7SUFDeEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxDQUFDLEtBQUssVUFBVSxLQUFLLGlCQUFpQixLQUFLLE1BQU07Q0FDdEQ7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUc7R0FDekIsS0FBSyxXQUFXO0dBQ2hCLEtBQUssV0FBVyxLQUFLO0VBQ3RCO0NBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEJBLGlCQUFpQixPQUFPO0VBQ3ZCLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVcsT0FBTyxZQUFZO0dBQ2xDLElBQUksT0FBTyxZQUFZLFdBQVcsS0FBSyxXQUFXLE9BQU87UUFDcEQsS0FBSyxRQUFRO0VBQ25CLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CQSxXQUFXLFNBQVM7RUFDbkIsSUFBSSxLQUFLLGFBQWEsU0FBUztHQUM5QixLQUFLLFdBQVc7R0FDaEIsS0FBSyxRQUFRO0VBQ2Q7Q0FDRDs7OztDQUlBLFVBQVU7RUFDVCxNQUFNLFlBQVksS0FBSyxVQUFVO0VBQ2pDLEtBQUssVUFBVSxTQUFTLGFBQWE7R0FDcEMsU0FBUyxTQUFTO0VBQ25CLENBQUM7Q0FDRjs7OztDQUlBLFlBQVk7RUFDWCxJQUFJLE9BQU8sS0FBSyxhQUFhLFdBQVcsT0FBTyxLQUFLO0VBQ3BELE9BQU8sV0FBVyxVQUFVLG9CQUFvQjtDQUNqRDtBQUNEOzs7O0FBSUEsSUFBTSxlQUFlLElBQUksYUFBYTs7O0FDM0d0QyxTQUFTLGVBQWUsU0FBUztDQUNoQyxJQUFJO0NBQ0osUUFBUSxNQUFNLFdBQVc7RUFDeEIsT0FBTztFQUNQLE9BQU87Q0FDUixHQUFHLElBQUksQ0FBQyxFQUFFLFFBQVEsSUFBSTtDQUN0QixJQUFJLFNBQVMsS0FBSyxHQUFHLE9BQU8sRUFBRSxLQUFLO0FBQ3BDO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtDQUNwQyxPQUFPO0VBQ04sYUFBYSxTQUFTLFFBQVE7RUFDOUIsT0FBTyxTQUFTO0VBQ2hCLEdBQUcsU0FBUyxRQUFRLFNBQVMsRUFBRSxPQUFPLFNBQVMsUUFBUSxNQUFNO0VBQzdELEdBQUcsU0FBUyxRQUFRLEVBQUUsTUFBTSxTQUFTLEtBQUs7Q0FDM0M7QUFDRDtBQUNBLFNBQVMsaUJBQWlCLE9BQU8sZUFBZSxvQkFBb0I7Q0FDbkUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLGFBQWEsQ0FBQyxDQUFDLE9BQU8sVUFBVTtFQUNuRSxJQUFJLHFCQUFxQixLQUFLLE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLO0VBQzNCLFFBQVEsTUFBTSwrREFBK0QsTUFBTSxVQUFVLEtBQUssTUFBTSxrREFBa0Q7RUFDck0sT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sVUFBVSxDQUFDO0NBQzVELENBQUM7Q0FDRCxTQUFTLE1BQU0sSUFBSTtDQUNuQixPQUFPO0FBQ1I7Ozs7Ozs7Ozs7O0FBV0EsU0FBUyxlQUFlLE9BQU8sZUFBZSxvQkFBb0I7Q0FDakUsT0FBTztFQUNOLGNBQWMsS0FBSyxJQUFJO0VBQ3ZCLE9BQU87R0FDTixHQUFHLE1BQU07R0FDVCxHQUFHLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLGNBQWMsTUFBTSxNQUFNLElBQUksSUFBSSxNQUFNLE1BQU0sS0FBSztFQUM5RztFQUNBLFVBQVUsTUFBTTtFQUNoQixXQUFXLE1BQU07RUFDakIsR0FBRyxNQUFNLE1BQU0sV0FBVyxhQUFhLEVBQUUsU0FBUyxpQkFBaUIsT0FBTyxlQUFlLGtCQUFrQixFQUFFO0VBQzdHLEdBQUcsTUFBTSxRQUFRLEVBQUUsTUFBTSxNQUFNLEtBQUs7RUFDcEMsR0FBRyxNQUFNLGFBQWEsRUFBRSxXQUFXLE1BQU0sVUFBVTtDQUNwRDtBQUNEOzs7OztBQUtBLFNBQVMsK0JBQStCLFVBQVU7Q0FDakQsT0FBTyxTQUFTLE1BQU07QUFDdkI7Ozs7O0FBS0EsU0FBUyw0QkFBNEIsT0FBTztDQUMzQyxPQUFPLE1BQU0sTUFBTSxXQUFXO0FBQy9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLFNBQVMsVUFBVSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0saUJBQWlCLFFBQVEsMkJBQTJCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLDJCQUEyQjtDQUMzSCxNQUFNLFlBQVksT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsYUFBYSxlQUFlLFFBQVEsSUFBSSxDQUFDLGtCQUFrQixRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDeEksTUFBTSxjQUFjLFFBQVEsd0JBQXdCLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxXQUFXLHdCQUF3QjtDQUNsSCxNQUFNLHFCQUFxQixRQUFRLHNCQUFzQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVztDQUMvRixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVztDQUNyRixPQUFPO0VBQ047RUFDQSxTQUFTLE9BQU8sY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVLFlBQVksS0FBSyxJQUFJLENBQUMsZUFBZSxPQUFPLGVBQWUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDako7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBLFNBQVMsUUFBUSxRQUFRLGlCQUFpQixTQUFTO0NBQ2xELE1BQU0sZ0JBQWdCLE9BQU8saUJBQWlCO0NBQzlDLE1BQU0sYUFBYSxPQUFPLGNBQWM7Q0FDeEMsTUFBTSxrQkFBa0IsU0FBUyxnQkFBZ0IsbUJBQW1CLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTO0NBQ3hHLGdCQUFnQixXQUFXLFNBQVMsRUFBRSxPQUFPLEdBQUcsc0JBQXNCO0VBQ3JFLGNBQWMsTUFBTSxRQUFRO0dBQzNCLEdBQUcsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVM7R0FDdkMsR0FBRyxTQUFTLGdCQUFnQjtHQUM1QixHQUFHO0VBQ0osR0FBRyxLQUFLO0NBQ1QsQ0FBQztDQUNELGdCQUFnQixTQUFTLFNBQVMsRUFBRSxVQUFVLE9BQU8sV0FBVyxNQUFNLFNBQVMsY0FBYyxnQkFBZ0I7RUFDNUcsTUFBTSxXQUFXLFVBQVUsZUFBZSxPQUFPLElBQUksS0FBSztFQUMxRCxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUssSUFBSSxVQUFVLE9BQU8sTUFBTTtFQUMvRCxNQUFNLE9BQU8sWUFBWSxLQUFLLElBQUksVUFBVSxrQkFBa0IsZ0JBQWdCLE9BQU8sSUFBSTtFQUN6RixJQUFJLFFBQVEsV0FBVyxJQUFJLFNBQVM7RUFDcEMsTUFBTSx5QkFBeUIsT0FBTyxNQUFNLFdBQVc7RUFDdkQsTUFBTSwwQkFBMEIsT0FBTyxNQUFNLGdCQUFnQjtFQUM3RCxJQUFJLE9BQU87R0FDVixNQUFNLG1CQUFtQixZQUFZLGVBQWUsTUFBTSxNQUFNO0dBQ2hFLElBQUksTUFBTSxnQkFBZ0IsTUFBTSxNQUFNLGlCQUFpQixrQkFBa0I7SUFDeEUsTUFBTSxFQUFFLGFBQWEsVUFBVSxHQUFHLG9CQUFvQjtJQUN0RCxNQUFNLFNBQVM7S0FDZCxHQUFHO0tBQ0g7S0FDQSxHQUFHLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxLQUFLO01BQ25ELFFBQVE7TUFDUixlQUFlO01BQ2YsR0FBRyxDQUFDLDJCQUEyQixFQUFFLGFBQWEsT0FBTztLQUN0RDtJQUNELENBQUM7R0FDRjtFQUNELE9BQU8sUUFBUSxXQUFXLE1BQU0sUUFBUTtHQUN2QyxHQUFHLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxTQUFTO0dBQ3ZDLEdBQUcsU0FBUyxnQkFBZ0I7R0FDNUI7R0FDQTtHQUNBO0dBQ0EsT0FBTztFQUNSLEdBQUc7R0FDRixHQUFHO0dBQ0g7R0FDQSxhQUFhO0dBQ2IsUUFBUSxNQUFNLFdBQVcsYUFBYSxTQUFTLEtBQUssSUFBSSxZQUFZLE1BQU07R0FDMUUsR0FBRyxNQUFNLFdBQVcsYUFBYSxTQUFTLEtBQUssS0FBSyxFQUFFLGVBQWUsYUFBYTtFQUNuRixDQUFDO0VBQ0QsSUFBSSxXQUFXLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLDJCQUEyQixlQUFlLE1BQU0sTUFBTSxlQUFlLE1BQU0sTUFBTSxLQUFLLEdBQUcsRUFBRSxnQkFBZ0IsUUFBUSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUNoTyxDQUFDO0FBQ0Y7Ozs7Ozs7QUN6SkEsSUFBTSxtQkFBbUI7QUFDekIsU0FBUyxzQkFBc0I7Q0FDOUIsSUFBSSxRQUFRLENBQUM7Q0FDYixJQUFJLGVBQWU7Q0FDbkIsSUFBSSxZQUFZLGFBQWE7RUFDNUIsU0FBUztDQUNWO0NBQ0EsSUFBSSxpQkFBaUIsYUFBYTtFQUNqQyxTQUFTO0NBQ1Y7Q0FDQSxJQUFJLGFBQWE7Q0FDakIsTUFBTSxZQUFZLGFBQWE7RUFDOUIsSUFBSSxjQUFjLE1BQU0sS0FBSyxRQUFRO09BQ2hDLGlCQUFpQjtHQUNyQixTQUFTLFFBQVE7RUFDbEIsQ0FBQztDQUNGO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLE1BQU0sZ0JBQWdCO0VBQ3RCLFFBQVEsQ0FBQztFQUNULElBQUksY0FBYyxRQUFRLGlCQUFpQjtHQUMxQyxvQkFBb0I7SUFDbkIsY0FBYyxTQUFTLGFBQWE7S0FDbkMsU0FBUyxRQUFRO0lBQ2xCLENBQUM7R0FDRixDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsT0FBTzs7Ozs7OztFQU9OLFFBQVEsYUFBYTtHQUNwQixJQUFJO0dBQ0o7R0FDQSxJQUFJO0lBQ0gsU0FBUyxTQUFTO0dBQ25CLFVBQVU7SUFDVDtJQUNBLElBQUksQ0FBQyxjQUFjLE1BQU07R0FDMUI7R0FDQSxPQUFPO0VBQ1I7Ozs7RUFJQSxhQUFhLGFBQWE7R0FDekIsUUFBUSxHQUFHLFNBQVM7SUFDbkIsZUFBZTtLQUNkLFNBQVMsR0FBRyxJQUFJO0lBQ2pCLENBQUM7R0FDRjtFQUNEOzs7OztFQUtBOzs7OztFQUtBLG9CQUFvQixPQUFPO0dBQzFCLFdBQVc7RUFDWjs7Ozs7Ozs7Ozs7Ozs7RUFjQSx5QkFBeUIsT0FBTztHQUMvQixnQkFBZ0I7RUFDakI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFtQkEsZUFBZSxPQUFPO0dBQ3JCLGFBQWE7RUFDZDtDQUNEO0FBQ0Q7Ozs7QUFJQSxJQUFNLGdCQUFnQixvQkFBb0I7Ozs7Ozs7Ozs7OztBQ3pHMUMsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzlDLFVBQVU7Q0FDVjtDQUNBO0NBQ0EsY0FBYztFQUNiLE1BQU07RUFDTixLQUFLLFVBQVUsYUFBYTtHQUMzQixJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sa0JBQWtCO0lBQzdELE1BQU0sdUJBQXVCLFNBQVMsSUFBSTtJQUMxQyxNQUFNLHdCQUF3QixTQUFTLEtBQUs7SUFDNUMsT0FBTyxpQkFBaUIsVUFBVSxnQkFBZ0IsS0FBSztJQUN2RCxPQUFPLGlCQUFpQixXQUFXLGlCQUFpQixLQUFLO0lBQ3pELGFBQWE7S0FDWixPQUFPLG9CQUFvQixVQUFVLGNBQWM7S0FDbkQsT0FBTyxvQkFBb0IsV0FBVyxlQUFlO0lBQ3REO0dBQ0Q7RUFDRDtDQUNEO0NBQ0EsY0FBYztFQUNiLElBQUksQ0FBQyxLQUFLLFVBQVUsS0FBSyxpQkFBaUIsS0FBSyxNQUFNO0NBQ3REO0NBQ0EsZ0JBQWdCO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHO0dBQ3pCLEtBQUssV0FBVztHQUNoQixLQUFLLFdBQVcsS0FBSztFQUN0QjtDQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGlCQUFpQixPQUFPO0VBQ3ZCLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVcsTUFBTSxLQUFLLFVBQVUsS0FBSyxJQUFJLENBQUM7Q0FDaEQ7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFVBQVUsUUFBUTtFQUNqQixJQUFJLEtBQUssWUFBWSxRQUFRO0dBQzVCLEtBQUssVUFBVTtHQUNmLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDcEMsU0FBUyxNQUFNO0dBQ2hCLENBQUM7RUFDRjtDQUNEOzs7O0NBSUEsV0FBVztFQUNWLE9BQU8sS0FBSztDQUNiO0FBQ0Q7Ozs7QUFJQSxJQUFNLGdCQUFnQixJQUFJLGNBQWM7OztBQ3pGeEMsU0FBUyxrQkFBa0IsY0FBYztDQUN4QyxPQUFPLEtBQUssSUFBSSxNQUFNLEtBQUssY0FBYyxHQUFHO0FBQzdDO0FBQ0EsU0FBUyxTQUFTLGFBQWE7Q0FDOUIsUUFBUSxlQUFlLGNBQWMsV0FBVyxjQUFjLFNBQVMsSUFBSTtBQUM1RTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFJLGlCQUFpQixjQUFjLE1BQU07Q0FDeEMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sZ0JBQWdCO0VBQ3RCLEtBQUssU0FBUyxTQUFTO0VBQ3ZCLEtBQUssU0FBUyxTQUFTO0NBQ3hCO0FBQ0Q7Ozs7QUFJQSxTQUFTLGlCQUFpQixPQUFPO0NBQ2hDLE9BQU8saUJBQWlCO0FBQ3pCO0FBQ0EsU0FBUyxjQUFjLFFBQVE7Q0FDOUIsSUFBSSxtQkFBbUI7Q0FDdkIsSUFBSSxlQUFlO0NBQ25CLElBQUk7Q0FDSixJQUFJLFNBQVM7Q0FDYixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sVUFBVSxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ2hELGlCQUFpQjtFQUNqQixnQkFBZ0I7Q0FDakIsQ0FBQztDQUNELFFBQVEsTUFBTSxJQUFJO0NBQ2xCLE1BQU0sbUJBQW1CLFdBQVc7Q0FDcEMsTUFBTSxVQUFVLGtCQUFrQjtFQUNqQyxJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLE1BQU0sUUFBUSxJQUFJLGVBQWUsYUFBYTtHQUM5QyxPQUFPLEtBQUs7R0FDWixPQUFPLFdBQVcsS0FBSztFQUN4QjtDQUNEO0NBQ0EsTUFBTSxvQkFBb0I7RUFDekIsbUJBQW1CO0NBQ3BCO0NBQ0EsTUFBTSxzQkFBc0I7RUFDM0IsbUJBQW1CO0NBQ3BCO0NBQ0EsTUFBTSxvQkFBb0IsYUFBYSxVQUFVLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWSxjQUFjLFNBQVMsTUFBTSxPQUFPLE9BQU87Q0FDckksTUFBTSxpQkFBaUIsU0FBUyxPQUFPLFdBQVcsS0FBSyxPQUFPLE9BQU87Q0FDckUsTUFBTSxXQUFXLFVBQVU7RUFDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRztHQUNsQixhQUFhO0dBQ2IsU0FBUztHQUNULGVBQWUsS0FBSztFQUNyQjtDQUNEO0NBQ0EsTUFBTSxVQUFVLFVBQVU7RUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRztHQUNsQixhQUFhO0dBQ2IsU0FBUztHQUNULGNBQWMsS0FBSztFQUNwQjtDQUNEO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLE9BQU8sSUFBSSxTQUFTLG9CQUFvQjtHQUN2QyxjQUFjLFVBQVU7SUFDdkIsSUFBSSxXQUFXLEtBQUssWUFBWSxHQUFHLGdCQUFnQixLQUFLO0dBQ3pEO0dBQ0EsT0FBTyxVQUFVO0VBQ2xCLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixhQUFhLEtBQUs7R0FDbEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLGFBQWE7RUFDeEMsQ0FBQztDQUNGO0NBQ0EsTUFBTSxZQUFZO0VBQ2pCLElBQUksV0FBVyxHQUFHO0VBQ2xCLElBQUk7RUFDSixNQUFNLGlCQUFpQixpQkFBaUIsSUFBSSxPQUFPLGlCQUFpQixLQUFLO0VBQ3pFLElBQUk7R0FDSCxpQkFBaUIsa0JBQWtCLE9BQU8sR0FBRztFQUM5QyxTQUFTLE9BQU87R0FDZixpQkFBaUIsUUFBUSxPQUFPLEtBQUs7RUFDdEM7RUFDQSxRQUFRLFFBQVEsY0FBYyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDOUQsSUFBSSxXQUFXLEdBQUc7R0FDbEIsTUFBTSxRQUFRLE9BQU8sVUFBVUMsV0FBUyxJQUFJLElBQUk7R0FDaEQsTUFBTSxhQUFhLE9BQU8sY0FBYztHQUN4QyxNQUFNLFFBQVEsT0FBTyxlQUFlLGFBQWEsV0FBVyxjQUFjLEtBQUssSUFBSTtHQUNuRixNQUFNLGNBQWMsVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLGVBQWUsU0FBUyxPQUFPLFVBQVUsY0FBYyxNQUFNLGNBQWMsS0FBSztHQUNuSixJQUFJLG9CQUFvQixDQUFDLGFBQWE7SUFDckMsT0FBTyxLQUFLO0lBQ1o7R0FDRDtHQUNBO0dBQ0EsT0FBTyxTQUFTLGNBQWMsS0FBSztHQUNuQyxNQUFNLEtBQUssQ0FBQyxDQUFDLFdBQVc7SUFDdkIsT0FBTyxZQUFZLElBQUksS0FBSyxJQUFJLE1BQU07R0FDdkMsQ0FBQyxDQUFDLENBQUMsV0FBVztJQUNiLElBQUksa0JBQWtCLE9BQU8sS0FBSztTQUM3QixJQUFJO0dBQ1YsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLE9BQU87RUFDTjtFQUNBLGNBQWM7RUFDZDtFQUNBLGdCQUFnQjtHQUNmLGFBQWE7R0FDYixPQUFPO0VBQ1I7RUFDQTtFQUNBO0VBQ0E7RUFDQSxhQUFhO0dBQ1osSUFBSSxTQUFTLEdBQUcsSUFBSTtRQUNmLE1BQU0sQ0FBQyxDQUFDLEtBQUssR0FBRztHQUNyQixPQUFPO0VBQ1I7Q0FDRDtBQUNEOzs7Ozs7O0FDcklBLElBQUksWUFBWSxNQUFNO0NBQ3JCOzs7Ozs7Q0FNQSxVQUFVO0VBQ1QsS0FBSyxlQUFlO0NBQ3JCO0NBQ0EsYUFBYTtFQUNaLEtBQUssZUFBZTtFQUNwQixJQUFJLGVBQWUsS0FBSyxNQUFNLEdBQUcsS0FBSyxhQUFhLGVBQWUsaUJBQWlCO0dBQ2xGLEtBQUssZUFBZTtFQUNyQixHQUFHLEtBQUssTUFBTTtDQUNmO0NBQ0EsYUFBYSxXQUFXO0VBQ3ZCLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxVQUFVLEdBQUcsY0FBY0MsV0FBUyxJQUFJLFdBQVcsSUFBSTtDQUNwRjtDQUNBLGlCQUFpQjtFQUNoQixJQUFJLEtBQUssZUFBZSxLQUFLLEdBQUc7R0FDL0IsZUFBZSxhQUFhLEtBQUssVUFBVTtHQUMzQyxLQUFLLGFBQWEsS0FBSztFQUN4QjtDQUNEO0FBQ0Q7OztBQy9CQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3JDLE9BQU8sRUFBRSxVQUFVLFNBQVMsVUFBVTtFQUNyQyxNQUFNLFVBQVUsUUFBUTtFQUN4QixNQUFNLFlBQVksUUFBUSxjQUFjLE1BQU0sV0FBVztFQUN6RCxNQUFNLFdBQVcsUUFBUSxNQUFNLE1BQU0sU0FBUyxDQUFDO0VBQy9DLE1BQU0sZ0JBQWdCLFFBQVEsTUFBTSxNQUFNLGNBQWMsQ0FBQztFQUN6RCxJQUFJLFNBQVM7R0FDWixPQUFPLENBQUM7R0FDUixZQUFZLENBQUM7RUFDZDtFQUNBLElBQUksY0FBYztFQUNsQixNQUFNLFVBQVUsWUFBWTtHQUMzQixJQUFJLFlBQVk7R0FDaEIsTUFBTSxxQkFBcUIsV0FBVztJQUNyQyxzQkFBc0IsY0FBYyxRQUFRLGNBQWMsWUFBWSxJQUFJO0dBQzNFO0dBQ0EsTUFBTSxVQUFVLGNBQWMsUUFBUSxTQUFTLFFBQVEsWUFBWTtHQUNuRSxNQUFNLFlBQVksT0FBTyxNQUFNLE9BQU8sYUFBYTtJQUNsRCxJQUFJLFdBQVcsT0FBTyxRQUFRLE9BQU8sUUFBUSxPQUFPLE1BQU07SUFDMUQsSUFBSSxTQUFTLFFBQVEsS0FBSyxNQUFNLFFBQVEsT0FBTyxRQUFRLFFBQVEsSUFBSTtJQUNuRSxNQUFNLDZCQUE2QjtLQUNsQyxNQUFNLGlCQUFpQjtNQUN0QixRQUFRLFFBQVE7TUFDaEIsVUFBVSxRQUFRO01BQ2xCLFdBQVc7TUFDWCxXQUFXLFdBQVcsYUFBYTtNQUNuQyxNQUFNLFFBQVEsUUFBUTtLQUN2QjtLQUNBLGtCQUFrQixjQUFjO0tBQ2hDLE9BQU87SUFDUjtJQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtJQUM1QyxNQUFNLE9BQU8sTUFBTSxRQUFRLGNBQWM7SUFDekMsTUFBTSxFQUFFLGFBQWEsUUFBUTtJQUM3QixNQUFNLFFBQVEsV0FBVyxhQUFhO0lBQ3RDLE9BQU87S0FDTixPQUFPLE1BQU0sS0FBSyxPQUFPLE1BQU0sUUFBUTtLQUN2QyxZQUFZLE1BQU0sS0FBSyxZQUFZLE9BQU8sUUFBUTtJQUNuRDtHQUNEO0dBQ0EsSUFBSSxhQUFhLFNBQVMsUUFBUTtJQUNqQyxNQUFNLFdBQVcsY0FBYztJQUMvQixNQUFNLGNBQWMsV0FBVyx1QkFBdUI7SUFDdEQsTUFBTSxVQUFVO0tBQ2YsT0FBTztLQUNQLFlBQVk7SUFDYjtJQUNBLFNBQVMsTUFBTSxVQUFVLFNBQVMsWUFBWSxTQUFTLE9BQU8sR0FBRyxRQUFRO0dBQzFFLE9BQU87SUFDTixNQUFNLGlCQUFpQixTQUFTLFNBQVM7SUFDekMsR0FBRztLQUNGLE1BQU0sUUFBUSxnQkFBZ0IsSUFBSSxjQUFjLE1BQU0sUUFBUSxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtLQUNqSCxJQUFJLGNBQWMsS0FBSyxTQUFTLE1BQU07S0FDdEMsU0FBUyxNQUFNLFVBQVUsUUFBUSxLQUFLO0tBQ3RDO0lBQ0QsU0FBUyxjQUFjO0dBQ3hCO0dBQ0EsT0FBTztFQUNSO0VBQ0EsSUFBSSxRQUFRLFFBQVEsV0FBVyxRQUFRLGdCQUFnQjtHQUN0RCxPQUFPLFFBQVEsUUFBUSxZQUFZLFNBQVM7SUFDM0MsUUFBUSxRQUFRO0lBQ2hCLFVBQVUsUUFBUTtJQUNsQixNQUFNLFFBQVEsUUFBUTtJQUN0QixRQUFRLFFBQVE7R0FDakIsR0FBRyxLQUFLO0VBQ1Q7T0FDSyxRQUFRLFVBQVU7Q0FDeEIsRUFBRTtBQUNIO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUN6RCxNQUFNLFlBQVksTUFBTSxTQUFTO0NBQ2pDLE9BQU8sTUFBTSxTQUFTLElBQUksUUFBUSxpQkFBaUIsTUFBTSxZQUFZLE9BQU8sV0FBVyxZQUFZLFVBQVUsSUFBSSxLQUFLO0FBQ3ZIO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUM3RCxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsdUJBQXVCLE1BQU0sSUFBSSxPQUFPLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSztBQUM3Rzs7OztBQUlBLFNBQVMsWUFBWSxTQUFTLE1BQU07Q0FDbkMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLGlCQUFpQixTQUFTLElBQUksS0FBSztBQUMzQzs7OztBQUlBLFNBQVMsZ0JBQWdCLFNBQVMsTUFBTTtDQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsc0JBQXNCLE9BQU87Q0FDbkQsT0FBTyxxQkFBcUIsU0FBUyxJQUFJLEtBQUs7QUFDL0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuRUEsSUFBSSxRQUFRLGNBQWMsVUFBVTtDQUNuQztDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxRQUFRO0VBQ25CLE1BQU07RUFDTixLQUFLLHVCQUF1QjtFQUM1QixLQUFLLGtCQUFrQixPQUFPO0VBQzlCLEtBQUssV0FBVyxPQUFPLE9BQU87RUFDOUIsS0FBSyxZQUFZLENBQUM7RUFDbEIsS0FBSyxVQUFVLE9BQU87RUFDdEIsS0FBSyxTQUFTLEtBQUssUUFBUSxjQUFjO0VBQ3pDLEtBQUssV0FBVyxPQUFPO0VBQ3ZCLEtBQUssWUFBWSxPQUFPO0VBQ3hCLEtBQUssZ0JBQWdCQyxrQkFBZ0IsS0FBSyxPQUFPO0VBQ2pELEtBQUssUUFBUSxPQUFPLFNBQVMsS0FBSztFQUNsQyxLQUFLLFdBQVc7Q0FDakI7Ozs7Q0FJQSxJQUFJLE9BQU87RUFDVixPQUFPLEtBQUssUUFBUTtDQUNyQjs7Q0FFQSxJQUFJLFlBQVk7RUFDZixPQUFPLEtBQUs7Q0FDYjs7Ozs7Q0FLQSxJQUFJLFVBQVU7RUFDYixPQUFPLEtBQUssVUFBVTtDQUN2Qjs7Q0FFQSxXQUFXLFNBQVM7RUFDbkIsS0FBSyxVQUFVO0dBQ2QsR0FBRyxLQUFLO0dBQ1IsR0FBRztFQUNKO0VBQ0EsSUFBSSxTQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVE7RUFDOUMsS0FBSyxhQUFhLEtBQUssUUFBUSxNQUFNO0VBQ3JDLElBQUksS0FBSyxTQUFTLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRztHQUM3QyxNQUFNLGVBQWVBLGtCQUFnQixLQUFLLE9BQU87R0FDakQsSUFBSSxhQUFhLFNBQVMsS0FBSyxHQUFHO0lBQ2pDLEtBQUssU0FBUyxhQUFhLGFBQWEsTUFBTSxhQUFhLGFBQWEsQ0FBQztJQUN6RSxLQUFLLGdCQUFnQjtHQUN0QjtFQUNEO0NBQ0Q7Q0FDQSxpQkFBaUI7RUFDaEIsSUFBSSxDQUFDLEtBQUssVUFBVSxVQUFVLEtBQUssTUFBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU8sT0FBTyxJQUFJO0NBQ3pGOztDQUVBLFFBQVEsU0FBUyxTQUFTO0VBQ3pCLE1BQU0sT0FBTyxZQUFZLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxPQUFPO0VBQy9ELEtBQUssVUFBVTtHQUNkO0dBQ0EsTUFBTTtHQUNOLGVBQWUsU0FBUztHQUN4QixRQUFRLFNBQVM7RUFDbEIsQ0FBQztFQUNELE9BQU87Q0FDUjs7Ozs7O0NBTUEsU0FBUyxPQUFPO0VBQ2YsS0FBSyxVQUFVO0dBQ2QsTUFBTTtHQUNOO0VBQ0QsQ0FBQztDQUNGOzs7Ozs7Ozs7OztDQVdBLE9BQU8sU0FBUztFQUNmLE1BQU0sVUFBVSxLQUFLLFVBQVU7RUFDL0IsS0FBSyxVQUFVLE9BQU8sT0FBTztFQUM3QixPQUFPLFVBQVUsUUFBUSxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxJQUFJLFFBQVEsUUFBUTtDQUNuRTs7Ozs7Ozs7Q0FRQSxVQUFVO0VBQ1QsTUFBTSxRQUFRO0VBQ2QsS0FBSyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7Q0FDN0I7O0NBRUEsSUFBSSxhQUFhO0VBQ2hCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Q0FNQSxRQUFRO0VBQ1AsS0FBSyxRQUFRO0VBQ2IsS0FBSyxTQUFTLEtBQUssVUFBVTtDQUM5Qjs7Ozs7Q0FLQSxXQUFXO0VBQ1YsT0FBTyxLQUFLLFVBQVUsTUFBTSxhQUFhLGtCQUFrQixTQUFTLFFBQVEsU0FBUyxJQUFJLE1BQU0sS0FBSztDQUNyRzs7Ozs7Ozs7O0NBU0EsYUFBYTtFQUNaLElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFDeEQsT0FBTyxLQUFLLFFBQVEsWUFBWSxhQUFhLENBQUMsS0FBSyxVQUFVO0NBQzlEOzs7OztDQUtBLFlBQVk7RUFDWCxPQUFPLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxNQUFNLG1CQUFtQjtDQUNuRTs7Ozs7Q0FLQSxXQUFXO0VBQ1YsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUcsT0FBTyxLQUFLLFVBQVUsTUFBTSxhQUFhLGtCQUFrQixTQUFTLFFBQVEsV0FBVyxJQUFJLE1BQU0sUUFBUTtFQUMzSSxPQUFPO0NBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFVBQVU7RUFDVCxJQUFJLEtBQUssa0JBQWtCLElBQUksR0FBRyxPQUFPLEtBQUssVUFBVSxNQUFNLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQyxDQUFDLE9BQU87RUFDOUcsT0FBTyxLQUFLLE1BQU0sU0FBUyxLQUFLLEtBQUssS0FBSyxNQUFNO0NBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxjQUFjLFlBQVksR0FBRztFQUM1QixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRyxPQUFPO0VBQ3ZDLElBQUksY0FBYyxVQUFVLE9BQU87RUFDbkMsSUFBSSxLQUFLLE1BQU0sZUFBZSxPQUFPO0VBQ3JDLE9BQU8sQ0FBQyxlQUFlLEtBQUssTUFBTSxlQUFlLFNBQVM7Q0FDM0Q7O0NBRUEsVUFBVTtFQUNULEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSx5QkFBeUIsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0VBQzFGLEtBQUssVUFBVSxTQUFTO0NBQ3pCOztDQUVBLFdBQVc7RUFDVixLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUsdUJBQXVCLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztFQUN4RixLQUFLLFVBQVUsU0FBUztDQUN6Qjs7Q0FFQSxZQUFZLFVBQVU7RUFDckIsSUFBSSxDQUFDLEtBQUssVUFBVSxTQUFTLFFBQVEsR0FBRztHQUN2QyxLQUFLLFVBQVUsS0FBSyxRQUFRO0dBQzVCLEtBQUssZUFBZTtHQUNwQixLQUFLLE9BQU8sT0FBTztJQUNsQixNQUFNO0lBQ04sT0FBTztJQUNQO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7O0NBRUEsZUFBZSxVQUFVO0VBQ3hCLE1BQU0sUUFBUSxLQUFLLFVBQVUsUUFBUSxRQUFRO0VBQzdDLElBQUksVUFBVSxJQUFJO0dBQ2pCLEtBQUssVUFBVSxPQUFPLE9BQU8sQ0FBQztHQUM5QixJQUFJLENBQUMsS0FBSyxVQUFVLFFBQVE7SUFDM0IsSUFBSSxLQUFLLFVBQVU7S0FDbEIsSUFBSSxLQUFLLHdCQUF3QixLQUFLLE1BQU0sZ0JBQWdCLFlBQVksS0FBSyxNQUFNLFdBQVcsV0FBVyxLQUFLLFNBQVMsT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDO1VBQ3pJLEtBQUssU0FBUyxZQUFZO0lBQ2hDO0lBQ0EsS0FBSyxXQUFXO0dBQ2pCO0dBQ0EsS0FBSyxPQUFPLE9BQU87SUFDbEIsTUFBTTtJQUNOLE9BQU87SUFDUDtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Ozs7OztDQVdBLG9CQUFvQjtFQUNuQixPQUFPLEtBQUssVUFBVTtDQUN2Qjs7Ozs7Ozs7Ozs7Q0FXQSxhQUFhO0VBQ1osSUFBSSxDQUFDLEtBQUssTUFBTSxlQUFlLEtBQUssVUFBVSxFQUFFLE1BQU0sYUFBYSxDQUFDO0NBQ3JFOzs7Ozs7Ozs7OztDQVdBLE1BQU0sTUFBTSxTQUFTLGNBQWM7RUFDbEMsSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLFVBQVUsS0FBSyxVQUFVLE9BQU8sTUFBTSxZQUFZO0dBQ2hGLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLGNBQWMsZUFBZSxLQUFLLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztRQUN0RixJQUFJLEtBQUssVUFBVTtJQUN2QixLQUFLLFNBQVMsY0FBYztJQUM1QixPQUFPLEtBQUssU0FBUztHQUN0QjtFQUNEO0VBQ0EsSUFBSSxTQUFTLEtBQUssV0FBVyxPQUFPO0VBQ3BDLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUztHQUMxQixNQUFNLFdBQVcsS0FBSyxVQUFVLE1BQU0sTUFBTSxFQUFFLFFBQVEsT0FBTztHQUM3RCxJQUFJLFVBQVUsS0FBSyxXQUFXLFNBQVMsT0FBTztFQUMvQztFQUVDLElBQUksQ0FBQyxNQUFNLFFBQVEsS0FBSyxRQUFRLFFBQVEsR0FBRyxRQUFRLE1BQU0scUlBQXFJO0VBRS9MLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLE1BQU0scUJBQXFCLFdBQVc7R0FDckMsT0FBTyxlQUFlLFFBQVEsVUFBVTtJQUN2QyxZQUFZO0lBQ1osV0FBVztLQUNWLEtBQUssdUJBQXVCO0tBQzVCLE9BQU8sZ0JBQWdCO0lBQ3hCO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsTUFBTSxnQkFBZ0I7R0FDckIsTUFBTSxVQUFVLGNBQWMsS0FBSyxTQUFTLFlBQVk7R0FDeEQsTUFBTSw2QkFBNkI7SUFDbEMsTUFBTSxpQkFBaUI7S0FDdEIsUUFBUSxLQUFLO0tBQ2IsVUFBVSxLQUFLO0tBQ2YsTUFBTSxLQUFLO0lBQ1o7SUFDQSxrQkFBa0IsY0FBYztJQUNoQyxPQUFPO0dBQ1I7R0FDQSxNQUFNLGlCQUFpQixxQkFBcUI7R0FDNUMsS0FBSyx1QkFBdUI7R0FDNUIsSUFBSSxLQUFLLFFBQVEsV0FBVyxPQUFPLEtBQUssUUFBUSxVQUFVLFNBQVMsZ0JBQWdCLElBQUk7R0FDdkYsT0FBTyxRQUFRLGNBQWM7RUFDOUI7RUFDQSxNQUFNLDJCQUEyQjtHQUNoQyxNQUFNLFVBQVU7SUFDZjtJQUNBLFNBQVMsS0FBSztJQUNkLFVBQVUsS0FBSztJQUNmLFFBQVEsS0FBSztJQUNiLE9BQU8sS0FBSztJQUNaO0dBQ0Q7R0FDQSxrQkFBa0IsT0FBTztHQUN6QixPQUFPO0VBQ1I7RUFDQSxNQUFNLFVBQVUsbUJBQW1CO0VBQ25DLENBQUMsS0FBSyxlQUFlLGFBQWEsc0JBQXNCLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxRQUFRLFNBQUEsRUFBVyxRQUFRLFNBQVMsSUFBSTtFQUMzSCxLQUFLLGVBQWUsS0FBSztFQUN6QixJQUFJLEtBQUssTUFBTSxnQkFBZ0IsVUFBVSxLQUFLLE1BQU0sY0FBYyxRQUFRLGNBQWMsTUFBTSxLQUFLLFVBQVU7R0FDNUcsTUFBTTtHQUNOLE1BQU0sUUFBUSxjQUFjO0VBQzdCLENBQUM7RUFDRCxNQUFNLFVBQVUsS0FBSyxXQUFXLGNBQWM7R0FDN0MsZ0JBQWdCLGNBQWM7R0FDOUIsSUFBSSxRQUFRO0dBQ1osV0FBVyxVQUFVO0lBQ3BCLElBQUksaUJBQWlCLGtCQUFrQixNQUFNLFFBQVEsS0FBSyxTQUFTO0tBQ2xFLEdBQUcsS0FBSztLQUNSLGFBQWE7SUFDZCxDQUFDO0lBQ0QsZ0JBQWdCLE1BQU07R0FDdkI7R0FDQSxTQUFTLGNBQWMsVUFBVTtJQUNoQyxLQUFLLFVBQVU7S0FDZCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7R0FDRjtHQUNBLGVBQWU7SUFDZCxLQUFLLFVBQVUsRUFBRSxNQUFNLFFBQVEsQ0FBQztHQUNqQztHQUNBLGtCQUFrQjtJQUNqQixLQUFLLFVBQVUsRUFBRSxNQUFNLFdBQVcsQ0FBQztHQUNwQztHQUNBLE9BQU8sUUFBUSxRQUFRO0dBQ3ZCLFlBQVksUUFBUSxRQUFRO0dBQzVCLGFBQWEsUUFBUSxRQUFRO0dBQzdCLGNBQWM7RUFDZixDQUFDO0VBQ0QsSUFBSTtHQUNILE1BQU0sT0FBTyxNQUFNLFFBQVEsTUFBTTtHQUNqQyxJQUFJLFNBQVMsS0FBSyxHQUFHO0lBQ3VCLFFBQVEsTUFBTSx5SUFBeUksS0FBSyxXQUFXO0lBQ2xOLE1BQU0sSUFBSSxNQUFNLEdBQUcsS0FBSyxVQUFVLG1CQUFtQjtHQUN0RDtHQUNBLEtBQUssUUFBUSxJQUFJO0dBQ2pCLEtBQUssT0FBTyxPQUFPLFlBQVksTUFBTSxJQUFJO0dBQ3pDLEtBQUssT0FBTyxPQUFPLFlBQVksTUFBTSxLQUFLLE1BQU0sT0FBTyxJQUFJO0dBQzNELE9BQU87RUFDUixTQUFTLE9BQU87R0FDZixJQUFJLGlCQUFpQixnQkFBZ0I7SUFDcEMsSUFBSSxNQUFNLFFBQVEsT0FBTyxLQUFLLFNBQVM7U0FDbEMsSUFBSSxNQUFNLFFBQVE7S0FDdEIsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEdBQUcsTUFBTTtLQUN0QyxPQUFPLEtBQUssTUFBTTtJQUNuQjtHQUNEO0dBQ0EsS0FBSyxVQUFVO0lBQ2QsTUFBTTtJQUNOO0dBQ0QsQ0FBQztHQUNELEtBQUssT0FBTyxPQUFPLFVBQVUsT0FBTyxJQUFJO0dBQ3hDLEtBQUssT0FBTyxPQUFPLFlBQVksS0FBSyxNQUFNLE1BQU0sT0FBTyxJQUFJO0dBQzNELE1BQU07RUFDUCxVQUFVO0dBQ1QsSUFBSSxLQUFLLGFBQWEsU0FBUyxLQUFLLFdBQVcsS0FBSztHQUNwRCxLQUFLLFdBQVc7RUFDakI7Q0FDRDtDQUNBLFVBQVUsUUFBUTtFQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMxQixRQUFRLE9BQU8sTUFBZjtJQUNDLEtBQUssVUFBVSxPQUFPO0tBQ3JCLEdBQUc7S0FDSCxtQkFBbUIsT0FBTztLQUMxQixvQkFBb0IsT0FBTztJQUM1QjtJQUNBLEtBQUssU0FBUyxPQUFPO0tBQ3BCLEdBQUc7S0FDSCxhQUFhO0lBQ2Q7SUFDQSxLQUFLLFlBQVksT0FBTztLQUN2QixHQUFHO0tBQ0gsYUFBYTtJQUNkO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILEdBQUcsV0FBVyxNQUFNLE1BQU0sS0FBSyxPQUFPO0tBQ3RDLFdBQVcsT0FBTyxRQUFRO0lBQzNCO0lBQ0EsS0FBSztLQUNKLE1BQU0sV0FBVztNQUNoQixHQUFHO01BQ0gsR0FBRyxhQUFhLE9BQU8sTUFBTSxPQUFPLGFBQWE7TUFDakQsaUJBQWlCLE1BQU0sa0JBQWtCO01BQ3pDLEdBQUcsQ0FBQyxPQUFPLFVBQVU7T0FDcEIsYUFBYTtPQUNiLG1CQUFtQjtPQUNuQixvQkFBb0I7TUFDckI7S0FDRDtLQUNBLEtBQUssZUFBZSxPQUFPLFNBQVMsV0FBVyxLQUFLO0tBQ3BELE9BQU87SUFDUixLQUFLO0tBQ0osTUFBTSxRQUFRLE9BQU87S0FDckIsT0FBTztNQUNOLEdBQUc7TUFDSDtNQUNBLGtCQUFrQixNQUFNLG1CQUFtQjtNQUMzQyxnQkFBZ0IsS0FBSyxJQUFJO01BQ3pCLG1CQUFtQixNQUFNLG9CQUFvQjtNQUM3QyxvQkFBb0I7TUFDcEIsYUFBYTtNQUNiLFFBQVE7TUFDUixlQUFlO0tBQ2hCO0lBQ0QsS0FBSyxjQUFjLE9BQU87S0FDekIsR0FBRztLQUNILGVBQWU7SUFDaEI7SUFDQSxLQUFLLFlBQVksT0FBTztLQUN2QixHQUFHO0tBQ0gsR0FBRyxPQUFPO0lBQ1g7R0FDRDtFQUNEO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN6QixLQUFLLFVBQVUsTUFBTSxDQUFDLENBQUMsU0FBUyxhQUFhO0lBQzVDLFNBQVMsY0FBYztHQUN4QixDQUFDO0dBQ0QsS0FBSyxPQUFPLE9BQU87SUFDbEIsT0FBTztJQUNQLE1BQU07SUFDTjtHQUNELENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDtBQUNBLFNBQVMsV0FBVyxNQUFNLFNBQVM7Q0FDbEMsT0FBTztFQUNOLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsYUFBYSxTQUFTLFFBQVEsV0FBVyxJQUFJLGFBQWE7RUFDMUQsR0FBRyxTQUFTLEtBQUssS0FBSztHQUNyQixPQUFPO0dBQ1AsUUFBUTtFQUNUO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsYUFBYSxNQUFNLGVBQWU7Q0FDMUMsT0FBTztFQUNOO0VBQ0EsZUFBZSxpQkFBaUIsS0FBSyxJQUFJO0VBQ3pDLE9BQU87RUFDUCxlQUFlO0VBQ2YsUUFBUTtDQUNUO0FBQ0Q7QUFDQSxTQUFTQSxrQkFBZ0IsU0FBUztDQUNqQyxNQUFNLE9BQU8sT0FBTyxRQUFRLGdCQUFnQixhQUFhLFFBQVEsWUFBWSxJQUFJLFFBQVE7Q0FDekYsTUFBTSxVQUFVLFNBQVMsS0FBSztDQUM5QixNQUFNLHVCQUF1QixVQUFVLE9BQU8sUUFBUSx5QkFBeUIsYUFBYSxRQUFRLHFCQUFxQixJQUFJLFFBQVEsdUJBQXVCO0NBQzVKLE9BQU87RUFDTjtFQUNBLGlCQUFpQjtFQUNqQixlQUFlLFVBQVUsd0JBQXdCLEtBQUssSUFBSSxJQUFJO0VBQzlELE9BQU87RUFDUCxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQixvQkFBb0I7RUFDcEIsV0FBVztFQUNYLGVBQWU7RUFDZixRQUFRLFVBQVUsWUFBWTtFQUM5QixhQUFhO0NBQ2Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvZUEsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzlDO0NBQ0EsZ0JBQWdCLEtBQUs7Q0FDckIsNEJBQTRCLEtBQUs7Q0FDakMsaUJBQWlCLEtBQUs7Q0FDdEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsZ0NBQWdDLElBQUksSUFBSTtDQUN4QyxZQUFZLFFBQVEsU0FBUztFQUM1QixNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxVQUFVO0VBQ2YsS0FBSyxlQUFlO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixLQUFLLFdBQVcsT0FBTztDQUN4QjtDQUNBLGNBQWM7RUFDYixLQUFLLFVBQVUsS0FBSyxRQUFRLEtBQUssSUFBSTtDQUN0QztDQUNBLGNBQWM7RUFDYixJQUFJLEtBQUssVUFBVSxTQUFTLEdBQUc7R0FDOUIsS0FBSyxjQUFjLFlBQVksSUFBSTtHQUNuQyxJQUFJLG1CQUFtQixLQUFLLGVBQWUsS0FBSyxPQUFPLEdBQUcsS0FBSyxjQUFjO1FBQ3hFLEtBQUssYUFBYTtHQUN2QixLQUFLLGNBQWM7RUFDcEI7Q0FDRDtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRyxLQUFLLFFBQVE7Q0FDeEM7Ozs7OztDQU1BLHlCQUF5QjtFQUN4QixPQUFPLGNBQWMsS0FBSyxlQUFlLEtBQUssU0FBUyxLQUFLLFFBQVEsa0JBQWtCO0NBQ3ZGOzs7Ozs7Q0FNQSwyQkFBMkI7RUFDMUIsT0FBTyxjQUFjLEtBQUssZUFBZSxLQUFLLFNBQVMsS0FBSyxRQUFRLG9CQUFvQjtDQUN6Rjs7Ozs7O0NBTUEsVUFBVTtFQUNULEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLG1CQUFtQjtFQUN4QixLQUFLLHNCQUFzQjtFQUMzQixLQUFLLGNBQWMsZUFBZSxJQUFJO0NBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxXQUFXLFNBQVM7RUFDbkIsTUFBTSxjQUFjLEtBQUs7RUFDekIsTUFBTSxZQUFZLEtBQUs7RUFDdkIsS0FBSyxVQUFVLEtBQUssUUFBUSxvQkFBb0IsT0FBTztFQUN2RCxJQUFJLEtBQUssUUFBUSxZQUFZLEtBQUssS0FBSyxPQUFPLEtBQUssUUFBUSxZQUFZLGFBQWEsT0FBTyxLQUFLLFFBQVEsWUFBWSxjQUFjLE9BQU8sa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLFdBQVcsTUFBTSxJQUFJLE1BQU0sdUVBQXVFO0VBQzNTLEtBQUssYUFBYTtFQUNsQixLQUFLLGNBQWMsV0FBVyxLQUFLLE9BQU87RUFDMUMsSUFBSSxZQUFZLGNBQWMsQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsT0FBTztHQUNsSCxNQUFNO0dBQ04sT0FBTyxLQUFLO0dBQ1osVUFBVTtFQUNYLENBQUM7RUFDRCxNQUFNLFVBQVUsS0FBSyxhQUFhO0VBQ2xDLElBQUksV0FBVyxzQkFBc0IsS0FBSyxlQUFlLFdBQVcsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLGNBQWM7RUFDbkgsS0FBSyxhQUFhO0VBQ2xCLElBQUksWUFBWSxLQUFLLGtCQUFrQixhQUFhLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxrQkFBa0IsWUFBWSxTQUFTLEtBQUssYUFBYSxLQUFLLGtCQUFrQixLQUFLLFFBQVEsV0FBVyxLQUFLLGFBQWEsTUFBTSxrQkFBa0IsWUFBWSxXQUFXLEtBQUssYUFBYSxJQUFJLEtBQUssb0JBQW9CO0VBQzVVLE1BQU0sc0JBQXNCLEtBQUssd0JBQXdCO0VBQ3pELElBQUksWUFBWSxLQUFLLGtCQUFrQixhQUFhLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxrQkFBa0IsWUFBWSxTQUFTLEtBQUssYUFBYSxLQUFLLHdCQUF3QixLQUFLLDBCQUEwQixLQUFLLHVCQUF1QixtQkFBbUI7Q0FDelI7Ozs7Ozs7Q0FPQSxvQkFBb0IsU0FBUztFQUM1QixNQUFNLFFBQVEsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLE9BQU87RUFDdEUsTUFBTSxTQUFTLEtBQUssYUFBYSxPQUFPLE9BQU87RUFDL0MsSUFBSSxDQUFDLG9CQUFvQixLQUFLLGlCQUFpQixHQUFHLE1BQU0sR0FBRztHQUMxRCxLQUFLLGlCQUFpQjtHQUN0QixLQUFLLHdCQUF3QixLQUFLO0dBQ2xDLEtBQUssc0JBQXNCLEtBQUssY0FBYztFQUMvQztFQUNBLE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7OztDQWFBLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7OztDQU9BLFlBQVksUUFBUSxlQUFlO0VBQ2xDLE9BQU8sSUFBSSxNQUFNLFFBQVEsRUFBRSxNQUFNLFFBQVEsUUFBUTtHQUNoRCxLQUFLLFVBQVUsR0FBRztHQUNsQixnQkFBZ0IsR0FBRztHQUNuQixPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUc7RUFDL0IsRUFBRSxDQUFDO0NBQ0o7Ozs7Ozs7Q0FPQSxVQUFVLEtBQUs7RUFDZCxLQUFLLGNBQWMsSUFBSSxHQUFHO0NBQzNCOzs7O0NBSUEsa0JBQWtCO0VBQ2pCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7OztDQVdBLFFBQVEsRUFBRSxHQUFHLFlBQVksQ0FBQyxHQUFHO0VBQzVCLE9BQU8sS0FBSyxNQUFNLEVBQUUsR0FBRyxRQUFRLENBQUM7Q0FDakM7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLGdCQUFnQixTQUFTO0VBQ3hCLE1BQU0sbUJBQW1CLEtBQUssUUFBUSxvQkFBb0IsT0FBTztFQUNqRSxNQUFNLFFBQVEsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLGdCQUFnQjtFQUMvRSxJQUFJLG9CQUFvQixDQUFDO0VBQ3pCLElBQUk7RUFDSixNQUFNLGVBQWUsSUFBSSxTQUFTLFlBQVk7R0FDN0MsZUFBZTtHQUNmLGNBQWMsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLFdBQVcsVUFBVTtJQUMvRCxJQUFJLE1BQU0sU0FBUyxhQUFhLE1BQU0sTUFBTSxjQUFjLE1BQU0sYUFBYSxNQUFNLE1BQU0sU0FBUyxLQUFLLEdBQUc7S0FDekcsWUFBWTtLQUNaLFFBQVEsS0FBSyxhQUFhLE9BQU8sZ0JBQWdCLENBQUM7SUFDbkQ7R0FDRCxDQUFDO0VBQ0YsQ0FBQztFQUNELE9BQU8sUUFBUSxLQUFLLENBQUMsTUFBTSxNQUFNLENBQUMsQ0FBQyxXQUFXO0dBQzdDLE1BQU0sU0FBUyxLQUFLLGFBQWEsT0FBTyxnQkFBZ0I7R0FDeEQsZUFBZSxNQUFNO0dBQ3JCLE9BQU87RUFDUixDQUFDLENBQUMsQ0FBQyxjQUFjO0dBQ2hCLFlBQVk7RUFDYixDQUFDLEdBQUcsWUFBWSxDQUFDO0NBQ2xCO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLE9BQU8sS0FBSyxjQUFjO0dBQ3pCLEdBQUc7R0FDSCxlQUFlLGFBQWEsaUJBQWlCO0VBQzlDLENBQUMsQ0FBQyxDQUFDLFdBQVc7R0FDYixLQUFLLGFBQWE7R0FDbEIsT0FBTyxLQUFLO0VBQ2IsQ0FBQztDQUNGO0NBQ0EsY0FBYyxjQUFjO0VBQzNCLEtBQUssYUFBYTtFQUNsQixJQUFJLFVBQVUsS0FBSyxjQUFjLE1BQU0sS0FBSyxTQUFTLFlBQVk7RUFDakUsSUFBSSxDQUFDLGNBQWMsY0FBYyxVQUFVLFFBQVEsTUFBTSxJQUFJO0VBQzdELE9BQU87Q0FDUjtDQUNBLHFCQUFxQixTQUFTO0VBQzdCLE9BQU8sQ0FBQ0MsV0FBUyxLQUFLLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxTQUFTLGVBQWUsT0FBTztDQUN0SDtDQUNBLHNCQUFzQjtFQUNyQixLQUFLLG1CQUFtQjtFQUN4QixNQUFNLFlBQVksa0JBQWtCLEtBQUssUUFBUSxXQUFXLEtBQUssYUFBYTtFQUM5RSxJQUFJLEtBQUssZUFBZSxXQUFXLENBQUMsS0FBSyxxQkFBcUIsU0FBUyxHQUFHO0VBQzFFLE1BQU0sVUFBVSxlQUFlLEtBQUssZUFBZSxlQUFlLFNBQVMsSUFBSTtFQUMvRSxLQUFLLGtCQUFrQixlQUFlLGlCQUFpQjtHQUN0RCxJQUFJLENBQUMsS0FBSyxlQUFlLFNBQVMsS0FBSyxhQUFhO0VBQ3JELEdBQUcsT0FBTztDQUNYO0NBQ0EsMEJBQTBCO0VBQ3pCLE9BQU8sa0JBQWtCLEtBQUssUUFBUSxpQkFBaUIsS0FBSyxhQUFhLEtBQUs7Q0FDL0U7Q0FDQSx1QkFBdUIsY0FBYztFQUNwQyxLQUFLLHNCQUFzQjtFQUMzQixLQUFLLDBCQUEwQjtFQUMvQixJQUFJLEtBQUssNEJBQTRCLEtBQUssQ0FBQyxLQUFLLHFCQUFxQixLQUFLLHVCQUF1QixHQUFHO0VBQ3BHLEtBQUsscUJBQXFCLGVBQWUsa0JBQWtCO0dBQzFELElBQUksS0FBSyxRQUFRLCtCQUErQixhQUFhLFVBQVUsR0FBRyxLQUFLLGNBQWM7RUFDOUYsR0FBRyxLQUFLLHVCQUF1QjtDQUNoQztDQUNBLGdCQUFnQjtFQUNmLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssdUJBQXVCLEtBQUssd0JBQXdCLENBQUM7Q0FDM0Q7Q0FDQSxxQkFBcUI7RUFDcEIsSUFBSSxLQUFLLG9CQUFvQixLQUFLLEdBQUc7R0FDcEMsZUFBZSxhQUFhLEtBQUssZUFBZTtHQUNoRCxLQUFLLGtCQUFrQixLQUFLO0VBQzdCO0NBQ0Q7Q0FDQSx3QkFBd0I7RUFDdkIsSUFBSSxLQUFLLHVCQUF1QixLQUFLLEdBQUc7R0FDdkMsZUFBZSxjQUFjLEtBQUssa0JBQWtCO0dBQ3BELEtBQUsscUJBQXFCLEtBQUs7RUFDaEM7Q0FDRDtDQUNBLGFBQWEsT0FBTyxTQUFTO0VBQzVCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLE1BQU0sa0JBQWtCLEtBQUs7RUFDN0IsTUFBTSxvQkFBb0IsS0FBSztFQUMvQixNQUFNLG9CQUFvQixVQUFVLFlBQVksTUFBTSxRQUFRLEtBQUs7RUFDbkUsTUFBTSxFQUFFLFVBQVU7RUFDbEIsSUFBSSxXQUFXLEVBQUUsR0FBRyxNQUFNO0VBQzFCLElBQUksb0JBQW9CO0VBQ3hCLElBQUk7RUFDSixJQUFJLFFBQVEsb0JBQW9CO0dBQy9CLE1BQU0sVUFBVSxLQUFLLGFBQWE7R0FDbEMsTUFBTSxlQUFlLENBQUMsV0FBVyxtQkFBbUIsT0FBTyxPQUFPO0dBQ2xFLE1BQU0sa0JBQWtCLFdBQVcsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLFdBQVc7R0FDL0YsSUFBSSxnQkFBZ0IsaUJBQWlCLFdBQVc7SUFDL0MsR0FBRztJQUNILEdBQUcsV0FBVyxNQUFNLE1BQU0sTUFBTSxPQUFPO0dBQ3hDO0dBQ0EsSUFBSSxRQUFRLHVCQUF1QixlQUFlLFNBQVMsY0FBYztFQUMxRTtFQUNBLElBQUksRUFBRSxPQUFPLGdCQUFnQixXQUFXO0VBQ3hDLE9BQU8sU0FBUztFQUNoQixJQUFJLGFBQWE7RUFDakIsSUFBSSxRQUFRLG9CQUFvQixLQUFLLEtBQUssU0FBUyxLQUFLLEtBQUssV0FBVyxXQUFXO0dBQ2xGLElBQUk7R0FDSixJQUFJLFlBQVkscUJBQXFCLFFBQVEsb0JBQW9CLG1CQUFtQixpQkFBaUI7SUFDcEcsa0JBQWtCLFdBQVc7SUFDN0IsYUFBYTtHQUNkLE9BQU8sa0JBQWtCLE9BQU8sUUFBUSxvQkFBb0IsYUFBYSxRQUFRLGdCQUFnQixLQUFLLDJCQUEyQixNQUFNLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxRQUFRO0dBQ3ZMLElBQUksb0JBQW9CLEtBQUssR0FBRztJQUMvQixTQUFTO0lBQ1QsT0FBTyxZQUFZLFlBQVksTUFBTSxpQkFBaUIsT0FBTztJQUM3RCxvQkFBb0I7R0FDckI7RUFDRDtFQUNBLElBQUksUUFBUSxVQUFVLFNBQVMsS0FBSyxLQUFLLENBQUMsWUFBWTtHQUNyRCxJQUFJLGNBQWMsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLFdBQVcsS0FBSyxXQUFXLE9BQU8sS0FBSztRQUM5RixJQUFJO0lBQ1IsS0FBSyxZQUFZLFFBQVE7SUFDekIsT0FBTyxRQUFRLE9BQU8sSUFBSTtJQUMxQixPQUFPLFlBQVksWUFBWSxNQUFNLE1BQU0sT0FBTztJQUNsRCxLQUFLLGdCQUFnQjtJQUNyQixLQUFLLGVBQWU7R0FDckIsU0FBUyxhQUFhO0lBQ3JCLEtBQUssZUFBZTtHQUNyQjtFQUNELE9BQU8sSUFBSSxTQUFTLEtBQUssR0FBRyxLQUFLLGVBQWU7RUFDaEQsSUFBSSxLQUFLLGNBQWM7R0FDdEIsUUFBUSxLQUFLO0dBQ2IsT0FBTyxLQUFLO0dBQ1osaUJBQWlCLEtBQUssSUFBSTtHQUMxQixTQUFTO0dBQ1Qsb0JBQW9CO0VBQ3JCO0VBQ0EsTUFBTSxhQUFhLFNBQVMsZ0JBQWdCO0VBQzVDLE1BQU0sWUFBWSxXQUFXO0VBQzdCLE1BQU0sVUFBVSxXQUFXO0VBQzNCLE1BQU0sWUFBWSxhQUFhO0VBQy9CLE1BQU0sVUFBVSxTQUFTLEtBQUs7RUFDOUIsT0FBTztHQUNOO0dBQ0EsYUFBYSxTQUFTO0dBQ3RCO0dBQ0EsV0FBVyxXQUFXO0dBQ3RCO0dBQ0Esa0JBQWtCO0dBQ2xCO0dBQ0E7R0FDQSxlQUFlLFNBQVM7R0FDeEI7R0FDQTtHQUNBLGNBQWMsU0FBUztHQUN2QixlQUFlLFNBQVM7R0FDeEIsa0JBQWtCLFNBQVM7R0FDM0IsV0FBVyxNQUFNLFVBQVU7R0FDM0IscUJBQXFCLFNBQVMsa0JBQWtCLGtCQUFrQixtQkFBbUIsU0FBUyxtQkFBbUIsa0JBQWtCO0dBQ25JO0dBQ0EsY0FBYyxjQUFjLENBQUM7R0FDN0IsZ0JBQWdCLFdBQVcsQ0FBQztHQUM1QixVQUFVLFNBQVMsZ0JBQWdCO0dBQ25DO0dBQ0EsZ0JBQWdCLFdBQVc7R0FDM0IsU0FBUyxRQUFRLE9BQU8sT0FBTztHQUMvQixTQUFTLEtBQUs7R0FDZCxXQUFXLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNO0VBQzFEO0NBQ0Q7Ozs7OztDQU1BLGVBQWU7RUFDZCxNQUFNLGFBQWEsS0FBSztFQUN4QixNQUFNLGFBQWEsS0FBSyxhQUFhLEtBQUssZUFBZSxLQUFLLE9BQU87RUFDckUsS0FBSyxzQkFBc0IsS0FBSyxjQUFjO0VBQzlDLEtBQUssd0JBQXdCLEtBQUs7RUFDbEMsSUFBSSxLQUFLLG9CQUFvQixTQUFTLEtBQUssR0FBRyxLQUFLLDRCQUE0QixLQUFLO0VBQ3BGLElBQUksb0JBQW9CLFlBQVksVUFBVSxHQUFHO0VBQ2pELEtBQUssaUJBQWlCO0VBQ3RCLE1BQU0sOEJBQThCO0dBQ25DLElBQUksQ0FBQyxZQUFZLE9BQU87R0FDeEIsTUFBTSxFQUFFLHdCQUF3QixLQUFLO0dBQ3JDLE1BQU0sMkJBQTJCLE9BQU8sd0JBQXdCLGFBQWEsb0JBQW9CLElBQUk7R0FDckcsSUFBSSw2QkFBNkIsU0FBUyxDQUFDLDRCQUE0QixDQUFDLEtBQUssY0FBYyxNQUFNLE9BQU87R0FDeEcsTUFBTSxnQkFBZ0IsSUFBSSxJQUFJLDRCQUE0QixLQUFLLGFBQWE7R0FDNUUsSUFBSSxLQUFLLFFBQVEsY0FBYyxjQUFjLElBQUksT0FBTztHQUN4RCxPQUFPLE9BQU8sS0FBSyxLQUFLLGNBQWMsQ0FBQyxDQUFDLE1BQU0sUUFBUTtJQUNyRCxNQUFNLFdBQVc7SUFDakIsT0FBTyxLQUFLLGVBQWUsY0FBYyxXQUFXLGFBQWEsY0FBYyxJQUFJLFFBQVE7R0FDNUYsQ0FBQztFQUNGO0VBQ0EsTUFBTSxrQkFBa0Isc0JBQXNCO0VBQzlDLGNBQWMsWUFBWTtHQUN6QixJQUFJLGlCQUFpQixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ3pELFNBQVMsS0FBSyxjQUFjO0dBQzdCLENBQUM7R0FDRCxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsT0FBTztJQUNuQyxPQUFPLEtBQUs7SUFDWixNQUFNO0dBQ1AsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLGVBQWU7RUFDZCxNQUFNLFFBQVEsS0FBSyxRQUFRLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxTQUFTLEtBQUssT0FBTztFQUMzRSxJQUFJLFVBQVUsS0FBSyxlQUFlO0VBQ2xDLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssNEJBQTRCLE1BQU07RUFDdkMsSUFBSSxLQUFLLGFBQWEsR0FBRztHQUN4QixXQUFXLGVBQWUsSUFBSTtHQUM5QixNQUFNLFlBQVksSUFBSTtFQUN2QjtDQUNEOztDQUVBLGdCQUFnQjtFQUNmLEtBQUssYUFBYTtFQUNsQixJQUFJLEtBQUssYUFBYSxHQUFHLEtBQUssY0FBYztDQUM3QztBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxTQUFTO0NBQzFDLE9BQU8sa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxLQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sV0FBVyxXQUFXLGtCQUFrQixRQUFRLGNBQWMsS0FBSyxNQUFNO0FBQ3JMO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTyxTQUFTO0NBQzNDLE9BQU8sa0JBQWtCLE9BQU8sT0FBTyxLQUFLLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSyxjQUFjLE9BQU8sU0FBUyxRQUFRLGNBQWM7QUFDaEk7QUFDQSxTQUFTLGNBQWMsT0FBTyxTQUFTLE9BQU87Q0FDN0MsSUFBSSxrQkFBa0IsUUFBUSxTQUFTLEtBQUssTUFBTSxTQUFTLGtCQUFrQixRQUFRLFdBQVcsS0FBSyxNQUFNLFVBQVU7RUFDcEgsTUFBTSxRQUFRLGtCQUFrQixPQUFPLEtBQUs7RUFDNUMsT0FBTyxVQUFVLFlBQVksVUFBVSxTQUFTLFFBQVEsT0FBTyxPQUFPO0NBQ3ZFO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxzQkFBc0IsT0FBTyxXQUFXLFNBQVMsYUFBYTtDQUN0RSxRQUFRLFVBQVUsYUFBYSxrQkFBa0IsWUFBWSxTQUFTLEtBQUssTUFBTSxXQUFXLENBQUMsUUFBUSxZQUFZLE1BQU0sTUFBTSxXQUFXLFlBQVksUUFBUSxPQUFPLE9BQU87QUFDM0s7QUFDQSxTQUFTLFFBQVEsT0FBTyxTQUFTO0NBQ2hDLE9BQU8sa0JBQWtCLFFBQVEsU0FBUyxLQUFLLE1BQU0sU0FBUyxNQUFNLGNBQWMsa0JBQWtCLFFBQVEsV0FBVyxLQUFLLENBQUM7QUFDOUg7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxYUEsSUFBSSx3QkFBd0IsY0FBYyxjQUFjO0NBQ3ZELFlBQVksUUFBUSxTQUFTO0VBQzVCLE1BQU0sUUFBUSxPQUFPO0NBQ3RCO0NBQ0EsY0FBYztFQUNiLE1BQU0sWUFBWTtFQUNsQixLQUFLLGdCQUFnQixLQUFLLGNBQWMsS0FBSyxJQUFJO0VBQ2pELEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtDQUMxRDs7Ozs7OztDQU9BLFdBQVcsU0FBUztFQUNuQixRQUFRLFFBQVE7RUFDaEIsTUFBTSxXQUFXLE9BQU87Q0FDekI7Ozs7Ozs7Q0FPQSxvQkFBb0IsU0FBUztFQUM1QixRQUFRLFFBQVE7RUFDaEIsT0FBTyxNQUFNLG9CQUFvQixPQUFPO0NBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGNBQWMsU0FBUztFQUN0QixPQUFPLEtBQUssTUFBTTtHQUNqQixHQUFHO0dBQ0gsTUFBTSxFQUFFLFdBQVcsRUFBRSxXQUFXLFVBQVUsRUFBRTtFQUM3QyxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQkEsa0JBQWtCLFNBQVM7RUFDMUIsT0FBTyxLQUFLLE1BQU07R0FDakIsR0FBRztHQUNILE1BQU0sRUFBRSxXQUFXLEVBQUUsV0FBVyxXQUFXLEVBQUU7RUFDOUMsQ0FBQztDQUNGO0NBQ0EsYUFBYSxPQUFPLFNBQVM7RUFDNUIsTUFBTSxFQUFFLFVBQVU7RUFDbEIsTUFBTSxlQUFlLE1BQU0sYUFBYSxPQUFPLE9BQU87RUFDdEQsTUFBTSxFQUFFLFlBQVksY0FBYyxTQUFTLG1CQUFtQjtFQUM5RCxNQUFNLGlCQUFpQixNQUFNLFdBQVcsV0FBVztFQUNuRCxNQUFNLHVCQUF1QixXQUFXLG1CQUFtQjtFQUMzRCxNQUFNLHFCQUFxQixjQUFjLG1CQUFtQjtFQUM1RCxNQUFNLDJCQUEyQixXQUFXLG1CQUFtQjtFQUMvRCxNQUFNLHlCQUF5QixjQUFjLG1CQUFtQjtFQUNoRSxPQUFPO0dBQ04sR0FBRztHQUNILGVBQWUsS0FBSztHQUNwQixtQkFBbUIsS0FBSztHQUN4QixhQUFhLFlBQVksU0FBUyxNQUFNLElBQUk7R0FDNUMsaUJBQWlCLGdCQUFnQixTQUFTLE1BQU0sSUFBSTtHQUNwRDtHQUNBO0dBQ0E7R0FDQTtHQUNBLGdCQUFnQixrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQztHQUM1RCxjQUFjLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDO0VBQ3ZEO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyR0EsSUFBSSxXQUFXLGNBQWMsVUFBVTtDQUN0QztDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksUUFBUTtFQUNuQixNQUFNO0VBQ04sS0FBSyxVQUFVLE9BQU87RUFDdEIsS0FBSyxhQUFhLE9BQU87RUFDekIsS0FBSyxpQkFBaUIsT0FBTztFQUM3QixLQUFLLGFBQWEsQ0FBQztFQUNuQixLQUFLLFFBQVEsT0FBTyxTQUFTLGdCQUFnQjtFQUM3QyxLQUFLLFdBQVcsT0FBTyxPQUFPO0VBQzlCLEtBQUssV0FBVztDQUNqQjs7Q0FFQSxXQUFXLFNBQVM7RUFDbkIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxhQUFhLEtBQUssUUFBUSxNQUFNO0NBQ3RDOzs7O0NBSUEsSUFBSSxPQUFPO0VBQ1YsT0FBTyxLQUFLLFFBQVE7Q0FDckI7O0NBRUEsWUFBWSxVQUFVO0VBQ3JCLElBQUksQ0FBQyxLQUFLLFdBQVcsU0FBUyxRQUFRLEdBQUc7R0FDeEMsS0FBSyxXQUFXLEtBQUssUUFBUTtHQUM3QixLQUFLLGVBQWU7R0FDcEIsS0FBSyxlQUFlLE9BQU87SUFDMUIsTUFBTTtJQUNOLFVBQVU7SUFDVjtHQUNELENBQUM7RUFDRjtDQUNEOztDQUVBLGVBQWUsVUFBVTtFQUN4QixLQUFLLGFBQWEsS0FBSyxXQUFXLFFBQVEsTUFBTSxNQUFNLFFBQVE7RUFDOUQsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZUFBZSxPQUFPO0dBQzFCLE1BQU07R0FDTixVQUFVO0dBQ1Y7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxpQkFBaUI7RUFDaEIsSUFBSSxDQUFDLEtBQUssV0FBVyxRQUFRO0dBQzVCLElBQUksS0FBSyxNQUFNLFdBQVcsV0FBVyxLQUFLLFdBQVc7UUFDaEQsS0FBSyxlQUFlLE9BQU8sSUFBSTtFQUNyQztDQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLFdBQVc7RUFDVixPQUFPLEtBQUssVUFBVSxTQUFTLE1BQU0sS0FBSyxNQUFNLFdBQVcsWUFBWSxLQUFLLFFBQVEsS0FBSyxNQUFNLFNBQVMsSUFBSSxRQUFRLFFBQVE7Q0FDN0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0ErQkEsTUFBTSxRQUFRLFdBQVc7RUFDeEIsTUFBTSxtQkFBbUI7R0FDeEIsS0FBSyxVQUFVLEVBQUUsTUFBTSxXQUFXLENBQUM7RUFDcEM7RUFDQSxNQUFNLG9CQUFvQjtHQUN6QixRQUFRLEtBQUs7R0FDYixNQUFNLEtBQUssUUFBUTtHQUNuQixhQUFhLEtBQUssUUFBUTtFQUMzQjtFQUNBLE1BQU0sVUFBVSxLQUFLLFdBQVcsY0FBYztHQUM3QyxVQUFVO0lBQ1QsSUFBSSxDQUFDLEtBQUssUUFBUSxZQUFZLE9BQU8sUUFBUSx1QkFBdUIsSUFBSSxNQUFNLHFCQUFxQixDQUFDO0lBQ3BHLE9BQU8sS0FBSyxRQUFRLFdBQVcsV0FBVyxpQkFBaUI7R0FDNUQ7R0FDQSxTQUFTLGNBQWMsVUFBVTtJQUNoQyxLQUFLLFVBQVU7S0FDZCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7R0FDRjtHQUNBLGVBQWU7SUFDZCxLQUFLLFVBQVUsRUFBRSxNQUFNLFFBQVEsQ0FBQztHQUNqQztHQUNBO0dBQ0EsT0FBTyxLQUFLLFFBQVEsU0FBUztHQUM3QixZQUFZLEtBQUssUUFBUTtHQUN6QixhQUFhLEtBQUssUUFBUTtHQUMxQixjQUFjLEtBQUssZUFBZSxPQUFPLElBQUk7RUFDOUMsQ0FBQztFQUNELE1BQU0sV0FBVyxLQUFLLE1BQU0sV0FBVztFQUN2QyxNQUFNLFdBQVcsQ0FBQyxRQUFRLFNBQVM7RUFDbkMsSUFBSTtHQUNILElBQUksVUFBVSxXQUFXO1FBQ3BCO0lBQ0osS0FBSyxVQUFVO0tBQ2QsTUFBTTtLQUNOO0tBQ0E7SUFDRCxDQUFDO0lBQ0QsSUFBSSxLQUFLLGVBQWUsT0FBTyxVQUFVLE1BQU0sS0FBSyxlQUFlLE9BQU8sU0FBUyxXQUFXLE1BQU0saUJBQWlCO0lBQ3JILE1BQU0sVUFBVSxNQUFNLEtBQUssUUFBUSxXQUFXLFdBQVcsaUJBQWlCO0lBQzFFLElBQUksWUFBWSxLQUFLLE1BQU0sU0FBUyxLQUFLLFVBQVU7S0FDbEQsTUFBTTtLQUNOO0tBQ0E7S0FDQTtJQUNELENBQUM7R0FDRjtHQUNBLE1BQU0sT0FBTyxNQUFNLFFBQVEsTUFBTTtHQUNqQyxNQUFNLEtBQUssZUFBZSxPQUFPLFlBQVksTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLE1BQU0saUJBQWlCO0dBQ3pHLE1BQU0sS0FBSyxRQUFRLFlBQVksTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLGlCQUFpQjtHQUNyRixNQUFNLEtBQUssZUFBZSxPQUFPLFlBQVksTUFBTSxNQUFNLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLE1BQU0saUJBQWlCO0dBQzFILE1BQU0sS0FBSyxRQUFRLFlBQVksTUFBTSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQzNGLEtBQUssVUFBVTtJQUNkLE1BQU07SUFDTjtHQUNELENBQUM7R0FDRCxPQUFPO0VBQ1IsU0FBUyxPQUFPO0dBQ2YsSUFBSTtJQUNILE1BQU0sS0FBSyxlQUFlLE9BQU8sVUFBVSxPQUFPLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDekcsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxJQUFJO0lBQ0gsTUFBTSxLQUFLLFFBQVEsVUFBVSxPQUFPLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQ3JGLFNBQVMsR0FBRztJQUNYLFFBQVEsT0FBTyxDQUFDO0dBQ2pCO0dBQ0EsSUFBSTtJQUNILE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxLQUFLLEdBQUcsT0FBTyxLQUFLLE1BQU0sV0FBVyxLQUFLLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtHQUM5SCxTQUFTLEdBQUc7SUFDWCxRQUFRLE9BQU8sQ0FBQztHQUNqQjtHQUNBLElBQUk7SUFDSCxNQUFNLEtBQUssUUFBUSxZQUFZLEtBQUssR0FBRyxPQUFPLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQy9GLFNBQVMsR0FBRztJQUNYLFFBQVEsT0FBTyxDQUFDO0dBQ2pCO0dBQ0EsS0FBSyxVQUFVO0lBQ2QsTUFBTTtJQUNOO0dBQ0QsQ0FBQztHQUNELE1BQU07RUFDUCxVQUFVO0dBQ1QsSUFBSSxLQUFLLGFBQWEsU0FBUyxLQUFLLFdBQVcsS0FBSztHQUNwRCxLQUFLLGVBQWUsUUFBUSxJQUFJO0VBQ2pDO0NBQ0Q7Q0FDQSxVQUFVLFFBQVE7RUFDakIsTUFBTSxXQUFXLFVBQVU7R0FDMUIsUUFBUSxPQUFPLE1BQWY7SUFDQyxLQUFLLFVBQVUsT0FBTztLQUNyQixHQUFHO0tBQ0gsY0FBYyxPQUFPO0tBQ3JCLGVBQWUsT0FBTztJQUN2QjtJQUNBLEtBQUssU0FBUyxPQUFPO0tBQ3BCLEdBQUc7S0FDSCxVQUFVO0lBQ1g7SUFDQSxLQUFLLFlBQVksT0FBTztLQUN2QixHQUFHO0tBQ0gsVUFBVTtJQUNYO0lBQ0EsS0FBSyxXQUFXLE9BQU87S0FDdEIsR0FBRztLQUNILFNBQVMsT0FBTztLQUNoQixNQUFNLEtBQUs7S0FDWCxjQUFjO0tBQ2QsZUFBZTtLQUNmLE9BQU87S0FDUCxVQUFVLE9BQU87S0FDakIsUUFBUTtLQUNSLFdBQVcsT0FBTztLQUNsQixhQUFhLEtBQUssSUFBSTtJQUN2QjtJQUNBLEtBQUssV0FBVyxPQUFPO0tBQ3RCLEdBQUc7S0FDSCxNQUFNLE9BQU87S0FDYixjQUFjO0tBQ2QsZUFBZTtLQUNmLE9BQU87S0FDUCxRQUFRO0tBQ1IsVUFBVTtJQUNYO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILE1BQU0sS0FBSztLQUNYLE9BQU8sT0FBTztLQUNkLGNBQWMsTUFBTSxlQUFlO0tBQ25DLGVBQWUsT0FBTztLQUN0QixVQUFVO0tBQ1YsUUFBUTtJQUNUO0dBQ0Q7RUFDRDtFQUNBLEtBQUssUUFBUSxRQUFRLEtBQUssS0FBSztFQUMvQixjQUFjLFlBQVk7R0FDekIsS0FBSyxXQUFXLFNBQVMsYUFBYTtJQUNyQyxTQUFTLGlCQUFpQixNQUFNO0dBQ2pDLENBQUM7R0FDRCxLQUFLLGVBQWUsT0FBTztJQUMxQixVQUFVO0lBQ1YsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGLENBQUM7Q0FDRjtBQUNEO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDMUIsT0FBTztFQUNOLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLE9BQU87RUFDUCxjQUFjO0VBQ2QsZUFBZTtFQUNmLFVBQVU7RUFDVixRQUFRO0VBQ1IsV0FBVyxLQUFLO0VBQ2hCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2pSQSxJQUFJLGdCQUFnQixjQUFjLGFBQWE7Q0FDOUM7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxTQUFTLENBQUMsR0FBRztFQUN4QixNQUFNO0VBQ04sS0FBSyxTQUFTO0VBQ2QsS0FBSyw2QkFBNkIsSUFBSSxJQUFJO0VBQzFDLEtBQUssMEJBQTBCLElBQUksSUFBSTtFQUN2QyxLQUFLLGNBQWM7Q0FDcEI7O0NBRUEsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM3QixNQUFNLFdBQVcsSUFBSSxTQUFTO0dBQzdCO0dBQ0EsZUFBZTtHQUNmLFlBQVksRUFBRSxLQUFLO0dBQ25CLFNBQVMsT0FBTyx1QkFBdUIsT0FBTztHQUM5QztFQUNELENBQUM7RUFDRCxLQUFLLElBQUksUUFBUTtFQUNqQixPQUFPO0NBQ1I7O0NBRUEsSUFBSSxVQUFVO0VBQ2IsS0FBSyxXQUFXLElBQUksUUFBUTtFQUM1QixNQUFNLFFBQVEsU0FBUyxRQUFRO0VBQy9CLElBQUksT0FBTyxVQUFVLFVBQVU7R0FDOUIsTUFBTSxrQkFBa0IsS0FBSyxRQUFRLElBQUksS0FBSztHQUM5QyxJQUFJLGlCQUFpQixnQkFBZ0IsS0FBSyxRQUFRO1FBQzdDLEtBQUssUUFBUSxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUM7RUFDeEM7RUFDQSxLQUFLLE9BQU87R0FDWCxNQUFNO0dBQ047RUFDRCxDQUFDO0NBQ0Y7O0NBRUEsT0FBTyxVQUFVO0VBQ2hCLElBQUksS0FBSyxXQUFXLE9BQU8sUUFBUSxHQUFHO0dBQ3JDLE1BQU0sUUFBUSxTQUFTLFFBQVE7R0FDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtJQUM5QixNQUFNLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxLQUFLO0lBQzlDLElBQUksaUJBQWlCO0tBQ3BCLElBQUksZ0JBQWdCLFNBQVMsR0FBRztNQUMvQixNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsUUFBUTtNQUM5QyxJQUFJLFVBQVUsSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLENBQUM7S0FDbEQsT0FBTyxJQUFJLGdCQUFnQixPQUFPLFVBQVUsS0FBSyxRQUFRLE9BQU8sS0FBSztJQUN0RTtHQUNEO0VBQ0Q7RUFDQSxLQUFLLE9BQU87R0FDWCxNQUFNO0dBQ047RUFDRCxDQUFDO0NBQ0Y7O0NBRUEsT0FBTyxVQUFVO0VBQ2hCLE1BQU0sUUFBUSxTQUFTLFFBQVE7RUFDL0IsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM5QixNQUFNLHVCQUF1QixLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU0sRUFBRSxNQUFNLFdBQVcsU0FBUztHQUM5RixPQUFPLENBQUMsd0JBQXdCLHlCQUF5QjtFQUMxRCxPQUFPLE9BQU87Q0FDZjs7Q0FFQSxRQUFRLFVBQVU7RUFDakIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVLFFBQVEsS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU0sWUFBWSxFQUFFLE1BQU0sUUFBUSxFQUFBLEVBQUksU0FBUyxLQUFLLFFBQVEsUUFBUTtPQUMzSSxPQUFPLFFBQVEsUUFBUTtDQUM3Qjs7Ozs7Ozs7Ozs7Q0FXQSxRQUFRO0VBQ1AsY0FBYyxZQUFZO0dBQ3pCLEtBQUssV0FBVyxTQUFTLGFBQWE7SUFDckMsS0FBSyxPQUFPO0tBQ1gsTUFBTTtLQUNOO0lBQ0QsQ0FBQztHQUNGLENBQUM7R0FDRCxLQUFLLFdBQVcsTUFBTTtHQUN0QixLQUFLLFFBQVEsTUFBTTtFQUNwQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUztFQUNSLE9BQU8sTUFBTSxLQUFLLEtBQUssVUFBVTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxLQUFLLFNBQVM7RUFDYixNQUFNLG1CQUFtQjtHQUN4QixPQUFPO0dBQ1AsR0FBRztFQUNKO0VBQ0EsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE1BQU0sYUFBYSxjQUFjLGtCQUFrQixRQUFRLENBQUM7Q0FDbEY7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsUUFBUSxVQUFVLENBQUMsR0FBRztFQUNyQixPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsUUFBUSxhQUFhLGNBQWMsU0FBUyxRQUFRLENBQUM7Q0FDM0U7O0NBRUEsT0FBTyxPQUFPO0VBQ2IsY0FBYyxZQUFZO0dBQ3pCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDcEMsU0FBUyxLQUFLO0dBQ2YsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Q0FFQSx3QkFBd0I7RUFDdkIsTUFBTSxrQkFBa0IsS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUFRLE1BQU0sRUFBRSxNQUFNLFFBQVE7RUFDcEUsT0FBTyxjQUFjLFlBQVksUUFBUSxJQUFJLGdCQUFnQixLQUFLLGFBQWEsU0FBUyxTQUFTLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7Q0FDakg7QUFDRDtBQUNBLFNBQVMsU0FBUyxVQUFVO0NBQzNCLE9BQU8sU0FBUyxRQUFRLE9BQU87QUFDaEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25LQSxJQUFJLG1CQUFtQixjQUFjLGFBQWE7Q0FDakQ7Q0FDQSxpQkFBaUIsS0FBSztDQUN0QjtDQUNBO0NBQ0EsWUFBWSxRQUFRLFNBQVM7RUFDNUIsTUFBTTtFQUNOLEtBQUssVUFBVTtFQUNmLEtBQUssV0FBVyxPQUFPO0VBQ3ZCLEtBQUssWUFBWTtFQUNqQixLQUFLLGNBQWM7Q0FDcEI7Q0FDQSxjQUFjO0VBQ2IsS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7RUFDbkMsS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLElBQUk7Q0FDbEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLFdBQVcsU0FBUztFQUNuQixNQUFNLGNBQWMsS0FBSztFQUN6QixLQUFLLFVBQVUsS0FBSyxRQUFRLHVCQUF1QixPQUFPO0VBQzFELElBQUksQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxPQUFPO0dBQzNGLE1BQU07R0FDTixVQUFVLEtBQUs7R0FDZixVQUFVO0VBQ1gsQ0FBQztFQUNELElBQUksYUFBYSxlQUFlLEtBQUssUUFBUSxlQUFlLFFBQVEsWUFBWSxXQUFXLE1BQU0sUUFBUSxLQUFLLFFBQVEsV0FBVyxHQUFHLEtBQUssTUFBTTtPQUMxSSxJQUFJLEtBQUssa0JBQWtCLE1BQU0sV0FBVyxXQUFXLEtBQUssaUJBQWlCLFdBQVcsS0FBSyxPQUFPO0NBQzFHO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsS0FBSyxLQUFLLGtCQUFrQjtHQUN2RCxLQUFLLGlCQUFpQixZQUFZLElBQUk7R0FDdEMsS0FBSyxjQUFjO0VBQ3BCO0NBQ0Q7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUcsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0NBQ3JFOztDQUVBLGlCQUFpQixRQUFRO0VBQ3hCLEtBQUssY0FBYztFQUNuQixLQUFLLFFBQVEsTUFBTTtDQUNwQjs7Ozs7O0NBTUEsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxRQUFRO0VBQ1AsS0FBSyxrQkFBa0IsZUFBZSxJQUFJO0VBQzFDLEtBQUssbUJBQW1CLEtBQUs7RUFDN0IsS0FBSyxjQUFjO0VBQ25CLEtBQUssUUFBUTtDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLE9BQU8sV0FBVyxTQUFTO0VBQzFCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssa0JBQWtCLGVBQWUsSUFBSTtFQUMxQyxLQUFLLG1CQUFtQixLQUFLLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDeEYsS0FBSyxpQkFBaUIsWUFBWSxJQUFJO0VBQ3RDLE9BQU8sS0FBSyxpQkFBaUIsUUFBUSxTQUFTO0NBQy9DO0NBQ0EsZ0JBQWdCO0VBQ2YsTUFBTSxRQUFRLEtBQUssa0JBQWtCLFNBQVMsZ0JBQWdCO0VBQzlELEtBQUssaUJBQWlCO0dBQ3JCLEdBQUc7R0FDSCxXQUFXLE1BQU0sV0FBVztHQUM1QixXQUFXLE1BQU0sV0FBVztHQUM1QixTQUFTLE1BQU0sV0FBVztHQUMxQixRQUFRLE1BQU0sV0FBVztHQUN6QixRQUFRLEtBQUs7R0FDYixPQUFPLEtBQUs7RUFDYjtDQUNEO0NBQ0EsUUFBUSxRQUFRO0VBQ2YsY0FBYyxZQUFZO0dBQ3pCLElBQUksS0FBSyxrQkFBa0IsS0FBSyxhQUFhLEdBQUc7SUFDL0MsTUFBTSxZQUFZLEtBQUssZUFBZTtJQUN0QyxNQUFNLGlCQUFpQixLQUFLLGVBQWU7SUFDM0MsTUFBTSxVQUFVO0tBQ2YsUUFBUSxLQUFLO0tBQ2IsTUFBTSxLQUFLLFFBQVE7S0FDbkIsYUFBYSxLQUFLLFFBQVE7SUFDM0I7SUFDQSxJQUFJLFFBQVEsU0FBUyxXQUFXO0tBQy9CLElBQUk7TUFDSCxLQUFLLGVBQWUsWUFBWSxPQUFPLE1BQU0sV0FBVyxnQkFBZ0IsT0FBTztLQUNoRixTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtLQUNBLElBQUk7TUFDSCxLQUFLLGVBQWUsWUFBWSxPQUFPLE1BQU0sTUFBTSxXQUFXLGdCQUFnQixPQUFPO0tBQ3RGLFNBQVMsR0FBRztNQUNYLFFBQVEsT0FBTyxDQUFDO0tBQ2pCO0lBQ0QsT0FBTyxJQUFJLFFBQVEsU0FBUyxTQUFTO0tBQ3BDLElBQUk7TUFDSCxLQUFLLGVBQWUsVUFBVSxPQUFPLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTztLQUMvRSxTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtLQUNBLElBQUk7TUFDSCxLQUFLLGVBQWUsWUFBWSxLQUFLLEdBQUcsT0FBTyxPQUFPLFdBQVcsZ0JBQWdCLE9BQU87S0FDekYsU0FBUyxHQUFHO01BQ1gsUUFBUSxPQUFPLENBQUM7S0FDakI7SUFDRDtHQUNEO0dBQ0EsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUssY0FBYztHQUM3QixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7OztBQ2xMQSxTQUFTLFdBQVcsUUFBUSxRQUFRO0NBQ25DLE1BQU0sYUFBYSxJQUFJLElBQUksTUFBTTtDQUNqQyxPQUFPLE9BQU8sUUFBUSxNQUFNLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUMvQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEsSUFBSSxrQkFBa0IsY0FBYyxhQUFhO0NBQ2hEO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLG1CQUFtQixDQUFDO0NBQ3BCLFlBQVksUUFBUSxTQUFTLFNBQVM7RUFDckMsTUFBTTtFQUNOLEtBQUssVUFBVTtFQUNmLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVcsQ0FBQztFQUNqQixLQUFLLGFBQWEsQ0FBQztFQUNuQixLQUFLLFVBQVUsQ0FBQztFQUNoQixLQUFLLFdBQVcsT0FBTztDQUN4QjtDQUNBLGNBQWM7RUFDYixJQUFJLEtBQUssVUFBVSxTQUFTLEdBQUcsS0FBSyxXQUFXLFNBQVMsYUFBYTtHQUNwRSxTQUFTLFdBQVcsV0FBVztJQUM5QixLQUFLLFVBQVUsVUFBVSxNQUFNO0dBQ2hDLENBQUM7RUFDRixDQUFDO0NBQ0Y7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxVQUFVLE1BQU0sS0FBSyxRQUFRO0NBQ3hDOzs7OztDQUtBLFVBQVU7RUFDVCxLQUFLLDRCQUE0QixJQUFJLElBQUk7RUFDekMsS0FBSyxXQUFXLFNBQVMsYUFBYTtHQUNyQyxTQUFTLFFBQVE7RUFDbEIsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxXQUFXLFNBQVMsU0FBUztFQUM1QixLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXO0VBQzJCO0dBQzFDLE1BQU0sY0FBYyxRQUFRLEtBQUssVUFBVSxLQUFLLFFBQVEsb0JBQW9CLEtBQUssQ0FBQyxDQUFDLFNBQVM7R0FDNUYsSUFBSSxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsU0FBUyxZQUFZLFFBQVEsUUFBUSxLQUFLLHVGQUF1RjtFQUMzSjtFQUNBLGNBQWMsWUFBWTtHQUN6QixNQUFNLGdCQUFnQixLQUFLO0dBQzNCLE1BQU0scUJBQXFCLEtBQUssdUJBQXVCLEtBQUssUUFBUTtHQUNwRSxtQkFBbUIsU0FBUyxVQUFVLE1BQU0sU0FBUyxXQUFXLE1BQU0scUJBQXFCLENBQUM7R0FDNUYsTUFBTSxlQUFlLG1CQUFtQixLQUFLLFVBQVUsTUFBTSxRQUFRO0dBQ3JFLE1BQU0sWUFBWSxhQUFhLEtBQUssYUFBYSxTQUFTLGlCQUFpQixDQUFDO0dBQzVFLE1BQU0sa0JBQWtCLGNBQWMsV0FBVyxhQUFhO0dBQzlELE1BQU0saUJBQWlCLGFBQWEsTUFBTSxVQUFVLFVBQVUsYUFBYSxjQUFjLE1BQU07R0FDL0YsTUFBTSxzQkFBc0IsbUJBQW1CO0dBQy9DLE1BQU0sa0JBQWtCLHNCQUFzQixPQUFPLFVBQVUsTUFBTSxRQUFRLFVBQVU7SUFDdEYsTUFBTSxPQUFPLEtBQUssUUFBUTtJQUMxQixPQUFPLENBQUMsUUFBUSxDQUFDLG9CQUFvQixRQUFRLElBQUk7R0FDbEQsQ0FBQztHQUNELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxpQkFBaUI7R0FDOUMsSUFBSSxxQkFBcUI7SUFDeEIsS0FBSyxtQkFBbUI7SUFDeEIsS0FBSyxhQUFhO0dBQ25CO0dBQ0EsS0FBSyxVQUFVO0dBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHO0dBQzFCLElBQUkscUJBQXFCO0lBQ3hCLFdBQVcsZUFBZSxZQUFZLENBQUMsQ0FBQyxTQUFTLGFBQWE7S0FDN0QsU0FBUyxRQUFRO0lBQ2xCLENBQUM7SUFDRCxXQUFXLGNBQWMsYUFBYSxDQUFDLENBQUMsU0FBUyxhQUFhO0tBQzdELFNBQVMsV0FBVyxXQUFXO01BQzlCLEtBQUssVUFBVSxVQUFVLE1BQU07S0FDaEMsQ0FBQztJQUNGLENBQUM7R0FDRjtHQUNBLEtBQUssUUFBUTtFQUNkLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7O0NBWUEsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7OztDQUtBLGFBQWE7RUFDWixPQUFPLEtBQUssV0FBVyxLQUFLLGFBQWEsU0FBUyxnQkFBZ0IsQ0FBQztDQUNwRTs7Ozs7O0NBTUEsZUFBZTtFQUNkLE9BQU8sS0FBSztDQUNiOzs7Ozs7OztDQVFBLG9CQUFvQixTQUFTLFNBQVM7RUFDckMsTUFBTSxVQUFVLEtBQUssdUJBQXVCLE9BQU87RUFDbkQsTUFBTSxTQUFTLFFBQVEsS0FBSyxVQUFVLE1BQU0sU0FBUyxvQkFBb0IsTUFBTSxxQkFBcUIsQ0FBQztFQUNyRyxNQUFNLGNBQWMsUUFBUSxLQUFLLFVBQVUsTUFBTSxzQkFBc0IsU0FBUztFQUNoRixPQUFPO0dBQ047SUFDQyxNQUFNO0lBQ04sT0FBTyxLQUFLLGVBQWUsS0FBSyxRQUFRLFNBQVMsV0FBVztHQUM3RDtTQUNNO0lBQ0wsT0FBTyxLQUFLLGFBQWEsUUFBUSxPQUFPO0dBQ3pDO0VBQ0Q7Q0FDRDtDQUNBLGFBQWEsUUFBUSxTQUFTO0VBQzdCLE1BQU0sK0JBQStCLElBQUksSUFBSTtFQUM3QyxPQUFPLFFBQVEsS0FBSyxPQUFPLFVBQVU7R0FDcEMsTUFBTSxpQkFBaUIsT0FBTztHQUM5QixPQUFPLENBQUMsTUFBTSxzQkFBc0Isc0JBQXNCLE1BQU0sU0FBUyxZQUFZLGlCQUFpQixpQkFBaUI7SUFDdEgsSUFBSSxDQUFDLGFBQWEsSUFBSSxZQUFZLEdBQUc7S0FDcEMsYUFBYSxJQUFJLFlBQVk7S0FDN0IsUUFBUSxTQUFTLE1BQU07TUFDdEIsRUFBRSxTQUFTLFVBQVUsWUFBWTtLQUNsQyxDQUFDO0lBQ0Y7R0FDRCxDQUFDLElBQUk7RUFDTixDQUFDO0NBQ0Y7Q0FDQSxlQUFlLE9BQU8sU0FBUyxhQUFhO0VBQzNDLElBQUksU0FBUztHQUNaLE1BQU0sYUFBYSxLQUFLO0dBQ3hCLE1BQU0scUJBQXFCLGdCQUFnQixLQUFLLEtBQUssZUFBZSxLQUFLLE1BQU0sV0FBVyxXQUFXLFlBQVksVUFBVSxZQUFZLE1BQU0sTUFBTSxNQUFNLFNBQVMsV0FBVyxFQUFFO0dBQy9LLElBQUksS0FBSyxZQUFZLEtBQUssZUFBZSxzQkFBc0IsWUFBWSxLQUFLLGNBQWM7SUFDN0YsS0FBSyxlQUFlO0lBQ3BCLEtBQUssY0FBYyxLQUFLO0lBQ3hCLElBQUksZ0JBQWdCLEtBQUssR0FBRyxLQUFLLG1CQUFtQjtJQUNwRCxLQUFLLGtCQUFrQixpQkFBaUIsS0FBSyxpQkFBaUIsUUFBUSxLQUFLLENBQUM7R0FDN0U7R0FDQSxPQUFPLEtBQUs7RUFDYjtFQUNBLE9BQU87Q0FDUjtDQUNBLHFCQUFxQjtFQUNwQixPQUFPLENBQUMsS0FBSyxVQUFVLFdBQVcsS0FBSyxXQUFXLE1BQU0sVUFBVSxVQUFVO0dBQzNFLE9BQU8sU0FBUyxRQUFRLFlBQVksS0FBSyxRQUFRLE1BQU0sRUFBRSxTQUFTLEtBQUs7RUFDeEUsQ0FBQztDQUNGO0NBQ0EsdUJBQXVCLFNBQVM7RUFDL0IsTUFBTSxtQ0FBbUMsSUFBSSxJQUFJO0VBQ2pELEtBQUssV0FBVyxTQUFTLGFBQWE7R0FDckMsTUFBTSxNQUFNLFNBQVMsUUFBUTtHQUM3QixJQUFJLENBQUMsS0FBSztHQUNWLE1BQU0sb0JBQW9CLGlCQUFpQixJQUFJLEdBQUc7R0FDbEQsSUFBSSxtQkFBbUIsa0JBQWtCLEtBQUssUUFBUTtRQUNqRCxpQkFBaUIsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDO0VBQzFDLENBQUM7RUFDRCxNQUFNLFlBQVksQ0FBQztFQUNuQixRQUFRLFNBQVMsWUFBWTtHQUM1QixNQUFNLG1CQUFtQixLQUFLLFFBQVEsb0JBQW9CLE9BQU87R0FDakUsTUFBTSxXQUFXLGlCQUFpQixJQUFJLGlCQUFpQixTQUFTLENBQUMsRUFBRSxNQUFNLEtBQUssSUFBSSxjQUFjLEtBQUssU0FBUyxnQkFBZ0I7R0FDOUgsVUFBVSxLQUFLO0lBQ2QsdUJBQXVCO0lBQ3ZCO0dBQ0QsQ0FBQztFQUNGLENBQUM7RUFDRCxPQUFPO0NBQ1I7Q0FDQSxVQUFVLFVBQVUsUUFBUTtFQUMzQixNQUFNLFFBQVEsS0FBSyxXQUFXLFFBQVEsUUFBUTtFQUM5QyxJQUFJLFVBQVUsSUFBSTtHQUNqQixLQUFLLFVBQVUsS0FBSyxRQUFRLE1BQU07R0FDbEMsS0FBSyxRQUFRLFNBQVM7R0FDdEIsS0FBSyxRQUFRO0VBQ2Q7Q0FDRDtDQUNBLFVBQVU7RUFDVCxJQUFJLEtBQUssYUFBYSxHQUFHO0dBQ3hCLE1BQU0sb0JBQW9CLEtBQUssbUJBQW1CO0dBQ2xELE1BQU0saUJBQWlCLEtBQUs7R0FDNUIsTUFBTSxZQUFZLG9CQUFvQixpQkFBaUIsS0FBSyxlQUFlLEtBQUssYUFBYSxLQUFLLFNBQVMsS0FBSyxnQkFBZ0IsR0FBRyxLQUFLLFVBQVUsT0FBTztHQUN6SixJQUFJLHFCQUFxQixtQkFBbUIsV0FBVyxjQUFjLFlBQVk7SUFDaEYsS0FBSyxVQUFVLFNBQVMsYUFBYTtLQUNwQyxTQUFTLEtBQUssT0FBTztJQUN0QixDQUFDO0dBQ0YsQ0FBQztFQUNGO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvTkEsSUFBSSxhQUFhLGNBQWMsYUFBYTtDQUMzQztDQUNBLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDeEIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssMkJBQTJCLElBQUksSUFBSTtDQUN6Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM3QixNQUFNLFdBQVcsUUFBUTtFQUN6QixNQUFNLFlBQVksUUFBUSxhQUFhLHNCQUFzQixVQUFVLE9BQU87RUFDOUUsSUFBSSxRQUFRLEtBQUssSUFBSSxTQUFTO0VBQzlCLElBQUksQ0FBQyxPQUFPO0dBQ1gsUUFBUSxJQUFJLE1BQU07SUFDakI7SUFDQTtJQUNBO0lBQ0EsU0FBUyxPQUFPLG9CQUFvQixPQUFPO0lBQzNDO0lBQ0EsZ0JBQWdCLE9BQU8saUJBQWlCLFFBQVE7R0FDakQsQ0FBQztHQUNELEtBQUssSUFBSSxLQUFLO0VBQ2Y7RUFDQSxPQUFPO0NBQ1I7O0NBRUEsSUFBSSxPQUFPO0VBQ1YsSUFBSSxDQUFDLEtBQUssU0FBUyxJQUFJLE1BQU0sU0FBUyxHQUFHO0dBQ3hDLEtBQUssU0FBUyxJQUFJLE1BQU0sV0FBVyxLQUFLO0dBQ3hDLEtBQUssT0FBTztJQUNYLE1BQU07SUFDTjtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxPQUFPLE9BQU87RUFDYixJQUFJLEtBQUssU0FBUyxJQUFJLE1BQU0sU0FBUyxNQUFNLE9BQU87R0FDakQsTUFBTSxRQUFRO0dBQ2QsS0FBSyxTQUFTLE9BQU8sTUFBTSxTQUFTO0dBQ3BDLEtBQUssT0FBTztJQUNYLE1BQU07SUFDTjtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Ozs7OztDQVdBLFFBQVE7RUFDUCxjQUFjLFlBQVk7R0FDekIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEMsS0FBSyxPQUFPLEtBQUs7R0FDbEIsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsSUFBSSxXQUFXO0VBQ2QsT0FBTyxLQUFLLFNBQVMsSUFBSSxTQUFTO0NBQ25DOzs7Ozs7Ozs7OztDQVdBLFNBQVM7RUFDUixPQUFPLENBQUMsR0FBRyxLQUFLLFNBQVMsT0FBTyxDQUFDO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLEtBQUssU0FBUztFQUNiLE1BQU0sbUJBQW1CO0dBQ3hCLE9BQU87R0FDUCxHQUFHO0VBQ0o7RUFDQSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxVQUFVLFdBQVcsa0JBQWtCLEtBQUssQ0FBQztDQUN6RTs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQ3JCLE1BQU0sVUFBVSxLQUFLLE9BQU87RUFDNUIsT0FBTyxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxJQUFJLFFBQVEsUUFBUSxVQUFVLFdBQVcsU0FBUyxLQUFLLENBQUMsSUFBSTtDQUNsRzs7Q0FFQSxPQUFPLE9BQU87RUFDYixjQUFjLFlBQVk7R0FDekIsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLEtBQUs7R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGOztDQUVBLFVBQVU7RUFDVCxjQUFjLFlBQVk7R0FDekIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEMsTUFBTSxRQUFRO0dBQ2YsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Q0FFQSxXQUFXO0VBQ1YsY0FBYyxZQUFZO0dBQ3pCLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ2hDLE1BQU0sU0FBUztHQUNoQixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVMQSxJQUFJLGNBQWMsTUFBTTtDQUN2QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxTQUFTLENBQUMsR0FBRztFQUN4QixLQUFLLGNBQWMsT0FBTyxjQUFjLElBQUksV0FBVztFQUN2RCxLQUFLLGlCQUFpQixPQUFPLGlCQUFpQixJQUFJLGNBQWM7RUFDaEUsS0FBSyxrQkFBa0IsT0FBTyxrQkFBa0IsQ0FBQztFQUNqRCxLQUFLLGlDQUFpQyxJQUFJLElBQUk7RUFDOUMsS0FBSyxvQ0FBb0MsSUFBSSxJQUFJO0VBQ2pELEtBQUssY0FBYztDQUNwQjs7Ozs7OztDQU9BLFFBQVE7RUFDUCxLQUFLO0VBQ0wsSUFBSSxLQUFLLGdCQUFnQixHQUFHO0VBQzVCLEtBQUssb0JBQW9CLGFBQWEsVUFBVSxPQUFPLFlBQVk7R0FDbEUsSUFBSSxTQUFTO0lBQ1osTUFBTSxLQUFLLHNCQUFzQjtJQUNqQyxLQUFLLFlBQVksUUFBUTtHQUMxQjtFQUNELENBQUM7RUFDRCxLQUFLLHFCQUFxQixjQUFjLFVBQVUsT0FBTyxXQUFXO0dBQ25FLElBQUksUUFBUTtJQUNYLE1BQU0sS0FBSyxzQkFBc0I7SUFDakMsS0FBSyxZQUFZLFNBQVM7R0FDM0I7RUFDRCxDQUFDO0NBQ0Y7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLO0VBQ0wsSUFBSSxLQUFLLGdCQUFnQixHQUFHO0VBQzVCLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssb0JBQW9CLEtBQUs7RUFDOUIsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyxxQkFBcUIsS0FBSztDQUNoQzs7Ozs7Ozs7Ozs7OztDQWFBLFdBQVcsU0FBUztFQUNuQixPQUFPLEtBQUssWUFBWSxRQUFRO0dBQy9CLEdBQUc7R0FDSCxhQUFhO0VBQ2QsQ0FBQyxDQUFDLENBQUM7Q0FDSjs7Ozs7Ozs7Ozs7O0NBWUEsV0FBVyxTQUFTO0VBQ25CLE9BQU8sS0FBSyxlQUFlLFFBQVE7R0FDbEMsR0FBRztHQUNILFFBQVE7RUFDVCxDQUFDLENBQUMsQ0FBQztDQUNKOzs7Ozs7Ozs7OztDQVdBLGFBQWEsVUFBVTtFQUN0QixNQUFNLFVBQVUsS0FBSyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7RUFDckQsT0FBTyxLQUFLLFlBQVksSUFBSSxRQUFRLFNBQVMsQ0FBQyxFQUFFLE1BQU07Q0FDdkQ7Ozs7Q0FJQSxnQkFBZ0IsU0FBUztFQUN4QixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELE1BQU0sUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxNQUFNLGFBQWEsTUFBTSxNQUFNO0VBQy9CLElBQUksZUFBZSxLQUFLLEdBQUcsT0FBTyxLQUFLLFdBQVcsT0FBTztFQUN6RCxJQUFJLFFBQVEscUJBQXFCLE1BQU0sY0FBYyxrQkFBa0IsaUJBQWlCLFdBQVcsS0FBSyxDQUFDLEdBQUcsS0FBSyxjQUFjLGdCQUFnQjtFQUMvSSxPQUFPLFFBQVEsUUFBUSxVQUFVO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGVBQWUsU0FBUztFQUN2QixPQUFPLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLFlBQVk7R0FDckUsT0FBTyxDQUFDLFVBQVUsTUFBTSxJQUFJO0VBQzdCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXlCQSxhQUFhLFVBQVUsU0FBUyxTQUFTO0VBQ3hDLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQzlELE1BQU0sV0FBVyxLQUFLLFlBQVksSUFBSSxpQkFBaUIsU0FBUyxDQUFDLEVBQUUsTUFBTTtFQUN6RSxNQUFNLE9BQU8saUJBQWlCLFNBQVMsUUFBUTtFQUMvQyxJQUFJLFNBQVMsS0FBSyxHQUFHO0VBQ3JCLE9BQU8sS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsTUFBTTtHQUNuRSxHQUFHO0dBQ0gsUUFBUTtFQUNULENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxlQUFlLFNBQVMsU0FBUyxTQUFTO0VBQ3pDLE9BQU8sY0FBYyxZQUFZLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxlQUFlLENBQUMsVUFBVSxLQUFLLGFBQWEsVUFBVSxTQUFTLE9BQU8sQ0FBQyxDQUFDLENBQUM7Q0FDcEo7Ozs7Ozs7Ozs7O0NBV0EsY0FBYyxVQUFVO0VBQ3ZCLE1BQU0sVUFBVSxLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUNyRCxPQUFPLEtBQUssWUFBWSxJQUFJLFFBQVEsU0FBUyxDQUFDLEVBQUU7Q0FDakQ7Ozs7Ozs7Ozs7OztDQVlBLGNBQWMsU0FBUztFQUN0QixNQUFNLGFBQWEsS0FBSztFQUN4QixjQUFjLFlBQVk7R0FDekIsV0FBVyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUM5QyxXQUFXLE9BQU8sS0FBSztHQUN4QixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7OztDQVdBLGFBQWEsU0FBUyxTQUFTO0VBQzlCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLE9BQU8sY0FBYyxZQUFZO0dBQ2hDLE1BQU0sVUFBVSxXQUFXLFFBQVEsT0FBTztHQUMxQyxNQUFNLG1CQUFtQixJQUFJLElBQUksT0FBTztHQUN4QyxRQUFRLFNBQVMsVUFBVTtJQUMxQixNQUFNLE1BQU07R0FDYixDQUFDO0dBQ0QsT0FBTyxLQUFLLGVBQWU7SUFDMUIsTUFBTTtJQUNOLFlBQVksVUFBVSxpQkFBaUIsSUFBSSxLQUFLO0dBQ2pELEdBQUcsT0FBTztFQUNYLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Q0FjQSxjQUFjLFNBQVMsZ0JBQWdCLENBQUMsR0FBRztFQUMxQyxNQUFNLHlCQUF5QjtHQUM5QixRQUFRO0dBQ1IsR0FBRztFQUNKO0VBQ0EsTUFBTSxXQUFXLGNBQWMsWUFBWSxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLFVBQVUsTUFBTSxPQUFPLHNCQUFzQixDQUFDLENBQUM7RUFDakksT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDbkQ7Ozs7Ozs7Ozs7Ozs7O0NBY0Esa0JBQWtCLFNBQVMsVUFBVSxDQUFDLEdBQUc7RUFDeEMsT0FBTyxjQUFjLFlBQVk7R0FDaEMsS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxVQUFVO0lBQ3BELE1BQU0sV0FBVztHQUNsQixDQUFDO0dBQ0QsSUFBSSxTQUFTLGdCQUFnQixRQUFRLE9BQU8sUUFBUSxRQUFRO0dBQzVELE9BQU8sS0FBSyxlQUFlO0lBQzFCLEdBQUc7SUFDSCxNQUFNLFNBQVMsZUFBZSxTQUFTLFFBQVE7R0FDaEQsR0FBRyxPQUFPO0VBQ1gsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLGVBQWUsU0FBUyxVQUFVLENBQUMsR0FBRztFQUNyQyxNQUFNLGVBQWU7R0FDcEIsR0FBRztHQUNILGVBQWUsUUFBUSxpQkFBaUI7RUFDekM7RUFDQSxNQUFNLFdBQVcsY0FBYyxZQUFZLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFFBQVEsVUFBVSxDQUFDLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVTtHQUN2SixJQUFJLFVBQVUsTUFBTSxNQUFNLEtBQUssR0FBRyxZQUFZO0dBQzlDLElBQUksQ0FBQyxhQUFhLGNBQWMsVUFBVSxRQUFRLE1BQU0sSUFBSTtHQUM1RCxPQUFPLE1BQU0sTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLFFBQVEsSUFBSTtFQUNuRSxDQUFDLENBQUM7RUFDRixPQUFPLFFBQVEsSUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFLLElBQUk7Q0FDdkM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NBLE1BQU0sTUFBTSxTQUFTO0VBQ3BCLE1BQU0sbUJBQW1CLEtBQUssb0JBQW9CLE9BQU87RUFDekQsSUFBSSxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsaUJBQWlCLFFBQVE7RUFDaEUsTUFBTSxRQUFRLEtBQUssWUFBWSxNQUFNLE1BQU0sZ0JBQWdCO0VBQzNELE1BQU0sWUFBWSxNQUFNLGNBQWMsa0JBQWtCLGlCQUFpQixXQUFXLEtBQUssQ0FBQyxJQUFJLE1BQU0sTUFBTSxNQUFNLGdCQUFnQixJQUFJLE1BQU0sTUFBTTtFQUNoSixNQUFNLFNBQVMsaUJBQWlCO0VBQ2hDLElBQUksUUFBUSxPQUFPLE9BQU8sU0FBUztFQUNuQyxPQUFPO0NBQ1I7Ozs7Q0FJQSxXQUFXLFNBQVM7RUFDbkIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxJQUFJLGlCQUFpQixVQUFVLEtBQUssR0FBRyxpQkFBaUIsUUFBUTtFQUNoRSxNQUFNLFFBQVEsS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsT0FBTyxNQUFNLGNBQWMsa0JBQWtCLGlCQUFpQixXQUFXLEtBQUssQ0FBQyxJQUFJLE1BQU0sTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLFFBQVEsTUFBTSxNQUFNLElBQUk7Q0FDcEo7Ozs7Q0FJQSxjQUFjLFNBQVM7RUFDdEIsT0FBTyxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQkEsY0FBYyxTQUFTO0VBQ3RCLFFBQVEsUUFBUTtFQUNoQixPQUFPLEtBQUssTUFBTSxPQUFPO0NBQzFCOzs7O0NBSUEsbUJBQW1CLFNBQVM7RUFDM0IsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxXQUFXLE9BQU87Q0FDL0I7Ozs7Q0FJQSxzQkFBc0IsU0FBUztFQUM5QixPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQzlEOzs7O0NBSUEsd0JBQXdCLFNBQVM7RUFDaEMsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxnQkFBZ0IsT0FBTztDQUNwQzs7Ozs7Ozs7Ozs7OztDQWFBLHdCQUF3QjtFQUN2QixJQUFJLGNBQWMsU0FBUyxHQUFHLE9BQU8sS0FBSyxlQUFlLHNCQUFzQjtFQUMvRSxPQUFPLFFBQVEsUUFBUTtDQUN4Qjs7Ozs7Ozs7Ozs7OztDQWFBLGdCQUFnQjtFQUNmLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7O0NBYUEsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7O0NBYUEsb0JBQW9CO0VBQ25CLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsa0JBQWtCLFNBQVM7RUFDMUIsS0FBSyxrQkFBa0I7Q0FDeEI7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsaUJBQWlCLFVBQVUsU0FBUztFQUNuQyxLQUFLLGVBQWUsSUFBSSxRQUFRLFFBQVEsR0FBRztHQUMxQztHQUNBLGdCQUFnQjtFQUNqQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7O0NBV0EsaUJBQWlCLFVBQVU7RUFDMUIsTUFBTSxXQUFXLENBQUMsR0FBRyxLQUFLLGVBQWUsT0FBTyxDQUFDO0VBQ2pELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLFNBQVMsU0FBUyxpQkFBaUI7R0FDbEMsSUFBSSxnQkFBZ0IsVUFBVSxhQUFhLFFBQVEsR0FBRyxPQUFPLE9BQU8sUUFBUSxhQUFhLGNBQWM7RUFDeEcsQ0FBQztFQUNELE9BQU87Q0FDUjs7Ozs7Ozs7Ozs7O0NBWUEsb0JBQW9CLGFBQWEsU0FBUztFQUN6QyxLQUFLLGtCQUFrQixJQUFJLFFBQVEsV0FBVyxHQUFHO0dBQ2hEO0dBQ0EsZ0JBQWdCO0VBQ2pCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Q0FXQSxvQkFBb0IsYUFBYTtFQUNoQyxNQUFNLFdBQVcsQ0FBQyxHQUFHLEtBQUssa0JBQWtCLE9BQU8sQ0FBQztFQUNwRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixTQUFTLFNBQVMsaUJBQWlCO0dBQ2xDLElBQUksZ0JBQWdCLGFBQWEsYUFBYSxXQUFXLEdBQUcsT0FBTyxPQUFPLFFBQVEsYUFBYSxjQUFjO0VBQzlHLENBQUM7RUFDRCxPQUFPO0NBQ1I7Ozs7Ozs7Q0FPQSxvQkFBb0IsU0FBUztFQUM1QixJQUFJLFFBQVEsWUFBWSxPQUFPO0VBQy9CLE1BQU0sbUJBQW1CO0dBQ3hCLEdBQUcsS0FBSyxnQkFBZ0I7R0FDeEIsR0FBRyxLQUFLLGlCQUFpQixRQUFRLFFBQVE7R0FDekMsR0FBRztHQUNILFlBQVk7RUFDYjtFQUNBLElBQUksQ0FBQyxpQkFBaUIsV0FBVyxpQkFBaUIsWUFBWSxzQkFBc0IsaUJBQWlCLFVBQVUsZ0JBQWdCO0VBQy9ILElBQUksaUJBQWlCLHVCQUF1QixLQUFLLEdBQUcsaUJBQWlCLHFCQUFxQixpQkFBaUIsZ0JBQWdCO0VBQzNILElBQUksaUJBQWlCLGlCQUFpQixLQUFLLEdBQUcsaUJBQWlCLGVBQWUsQ0FBQyxDQUFDLGlCQUFpQjtFQUNqRyxJQUFJLENBQUMsaUJBQWlCLGVBQWUsaUJBQWlCLFdBQVcsaUJBQWlCLGNBQWM7RUFDaEcsSUFBSSxpQkFBaUIsWUFBWSxXQUFXLGlCQUFpQixVQUFVO0VBQ3ZFLE9BQU87Q0FDUjs7Ozs7OztDQU9BLHVCQUF1QixTQUFTO0VBQy9CLElBQUksU0FBUyxZQUFZLE9BQU87RUFDaEMsT0FBTztHQUNOLEdBQUcsS0FBSyxnQkFBZ0I7R0FDeEIsR0FBRyxTQUFTLGVBQWUsS0FBSyxvQkFBb0IsUUFBUSxXQUFXO0dBQ3ZFLEdBQUc7R0FDSCxZQUFZO0VBQ2I7Q0FDRDs7Ozs7Ozs7Ozs7O0NBWUEsUUFBUTtFQUNQLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssZUFBZSxNQUFNO0NBQzNCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0bkJBLFNBQVMsY0FBYyxFQUFFLFVBQVUsY0FBYyxTQUFTLFdBQVcsT0FBTyxVQUFVLFNBQVMsT0FBTyxLQUFLLEdBQUcsZUFBZSxDQUFDLEtBQUs7Q0FDbEksT0FBTyxPQUFPLFlBQVk7RUFDekIsTUFBTSxRQUFRLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxLQUFLO0dBQ2pELFVBQVUsUUFBUTtHQUNsQixPQUFPO0VBQ1IsQ0FBQztFQUNELE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxNQUFNLFVBQVU7RUFDN0MsSUFBSSxhQUFhLGdCQUFnQixTQUFTLE1BQU0sU0FBUztHQUN4RCxHQUFHLE1BQU07R0FDVCxhQUFhO0VBQ2QsQ0FBQztFQUNELElBQUksU0FBUztFQUNiLElBQUksWUFBWTtFQUNoQixNQUFNLFNBQVMsTUFBTSxTQUFTLHNCQUFzQjtHQUNuRCxRQUFRLFFBQVE7R0FDaEIsTUFBTSxRQUFRO0dBQ2QsVUFBVSxRQUFRO0dBQ2xCLFdBQVcsUUFBUTtHQUNuQixXQUFXLFFBQVE7RUFDcEIsU0FBUyxRQUFRLGNBQWMsWUFBWSxJQUFJLENBQUM7RUFDaEQsTUFBTSxtQkFBbUIsYUFBYSxnQkFBZ0I7RUFDdEQsV0FBVyxNQUFNLFNBQVMsUUFBUTtHQUNqQyxJQUFJLFdBQVc7R0FDZixJQUFJLGtCQUFrQixTQUFTLFFBQVEsUUFBUSxLQUFLO1FBQy9DLFFBQVEsT0FBTyxhQUFhLFFBQVEsV0FBVyxTQUFTLFFBQVEsU0FBUyxLQUFLLElBQUksZUFBZSxNQUFNLEtBQUssQ0FBQztFQUNuSDtFQUNBLElBQUksb0JBQW9CLENBQUMsV0FBVyxRQUFRLE9BQU8sYUFBYSxRQUFRLFVBQVUsTUFBTTtFQUN4RixNQUFNLE9BQU8sUUFBUSxPQUFPLGFBQWEsUUFBUSxRQUFRO0VBQ3pELE9BQU8sU0FBUyxLQUFLLElBQUksZUFBZTtDQUN6QztBQUNEOzs7O0FDOUNBLElBQU0sZ0JBQWdCLE9BQU87QUFDN0IsSUFBTSxxQkFBcUIsT0FBTztBQUNsQyxJQUFNLGNBQWMsT0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzRDM0IsSUFBTSxxQkFBcUIsRUFBRSxVQUFVLFVBQVUsQ0FBQyxHQUFHLE9BQU8sa0JBQWtCO0NBQzdFLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxhQUFBLGFBQW1CLE9BQU8sT0FBTztDQUN2QyxhQUFNLGdCQUFnQjtFQUNyQixXQUFXLFVBQVU7Q0FDdEIsQ0FBQztDQUNELE1BQU0saUJBQUEsYUFBdUIsY0FBYztFQUMxQyxJQUFJLE9BQU87R0FDVixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQy9CLE1BQU0sYUFBYSxPQUFPLGNBQWM7R0FDeEMsTUFBTSxVQUFVLE1BQU0sV0FBVyxDQUFDO0dBQ2xDLE1BQU0sYUFBYSxDQUFDO0dBQ3BCLE1BQU0sa0JBQWtCLENBQUM7R0FDekIsS0FBSyxNQUFNLG1CQUFtQixTQUFTO0lBQ3RDLE1BQU0sZ0JBQWdCLFdBQVcsSUFBSSxnQkFBZ0IsU0FBUztJQUM5RCxJQUFJLENBQUMsZUFBZSxXQUFXLEtBQUssZUFBZTtTQUM5QyxJQUFJLGdCQUFnQixNQUFNLGdCQUFnQixjQUFjLE1BQU0saUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsTUFBTSxXQUFXLGFBQWEsY0FBYyxNQUFNLGdCQUFnQixjQUFjLGdCQUFnQixlQUFlLGNBQWMsTUFBTSxlQUFlLGdCQUFnQixLQUFLLGVBQWU7R0FDcFQ7R0FDQSxJQUFJLFdBQVcsU0FBUyxHQUFHLFFBQVEsUUFBUSxFQUFFLFNBQVMsV0FBVyxHQUFHLFdBQVcsT0FBTztHQUN0RixJQUFJLGdCQUFnQixTQUFTLEdBQUcsT0FBTztFQUN4QztDQUNELEdBQUcsQ0FBQyxRQUFRLEtBQUssQ0FBQztDQUNsQixhQUFNLGdCQUFnQjtFQUNyQixJQUFJLGdCQUFnQixRQUFRLFFBQVEsRUFBRSxTQUFTLGVBQWUsR0FBRyxXQUFXLE9BQU87Q0FDcEYsR0FBRyxDQUFDLFFBQVEsY0FBYyxDQUFDO0NBQzNCLE9BQU87QUFDUjs7O0FDdkVBLElBQU0scUJBQUEsYUFBMkIsY0FBYyxLQUFLOzs7Ozs7OztBQVFwRCxJQUFNLHVCQUFBLGFBQTZCLFdBQVcsa0JBQWtCOzs7OztBQUtoRSxJQUFNLHNCQUFzQixtQkFBbUI7Ozs7OztBQ1QvQyxTQUFTLGNBQWM7Q0FDdEIsSUFBSSxVQUFVO0NBQ2QsT0FBTzs7OztFQUlOLGtCQUFrQjtHQUNqQixVQUFVO0VBQ1g7Ozs7RUFJQSxhQUFhO0dBQ1osVUFBVTtFQUNYOzs7O0VBSUEsZUFBZTtHQUNkLE9BQU87RUFDUjtDQUNEO0FBQ0Q7QUFDQSxJQUFNLGlDQUFBLGFBQXVDLGNBQWMsWUFBWSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBK0J4RSxJQUFNLG1DQUFBLGFBQXlDLFdBQVcsOEJBQThCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1DeEYsSUFBTSwyQkFBMkIsRUFBRSxlQUFlO0NBQ2pELE1BQU0sQ0FBQyxTQUFBLGFBQWUsZUFBZSxZQUFZLENBQUM7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksK0JBQStCLFVBQVU7RUFDbkU7RUFDQSxVQUFVLE9BQU8sYUFBYSxhQUFhLFNBQVMsS0FBSyxJQUFJO0NBQzlELENBQUM7QUFDRjs7O0FDbEdBLElBQU0sbUNBQW1DLFNBQVMsb0JBQW9CLFVBQVU7Q0FDL0UsTUFBTSxlQUFlLE9BQU8sTUFBTSxTQUFTLE9BQU8sUUFBUSxpQkFBaUIsYUFBYSxpQkFBaUIsUUFBUSxjQUFjLENBQUMsTUFBTSxNQUFNLE9BQU8sS0FBSyxDQUFDLElBQUksUUFBUTtDQUNySyxJQUFJLFFBQVEsWUFBWSxjQUNuQjtNQUFBLENBQUMsbUJBQW1CLFFBQVEsR0FBRyxRQUFRLGVBQWU7Q0FBQTtBQUU1RDtBQUNBLElBQU0sOEJBQThCLHVCQUF1QjtDQUMxRCxhQUFNLGdCQUFnQjtFQUNyQixtQkFBbUIsV0FBVztDQUMvQixHQUFHLENBQUMsa0JBQWtCLENBQUM7QUFDeEI7QUFDQSxJQUFNLGVBQWUsRUFBRSxRQUFRLG9CQUFvQixjQUFjLE9BQU8sZUFBZTtDQUN0RixPQUFPLE9BQU8sV0FBVyxDQUFDLG1CQUFtQixRQUFRLEtBQUssQ0FBQyxPQUFPLGNBQWMsVUFBVSxZQUFZLE9BQU8sU0FBUyxLQUFLLEtBQUssaUJBQWlCLGNBQWMsQ0FBQyxPQUFPLE9BQU8sS0FBSyxDQUFDO0FBQ3JMOzs7QUNoQkEsSUFBTSx1QkFBdUIsUUFBUSxVQUFVLE1BQU0sTUFBTSxTQUFTLEtBQUs7QUFDekUsSUFBTSx3QkFBd0IscUJBQXFCO0NBQ2xELElBQUksaUJBQWlCLFVBQVU7RUFDOUIsTUFBTSx1QkFBdUI7RUFDN0IsTUFBTSxTQUFTLFVBQVUsVUFBVSxXQUFXLFFBQVEsS0FBSyxJQUFJLFNBQVMsc0JBQXNCLG9CQUFvQjtFQUNsSCxNQUFNLG9CQUFvQixpQkFBaUI7RUFDM0MsaUJBQWlCLFlBQVksT0FBTyxzQkFBc0IsY0FBYyxHQUFHLFNBQVMsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFNLGlCQUFpQjtFQUMvSSxJQUFJLE9BQU8saUJBQWlCLFdBQVcsVUFBVSxpQkFBaUIsU0FBUyxLQUFLLElBQUksaUJBQWlCLFFBQVEsb0JBQW9CO0NBQ2xJO0FBQ0Q7QUFDQSxJQUFNLGlCQUFpQixrQkFBa0IsV0FBVyxrQkFBa0IsWUFBWSxPQUFPO0FBQ3pGLElBQU0sbUJBQW1CLGtCQUFrQixVQUFVLHVCQUF1QixTQUFTLGdCQUFnQixnQkFBZ0IsQ0FBQyxDQUFDLFlBQVk7Q0FDbEksbUJBQW1CLFdBQVc7QUFDL0IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzZIRCxTQUFTLFdBQVcsRUFBRSxTQUFTLEdBQUcsV0FBVyxhQUFhO0NBQ3pELE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxxQkFBcUIsMkJBQTJCO0NBQ3RELE1BQU0sYUFBYSxRQUFRLGVBQWU7Q0FDMUMsTUFBTSxtQkFBQSxhQUF5QixjQUFjLFFBQVEsS0FBSyxTQUFTO0VBQ2xFLE1BQU0sbUJBQW1CLE9BQU8sb0JBQW9CLElBQUk7RUFDeEQsaUJBQWlCLHFCQUFxQixjQUFjLGdCQUFnQixhQUFhLGVBQWUsS0FBSztFQUNyRyxPQUFPO0NBQ1IsQ0FBQyxHQUFHO0VBQ0g7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsaUJBQWlCLFNBQVMsaUJBQWlCO0VBQzFDLHFCQUFxQixZQUFZO0VBQ2pDLE1BQU0sUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksYUFBYSxTQUFTO0VBQy9ELGdDQUFnQyxjQUFjLG9CQUFvQixLQUFLO0NBQ3hFLENBQUM7Q0FDRCwyQkFBMkIsa0JBQWtCO0NBQzdDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQWUsSUFBSSxnQkFBZ0IsUUFBUSxrQkFBa0IsT0FBTyxDQUFDO0NBQzlGLE1BQU0sQ0FBQyxrQkFBa0IsbUJBQW1CLGVBQWUsU0FBUyxvQkFBb0Isa0JBQWtCLFFBQVEsT0FBTztDQUN6SCxNQUFNLGtCQUFrQixDQUFDLGVBQWU7Q0FDeEMsYUFBTSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsSUFBSSxNQUFNLENBQUMsVUFBVSxlQUFlLENBQUMsU0FBUyxTQUFTLGlCQUFpQixTQUFTLFNBQVMsaUJBQWlCLENBQUM7Q0FDeFAsYUFBTSxnQkFBZ0I7RUFDckIsU0FBUyxXQUFXLGtCQUFrQixPQUFPO0NBQzlDLEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxtQkFBbUIsaUJBQWlCLE1BQU0sUUFBUSxVQUFVLGNBQWMsaUJBQWlCLFFBQVEsTUFBTSxDQUFDLElBQUksaUJBQWlCLFNBQVMsUUFBUSxVQUFVO0VBQy9KLE1BQU0sT0FBTyxpQkFBaUI7RUFDOUIsSUFBSSxRQUFRLGNBQWMsTUFBTSxNQUFNLEdBRXJDLE9BQU8sZ0JBQWdCLE1BQU0sSUFESCxjQUFjLFFBQVEsSUFDbkIsR0FBZSxrQkFBa0I7RUFFL0QsT0FBTyxDQUFDO0NBQ1QsQ0FBQyxJQUFJLENBQUM7Q0FDTixJQUFJLGlCQUFpQixTQUFTLEdBQUcsTUFBTSxRQUFRLElBQUksZ0JBQWdCO0NBQ25FLE1BQU0sb0NBQW9DLGlCQUFpQixNQUFNLFFBQVEsVUFBVTtFQUNsRixNQUFNLFFBQVEsaUJBQWlCO0VBQy9CLE9BQU8sU0FBUyxZQUFZO0dBQzNCO0dBQ0E7R0FDQSxjQUFjLE1BQU07R0FDcEIsT0FBTyxPQUFPLGNBQWMsQ0FBQyxDQUFDLElBQUksTUFBTSxTQUFTO0dBQ2pELFVBQVUsTUFBTTtFQUNqQixDQUFDO0NBQ0YsQ0FBQztDQUNELElBQUksbUNBQW1DLE1BQU0sa0NBQWtDO0NBQy9FLE9BQU8sa0JBQWtCLFlBQVksQ0FBQztBQUN2Qzs7O0FDdkxBLFNBQVMsYUFBYSxTQUFTLFVBQVUsYUFBYTtDQUVwRCxJQUFJLE9BQU8sWUFBWSxZQUFZLE1BQU0sUUFBUSxPQUFPLEdBQUcsTUFBTSxJQUFJLE1BQU0sZ1NBQWdTO0NBRTVXLE1BQU0sY0FBYyxlQUFlO0NBQ25DLE1BQU0scUJBQXFCLDJCQUEyQjtDQUN0RCxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sbUJBQW1CLE9BQU8sb0JBQW9CLE9BQU87Q0FDM0QsTUFBTSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxpQkFBaUIsU0FBUztDQUVsRSxJQUFJLENBQUMsaUJBQWlCLFNBQVMsUUFBUSxNQUFNLElBQUksaUJBQWlCLFVBQVUsbVBBQW1QO0NBRWhVLE1BQU0sYUFBYSxRQUFRLGVBQWU7Q0FDMUMsaUJBQWlCLHFCQUFxQixjQUFjLGdCQUFnQixhQUFhLGVBQWUsS0FBSztDQUNyRyxxQkFBcUIsZ0JBQWdCO0NBQ3JDLGdDQUFnQyxrQkFBa0Isb0JBQW9CLEtBQUs7Q0FDM0UsMkJBQTJCLGtCQUFrQjtDQUM3QyxNQUFNLENBQUMsWUFBQSxhQUFrQixlQUFlLElBQUksU0FBUyxRQUFRLGdCQUFnQixDQUFDO0NBQzlFLE1BQU0sU0FBUyxTQUFTLG9CQUFvQixnQkFBZ0I7Q0FDNUQsTUFBTSxrQkFBa0IsQ0FBQyxlQUFlO0NBQ3hDLGFBQU0scUJBQUEsYUFBMkIsYUFBYSxrQkFBa0I7RUFDL0QsTUFBTSxjQUFjLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxJQUFJO0VBQ3BHLFNBQVMsYUFBYTtFQUN0QixPQUFPO0NBQ1IsR0FBRyxDQUFDLFVBQVUsZUFBZSxDQUFDLFNBQVMsU0FBUyxpQkFBaUIsU0FBUyxTQUFTLGlCQUFpQixDQUFDO0NBQ3JHLGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxnQkFBZ0I7Q0FDckMsR0FBRyxDQUFDLGtCQUFrQixRQUFRLENBQUM7Q0FDL0IsSUFBSSxjQUFjLGtCQUFrQixNQUFNLEdBQUcsTUFBTSxnQkFBZ0Isa0JBQWtCLFVBQVUsa0JBQWtCO0NBQ2pILElBQUksWUFBWTtFQUNmO0VBQ0E7RUFDQSxjQUFjLGlCQUFpQjtFQUMvQjtFQUNBLFVBQVUsaUJBQWlCO0NBQzVCLENBQUMsR0FBRyxNQUFNLE9BQU87Q0FDakIsT0FBTyxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxZQUFZLE1BQU0sSUFBSTtBQUMvRTs7O0FDMUNBLFNBQVMsU0FBUyxTQUFTLGFBQWE7Q0FDdkMsT0FBTyxhQUFhLFNBQVMsZUFBZSxXQUFXO0FBQ3hEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDa0VBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUU5QyxJQUFJLFFBQVEsWUFBWSxXQUFXLFFBQVEsTUFBTSwrQ0FBK0M7Q0FFakcsT0FBTyxhQUFhO0VBQ25CLEdBQUc7RUFDSCxTQUFTO0VBQ1QsVUFBVTtFQUNWLGNBQWM7RUFDZCxpQkFBaUIsS0FBSztDQUN2QixHQUFHLGVBQWUsV0FBVztBQUM5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNRQSxTQUFTLHlCQUF5QixTQUFTLGFBQWE7Q0FFdEQsSUFBSSxRQUFRLFlBQVksV0FBVyxRQUFRLE1BQU0sdURBQXVEO0NBRXpHLE9BQU8sYUFBYTtFQUNuQixHQUFHO0VBQ0gsU0FBUztFQUNULFVBQVU7RUFDVixjQUFjO0VBQ2QsaUJBQWlCLEtBQUs7Q0FDdkIsR0FBRyx1QkFBdUIsV0FBVztBQUN0Qzs7O0FDakdBLFNBQVMsbUJBQW1CLFNBQVMsYUFBYTtDQUNqRCxPQUFPLFdBQVc7RUFDakIsR0FBRztFQUNILFNBQVMsUUFBUSxRQUFRLEtBQUssVUFBVTtHQUV0QyxJQUFJLE1BQU0sWUFBWSxXQUFXLFFBQVEsTUFBTSxpREFBaUQ7R0FFakcsT0FBTztJQUNOLEdBQUc7SUFDSCxVQUFVO0lBQ1YsY0FBYztJQUNkLFNBQVM7SUFDVCxpQkFBaUIsS0FBSztHQUN2QjtFQUNELENBQUM7Q0FDRixHQUFHLFdBQVc7QUFDZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNpQkEsU0FBUyxpQkFBaUIsU0FBUyxhQUFhO0NBQy9DLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsSUFBSSxDQUFDLE9BQU8sY0FBYyxRQUFRLFFBQVEsR0FBRyxPQUFPLE1BQU0sT0FBTyxDQUFDLENBQUMsTUFBTSxJQUFJO0FBQzlFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ01BLFNBQVMseUJBQXlCLFNBQVMsYUFBYTtDQUN2RCxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQUcsT0FBTyxjQUFjLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSTtBQUN0Rjs7O0FDakRBLFNBQVMsYUFBYSxTQUFTO0NBQzlCLE9BQU87QUFDUjs7O0FDRkEsU0FBUyxxQkFBcUIsU0FBUztDQUN0QyxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3NDQSxTQUFTLGNBQWMsU0FBUyxhQUFhO0NBQzVDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxPQUFBLGFBQWEscUJBQUEsYUFBMkIsYUFBYSxrQkFBa0IsV0FBVyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLE9BQU8sQ0FBQztBQUN4Tjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJBLFNBQVMsY0FBYyxTQUFTLGFBQWE7Q0FDNUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxPQUFPLGlCQUFpQixFQUFFLFNBQVM7RUFDbEMsR0FBRztFQUNILFFBQVE7Q0FDVCxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDZDtBQUNBLFNBQVMsVUFBVSxlQUFlLFNBQVM7Q0FDMUMsT0FBTyxjQUFjLFFBQVEsUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLGFBQWEsUUFBUSxTQUFTLFFBQVEsT0FBTyxRQUFRLElBQUksU0FBUyxLQUFLO0FBQzNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTBFQSxTQUFTLGlCQUFpQixVQUFVLENBQUMsR0FBRyxhQUFhO0NBQ3BELE1BQU0sZ0JBQWdCLGVBQWUsV0FBVyxDQUFDLENBQUMsaUJBQWlCO0NBQ25FLE1BQU0sYUFBQSxhQUFtQixPQUFPLE9BQU87Q0FDdkMsTUFBTSxZQUFBLGFBQWtCLE9BQU8sSUFBSTtDQUNuQyxJQUFJLFVBQVUsWUFBWSxNQUFNLFVBQVUsVUFBVSxVQUFVLGVBQWUsT0FBTztDQUNwRixhQUFNLGdCQUFnQjtFQUNyQixXQUFXLFVBQVU7Q0FDdEIsQ0FBQztDQUNELE9BQUEsYUFBYSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixjQUFjLGdCQUFnQjtFQUNwRyxNQUFNLGFBQWEsaUJBQWlCLFVBQVUsU0FBUyxVQUFVLGVBQWUsV0FBVyxPQUFPLENBQUM7RUFDbkcsSUFBSSxVQUFVLFlBQVksWUFBWTtHQUNyQyxVQUFVLFVBQVU7R0FDcEIsY0FBYyxTQUFTLGFBQWE7RUFDckM7Q0FDRCxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsU0FBUyxVQUFVLGVBQWUsVUFBVSxPQUFPO0FBQ3ZFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcURBLFNBQVMsWUFBWSxTQUFTLGFBQWE7Q0FDMUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLENBQUMsWUFBQSxhQUFrQixlQUFlLElBQUksaUJBQWlCLFFBQVEsT0FBTyxDQUFDO0NBQzdFLGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxPQUFPO0NBQzVCLEdBQUcsQ0FBQyxVQUFVLE9BQU8sQ0FBQztDQUN0QixNQUFNLFNBQUEsYUFBZSxxQkFBQSxhQUEyQixhQUFhLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFNBQVMsU0FBUyxpQkFBaUIsU0FBUyxTQUFTLGlCQUFpQixDQUFDO0NBQzdOLE1BQU0sU0FBQSxhQUFlLGFBQWEsR0FBRyxTQUFTO0VBQzdDLFNBQVMsT0FBTyxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDN0MsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUNiLElBQUksT0FBTyxTQUFTLGlCQUFpQixTQUFTLFFBQVEsY0FBYyxDQUFDLE9BQU8sS0FBSyxDQUFDLEdBQUcsTUFBTSxPQUFPO0NBQ2xHLE9BQU87RUFDTixHQUFHO0VBQ0g7RUFDQSxhQUFhLE9BQU87Q0FDckI7QUFDRDs7O0FDaE1BLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDakMsT0FBTztBQUNSOzs7QUNDQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDL0MsT0FBTyxhQUFhLFNBQVMsdUJBQXVCLFdBQVc7QUFDaEUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119