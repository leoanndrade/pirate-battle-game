import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/menus/CaptainsLog.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=eccdfead";
import axios from "/node_modules/.vite/deps/axios.js?v=eccdfead";
import { useGameStore } from "/src/store/gameStore.ts";
import { soundManager } from "/src/game/SoundManager.ts";
import { SpriteButton } from "/src/ui/components/SpriteButton.tsx";
import { SpriteIcon } from "/src/ui/components/SpriteIcon.tsx";
import { MenuScreen, Panel, MenuTitle, theme, formatClock, formatDay, formatHour } from "/src/ui/components/menus/MenuKit.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/CaptainsLog.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
const PAGE_SIZE = 5;
const rowStyle = (highlight) => ({
	display: "grid",
	alignItems: "center",
	height: 50,
	marginBottom: 8,
	borderRadius: 6,
	background: highlight ? "rgba(160,130,60,0.45)" : "rgba(10,20,35,0.55)",
	border: highlight ? "1px solid rgba(245,196,81,0.5)" : "1px solid rgba(0,0,0,0.25)",
	fontSize: "1.05rem",
	fontWeight: 700
});
const cell = {
	padding: "0 14px",
	height: "100%",
	display: "flex",
	alignItems: "center",
	borderRight: "1px solid rgba(0,0,0,0.25)"
};
const headerStyle = {
	display: "grid",
	padding: "0 0 10px",
	fontSize: "0.72rem",
	fontWeight: 700,
	letterSpacing: 1.5,
	color: theme.muted
};
const RANK_COLS = "1.2fr 3fr 1.4fr 2fr";
const HIST_COLS = "2.6fr 1.6fr 2fr 1.6fr";
const fetchJson = (url) => async () => (await axios.get(url)).data;
export const CaptainsLog = () => {
	_s();
	const { setGameState, logTab, setLogTab, matchDuration, spawnRate } = useGameStore();
	const [page, setPage] = useState(0);
	const ranking = useQuery({
		queryKey: ["ranking"],
		queryFn: fetchJson("/api/ranking")
	});
	const history = useQuery({
		queryKey: ["history"],
		queryFn: fetchJson("/api/history")
	});
	const rows = (logTab === "RANKING" ? ranking.data : history.data) ?? [];
	const list = Array.isArray(rows) ? rows : [];
	const pageCount = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
	const visible = list.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);
	const switchTab = (tab) => {
		if (tab === logTab) return;
		soundManager.play("ui_click");
		setLogTab(tab);
		setPage(0);
	};
	const turnPage = (dir) => {
		soundManager.play("ui_click");
		setPage((p) => Math.min(pageCount - 1, Math.max(0, p + dir)));
	};
	return /* @__PURE__ */ _jsxDEV(MenuScreen, { children: /* @__PURE__ */ _jsxDEV(Panel, {
		width: 1400,
		minHeight: 740,
		style: { padding: "0 20px" },
		children: [
			/* @__PURE__ */ _jsxDEV(MenuTitle, {
				style: { marginTop: -16 },
				children: "CAPTAIN'S LOG"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 55,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				style: {
					display: "flex",
					gap: 30,
					margin: "10px 0 14px"
				},
				children: [/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: logTab === "RANKING" ? "button_primary" : "button_secondary",
					scale: .9,
					text: "RANKING",
					textStyle: { fontSize: "1.2rem" },
					onClick: () => switchTab("RANKING"),
					style: { margin: 0 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: logTab === "HISTORY" ? "button_primary" : "button_secondary",
					scale: .9,
					text: "MATCH HISTORY",
					textStyle: { fontSize: "1.2rem" },
					onClick: () => switchTab("HISTORY"),
					style: { margin: 0 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				style: {
					margin: "0 0 22px",
					fontSize: "0.85rem",
					fontWeight: 700,
					letterSpacing: .5
				},
				children: logTab === "RANKING" ? `${matchDuration} SECOND BATTLES · ${spawnRate} SECOND SPAWN INTERVAL` : "CAPTAIN JACK · YOUR RECENT BATTLES"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				style: {
					width: "100%",
					minHeight: 5 * 58 + 26
				},
				children: logTab === "RANKING" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
					style: {
						...headerStyle,
						gridTemplateColumns: RANK_COLS
					},
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							style: { paddingLeft: 14 },
							children: "RANK"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							style: { paddingLeft: 14 },
							children: "CAPTAIN"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 62
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							style: { paddingLeft: 14 },
							children: "POINTS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							style: { paddingLeft: 14 },
							children: "PLAYED"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 64
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 15
				}, this), visible.map((e, i) => {
					const rank = page * PAGE_SIZE + i + 1;
					return /* @__PURE__ */ _jsxDEV("div", {
						style: {
							...rowStyle(!!e.isPlayer),
							gridTemplateColumns: RANK_COLS
						},
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								style: {
									...cell,
									color: theme.gold
								},
								children: String(rank).padStart(2, "0")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: {
									...cell,
									gap: 8
								},
								children: [
									rank === 1 && /* @__PURE__ */ _jsxDEV(SpriteIcon, {
										name: "icon_score",
										scale: .55
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 82,
										columnNumber: 38
									}, this),
									e.name,
									e.isPlayer && /* @__PURE__ */ _jsxDEV("span", {
										style: {
											fontSize: "0.6rem",
											padding: "1px 5px",
											border: `1px solid ${theme.gold}`,
											borderRadius: 3,
											color: theme.gold
										},
										children: "YOU"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 85,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: {
									...cell,
									color: theme.gold
								},
								children: e.score
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: {
									...cell,
									borderRight: "none",
									fontSize: "0.85rem"
								},
								children: [
									formatDay(e.date),
									" · ",
									formatHour(e.date)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 21
							}, this)
						]
					}, e.id, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 19
					}, this);
				})] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						style: {
							...headerStyle,
							gridTemplateColumns: HIST_COLS
						},
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								style: { paddingLeft: 14 },
								children: "DATE"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: { paddingLeft: 14 },
								children: "POINTS"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 62
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: { paddingLeft: 14 },
								children: "DURATION"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: { paddingLeft: 14 },
								children: "RESULT"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 66
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 15
					}, this),
					visible.map((e, i) => /* @__PURE__ */ _jsxDEV("div", {
						style: {
							...rowStyle(page === 0 && i === 0),
							gridTemplateColumns: HIST_COLS
						},
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								style: cell,
								children: [formatDay(e.date), /* @__PURE__ */ _jsxDEV("span", {
									style: {
										fontSize: "0.8rem",
										marginLeft: 6,
										color: theme.muted
									},
									children: ["· ", formatHour(e.date)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 102,
									columnNumber: 57
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: {
									...cell,
									color: theme.gold
								},
								children: e.score
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: cell,
								children: formatClock(e.duration)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								style: {
									...cell,
									borderRight: "none",
									fontSize: "0.8rem",
									color: e.result === "TIME_UP" ? theme.cream : theme.red
								},
								children: e.result === "TIME_UP" ? "TIME UP" : "DEFEATED"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 19
							}, this)
						]
					}, e.id, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 17
					}, this)),
					visible.length === 0 && !history.isLoading && /* @__PURE__ */ _jsxDEV("p", {
						style: {
							textAlign: "center",
							color: theme.muted,
							marginTop: 60
						},
						children: "No battles yet. Set sail to start your log!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 17
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 20,
					margin: "4px 0 6px"
				},
				children: [
					/* @__PURE__ */ _jsxDEV(SpriteButton, {
						baseName: "button_round",
						scale: .65,
						icon: "icon_turn_left",
						iconScale: .5,
						disabled: page === 0,
						onClick: () => turnPage(-1),
						style: { margin: 0 }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						style: {
							fontSize: "0.85rem",
							fontWeight: 700
						},
						children: [
							"PAGE ",
							page + 1,
							" OF ",
							pageCount
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(SpriteButton, {
						baseName: "button_round",
						scale: .65,
						icon: "icon_turn_right",
						iconScale: .5,
						disabled: page >= pageCount - 1,
						onClick: () => turnPage(1),
						style: { margin: 0 }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(SpriteButton, {
				baseName: "button_primary",
				scale: 1.1,
				text: "MAIN MENU",
				textStyle: { fontSize: "1.5rem" },
				onClick: () => {
					soundManager.play("ui_click");
					setGameState("START_MENU");
				},
				style: { margin: "4px 0 -20px" }
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 5
	}, this);
};
_s(CaptainsLog, "CtLLRP9bopxw5schg+4+UkxiTJ4=", false, function() {
	return [
		useGameStore,
		useQuery,
		useQuery
	];
});
_c = CaptainsLog;
var _c;
$RefreshReg$(_c, "CaptainsLog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/menus/CaptainsLog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/CaptainsLog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/CaptainsLog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/CaptainsLog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGdCQUFnQjtBQUN6QixPQUFPLFdBQVc7QUFDbEIsU0FBUyxvQkFBb0I7QUFHN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxZQUFZLE9BQU8sV0FBVyxPQUFPLGFBQWEsV0FBVyxrQkFBa0I7Ozs7QUFFeEYsTUFBTSxZQUFZO0FBRWxCLE1BQU0sWUFBWSxlQUE2QztDQUM3RCxTQUFTO0NBQVEsWUFBWTtDQUFVLFFBQVE7Q0FBSSxjQUFjO0NBQUcsY0FBYztDQUNsRixZQUFZLFlBQVksMEJBQTBCO0NBQ2xELFFBQVEsWUFBWSxtQ0FBbUM7Q0FDdkQsVUFBVTtDQUFXLFlBQVk7QUFDbkM7QUFDQSxNQUFNLE9BQTRCO0NBQUUsU0FBUztDQUFVLFFBQVE7Q0FBUSxTQUFTO0NBQVEsWUFBWTtDQUFVLGFBQWE7QUFBNkI7QUFDeEosTUFBTSxjQUFtQztDQUFFLFNBQVM7Q0FBUSxTQUFTO0NBQVksVUFBVTtDQUFXLFlBQVk7Q0FBSyxlQUFlO0NBQUssT0FBTyxNQUFNO0FBQU07QUFFOUosTUFBTSxZQUFZO0FBQ2xCLE1BQU0sWUFBWTtBQUVsQixNQUFNLGFBQWlCLFFBQWdCLGFBQWEsTUFBTSxNQUFNLElBQU8sR0FBRyxFQUFDLENBQUU7QUFFN0UsT0FBTyxNQUFNLG9CQUE4Qjs7Q0FDekMsTUFBTSxFQUFFLGNBQWMsUUFBUSxXQUFXLGVBQWUsY0FBYyxhQUFhO0NBQ25GLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBRWxDLE1BQU0sVUFBVSxTQUF1QjtFQUFFLFVBQVUsQ0FBQyxTQUFTO0VBQUcsU0FBUyxVQUFVLGNBQWM7Q0FBRSxDQUFDO0NBQ3BHLE1BQU0sVUFBVSxTQUF5QjtFQUFFLFVBQVUsQ0FBQyxTQUFTO0VBQUcsU0FBUyxVQUFVLGNBQWM7Q0FBRSxDQUFDO0NBRXRHLE1BQU0sUUFBUSxXQUFXLFlBQVksUUFBUSxPQUFPLFFBQVEsU0FBUyxDQUFDO0NBQ3RFLE1BQU0sT0FBTyxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sQ0FBQztDQUMzQyxNQUFNLFlBQVksS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLEtBQUssU0FBUyxTQUFTLENBQUM7Q0FDaEUsTUFBTSxVQUFVLEtBQUssTUFBTSxPQUFPLFdBQVcsT0FBTyxZQUFZLFNBQVM7Q0FFekUsTUFBTSxhQUFhLFFBQWdCO0VBQ2pDLElBQUksUUFBUSxRQUFRO0VBQ3BCLGFBQWEsS0FBSyxVQUFVO0VBQzVCLFVBQVUsR0FBRztFQUNiLFFBQVEsQ0FBQztDQUNYO0NBRUEsTUFBTSxZQUFZLFFBQWdCO0VBQ2hDLGFBQWEsS0FBSyxVQUFVO0VBQzVCLFNBQVMsTUFBTSxLQUFLLElBQUksWUFBWSxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDLENBQUM7Q0FDOUQ7Q0FFQSxPQUNFLHdCQUFDLFlBQUQsWUFDRSx3QkFBQyxPQUFEO0VBQU8sT0FBTztFQUFNLFdBQVc7RUFBSyxPQUFPLEVBQUUsU0FBUyxTQUFTO1lBQS9EO0dBQ0Usd0JBQUMsV0FBRDtJQUFXLE9BQU8sRUFBRSxXQUFXLENBQUMsR0FBRztjQUFHO0dBQXdCOzs7OztHQUc5RCx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLFNBQVM7S0FBUSxLQUFLO0tBQUksUUFBUTtJQUFjO2NBQTlELENBQ0Usd0JBQUMsY0FBRDtLQUFjLFVBQVUsV0FBVyxZQUFZLG1CQUFtQjtLQUFvQixPQUFPO0tBQUssTUFBSztLQUFVLFdBQVcsRUFBRSxVQUFVLFNBQVM7S0FBRyxlQUFlLFVBQVUsU0FBUztLQUFHLE9BQU8sRUFBRSxRQUFRLEVBQUU7SUFBSTs7OztjQUNoTix3QkFBQyxjQUFEO0tBQWMsVUFBVSxXQUFXLFlBQVksbUJBQW1CO0tBQW9CLE9BQU87S0FBSyxNQUFLO0tBQWdCLFdBQVcsRUFBRSxVQUFVLFNBQVM7S0FBRyxlQUFlLFVBQVUsU0FBUztLQUFHLE9BQU8sRUFBRSxRQUFRLEVBQUU7SUFBSTs7OztZQUNuTjs7Ozs7O0dBRUwsd0JBQUMsS0FBRDtJQUFHLE9BQU87S0FBRSxRQUFRO0tBQVksVUFBVTtLQUFXLFlBQVk7S0FBSyxlQUFlO0lBQUk7Y0FDdEYsV0FBVyxZQUNSLEdBQUcsY0FBYyxvQkFBb0IsVUFBVSwwQkFDL0M7R0FDSDs7Ozs7R0FFSCx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLE9BQU87S0FBUSxXQUFXLElBQUksS0FBSztJQUFHO2NBQ2pELFdBQVcsWUFDVixnREFDRSx3QkFBQyxPQUFEO0tBQUssT0FBTztNQUFFLEdBQUc7TUFBYSxxQkFBcUI7S0FBVTtlQUE3RDtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxPQUFPLEVBQUUsYUFBYSxHQUFHO2lCQUFHO01BQVU7Ozs7O01BQUMsd0JBQUMsUUFBRDtPQUFNLE9BQU8sRUFBRSxhQUFhLEdBQUc7aUJBQUc7TUFBYTs7Ozs7TUFDNUYsd0JBQUMsUUFBRDtPQUFNLE9BQU8sRUFBRSxhQUFhLEdBQUc7aUJBQUc7TUFBWTs7Ozs7TUFBQyx3QkFBQyxRQUFEO09BQU0sT0FBTyxFQUFFLGFBQWEsR0FBRztpQkFBRztNQUFZOzs7OztLQUMxRjs7Ozs7Y0FDSCxRQUF5QixLQUFLLEdBQUcsTUFBTTtLQUN2QyxNQUFNLE9BQU8sT0FBTyxZQUFZLElBQUk7S0FDcEMsT0FDRSx3QkFBQyxPQUFEO01BQWdCLE9BQU87T0FBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDLEVBQUUsUUFBUTtPQUFHLHFCQUFxQjtNQUFVO2dCQUFuRjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxPQUFPO1NBQUUsR0FBRztTQUFNLE9BQU8sTUFBTTtRQUFLO2tCQUFJLE9BQU8sSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7T0FBUTs7Ozs7T0FDbEYsd0JBQUMsUUFBRDtRQUFNLE9BQU87U0FBRSxHQUFHO1NBQU0sS0FBSztRQUFFO2tCQUEvQjtTQUNHLFNBQVMsS0FBSyx3QkFBQyxZQUFEO1VBQVksTUFBSztVQUFhLE9BQU87U0FBTzs7Ozs7U0FDMUQsRUFBRTtTQUNGLEVBQUUsWUFDRCx3QkFBQyxRQUFEO1VBQU0sT0FBTztXQUFFLFVBQVU7V0FBVSxTQUFTO1dBQVcsUUFBUSxhQUFhLE1BQU07V0FBUSxjQUFjO1dBQUcsT0FBTyxNQUFNO1VBQUs7b0JBQUc7U0FBUzs7Ozs7UUFFdkk7Ozs7OztPQUNOLHdCQUFDLFFBQUQ7UUFBTSxPQUFPO1NBQUUsR0FBRztTQUFNLE9BQU8sTUFBTTtRQUFLO2tCQUFJLEVBQUU7T0FBWTs7Ozs7T0FDNUQsd0JBQUMsUUFBRDtRQUFNLE9BQU87U0FBRSxHQUFHO1NBQU0sYUFBYTtTQUFRLFVBQVU7UUFBVTtrQkFBakU7U0FBcUUsVUFBVSxFQUFFLElBQUk7U0FBRTtTQUFJLFdBQVcsRUFBRSxJQUFJO1FBQVE7Ozs7OztNQUNqSDtRQVhLLEVBQUU7Ozs7WUFXUDtJQUVULENBQUMsQ0FDRDs7OztlQUVGO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLE9BQU87T0FBRSxHQUFHO09BQWEscUJBQXFCO01BQVU7Z0JBQTdEO09BQ0Usd0JBQUMsUUFBRDtRQUFNLE9BQU8sRUFBRSxhQUFhLEdBQUc7a0JBQUc7T0FBVTs7Ozs7T0FBQyx3QkFBQyxRQUFEO1FBQU0sT0FBTyxFQUFFLGFBQWEsR0FBRztrQkFBRztPQUFZOzs7OztPQUMzRix3QkFBQyxRQUFEO1FBQU0sT0FBTyxFQUFFLGFBQWEsR0FBRztrQkFBRztPQUFjOzs7OztPQUFDLHdCQUFDLFFBQUQ7UUFBTSxPQUFPLEVBQUUsYUFBYSxHQUFHO2tCQUFHO09BQVk7Ozs7O01BQzVGOzs7Ozs7S0FDSCxRQUEyQixLQUFLLEdBQUcsTUFDbkMsd0JBQUMsT0FBRDtNQUFnQixPQUFPO09BQUUsR0FBRyxTQUFTLFNBQVMsS0FBSyxNQUFNLENBQUM7T0FBRyxxQkFBcUI7TUFBVTtnQkFBNUY7T0FDRSx3QkFBQyxRQUFEO1FBQU0sT0FBTztrQkFBYixDQUFvQixVQUFVLEVBQUUsSUFBSSxHQUFFLHdCQUFDLFFBQUQ7U0FBTSxPQUFPO1VBQUUsVUFBVTtVQUFVLFlBQVk7VUFBRyxPQUFPLE1BQU07U0FBTTttQkFBckUsQ0FBd0UsTUFBRyxXQUFXLEVBQUUsSUFBSSxDQUFROzs7OztnQkFBTzs7Ozs7O09BQ2pKLHdCQUFDLFFBQUQ7UUFBTSxPQUFPO1NBQUUsR0FBRztTQUFNLE9BQU8sTUFBTTtRQUFLO2tCQUFJLEVBQUU7T0FBWTs7Ozs7T0FDNUQsd0JBQUMsUUFBRDtRQUFNLE9BQU87a0JBQU8sWUFBWSxFQUFFLFFBQVE7T0FBUTs7Ozs7T0FDbEQsd0JBQUMsUUFBRDtRQUFNLE9BQU87U0FBRSxHQUFHO1NBQU0sYUFBYTtTQUFRLFVBQVU7U0FBVSxPQUFPLEVBQUUsV0FBVyxZQUFZLE1BQU0sUUFBUSxNQUFNO1FBQUk7a0JBQ3RILEVBQUUsV0FBVyxZQUFZLFlBQVk7T0FDbEM7Ozs7O01BQ0g7UUFQSyxFQUFFOzs7O1lBT1AsQ0FDTjtLQUNBLFFBQVEsV0FBVyxLQUFLLENBQUMsUUFBUSxhQUNoQyx3QkFBQyxLQUFEO01BQUcsT0FBTztPQUFFLFdBQVc7T0FBVSxPQUFPLE1BQU07T0FBTyxXQUFXO01BQUc7Z0JBQUc7S0FBOEM7Ozs7O0lBRXRIOzs7OztHQUVEOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxPQUFPO0tBQUUsU0FBUztLQUFRLFlBQVk7S0FBVSxLQUFLO0tBQUksUUFBUTtJQUFZO2NBQWxGO0tBQ0Usd0JBQUMsY0FBRDtNQUFjLFVBQVM7TUFBZSxPQUFPO01BQU0sTUFBSztNQUFpQixXQUFXO01BQUssVUFBVSxTQUFTO01BQUcsZUFBZSxTQUFTLENBQUMsQ0FBQztNQUFHLE9BQU8sRUFBRSxRQUFRLEVBQUU7S0FBSTs7Ozs7S0FDbkssd0JBQUMsUUFBRDtNQUFNLE9BQU87T0FBRSxVQUFVO09BQVcsWUFBWTtNQUFJO2dCQUFwRDtPQUF1RDtPQUFNLE9BQU87T0FBRTtPQUFLO01BQWdCOzs7Ozs7S0FDM0Ysd0JBQUMsY0FBRDtNQUFjLFVBQVM7TUFBZSxPQUFPO01BQU0sTUFBSztNQUFrQixXQUFXO01BQUssVUFBVSxRQUFRLFlBQVk7TUFBRyxlQUFlLFNBQVMsQ0FBQztNQUFHLE9BQU8sRUFBRSxRQUFRLEVBQUU7S0FBSTs7Ozs7SUFDM0s7Ozs7OztHQUVMLHdCQUFDLGNBQUQ7SUFBYyxVQUFTO0lBQWlCLE9BQU87SUFBSyxNQUFLO0lBQVksV0FBVyxFQUFFLFVBQVUsU0FBUztJQUNuRyxlQUFlO0tBQUUsYUFBYSxLQUFLLFVBQVU7S0FBRyxhQUFhLFlBQVk7SUFBRztJQUFHLE9BQU8sRUFBRSxRQUFRLGNBQWM7R0FBSTs7Ozs7RUFDL0c7Ozs7O1VBQ0c7Ozs7O0FBRWhCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcHRhaW5zTG9nLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSc7XG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xuaW1wb3J0IHsgdXNlR2FtZVN0b3JlIH0gZnJvbSAnLi4vLi4vLi4vc3RvcmUvZ2FtZVN0b3JlJztcbmltcG9ydCB0eXBlIHsgTG9nVGFiIH0gZnJvbSAnLi4vLi4vLi4vc3RvcmUvZ2FtZVN0b3JlJztcbmltcG9ydCB0eXBlIHsgU2NvcmVFbnRyeSwgSGlzdG9yeUVudHJ5IH0gZnJvbSAnLi4vLi4vLi4vbW9ja3MvaGFuZGxlcnMnO1xuaW1wb3J0IHsgc291bmRNYW5hZ2VyIH0gZnJvbSAnLi4vLi4vLi4vZ2FtZS9Tb3VuZE1hbmFnZXInO1xuaW1wb3J0IHsgU3ByaXRlQnV0dG9uIH0gZnJvbSAnLi4vU3ByaXRlQnV0dG9uJztcbmltcG9ydCB7IFNwcml0ZUljb24gfSBmcm9tICcuLi9TcHJpdGVJY29uJztcbmltcG9ydCB7IE1lbnVTY3JlZW4sIFBhbmVsLCBNZW51VGl0bGUsIHRoZW1lLCBmb3JtYXRDbG9jaywgZm9ybWF0RGF5LCBmb3JtYXRIb3VyIH0gZnJvbSAnLi9NZW51S2l0JztcblxuY29uc3QgUEFHRV9TSVpFID0gNTtcblxuY29uc3Qgcm93U3R5bGUgPSAoaGlnaGxpZ2h0OiBib29sZWFuKTogUmVhY3QuQ1NTUHJvcGVydGllcyA9PiAoe1xuICBkaXNwbGF5OiAnZ3JpZCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBoZWlnaHQ6IDUwLCBtYXJnaW5Cb3R0b206IDgsIGJvcmRlclJhZGl1czogNixcbiAgYmFja2dyb3VuZDogaGlnaGxpZ2h0ID8gJ3JnYmEoMTYwLDEzMCw2MCwwLjQ1KScgOiAncmdiYSgxMCwyMCwzNSwwLjU1KScsXG4gIGJvcmRlcjogaGlnaGxpZ2h0ID8gJzFweCBzb2xpZCByZ2JhKDI0NSwxOTYsODEsMC41KScgOiAnMXB4IHNvbGlkIHJnYmEoMCwwLDAsMC4yNSknLFxuICBmb250U2l6ZTogJzEuMDVyZW0nLCBmb250V2VpZ2h0OiA3MDAsXG59KTtcbmNvbnN0IGNlbGw6IFJlYWN0LkNTU1Byb3BlcnRpZXMgPSB7IHBhZGRpbmc6ICcwIDE0cHgnLCBoZWlnaHQ6ICcxMDAlJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgYm9yZGVyUmlnaHQ6ICcxcHggc29saWQgcmdiYSgwLDAsMCwwLjI1KScgfTtcbmNvbnN0IGhlYWRlclN0eWxlOiBSZWFjdC5DU1NQcm9wZXJ0aWVzID0geyBkaXNwbGF5OiAnZ3JpZCcsIHBhZGRpbmc6ICcwIDAgMTBweCcsIGZvbnRTaXplOiAnMC43MnJlbScsIGZvbnRXZWlnaHQ6IDcwMCwgbGV0dGVyU3BhY2luZzogMS41LCBjb2xvcjogdGhlbWUubXV0ZWQgfTtcblxuY29uc3QgUkFOS19DT0xTID0gJzEuMmZyIDNmciAxLjRmciAyZnInO1xuY29uc3QgSElTVF9DT0xTID0gJzIuNmZyIDEuNmZyIDJmciAxLjZmcic7XG5cbmNvbnN0IGZldGNoSnNvbiA9IDxULD4odXJsOiBzdHJpbmcpID0+IGFzeW5jICgpID0+IChhd2FpdCBheGlvcy5nZXQ8VD4odXJsKSkuZGF0YTtcblxuZXhwb3J0IGNvbnN0IENhcHRhaW5zTG9nOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBzZXRHYW1lU3RhdGUsIGxvZ1RhYiwgc2V0TG9nVGFiLCBtYXRjaER1cmF0aW9uLCBzcGF3blJhdGUgfSA9IHVzZUdhbWVTdG9yZSgpO1xuICBjb25zdCBbcGFnZSwgc2V0UGFnZV0gPSB1c2VTdGF0ZSgwKTtcblxuICBjb25zdCByYW5raW5nID0gdXNlUXVlcnk8U2NvcmVFbnRyeVtdPih7IHF1ZXJ5S2V5OiBbJ3JhbmtpbmcnXSwgcXVlcnlGbjogZmV0Y2hKc29uKCcvYXBpL3JhbmtpbmcnKSB9KTtcbiAgY29uc3QgaGlzdG9yeSA9IHVzZVF1ZXJ5PEhpc3RvcnlFbnRyeVtdPih7IHF1ZXJ5S2V5OiBbJ2hpc3RvcnknXSwgcXVlcnlGbjogZmV0Y2hKc29uKCcvYXBpL2hpc3RvcnknKSB9KTtcblxuICBjb25zdCByb3dzID0gKGxvZ1RhYiA9PT0gJ1JBTktJTkcnID8gcmFua2luZy5kYXRhIDogaGlzdG9yeS5kYXRhKSA/PyBbXTtcbiAgY29uc3QgbGlzdCA9IEFycmF5LmlzQXJyYXkocm93cykgPyByb3dzIDogW107XG4gIGNvbnN0IHBhZ2VDb3VudCA9IE1hdGgubWF4KDEsIE1hdGguY2VpbChsaXN0Lmxlbmd0aCAvIFBBR0VfU0laRSkpO1xuICBjb25zdCB2aXNpYmxlID0gbGlzdC5zbGljZShwYWdlICogUEFHRV9TSVpFLCBwYWdlICogUEFHRV9TSVpFICsgUEFHRV9TSVpFKTtcblxuICBjb25zdCBzd2l0Y2hUYWIgPSAodGFiOiBMb2dUYWIpID0+IHtcbiAgICBpZiAodGFiID09PSBsb2dUYWIpIHJldHVybjtcbiAgICBzb3VuZE1hbmFnZXIucGxheSgndWlfY2xpY2snKTtcbiAgICBzZXRMb2dUYWIodGFiKTtcbiAgICBzZXRQYWdlKDApO1xuICB9O1xuXG4gIGNvbnN0IHR1cm5QYWdlID0gKGRpcjogbnVtYmVyKSA9PiB7XG4gICAgc291bmRNYW5hZ2VyLnBsYXkoJ3VpX2NsaWNrJyk7XG4gICAgc2V0UGFnZSgocCkgPT4gTWF0aC5taW4ocGFnZUNvdW50IC0gMSwgTWF0aC5tYXgoMCwgcCArIGRpcikpKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxNZW51U2NyZWVuPlxuICAgICAgPFBhbmVsIHdpZHRoPXsxNDAwfSBtaW5IZWlnaHQ9ezc0MH0gc3R5bGU9e3sgcGFkZGluZzogJzAgMjBweCcgfX0+XG4gICAgICAgIDxNZW51VGl0bGUgc3R5bGU9e3sgbWFyZ2luVG9wOiAtMTYgfX0+Q0FQVEFJTidTIExPRzwvTWVudVRpdGxlPlxuXG4gICAgICAgIHsvKiBUYWJzOiBhY3RpdmUgdGFiIHVzZXMgdGhlIGdvbGQgcHJpbWFyeSBidXR0b24sIGluYWN0aXZlIHRoZSBkYXJrIHNlY29uZGFyeSAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogMzAsIG1hcmdpbjogJzEwcHggMCAxNHB4JyB9fT5cbiAgICAgICAgICA8U3ByaXRlQnV0dG9uIGJhc2VOYW1lPXtsb2dUYWIgPT09ICdSQU5LSU5HJyA/ICdidXR0b25fcHJpbWFyeScgOiAnYnV0dG9uX3NlY29uZGFyeSd9IHNjYWxlPXswLjl9IHRleHQ9XCJSQU5LSU5HXCIgdGV4dFN0eWxlPXt7IGZvbnRTaXplOiAnMS4ycmVtJyB9fSBvbkNsaWNrPXsoKSA9PiBzd2l0Y2hUYWIoJ1JBTktJTkcnKX0gc3R5bGU9e3sgbWFyZ2luOiAwIH19IC8+XG4gICAgICAgICAgPFNwcml0ZUJ1dHRvbiBiYXNlTmFtZT17bG9nVGFiID09PSAnSElTVE9SWScgPyAnYnV0dG9uX3ByaW1hcnknIDogJ2J1dHRvbl9zZWNvbmRhcnknfSBzY2FsZT17MC45fSB0ZXh0PVwiTUFUQ0ggSElTVE9SWVwiIHRleHRTdHlsZT17eyBmb250U2l6ZTogJzEuMnJlbScgfX0gb25DbGljaz17KCkgPT4gc3dpdGNoVGFiKCdISVNUT1JZJyl9IHN0eWxlPXt7IG1hcmdpbjogMCB9fSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8cCBzdHlsZT17eyBtYXJnaW46ICcwIDAgMjJweCcsIGZvbnRTaXplOiAnMC44NXJlbScsIGZvbnRXZWlnaHQ6IDcwMCwgbGV0dGVyU3BhY2luZzogMC41IH19PlxuICAgICAgICAgIHtsb2dUYWIgPT09ICdSQU5LSU5HJ1xuICAgICAgICAgICAgPyBgJHttYXRjaER1cmF0aW9ufSBTRUNPTkQgQkFUVExFUyDCtyAke3NwYXduUmF0ZX0gU0VDT05EIFNQQVdOIElOVEVSVkFMYFxuICAgICAgICAgICAgOiAnQ0FQVEFJTiBKQUNLIMK3IFlPVVIgUkVDRU5UIEJBVFRMRVMnfVxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBtaW5IZWlnaHQ6IDUgKiA1OCArIDI2IH19PlxuICAgICAgICAgIHtsb2dUYWIgPT09ICdSQU5LSU5HJyA/IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgLi4uaGVhZGVyU3R5bGUsIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFJBTktfQ09MUyB9fT5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBwYWRkaW5nTGVmdDogMTQgfX0+UkFOSzwvc3Bhbj48c3BhbiBzdHlsZT17eyBwYWRkaW5nTGVmdDogMTQgfX0+Q0FQVEFJTjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBwYWRkaW5nTGVmdDogMTQgfX0+UE9JTlRTPC9zcGFuPjxzcGFuIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiAxNCB9fT5QTEFZRUQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7KHZpc2libGUgYXMgU2NvcmVFbnRyeVtdKS5tYXAoKGUsIGkpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCByYW5rID0gcGFnZSAqIFBBR0VfU0laRSArIGkgKyAxO1xuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZS5pZH0gc3R5bGU9e3sgLi4ucm93U3R5bGUoISFlLmlzUGxheWVyKSwgZ3JpZFRlbXBsYXRlQ29sdW1uczogUkFOS19DT0xTIH19PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyAuLi5jZWxsLCBjb2xvcjogdGhlbWUuZ29sZCB9fT57U3RyaW5nKHJhbmspLnBhZFN0YXJ0KDIsICcwJyl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyAuLi5jZWxsLCBnYXA6IDggfX0+XG4gICAgICAgICAgICAgICAgICAgICAge3JhbmsgPT09IDEgJiYgPFNwcml0ZUljb24gbmFtZT1cImljb25fc2NvcmVcIiBzY2FsZT17MC41NX0gLz59XG4gICAgICAgICAgICAgICAgICAgICAge2UubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICB7ZS5pc1BsYXllciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzAuNnJlbScsIHBhZGRpbmc6ICcxcHggNXB4JywgYm9yZGVyOiBgMXB4IHNvbGlkICR7dGhlbWUuZ29sZH1gLCBib3JkZXJSYWRpdXM6IDMsIGNvbG9yOiB0aGVtZS5nb2xkIH19PllPVTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IC4uLmNlbGwsIGNvbG9yOiB0aGVtZS5nb2xkIH19PntlLnNjb3JlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgLi4uY2VsbCwgYm9yZGVyUmlnaHQ6ICdub25lJywgZm9udFNpemU6ICcwLjg1cmVtJyB9fT57Zm9ybWF0RGF5KGUuZGF0ZSl9IMK3IHtmb3JtYXRIb3VyKGUuZGF0ZSl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyAuLi5oZWFkZXJTdHlsZSwgZ3JpZFRlbXBsYXRlQ29sdW1uczogSElTVF9DT0xTIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiAxNCB9fT5EQVRFPC9zcGFuPjxzcGFuIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiAxNCB9fT5QT0lOVFM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgcGFkZGluZ0xlZnQ6IDE0IH19PkRVUkFUSU9OPC9zcGFuPjxzcGFuIHN0eWxlPXt7IHBhZGRpbmdMZWZ0OiAxNCB9fT5SRVNVTFQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICB7KHZpc2libGUgYXMgSGlzdG9yeUVudHJ5W10pLm1hcCgoZSwgaSkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtlLmlkfSBzdHlsZT17eyAuLi5yb3dTdHlsZShwYWdlID09PSAwICYmIGkgPT09IDApLCBncmlkVGVtcGxhdGVDb2x1bW5zOiBISVNUX0NPTFMgfX0+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17Y2VsbH0+e2Zvcm1hdERheShlLmRhdGUpfTxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44cmVtJywgbWFyZ2luTGVmdDogNiwgY29sb3I6IHRoZW1lLm11dGVkIH19PsK3IHtmb3JtYXRIb3VyKGUuZGF0ZSl9PC9zcGFuPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IC4uLmNlbGwsIGNvbG9yOiB0aGVtZS5nb2xkIH19PntlLnNjb3JlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXtjZWxsfT57Zm9ybWF0Q2xvY2soZS5kdXJhdGlvbil9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgLi4uY2VsbCwgYm9yZGVyUmlnaHQ6ICdub25lJywgZm9udFNpemU6ICcwLjhyZW0nLCBjb2xvcjogZS5yZXN1bHQgPT09ICdUSU1FX1VQJyA/IHRoZW1lLmNyZWFtIDogdGhlbWUucmVkIH19PlxuICAgICAgICAgICAgICAgICAgICB7ZS5yZXN1bHQgPT09ICdUSU1FX1VQJyA/ICdUSU1FIFVQJyA6ICdERUZFQVRFRCd9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICB7dmlzaWJsZS5sZW5ndGggPT09IDAgJiYgIWhpc3RvcnkuaXNMb2FkaW5nICYmIChcbiAgICAgICAgICAgICAgICA8cCBzdHlsZT17eyB0ZXh0QWxpZ246ICdjZW50ZXInLCBjb2xvcjogdGhlbWUubXV0ZWQsIG1hcmdpblRvcDogNjAgfX0+Tm8gYmF0dGxlcyB5ZXQuIFNldCBzYWlsIHRvIHN0YXJ0IHlvdXIgbG9nITwvcD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQYWdpbmF0aW9uICovfVxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogMjAsIG1hcmdpbjogJzRweCAwIDZweCcgfX0+XG4gICAgICAgICAgPFNwcml0ZUJ1dHRvbiBiYXNlTmFtZT1cImJ1dHRvbl9yb3VuZFwiIHNjYWxlPXswLjY1fSBpY29uPVwiaWNvbl90dXJuX2xlZnRcIiBpY29uU2NhbGU9ezAuNX0gZGlzYWJsZWQ9e3BhZ2UgPT09IDB9IG9uQ2xpY2s9eygpID0+IHR1cm5QYWdlKC0xKX0gc3R5bGU9e3sgbWFyZ2luOiAwIH19IC8+XG4gICAgICAgICAgPHNwYW4gc3R5bGU9e3sgZm9udFNpemU6ICcwLjg1cmVtJywgZm9udFdlaWdodDogNzAwIH19PlBBR0Uge3BhZ2UgKyAxfSBPRiB7cGFnZUNvdW50fTwvc3Bhbj5cbiAgICAgICAgICA8U3ByaXRlQnV0dG9uIGJhc2VOYW1lPVwiYnV0dG9uX3JvdW5kXCIgc2NhbGU9ezAuNjV9IGljb249XCJpY29uX3R1cm5fcmlnaHRcIiBpY29uU2NhbGU9ezAuNX0gZGlzYWJsZWQ9e3BhZ2UgPj0gcGFnZUNvdW50IC0gMX0gb25DbGljaz17KCkgPT4gdHVyblBhZ2UoMSl9IHN0eWxlPXt7IG1hcmdpbjogMCB9fSAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8U3ByaXRlQnV0dG9uIGJhc2VOYW1lPVwiYnV0dG9uX3ByaW1hcnlcIiBzY2FsZT17MS4xfSB0ZXh0PVwiTUFJTiBNRU5VXCIgdGV4dFN0eWxlPXt7IGZvbnRTaXplOiAnMS41cmVtJyB9fVxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc291bmRNYW5hZ2VyLnBsYXkoJ3VpX2NsaWNrJyk7IHNldEdhbWVTdGF0ZSgnU1RBUlRfTUVOVScpOyB9fSBzdHlsZT17eyBtYXJnaW46ICc0cHggMCAtMjBweCcgfX0gLz5cbiAgICAgIDwvUGFuZWw+XG4gICAgPC9NZW51U2NyZWVuPlxuICApO1xufTtcbiJdfQ==