import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/menus/GameOverMenu.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { useGameStore } from "/src/store/gameStore.ts";
import { soundManager } from "/src/game/SoundManager.ts";
import { gameEngine } from "/src/game/GameApplication.ts";
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=eccdfead";
import axios from "/node_modules/.vite/deps/axios.js?v=eccdfead";
import { SpriteButton } from "/src/ui/components/SpriteButton.tsx";
import { MenuScreen, Panel, MenuTitle, theme, formatClock } from "/src/ui/components/menus/MenuKit.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/GameOverMenu.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
export const GameOverMenu = () => {
	_s();
	const { setGameState, score, lastResult, matchDuration, spawnRate } = useGameStore();
	const queryClient = useQueryClient();
	const { mutate, isPending, isError } = useMutation({
		mutationFn: (body) => axios.post("/api/ranking", body),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["ranking"] });
			queryClient.invalidateQueries({ queryKey: ["history"] });
		}
	});
	const hasPosted = React.useRef(false);
	useEffect(() => {
		if (!hasPosted.current && lastResult) {
			hasPosted.current = true;
			mutate({
				score,
				duration: lastResult.duration,
				result: lastResult.reason
			});
		}
	}, [
		score,
		lastResult,
		mutate
	]);
	const handlePlayAgain = () => {
		soundManager.play("ui_click");
		setGameState("PLAYING");
		gameEngine.startGame(matchDuration, spawnRate);
	};
	const handleMainMenu = () => {
		soundManager.play("ui_click");
		setGameState("START_MENU");
	};
	const died = lastResult?.reason === "PLAYER_DIED";
	const big = { fontSize: "1.6rem" };
	return /* @__PURE__ */ _jsxDEV(MenuScreen, {
		dim: true,
		children: /* @__PURE__ */ _jsxDEV(Panel, {
			width: 780,
			minHeight: 660,
			style: { justifyContent: "center" },
			children: [
				/* @__PURE__ */ _jsxDEV(MenuTitle, { children: died ? "SHIP SUNK" : "BATTLE COMPLETE" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					style: {
						fontSize: "4.5rem",
						fontWeight: 900,
						lineHeight: 1.1,
						color: theme.gold,
						textShadow: theme.titleShadow,
						marginTop: 10
					},
					children: score
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					style: {
						margin: "4px 0 16px",
						fontSize: "0.95rem",
						fontWeight: 700,
						color: theme.cream
					},
					children: [
						"POINTS · ",
						formatClock(lastResult?.duration ?? 0),
						" · ",
						died ? "DEFEATED" : "TIME UP"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					style: {
						height: 18,
						fontSize: "0.8rem",
						color: isError ? theme.red : theme.muted
					},
					children: isPending ? "Saving to the Captain's Log..." : isError ? "Could not save score." : ""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_primary",
					scale: 1.25,
					text: "PLAY AGAIN",
					textStyle: big,
					onClick: handlePlayAgain,
					disabled: isPending,
					style: { margin: 6 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_primary",
					scale: 1.25,
					text: "MAIN MENU",
					textStyle: big,
					onClick: handleMainMenu,
					disabled: isPending,
					style: { margin: 6 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
};
_s(GameOverMenu, "yuGxIhVijAIGDrKEF81afDCb86Q=", false, function() {
	return [
		useGameStore,
		useQueryClient,
		useMutation
	];
});
_c = GameOverMenu;
var _c;
$RefreshReg$(_c, "GameOverMenu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/menus/GameOverMenu.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/GameOverMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/GameOverMenu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/GameOverMenu.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGlCQUFpQjtBQUNqQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGFBQWEsc0JBQXNCO0FBQzVDLE9BQU8sV0FBVztBQUVsQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFlBQVksT0FBTyxXQUFXLE9BQU8sbUJBQW1COzs7O0FBRWpFLE9BQU8sTUFBTSxxQkFBK0I7O0NBQzFDLE1BQU0sRUFBRSxjQUFjLE9BQU8sWUFBWSxlQUFlLGNBQWMsYUFBYTtDQUNuRixNQUFNLGNBQWMsZUFBZTtDQUVuQyxNQUFNLEVBQUUsUUFBUSxXQUFXLFlBQVksWUFBWTtFQUNqRCxhQUFhLFNBQXdCLE1BQU0sS0FBSyxnQkFBZ0IsSUFBSTtFQUNwRSxpQkFBaUI7R0FDZixZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztHQUN2RCxZQUFZLGtCQUFrQixFQUFFLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztFQUN6RDtDQUNGLENBQUM7Q0FFRCxNQUFNLFlBQVksTUFBTSxPQUFPLEtBQUs7Q0FDcEMsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLFVBQVUsV0FBVyxZQUFZO0dBQ3BDLFVBQVUsVUFBVTtHQUNwQixPQUFPO0lBQUU7SUFBTyxVQUFVLFdBQVc7SUFBVSxRQUFRLFdBQVc7R0FBTyxDQUFDO0VBQzVFO0NBQ0YsR0FBRztFQUFDO0VBQU87RUFBWTtDQUFNLENBQUM7Q0FFOUIsTUFBTSx3QkFBd0I7RUFDNUIsYUFBYSxLQUFLLFVBQVU7RUFDNUIsYUFBYSxTQUFTO0VBQ3RCLFdBQVcsVUFBVSxlQUFlLFNBQVM7Q0FDL0M7Q0FFQSxNQUFNLHVCQUF1QjtFQUMzQixhQUFhLEtBQUssVUFBVTtFQUM1QixhQUFhLFlBQVk7Q0FDM0I7Q0FFQSxNQUFNLE9BQU8sWUFBWSxXQUFXO0NBQ3BDLE1BQU0sTUFBTSxFQUFFLFVBQVUsU0FBUztDQUVqQyxPQUNFLHdCQUFDLFlBQUQ7RUFBWTtZQUNWLHdCQUFDLE9BQUQ7R0FBTyxPQUFPO0dBQUssV0FBVztHQUFLLE9BQU8sRUFBRSxnQkFBZ0IsU0FBUzthQUFyRTtJQUNFLHdCQUFDLFdBQUQsWUFBWSxPQUFPLGNBQWMsa0JBQTZCOzs7OztJQUU5RCx3QkFBQyxPQUFEO0tBQUssT0FBTztNQUFFLFVBQVU7TUFBVSxZQUFZO01BQUssWUFBWTtNQUFLLE9BQU8sTUFBTTtNQUFNLFlBQVksTUFBTTtNQUFhLFdBQVc7S0FBRztlQUNqSTtJQUNFOzs7OztJQUNMLHdCQUFDLEtBQUQ7S0FBRyxPQUFPO01BQUUsUUFBUTtNQUFjLFVBQVU7TUFBVyxZQUFZO01BQUssT0FBTyxNQUFNO0tBQU07ZUFBM0Y7TUFBOEY7TUFDbEYsWUFBWSxZQUFZLFlBQVksQ0FBQztNQUFFO01BQUksT0FBTyxhQUFhO0tBQ3hFOzs7Ozs7SUFFSCx3QkFBQyxPQUFEO0tBQUssT0FBTztNQUFFLFFBQVE7TUFBSSxVQUFVO01BQVUsT0FBTyxVQUFVLE1BQU0sTUFBTSxNQUFNO0tBQU07ZUFDcEYsWUFBWSxtQ0FBb0MsVUFBVSwwQkFBMEI7SUFDbEY7Ozs7O0lBRUwsd0JBQUMsY0FBRDtLQUFjLFVBQVM7S0FBaUIsT0FBTztLQUFNLE1BQUs7S0FBYSxXQUFXO0tBQUssU0FBUztLQUFpQixVQUFVO0tBQVcsT0FBTyxFQUFFLFFBQVEsRUFBRTtJQUFJOzs7OztJQUM3Six3QkFBQyxjQUFEO0tBQWMsVUFBUztLQUFpQixPQUFPO0tBQU0sTUFBSztLQUFZLFdBQVc7S0FBSyxTQUFTO0tBQWdCLFVBQVU7S0FBVyxPQUFPLEVBQUUsUUFBUSxFQUFFO0lBQUk7Ozs7O0dBQ3RKOzs7Ozs7Q0FDRzs7Ozs7QUFFaEIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2FtZU92ZXJNZW51LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlR2FtZVN0b3JlIH0gZnJvbSAnLi4vLi4vLi4vc3RvcmUvZ2FtZVN0b3JlJztcbmltcG9ydCB7IHNvdW5kTWFuYWdlciB9IGZyb20gJy4uLy4uLy4uL2dhbWUvU291bmRNYW5hZ2VyJztcbmltcG9ydCB7IGdhbWVFbmdpbmUgfSBmcm9tICcuLi8uLi8uLi9nYW1lL0dhbWVBcHBsaWNhdGlvbic7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknO1xuaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcbmltcG9ydCB0eXBlIHsgUG9zdFNjb3JlQm9keSB9IGZyb20gJy4uLy4uLy4uL21vY2tzL2hhbmRsZXJzJztcbmltcG9ydCB7IFNwcml0ZUJ1dHRvbiB9IGZyb20gJy4uL1Nwcml0ZUJ1dHRvbic7XG5pbXBvcnQgeyBNZW51U2NyZWVuLCBQYW5lbCwgTWVudVRpdGxlLCB0aGVtZSwgZm9ybWF0Q2xvY2sgfSBmcm9tICcuL01lbnVLaXQnO1xuXG5leHBvcnQgY29uc3QgR2FtZU92ZXJNZW51OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBzZXRHYW1lU3RhdGUsIHNjb3JlLCBsYXN0UmVzdWx0LCBtYXRjaER1cmF0aW9uLCBzcGF3blJhdGUgfSA9IHVzZUdhbWVTdG9yZSgpO1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG5cbiAgY29uc3QgeyBtdXRhdGUsIGlzUGVuZGluZywgaXNFcnJvciB9ID0gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IChib2R5OiBQb3N0U2NvcmVCb2R5KSA9PiBheGlvcy5wb3N0KCcvYXBpL3JhbmtpbmcnLCBib2R5KSxcbiAgICBvblN1Y2Nlc3M6ICgpID0+IHtcbiAgICAgIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncmFua2luZyddIH0pO1xuICAgICAgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydoaXN0b3J5J10gfSk7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCBoYXNQb3N0ZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaGFzUG9zdGVkLmN1cnJlbnQgJiYgbGFzdFJlc3VsdCkge1xuICAgICAgaGFzUG9zdGVkLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgbXV0YXRlKHsgc2NvcmUsIGR1cmF0aW9uOiBsYXN0UmVzdWx0LmR1cmF0aW9uLCByZXN1bHQ6IGxhc3RSZXN1bHQucmVhc29uIH0pO1xuICAgIH1cbiAgfSwgW3Njb3JlLCBsYXN0UmVzdWx0LCBtdXRhdGVdKTtcblxuICBjb25zdCBoYW5kbGVQbGF5QWdhaW4gPSAoKSA9PiB7XG4gICAgc291bmRNYW5hZ2VyLnBsYXkoJ3VpX2NsaWNrJyk7XG4gICAgc2V0R2FtZVN0YXRlKCdQTEFZSU5HJyk7XG4gICAgZ2FtZUVuZ2luZS5zdGFydEdhbWUobWF0Y2hEdXJhdGlvbiwgc3Bhd25SYXRlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVNYWluTWVudSA9ICgpID0+IHtcbiAgICBzb3VuZE1hbmFnZXIucGxheSgndWlfY2xpY2snKTtcbiAgICBzZXRHYW1lU3RhdGUoJ1NUQVJUX01FTlUnKTtcbiAgfTtcblxuICBjb25zdCBkaWVkID0gbGFzdFJlc3VsdD8ucmVhc29uID09PSAnUExBWUVSX0RJRUQnO1xuICBjb25zdCBiaWcgPSB7IGZvbnRTaXplOiAnMS42cmVtJyB9O1xuXG4gIHJldHVybiAoXG4gICAgPE1lbnVTY3JlZW4gZGltPlxuICAgICAgPFBhbmVsIHdpZHRoPXs3ODB9IG1pbkhlaWdodD17NjYwfSBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX0+XG4gICAgICAgIDxNZW51VGl0bGU+e2RpZWQgPyAnU0hJUCBTVU5LJyA6ICdCQVRUTEUgQ09NUExFVEUnfTwvTWVudVRpdGxlPlxuXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICc0LjVyZW0nLCBmb250V2VpZ2h0OiA5MDAsIGxpbmVIZWlnaHQ6IDEuMSwgY29sb3I6IHRoZW1lLmdvbGQsIHRleHRTaGFkb3c6IHRoZW1lLnRpdGxlU2hhZG93LCBtYXJnaW5Ub3A6IDEwIH19PlxuICAgICAgICAgIHtzY29yZX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxwIHN0eWxlPXt7IG1hcmdpbjogJzRweCAwIDE2cHgnLCBmb250U2l6ZTogJzAuOTVyZW0nLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiB0aGVtZS5jcmVhbSB9fT5cbiAgICAgICAgICBQT0lOVFMgwrcge2Zvcm1hdENsb2NrKGxhc3RSZXN1bHQ/LmR1cmF0aW9uID8/IDApfSDCtyB7ZGllZCA/ICdERUZFQVRFRCcgOiAnVElNRSBVUCd9XG4gICAgICAgIDwvcD5cblxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMTgsIGZvbnRTaXplOiAnMC44cmVtJywgY29sb3I6IGlzRXJyb3IgPyB0aGVtZS5yZWQgOiB0aGVtZS5tdXRlZCB9fT5cbiAgICAgICAgICB7aXNQZW5kaW5nID8gJ1NhdmluZyB0byB0aGUgQ2FwdGFpblxcJ3MgTG9nLi4uJyA6IGlzRXJyb3IgPyAnQ291bGQgbm90IHNhdmUgc2NvcmUuJyA6ICcnfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8U3ByaXRlQnV0dG9uIGJhc2VOYW1lPVwiYnV0dG9uX3ByaW1hcnlcIiBzY2FsZT17MS4yNX0gdGV4dD1cIlBMQVkgQUdBSU5cIiB0ZXh0U3R5bGU9e2JpZ30gb25DbGljaz17aGFuZGxlUGxheUFnYWlufSBkaXNhYmxlZD17aXNQZW5kaW5nfSBzdHlsZT17eyBtYXJnaW46IDYgfX0gLz5cbiAgICAgICAgPFNwcml0ZUJ1dHRvbiBiYXNlTmFtZT1cImJ1dHRvbl9wcmltYXJ5XCIgc2NhbGU9ezEuMjV9IHRleHQ9XCJNQUlOIE1FTlVcIiB0ZXh0U3R5bGU9e2JpZ30gb25DbGljaz17aGFuZGxlTWFpbk1lbnV9IGRpc2FibGVkPXtpc1BlbmRpbmd9IHN0eWxlPXt7IG1hcmdpbjogNiB9fSAvPlxuICAgICAgPC9QYW5lbD5cbiAgICA8L01lbnVTY3JlZW4+XG4gICk7XG59O1xuIl19