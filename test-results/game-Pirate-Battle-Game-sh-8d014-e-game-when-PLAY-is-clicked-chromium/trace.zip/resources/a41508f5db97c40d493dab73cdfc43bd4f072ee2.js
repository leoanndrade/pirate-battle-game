import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/menus/PauseMenu.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { useGameStore } from "/src/store/gameStore.ts";
import { gameEngine } from "/src/game/GameApplication.ts";
import { soundManager } from "/src/game/SoundManager.ts";
import { SpriteButton } from "/src/ui/components/SpriteButton.tsx";
import { MenuScreen, Panel, MenuTitle, theme } from "/src/ui/components/menus/MenuKit.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/PauseMenu.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
export const PauseMenu = () => {
	_s();
	const { setGameState, openOptions } = useGameStore();
	const handleResume = () => {
		soundManager.play("ui_click");
		setGameState("PLAYING");
		gameEngine.resumeGame();
	};
	const handleQuit = () => {
		soundManager.play("ui_click");
		gameEngine.endGame();
		setGameState("START_MENU");
	};
	const big = { fontSize: "1.6rem" };
	return /* @__PURE__ */ _jsxDEV(MenuScreen, {
		dim: true,
		children: /* @__PURE__ */ _jsxDEV(Panel, {
			width: 780,
			minHeight: 660,
			style: { justifyContent: "center" },
			children: [
				/* @__PURE__ */ _jsxDEV(MenuTitle, { children: "PAUSED" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					style: {
						margin: "14px 0 16px",
						fontSize: "1rem",
						fontWeight: 700,
						color: theme.cream
					},
					children: "Ready when you are."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_primary",
					scale: 1.25,
					text: "RESUME",
					textStyle: big,
					onClick: handleResume,
					style: { margin: 6 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_primary",
					scale: 1.25,
					text: "OPTIONS",
					textStyle: big,
					onClick: () => {
						soundManager.play("ui_click");
						openOptions("PAUSED");
					},
					style: { margin: 6 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_primary",
					scale: 1.25,
					text: "MAIN MENU",
					textStyle: big,
					onClick: handleQuit,
					style: { margin: 6 }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 5
	}, this);
};
_s(PauseMenu, "4tsWzqjbL+kdRnUQQfbLbND9IHU=", false, function() {
	return [useGameStore];
});
_c = PauseMenu;
var _c;
$RefreshReg$(_c, "PauseMenu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/menus/PauseMenu.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/PauseMenu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/PauseMenu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/PauseMenu.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsWUFBWSxPQUFPLFdBQVcsYUFBYTs7OztBQUVwRCxPQUFPLE1BQU0sa0JBQTRCOztDQUN2QyxNQUFNLEVBQUUsY0FBYyxnQkFBZ0IsYUFBYTtDQUVuRCxNQUFNLHFCQUFxQjtFQUN6QixhQUFhLEtBQUssVUFBVTtFQUM1QixhQUFhLFNBQVM7RUFDdEIsV0FBVyxXQUFXO0NBQ3hCO0NBRUEsTUFBTSxtQkFBbUI7RUFDdkIsYUFBYSxLQUFLLFVBQVU7RUFDNUIsV0FBVyxRQUFRO0VBQ25CLGFBQWEsWUFBWTtDQUMzQjtDQUVBLE1BQU0sTUFBTSxFQUFFLFVBQVUsU0FBUztDQUVqQyxPQUNFLHdCQUFDLFlBQUQ7RUFBWTtZQUNWLHdCQUFDLE9BQUQ7R0FBTyxPQUFPO0dBQUssV0FBVztHQUFLLE9BQU8sRUFBRSxnQkFBZ0IsU0FBUzthQUFyRTtJQUNFLHdCQUFDLFdBQUQsWUFBVyxTQUFpQjs7Ozs7SUFDNUIsd0JBQUMsS0FBRDtLQUFHLE9BQU87TUFBRSxRQUFRO01BQWUsVUFBVTtNQUFRLFlBQVk7TUFBSyxPQUFPLE1BQU07S0FBTTtlQUFHO0lBQXNCOzs7OztJQUVsSCx3QkFBQyxjQUFEO0tBQWMsVUFBUztLQUFpQixPQUFPO0tBQU0sTUFBSztLQUFTLFdBQVc7S0FBSyxTQUFTO0tBQWMsT0FBTyxFQUFFLFFBQVEsRUFBRTtJQUFJOzs7OztJQUNqSSx3QkFBQyxjQUFEO0tBQWMsVUFBUztLQUFpQixPQUFPO0tBQU0sTUFBSztLQUFVLFdBQVc7S0FBSyxlQUFlO01BQUUsYUFBYSxLQUFLLFVBQVU7TUFBRyxZQUFZLFFBQVE7S0FBRztLQUFHLE9BQU8sRUFBRSxRQUFRLEVBQUU7SUFBSTs7Ozs7SUFDckwsd0JBQUMsY0FBRDtLQUFjLFVBQVM7S0FBaUIsT0FBTztLQUFNLE1BQUs7S0FBWSxXQUFXO0tBQUssU0FBUztLQUFZLE9BQU8sRUFBRSxRQUFRLEVBQUU7SUFBSTs7Ozs7R0FDN0g7Ozs7OztDQUNHOzs7OztBQUVoQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQYXVzZU1lbnUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VHYW1lU3RvcmUgfSBmcm9tICcuLi8uLi8uLi9zdG9yZS9nYW1lU3RvcmUnO1xuaW1wb3J0IHsgZ2FtZUVuZ2luZSB9IGZyb20gJy4uLy4uLy4uL2dhbWUvR2FtZUFwcGxpY2F0aW9uJztcbmltcG9ydCB7IHNvdW5kTWFuYWdlciB9IGZyb20gJy4uLy4uLy4uL2dhbWUvU291bmRNYW5hZ2VyJztcbmltcG9ydCB7IFNwcml0ZUJ1dHRvbiB9IGZyb20gJy4uL1Nwcml0ZUJ1dHRvbic7XG5pbXBvcnQgeyBNZW51U2NyZWVuLCBQYW5lbCwgTWVudVRpdGxlLCB0aGVtZSB9IGZyb20gJy4vTWVudUtpdCc7XG5cbmV4cG9ydCBjb25zdCBQYXVzZU1lbnU6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IHNldEdhbWVTdGF0ZSwgb3Blbk9wdGlvbnMgfSA9IHVzZUdhbWVTdG9yZSgpO1xuXG4gIGNvbnN0IGhhbmRsZVJlc3VtZSA9ICgpID0+IHtcbiAgICBzb3VuZE1hbmFnZXIucGxheSgndWlfY2xpY2snKTtcbiAgICBzZXRHYW1lU3RhdGUoJ1BMQVlJTkcnKTtcbiAgICBnYW1lRW5naW5lLnJlc3VtZUdhbWUoKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVRdWl0ID0gKCkgPT4ge1xuICAgIHNvdW5kTWFuYWdlci5wbGF5KCd1aV9jbGljaycpO1xuICAgIGdhbWVFbmdpbmUuZW5kR2FtZSgpO1xuICAgIHNldEdhbWVTdGF0ZSgnU1RBUlRfTUVOVScpO1xuICB9O1xuXG4gIGNvbnN0IGJpZyA9IHsgZm9udFNpemU6ICcxLjZyZW0nIH07XG5cbiAgcmV0dXJuIChcbiAgICA8TWVudVNjcmVlbiBkaW0+XG4gICAgICA8UGFuZWwgd2lkdGg9ezc4MH0gbWluSGVpZ2h0PXs2NjB9IHN0eWxlPXt7IGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyB9fT5cbiAgICAgICAgPE1lbnVUaXRsZT5QQVVTRUQ8L01lbnVUaXRsZT5cbiAgICAgICAgPHAgc3R5bGU9e3sgbWFyZ2luOiAnMTRweCAwIDE2cHgnLCBmb250U2l6ZTogJzFyZW0nLCBmb250V2VpZ2h0OiA3MDAsIGNvbG9yOiB0aGVtZS5jcmVhbSB9fT5SZWFkeSB3aGVuIHlvdSBhcmUuPC9wPlxuXG4gICAgICAgIDxTcHJpdGVCdXR0b24gYmFzZU5hbWU9XCJidXR0b25fcHJpbWFyeVwiIHNjYWxlPXsxLjI1fSB0ZXh0PVwiUkVTVU1FXCIgdGV4dFN0eWxlPXtiaWd9IG9uQ2xpY2s9e2hhbmRsZVJlc3VtZX0gc3R5bGU9e3sgbWFyZ2luOiA2IH19IC8+XG4gICAgICAgIDxTcHJpdGVCdXR0b24gYmFzZU5hbWU9XCJidXR0b25fcHJpbWFyeVwiIHNjYWxlPXsxLjI1fSB0ZXh0PVwiT1BUSU9OU1wiIHRleHRTdHlsZT17YmlnfSBvbkNsaWNrPXsoKSA9PiB7IHNvdW5kTWFuYWdlci5wbGF5KCd1aV9jbGljaycpOyBvcGVuT3B0aW9ucygnUEFVU0VEJyk7IH19IHN0eWxlPXt7IG1hcmdpbjogNiB9fSAvPlxuICAgICAgICA8U3ByaXRlQnV0dG9uIGJhc2VOYW1lPVwiYnV0dG9uX3ByaW1hcnlcIiBzY2FsZT17MS4yNX0gdGV4dD1cIk1BSU4gTUVOVVwiIHRleHRTdHlsZT17YmlnfSBvbkNsaWNrPXtoYW5kbGVRdWl0fSBzdHlsZT17eyBtYXJnaW46IDYgfX0gLz5cbiAgICAgIDwvUGFuZWw+XG4gICAgPC9NZW51U2NyZWVuPlxuICApO1xufTtcbiJdfQ==