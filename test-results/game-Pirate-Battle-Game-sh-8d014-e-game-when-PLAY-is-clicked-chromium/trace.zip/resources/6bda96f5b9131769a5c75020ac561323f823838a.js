import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/HUD.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import { gameEvents } from "/src/utils/EventEmitter.ts";
import { SpriteIcon } from "/src/ui/components/SpriteIcon.tsx";
import { useGameStore } from "/src/store/gameStore.ts";
import { gameEngine } from "/src/game/GameApplication.ts";
import { soundManager } from "/src/game/SoundManager.ts";
import { SpriteButton } from "/src/ui/components/SpriteButton.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/HUD.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
export const HUD = () => {
	_s();
	const { score, timeRemaining, setGameState } = useGameStore();
	const [playerHealth, setPlayerHealth] = useState(100);
	const [damageFlash, setDamageFlash] = useState(false);
	useEffect(() => {
		const unsubHealth = gameEvents.on("PLAYER_HEALTH_CHANGED", (health) => setPlayerHealth(health));
		const unsubDamage = gameEvents.on("PLAYER_TOOK_DAMAGE", () => {
			setDamageFlash(true);
			setTimeout(() => setDamageFlash(false), 200);
		});
		return () => {
			unsubHealth();
			unsubDamage();
		};
	}, []);
	const handlePause = () => {
		soundManager.play("ui_click");
		gameEngine.pauseGame();
		setGameState("PAUSED");
	};
	const formatTime = (seconds) => {
		const m = Math.floor(seconds / 60);
		const s = Math.floor(seconds % 60);
		return `${m}:${s.toString().padStart(2, "0")}`;
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		style: {
			position: "absolute",
			top: 0,
			left: 0,
			width: "100%",
			height: "100%",
			pointerEvents: "none",
			padding: "20px",
			display: "flex",
			flexDirection: "column",
			justifyContent: "space-between",
			color: "#fff",
			fontFamily: "sans-serif",
			fontWeight: "bold",
			textShadow: "2px 2px 0px #000",
			transition: "box-shadow 0.2s",
			boxShadow: damageFlash ? "inset 0 0 150px rgba(255, 0, 0, 0.8)" : "none"
		},
		children: [/* @__PURE__ */ _jsxDEV("div", {
			style: {
				position: "relative",
				width: "100%",
				height: "64px"
			},
			children: [/* @__PURE__ */ _jsxDEV("div", {
				style: {
					position: "absolute",
					left: "50%",
					transform: "translateX(-50%)",
					display: "flex",
					gap: "20px",
					fontSize: "24px"
				},
				children: [/* @__PURE__ */ _jsxDEV("div", {
					style: {
						position: "relative",
						display: "flex",
						justifyContent: "center",
						alignItems: "center"
					},
					children: [/* @__PURE__ */ _jsxDEV(SpriteIcon, {
						name: "counter_panel",
						scale: 1.2
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						style: {
							position: "absolute",
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
							top: "50%",
							transform: "translateY(-55%)"
						},
						children: [/* @__PURE__ */ _jsxDEV("div", {
							style: {
								marginRight: 10,
								transform: "translateY(2px)"
							},
							children: /* @__PURE__ */ _jsxDEV(SpriteIcon, {
								name: "icon_score",
								scale: .7
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 78
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: score }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					style: {
						position: "relative",
						display: "flex",
						justifyContent: "center",
						alignItems: "center"
					},
					children: [/* @__PURE__ */ _jsxDEV(SpriteIcon, {
						name: "counter_panel",
						scale: 1.2
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						style: {
							position: "absolute",
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
							top: "50%",
							transform: "translateY(-55%)"
						},
						children: [/* @__PURE__ */ _jsxDEV("span", { children: formatTime(timeRemaining) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							style: {
								marginLeft: 10,
								transform: "translateY(2px)"
							},
							children: /* @__PURE__ */ _jsxDEV(SpriteIcon, {
								name: "icon_time",
								scale: .7
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 77
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				style: {
					position: "absolute",
					right: 0,
					top: 0
				},
				children: /* @__PURE__ */ _jsxDEV(SpriteButton, {
					baseName: "button_round",
					scale: 1.2,
					icon: "icon_pause",
					iconScale: .7,
					onClick: handlePause,
					style: {
						pointerEvents: "auto",
						margin: 0
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			style: {
				position: "absolute",
				bottom: "20px",
				left: "50%",
				transform: "translateX(-50%)",
				display: "flex",
				flexDirection: "column",
				alignItems: "center",
				fontSize: "24px"
			},
			children: [/* @__PURE__ */ _jsxDEV("div", {
				style: {
					display: "flex",
					alignItems: "center",
					marginBottom: 5
				},
				children: [/* @__PURE__ */ _jsxDEV("div", {
					style: { transform: "translateY(3px)" },
					children: /* @__PURE__ */ _jsxDEV(SpriteIcon, {
						name: "icon_heart",
						scale: .7
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 57
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					style: { marginLeft: 5 },
					children: ["HP: ", Math.max(0, playerHealth)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				style: {
					position: "relative",
					width: 256 * 1.6,
					height: 48 * 1.6
				},
				children: [/* @__PURE__ */ _jsxDEV("div", {
					style: {
						position: "absolute",
						top: 0,
						left: 0
					},
					children: /* @__PURE__ */ _jsxDEV(SpriteIcon, {
						name: "health_frame",
						scale: 1.6
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					style: {
						position: "absolute",
						top: 0,
						left: 0,
						width: `${Math.max(0, playerHealth)}%`,
						height: "100%",
						overflow: "hidden",
						transition: "width 0.2s"
					},
					children: /* @__PURE__ */ _jsxDEV(SpriteIcon, {
						name: playerHealth > 50 ? "health_fill_green" : playerHealth > 25 ? "health_fill_amber" : "health_fill_red",
						scale: 1.6
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 101,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};
_s(HUD, "r8tT66CG2LZofAS3iAsEwoeefPE=", false, function() {
	return [useGameStore];
});
_c = HUD;
var _c;
$RefreshReg$(_c, "HUD");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/HUD.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/HUD.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/HUD.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/HUD.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9COzs7O0FBRTdCLE9BQU8sTUFBTSxZQUFzQjs7Q0FDakMsTUFBTSxFQUFFLE9BQU8sZUFBZSxpQkFBaUIsYUFBYTtDQUM1RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxHQUFHO0NBQ3BELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FFcEQsZ0JBQWdCO0VBRWQsTUFBTSxjQUFjLFdBQVcsR0FBRywwQkFBMEIsV0FBVyxnQkFBZ0IsTUFBTSxDQUFDO0VBQzlGLE1BQU0sY0FBYyxXQUFXLEdBQUcsNEJBQTRCO0dBQzVELGVBQWUsSUFBSTtHQUNuQixpQkFBaUIsZUFBZSxLQUFLLEdBQUcsR0FBRztFQUM3QyxDQUFDO0VBRUQsYUFBYTtHQUNYLFlBQVk7R0FDWixZQUFZO0VBQ2Q7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sb0JBQW9CO0VBQ3hCLGFBQWEsS0FBSyxVQUFVO0VBQzVCLFdBQVcsVUFBVTtFQUNyQixhQUFhLFFBQVE7Q0FDdkI7Q0FFQSxNQUFNLGNBQWMsWUFBb0I7RUFDdEMsTUFBTSxJQUFJLEtBQUssTUFBTSxVQUFVLEVBQUU7RUFDakMsTUFBTSxJQUFJLEtBQUssTUFBTSxVQUFVLEVBQUU7RUFDakMsT0FBTyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQzdDO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsT0FBTztHQUNMLFVBQVU7R0FDVixLQUFLO0dBQ0wsTUFBTTtHQUNOLE9BQU87R0FDUCxRQUFRO0dBQ1IsZUFBZTtHQUNmLFNBQVM7R0FDVCxTQUFTO0dBQ1QsZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixPQUFPO0dBQ1AsWUFBWTtHQUNaLFlBQVk7R0FDWixZQUFZO0dBQ1osWUFBWTtHQUNaLFdBQVcsY0FBYyx5Q0FBeUM7RUFDcEU7WUFsQkYsQ0FxQkUsd0JBQUMsT0FBRDtHQUFLLE9BQU87SUFBRSxVQUFVO0lBQVksT0FBTztJQUFRLFFBQVE7R0FBTzthQUFsRSxDQUdFLHdCQUFDLE9BQUQ7SUFBSyxPQUFPO0tBQUUsVUFBVTtLQUFZLE1BQU07S0FBTyxXQUFXO0tBQW9CLFNBQVM7S0FBUSxLQUFLO0tBQVEsVUFBVTtJQUFPO2NBQS9ILENBR0Usd0JBQUMsT0FBRDtLQUFLLE9BQU87TUFBRSxVQUFVO01BQVksU0FBUztNQUFRLGdCQUFnQjtNQUFVLFlBQVk7S0FBUztlQUFwRyxDQUNFLHdCQUFDLFlBQUQ7TUFBWSxNQUFLO01BQWdCLE9BQU87S0FBTTs7OztlQUM5Qyx3QkFBQyxPQUFEO01BQUssT0FBTztPQUFFLFVBQVU7T0FBWSxTQUFTO09BQVEsWUFBWTtPQUFVLGdCQUFnQjtPQUFVLEtBQUs7T0FBTyxXQUFXO01BQW1CO2dCQUEvSSxDQUNFLHdCQUFDLE9BQUQ7T0FBSyxPQUFPO1FBQUUsYUFBYTtRQUFJLFdBQVc7T0FBa0I7aUJBQUcsd0JBQUMsWUFBRDtRQUFZLE1BQUs7UUFBYSxPQUFPO09BQU07Ozs7O01BQU07Ozs7Z0JBQ2hILHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O2NBQ2hCOzs7OzthQUNGOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxPQUFPO01BQUUsVUFBVTtNQUFZLFNBQVM7TUFBUSxnQkFBZ0I7TUFBVSxZQUFZO0tBQVM7ZUFBcEcsQ0FDRSx3QkFBQyxZQUFEO01BQVksTUFBSztNQUFnQixPQUFPO0tBQU07Ozs7ZUFDOUMsd0JBQUMsT0FBRDtNQUFLLE9BQU87T0FBRSxVQUFVO09BQVksU0FBUztPQUFRLFlBQVk7T0FBVSxnQkFBZ0I7T0FBVSxLQUFLO09BQU8sV0FBVztNQUFtQjtnQkFBL0ksQ0FDRSx3QkFBQyxRQUFELFlBQU8sV0FBVyxhQUFhLEVBQVE7Ozs7Z0JBQ3ZDLHdCQUFDLE9BQUQ7T0FBSyxPQUFPO1FBQUUsWUFBWTtRQUFJLFdBQVc7T0FBa0I7aUJBQUcsd0JBQUMsWUFBRDtRQUFZLE1BQUs7UUFBWSxPQUFPO09BQU07Ozs7O01BQU07Ozs7Y0FDM0c7Ozs7O2FBQ0Y7Ozs7O1lBRUY7Ozs7O2FBR0wsd0JBQUMsT0FBRDtJQUFLLE9BQU87S0FBRSxVQUFVO0tBQVksT0FBTztLQUFHLEtBQUs7SUFBRTtjQUNuRCx3QkFBQyxjQUFEO0tBQ0UsVUFBUztLQUNULE9BQU87S0FDUCxNQUFLO0tBQ0wsV0FBVztLQUNYLFNBQVM7S0FDVCxPQUFPO01BQUUsZUFBZTtNQUFRLFFBQVE7S0FBRTtJQUMzQzs7Ozs7R0FDRTs7OztXQUNGOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FBSyxPQUFPO0lBQUUsVUFBVTtJQUFZLFFBQVE7SUFBUSxNQUFNO0lBQU8sV0FBVztJQUFvQixTQUFTO0lBQVEsZUFBZTtJQUFVLFlBQVk7SUFBVSxVQUFVO0dBQU87YUFBakwsQ0FDRSx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLFNBQVM7S0FBUSxZQUFZO0tBQVUsY0FBYztJQUFFO2NBQXJFLENBQ0Usd0JBQUMsT0FBRDtLQUFLLE9BQU8sRUFBRSxXQUFXLGtCQUFrQjtlQUFHLHdCQUFDLFlBQUQ7TUFBWSxNQUFLO01BQWEsT0FBTztLQUFNOzs7OztJQUFNOzs7O2NBQy9GLHdCQUFDLFFBQUQ7S0FBTSxPQUFPLEVBQUUsWUFBWSxFQUFFO2VBQTdCLENBQWdDLFFBQUssS0FBSyxJQUFJLEdBQUcsWUFBWSxDQUFROzs7OztZQUNsRTs7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLFVBQVU7S0FBWSxPQUFPLE1BQU07S0FBSyxRQUFRLEtBQUs7SUFBSTtjQUF2RSxDQUNFLHdCQUFDLE9BQUQ7S0FBSyxPQUFPO01BQUUsVUFBVTtNQUFZLEtBQUs7TUFBRyxNQUFNO0tBQUU7ZUFDbEQsd0JBQUMsWUFBRDtNQUFZLE1BQUs7TUFBZSxPQUFPO0tBQU07Ozs7O0lBQzFDOzs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLE9BQU87TUFBRSxVQUFVO01BQVksS0FBSztNQUFHLE1BQU07TUFBRyxPQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsWUFBWSxFQUFFO01BQUksUUFBUTtNQUFRLFVBQVU7TUFBVSxZQUFZO0tBQWE7ZUFDeEosd0JBQUMsWUFBRDtNQUNFLE1BQU0sZUFBZSxLQUFLLHNCQUFzQixlQUFlLEtBQUssc0JBQXNCO01BQzFGLE9BQU87S0FDUjs7Ozs7SUFDRTs7OztZQUNGOzs7OztXQUNGOzs7OztVQUVGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIVUQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2FtZUV2ZW50cyB9IGZyb20gJy4uLy4uL3V0aWxzL0V2ZW50RW1pdHRlcic7XG5pbXBvcnQgeyBTcHJpdGVJY29uIH0gZnJvbSAnLi9TcHJpdGVJY29uJztcbmltcG9ydCB7IHVzZUdhbWVTdG9yZSB9IGZyb20gJy4uLy4uL3N0b3JlL2dhbWVTdG9yZSc7XG5pbXBvcnQgeyBnYW1lRW5naW5lIH0gZnJvbSAnLi4vLi4vZ2FtZS9HYW1lQXBwbGljYXRpb24nO1xuaW1wb3J0IHsgc291bmRNYW5hZ2VyIH0gZnJvbSAnLi4vLi4vZ2FtZS9Tb3VuZE1hbmFnZXInO1xuaW1wb3J0IHsgU3ByaXRlQnV0dG9uIH0gZnJvbSAnLi9TcHJpdGVCdXR0b24nO1xuXG5leHBvcnQgY29uc3QgSFVEOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBzY29yZSwgdGltZVJlbWFpbmluZywgc2V0R2FtZVN0YXRlIH0gPSB1c2VHYW1lU3RvcmUoKTtcbiAgY29uc3QgW3BsYXllckhlYWx0aCwgc2V0UGxheWVySGVhbHRoXSA9IHVzZVN0YXRlKDEwMCk7XG4gIGNvbnN0IFtkYW1hZ2VGbGFzaCwgc2V0RGFtYWdlRmxhc2hdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG5cbiAgICBjb25zdCB1bnN1YkhlYWx0aCA9IGdhbWVFdmVudHMub24oJ1BMQVlFUl9IRUFMVEhfQ0hBTkdFRCcsIChoZWFsdGgpID0+IHNldFBsYXllckhlYWx0aChoZWFsdGgpKTtcbiAgICBjb25zdCB1bnN1YkRhbWFnZSA9IGdhbWVFdmVudHMub24oJ1BMQVlFUl9UT09LX0RBTUFHRScsICgpID0+IHtcbiAgICAgIHNldERhbWFnZUZsYXNoKHRydWUpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXREYW1hZ2VGbGFzaChmYWxzZSksIDIwMCk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdW5zdWJIZWFsdGgoKTtcbiAgICAgIHVuc3ViRGFtYWdlKCk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZVBhdXNlID0gKCkgPT4ge1xuICAgIHNvdW5kTWFuYWdlci5wbGF5KCd1aV9jbGljaycpO1xuICAgIGdhbWVFbmdpbmUucGF1c2VHYW1lKCk7XG4gICAgc2V0R2FtZVN0YXRlKCdQQVVTRUQnKTtcbiAgfTtcblxuICBjb25zdCBmb3JtYXRUaW1lID0gKHNlY29uZHM6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IG0gPSBNYXRoLmZsb29yKHNlY29uZHMgLyA2MCk7XG4gICAgY29uc3QgcyA9IE1hdGguZmxvb3Ioc2Vjb25kcyAlIDYwKTtcbiAgICByZXR1cm4gYCR7bX06JHtzLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKX1gO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIHRvcDogMCxcbiAgICAgICAgbGVmdDogMCxcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcbiAgICAgICAgaGVpZ2h0OiAnMTAwJScsXG4gICAgICAgIHBvaW50ZXJFdmVudHM6ICdub25lJyxcbiAgICAgICAgcGFkZGluZzogJzIwcHgnLFxuICAgICAgICBkaXNwbGF5OiAnZmxleCcsXG4gICAgICAgIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLFxuICAgICAgICBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLFxuICAgICAgICBjb2xvcjogJyNmZmYnLFxuICAgICAgICBmb250RmFtaWx5OiAnc2Fucy1zZXJpZicsXG4gICAgICAgIGZvbnRXZWlnaHQ6ICdib2xkJyxcbiAgICAgICAgdGV4dFNoYWRvdzogJzJweCAycHggMHB4ICMwMDAnLFxuICAgICAgICB0cmFuc2l0aW9uOiAnYm94LXNoYWRvdyAwLjJzJyxcbiAgICAgICAgYm94U2hhZG93OiBkYW1hZ2VGbGFzaCA/ICdpbnNldCAwIDAgMTUwcHggcmdiYSgyNTUsIDAsIDAsIDAuOCknIDogJ25vbmUnXG4gICAgICB9fVxuICAgID5cbiAgICAgIHsvKiBUT1AgQVJFQSAqL31cbiAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdyZWxhdGl2ZScsIHdpZHRoOiAnMTAwJScsIGhlaWdodDogJzY0cHgnIH19PlxuICAgICAgICBcbiAgICAgICAgey8qIENlbnRlcjogU2NvcmUgYW5kIFRpbWUgKi99XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIGxlZnQ6ICc1MCUnLCB0cmFuc2Zvcm06ICd0cmFuc2xhdGVYKC01MCUpJywgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcyMHB4JywgZm9udFNpemU6ICcyNHB4JyB9fT5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogU2NvcmUgUGFuZWwgKi99XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJywgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGFsaWduSXRlbXM6ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgPFNwcml0ZUljb24gbmFtZT1cImNvdW50ZXJfcGFuZWxcIiBzY2FsZT17MS4yfSAvPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCB0b3A6ICc1MCUnLCB0cmFuc2Zvcm06ICd0cmFuc2xhdGVZKC01NSUpJyB9fT5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5SaWdodDogMTAsIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoMnB4KScgfX0+PFNwcml0ZUljb24gbmFtZT1cImljb25fc2NvcmVcIiBzY2FsZT17MC43fSAvPjwvZGl2PlxuICAgICAgICAgICAgICA8c3Bhbj57c2NvcmV9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFRpbWUgUGFuZWwgKi99XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJywgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGFsaWduSXRlbXM6ICdjZW50ZXInIH19PlxuICAgICAgICAgICAgPFNwcml0ZUljb24gbmFtZT1cImNvdW50ZXJfcGFuZWxcIiBzY2FsZT17MS4yfSAvPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ2Fic29sdXRlJywgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInLCB0b3A6ICc1MCUnLCB0cmFuc2Zvcm06ICd0cmFuc2xhdGVZKC01NSUpJyB9fT5cbiAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdFRpbWUodGltZVJlbWFpbmluZyl9PC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDEwLCB0cmFuc2Zvcm06ICd0cmFuc2xhdGVZKDJweCknIH19PjxTcHJpdGVJY29uIG5hbWU9XCJpY29uX3RpbWVcIiBzY2FsZT17MC43fSAvPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0OiBQYXVzZSBCdXR0b24gKi99XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIHJpZ2h0OiAwLCB0b3A6IDAgfX0+XG4gICAgICAgICAgPFNwcml0ZUJ1dHRvbiBcbiAgICAgICAgICAgIGJhc2VOYW1lPVwiYnV0dG9uX3JvdW5kXCJcbiAgICAgICAgICAgIHNjYWxlPXsxLjJ9XG4gICAgICAgICAgICBpY29uPVwiaWNvbl9wYXVzZVwiXG4gICAgICAgICAgICBpY29uU2NhbGU9ezAuN31cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVBhdXNlfVxuICAgICAgICAgICAgc3R5bGU9e3sgcG9pbnRlckV2ZW50czogJ2F1dG8nLCBtYXJnaW46IDAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQk9UVE9NIEFSRUE6IEhlYWx0aCBCYXIgKi99XG4gICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCBib3R0b206ICcyMHB4JywgbGVmdDogJzUwJScsIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVgoLTUwJSknLCBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZm9udFNpemU6ICcyNHB4JyB9fT5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBtYXJnaW5Cb3R0b206IDUgfX0+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyB0cmFuc2Zvcm06ICd0cmFuc2xhdGVZKDNweCknIH19PjxTcHJpdGVJY29uIG5hbWU9XCJpY29uX2hlYXJ0XCIgc2NhbGU9ezAuN30gLz48L2Rpdj5cbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBtYXJnaW5MZWZ0OiA1IH19PkhQOiB7TWF0aC5tYXgoMCwgcGxheWVySGVhbHRoKX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICBcbiAgICAgICAgey8qIEhlYWx0aCBiYXIgc2NhbGVkIGJ5IDEuNiAqL31cbiAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJywgd2lkdGg6IDI1NiAqIDEuNiwgaGVpZ2h0OiA0OCAqIDEuNiB9fT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCB0b3A6IDAsIGxlZnQ6IDAgfX0+XG4gICAgICAgICAgICA8U3ByaXRlSWNvbiBuYW1lPVwiaGVhbHRoX2ZyYW1lXCIgc2NhbGU9ezEuNn0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IHBvc2l0aW9uOiAnYWJzb2x1dGUnLCB0b3A6IDAsIGxlZnQ6IDAsIHdpZHRoOiBgJHtNYXRoLm1heCgwLCBwbGF5ZXJIZWFsdGgpfSVgLCBoZWlnaHQ6ICcxMDAlJywgb3ZlcmZsb3c6ICdoaWRkZW4nLCB0cmFuc2l0aW9uOiAnd2lkdGggMC4ycycgfX0+XG4gICAgICAgICAgICA8U3ByaXRlSWNvbiBcbiAgICAgICAgICAgICAgbmFtZT17cGxheWVySGVhbHRoID4gNTAgPyAnaGVhbHRoX2ZpbGxfZ3JlZW4nIDogcGxheWVySGVhbHRoID4gMjUgPyAnaGVhbHRoX2ZpbGxfYW1iZXInIDogJ2hlYWx0aF9maWxsX3JlZCd9IFxuICAgICAgICAgICAgICBzY2FsZT17MS42fSBcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=