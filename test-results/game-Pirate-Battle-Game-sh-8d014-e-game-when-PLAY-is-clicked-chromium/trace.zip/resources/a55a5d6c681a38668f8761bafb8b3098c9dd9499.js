import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/SpriteIcon.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import uiSheet from "/public/assets/spritesheet/ui_sheet.json?import";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteIcon.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
export const SpriteIcon = ({ name, scale = 1 }) => {
	const frameData = uiSheet.frames[name]?.frame;
	if (!frameData) {
		return /* @__PURE__ */ _jsxDEV("div", {
			style: {
				width: 32,
				height: 32,
				background: "red"
			},
			title: `Missing: ${name}`
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 12
		}, this);
	}
	const { x, y, w, h } = frameData;
	return /* @__PURE__ */ _jsxDEV("div", { style: {
		width: w * scale,
		height: h * scale,
		backgroundImage: "url(/assets/spritesheet/ui_sheet.png)",
		backgroundPosition: `-${x * scale}px -${y * scale}px`,
		backgroundSize: `${uiSheet.meta.size.w * scale}px ${uiSheet.meta.size.h * scale}px`,
		backgroundRepeat: "no-repeat",
		display: "inline-block"
	} }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
};
_c = SpriteIcon;
var _c;
$RefreshReg$(_c, "SpriteIcon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/SpriteIcon.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteIcon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteIcon.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteIcon.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sYUFBYTs7O0FBT3BCLE9BQU8sTUFBTSxjQUF5QyxFQUFFLE1BQU0sUUFBUSxRQUFRO0NBRTVFLE1BQU0sWUFBYSxRQUFRLE9BQWUsS0FBSyxFQUFFO0NBRWpELElBQUksQ0FBQyxXQUFXO0VBQ2QsT0FBTyx3QkFBQyxPQUFEO0dBQUssT0FBTztJQUFFLE9BQU87SUFBSSxRQUFRO0lBQUksWUFBWTtHQUFNO0dBQUcsT0FBTyxZQUFZO0VBQVM7Ozs7O0NBQy9GO0NBRUEsTUFBTSxFQUFFLEdBQUcsR0FBRyxHQUFHLE1BQU07Q0FFdkIsT0FDRSx3QkFBQyxPQUFELEVBQ0UsT0FBTztFQUNMLE9BQU8sSUFBSTtFQUNYLFFBQVEsSUFBSTtFQUNaLGlCQUFpQjtFQUNqQixvQkFBb0IsSUFBSSxJQUFJLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFDbEQsZ0JBQWdCLEdBQUcsUUFBUSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUssUUFBUSxLQUFLLEtBQUssSUFBSSxNQUFNO0VBQ2hGLGtCQUFrQjtFQUNsQixTQUFTO0NBQ1gsRUFDRDs7Ozs7QUFFTCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTcHJpdGVJY29uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHVpU2hlZXQgZnJvbSAnLi4vLi4vLi4vcHVibGljL2Fzc2V0cy9zcHJpdGVzaGVldC91aV9zaGVldC5qc29uJztcblxuaW50ZXJmYWNlIFNwcml0ZUljb25Qcm9wcyB7XG4gIG5hbWU6IHN0cmluZztcbiAgc2NhbGU/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBjb25zdCBTcHJpdGVJY29uOiBSZWFjdC5GQzxTcHJpdGVJY29uUHJvcHM+ID0gKHsgbmFtZSwgc2NhbGUgPSAxIH0pID0+IHtcblxuICBjb25zdCBmcmFtZURhdGEgPSAodWlTaGVldC5mcmFtZXMgYXMgYW55KVtuYW1lXT8uZnJhbWU7XG4gIFxuICBpZiAoIWZyYW1lRGF0YSkge1xuICAgIHJldHVybiA8ZGl2IHN0eWxlPXt7IHdpZHRoOiAzMiwgaGVpZ2h0OiAzMiwgYmFja2dyb3VuZDogJ3JlZCcgfX0gdGl0bGU9e2BNaXNzaW5nOiAke25hbWV9YH0gLz47XG4gIH1cblxuICBjb25zdCB7IHgsIHksIHcsIGggfSA9IGZyYW1lRGF0YTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIHdpZHRoOiB3ICogc2NhbGUsXG4gICAgICAgIGhlaWdodDogaCAqIHNjYWxlLFxuICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6ICd1cmwoL2Fzc2V0cy9zcHJpdGVzaGVldC91aV9zaGVldC5wbmcpJyxcbiAgICAgICAgYmFja2dyb3VuZFBvc2l0aW9uOiBgLSR7eCAqIHNjYWxlfXB4IC0ke3kgKiBzY2FsZX1weGAsXG4gICAgICAgIGJhY2tncm91bmRTaXplOiBgJHt1aVNoZWV0Lm1ldGEuc2l6ZS53ICogc2NhbGV9cHggJHt1aVNoZWV0Lm1ldGEuc2l6ZS5oICogc2NhbGV9cHhgLFxuICAgICAgICBiYWNrZ3JvdW5kUmVwZWF0OiAnbm8tcmVwZWF0JyxcbiAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaydcbiAgICAgIH19XG4gICAgLz5cbiAgKTtcbn07XG4iXX0=