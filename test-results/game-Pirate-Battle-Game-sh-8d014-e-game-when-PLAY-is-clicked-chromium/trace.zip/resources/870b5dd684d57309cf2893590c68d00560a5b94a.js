import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/SpriteButton.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
import uiSheet from "/public/assets/spritesheet/ui_sheet.json?import";
import { SpriteIcon } from "/src/ui/components/SpriteIcon.tsx";
import { soundManager } from "/src/game/SoundManager.ts";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteButton.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
var _s = $RefreshSig$();
const hasFrame = (name) => Boolean(uiSheet.frames[name]);
export const SpriteButton = ({ baseName, scale = 1, icon, iconScale = 1, text, textStyle, disabled, style, ...props }) => {
	_s();
	const [isHovered, setIsHovered] = useState(false);
	const [isPressed, setIsPressed] = useState(false);
	let state = "normal";
	if (disabled) state = "disabled";
	else if (isPressed) state = "pressed";
	else if (isHovered) state = "hover";
	let spriteName = `${baseName}_${state}`;
	let useHoverFilter = false;
	if (!hasFrame(spriteName)) {
		if (state === "hover") useHoverFilter = true;
		spriteName = `${baseName}_normal`;
	}
	const yOffset = isPressed ? "-42%" : "-55%";
	return /* @__PURE__ */ _jsxDEV("button", {
		...props,
		disabled,
		onPointerEnter: (e) => {
			if (!disabled) {
				setIsHovered(true);
				soundManager.play("ui_hover");
			}
			props.onPointerEnter?.(e);
		},
		onPointerLeave: (e) => {
			setIsHovered(false);
			setIsPressed(false);
			props.onPointerLeave?.(e);
		},
		onPointerDown: (e) => {
			if (!disabled) setIsPressed(true);
			props.onPointerDown?.(e);
		},
		onPointerUp: (e) => {
			setIsPressed(false);
			props.onPointerUp?.(e);
		},
		style: {
			position: "relative",
			background: "none",
			border: "none",
			padding: 0,
			margin: "10px",
			cursor: disabled ? "default" : "pointer",
			filter: useHoverFilter ? "brightness(1.2)" : disabled ? "grayscale(0.6)" : "none",
			transition: "filter 0.1s",
			...style
		},
		children: [
			/* @__PURE__ */ _jsxDEV(SpriteIcon, {
				name: spriteName,
				scale
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			icon && /* @__PURE__ */ _jsxDEV("div", {
				style: {
					position: "absolute",
					top: "50%",
					left: "50%",
					transform: `translate(-50%, ${yOffset})`,
					display: "flex",
					pointerEvents: "none"
				},
				children: /* @__PURE__ */ _jsxDEV(SpriteIcon, {
					name: icon,
					scale: iconScale
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 9
			}, this),
			text && /* @__PURE__ */ _jsxDEV("span", {
				style: {
					position: "absolute",
					top: "50%",
					left: "50%",
					transform: `translate(-50%, ${yOffset})`,
					color: disabled ? "#8a7a5a" : baseName === "button_primary" ? "#3b2410" : "#f8e4b5",
					fontSize: "1.4rem",
					fontWeight: 900,
					letterSpacing: .5,
					fontFamily: "\"Trebuchet MS\", \"Segoe UI\", Arial, sans-serif",
					textShadow: baseName === "button_primary" ? "0 1px 0 rgba(255,230,160,0.6)" : "0 2px 0 rgba(0,0,0,0.6)",
					pointerEvents: "none",
					whiteSpace: "nowrap",
					...textStyle
				},
				children: text
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
};
_s(SpriteButton, "uSeTHlSdfcPoupfE832R7o9fD4Q=");
_c = SpriteButton;
var _c;
$RefreshReg$(_c, "SpriteButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/SpriteButton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/SpriteButton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLGFBQWE7QUFDcEIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxvQkFBb0I7Ozs7QUFhN0IsTUFBTSxZQUFZLFNBRWhCLFFBQVMsUUFBUSxPQUFlLEtBQUs7QUFFdkMsT0FBTyxNQUFNLGdCQUE2QyxFQUN4RCxVQUFVLFFBQVEsR0FBRyxNQUFNLFlBQVksR0FBRyxNQUFNLFdBQVcsVUFBVSxPQUFPLEdBQUcsWUFDM0U7O0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBRWhELElBQUksUUFBcUQ7Q0FDekQsSUFBSSxVQUFVLFFBQVE7TUFDakIsSUFBSSxXQUFXLFFBQVE7TUFDdkIsSUFBSSxXQUFXLFFBQVE7Q0FFNUIsSUFBSSxhQUFhLEdBQUcsU0FBUyxHQUFHO0NBRWhDLElBQUksaUJBQWlCO0NBQ3JCLElBQUksQ0FBQyxTQUFTLFVBQVUsR0FBRztFQUN6QixJQUFJLFVBQVUsU0FBUyxpQkFBaUI7RUFDeEMsYUFBYSxHQUFHLFNBQVM7Q0FDM0I7Q0FFQSxNQUFNLFVBQVUsWUFBWSxTQUFTO0NBRXJDLE9BQ0Usd0JBQUMsVUFBRDtFQUNFLEdBQUk7RUFDTTtFQUNWLGlCQUFpQixNQUFNO0dBQ3JCLElBQUksQ0FBQyxVQUFVO0lBQUUsYUFBYSxJQUFJO0lBQUcsYUFBYSxLQUFLLFVBQVU7R0FBRztHQUNwRSxNQUFNLGlCQUFpQixDQUFDO0VBQzFCO0VBQ0EsaUJBQWlCLE1BQU07R0FBRSxhQUFhLEtBQUs7R0FBRyxhQUFhLEtBQUs7R0FBRyxNQUFNLGlCQUFpQixDQUFDO0VBQUc7RUFDOUYsZ0JBQWdCLE1BQU07R0FBRSxJQUFJLENBQUMsVUFBVSxhQUFhLElBQUk7R0FBRyxNQUFNLGdCQUFnQixDQUFDO0VBQUc7RUFDckYsY0FBYyxNQUFNO0dBQUUsYUFBYSxLQUFLO0dBQUcsTUFBTSxjQUFjLENBQUM7RUFBRztFQUNuRSxPQUFPO0dBQ0wsVUFBVTtHQUFZLFlBQVk7R0FBUSxRQUFRO0dBQVEsU0FBUztHQUFHLFFBQVE7R0FDOUUsUUFBUSxXQUFXLFlBQVk7R0FDL0IsUUFBUSxpQkFBaUIsb0JBQW9CLFdBQVcsbUJBQW1CO0dBQzNFLFlBQVk7R0FDWixHQUFHO0VBQ0w7WUFoQkY7R0FrQkUsd0JBQUMsWUFBRDtJQUFZLE1BQU07SUFBbUI7R0FBUTs7Ozs7R0FFNUMsUUFDQyx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLFVBQVU7S0FBWSxLQUFLO0tBQU8sTUFBTTtLQUFPLFdBQVcsbUJBQW1CLFFBQVE7S0FBSSxTQUFTO0tBQVEsZUFBZTtJQUFPO2NBQzVJLHdCQUFDLFlBQUQ7S0FBWSxNQUFNO0tBQU0sT0FBTztJQUFZOzs7OztHQUN4Qzs7Ozs7R0FHTixRQUNDLHdCQUFDLFFBQUQ7SUFBTSxPQUFPO0tBQ1gsVUFBVTtLQUFZLEtBQUs7S0FBTyxNQUFNO0tBQU8sV0FBVyxtQkFBbUIsUUFBUTtLQUNyRixPQUFPLFdBQVcsWUFBWSxhQUFhLG1CQUFtQixZQUFZO0tBQzFFLFVBQVU7S0FBVSxZQUFZO0tBQUssZUFBZTtLQUNwRCxZQUFZO0tBQ1osWUFBWSxhQUFhLG1CQUFtQixrQ0FBa0M7S0FDOUUsZUFBZTtLQUFRLFlBQVk7S0FDbkMsR0FBRztJQUNMO2NBQ0c7R0FDRzs7Ozs7RUFFRjs7Ozs7O0FBRVoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3ByaXRlQnV0dG9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdWlTaGVldCBmcm9tICcuLi8uLi8uLi9wdWJsaWMvYXNzZXRzL3Nwcml0ZXNoZWV0L3VpX3NoZWV0Lmpzb24nO1xuaW1wb3J0IHsgU3ByaXRlSWNvbiB9IGZyb20gJy4vU3ByaXRlSWNvbic7XG5pbXBvcnQgeyBzb3VuZE1hbmFnZXIgfSBmcm9tICcuLi8uLi9nYW1lL1NvdW5kTWFuYWdlcic7XG5cbnR5cGUgQnV0dG9uQmFzZSA9ICdidXR0b25fcHJpbWFyeScgfCAnYnV0dG9uX3NlY29uZGFyeScgfCAnYnV0dG9uX3JvdW5kJztcblxuaW50ZXJmYWNlIFNwcml0ZUJ1dHRvblByb3BzIGV4dGVuZHMgUmVhY3QuQnV0dG9uSFRNTEF0dHJpYnV0ZXM8SFRNTEJ1dHRvbkVsZW1lbnQ+IHtcbiAgYmFzZU5hbWU6IEJ1dHRvbkJhc2U7XG4gIHNjYWxlPzogbnVtYmVyO1xuICBpY29uPzogc3RyaW5nO1xuICBpY29uU2NhbGU/OiBudW1iZXI7XG4gIHRleHQ/OiBzdHJpbmc7XG4gIHRleHRTdHlsZT86IFJlYWN0LkNTU1Byb3BlcnRpZXM7XG59XG5cbmNvbnN0IGhhc0ZyYW1lID0gKG5hbWU6IHN0cmluZykgPT5cblxuICBCb29sZWFuKCh1aVNoZWV0LmZyYW1lcyBhcyBhbnkpW25hbWVdKTtcblxuZXhwb3J0IGNvbnN0IFNwcml0ZUJ1dHRvbjogUmVhY3QuRkM8U3ByaXRlQnV0dG9uUHJvcHM+ID0gKHtcbiAgYmFzZU5hbWUsIHNjYWxlID0gMSwgaWNvbiwgaWNvblNjYWxlID0gMSwgdGV4dCwgdGV4dFN0eWxlLCBkaXNhYmxlZCwgc3R5bGUsIC4uLnByb3BzXG59KSA9PiB7XG4gIGNvbnN0IFtpc0hvdmVyZWQsIHNldElzSG92ZXJlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc1ByZXNzZWQsIHNldElzUHJlc3NlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgbGV0IHN0YXRlOiAnbm9ybWFsJyB8ICdob3ZlcicgfCAncHJlc3NlZCcgfCAnZGlzYWJsZWQnID0gJ25vcm1hbCc7XG4gIGlmIChkaXNhYmxlZCkgc3RhdGUgPSAnZGlzYWJsZWQnO1xuICBlbHNlIGlmIChpc1ByZXNzZWQpIHN0YXRlID0gJ3ByZXNzZWQnO1xuICBlbHNlIGlmIChpc0hvdmVyZWQpIHN0YXRlID0gJ2hvdmVyJztcblxuICBsZXQgc3ByaXRlTmFtZSA9IGAke2Jhc2VOYW1lfV8ke3N0YXRlfWA7XG5cbiAgbGV0IHVzZUhvdmVyRmlsdGVyID0gZmFsc2U7XG4gIGlmICghaGFzRnJhbWUoc3ByaXRlTmFtZSkpIHtcbiAgICBpZiAoc3RhdGUgPT09ICdob3ZlcicpIHVzZUhvdmVyRmlsdGVyID0gdHJ1ZTtcbiAgICBzcHJpdGVOYW1lID0gYCR7YmFzZU5hbWV9X25vcm1hbGA7XG4gIH1cblxuICBjb25zdCB5T2Zmc2V0ID0gaXNQcmVzc2VkID8gJy00MiUnIDogJy01NSUnO1xuXG4gIHJldHVybiAoXG4gICAgPGJ1dHRvblxuICAgICAgey4uLnByb3BzfVxuICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkfVxuICAgICAgb25Qb2ludGVyRW50ZXI9eyhlKSA9PiB7XG4gICAgICAgIGlmICghZGlzYWJsZWQpIHsgc2V0SXNIb3ZlcmVkKHRydWUpOyBzb3VuZE1hbmFnZXIucGxheSgndWlfaG92ZXInKTsgfVxuICAgICAgICBwcm9wcy5vblBvaW50ZXJFbnRlcj8uKGUpO1xuICAgICAgfX1cbiAgICAgIG9uUG9pbnRlckxlYXZlPXsoZSkgPT4geyBzZXRJc0hvdmVyZWQoZmFsc2UpOyBzZXRJc1ByZXNzZWQoZmFsc2UpOyBwcm9wcy5vblBvaW50ZXJMZWF2ZT8uKGUpOyB9fVxuICAgICAgb25Qb2ludGVyRG93bj17KGUpID0+IHsgaWYgKCFkaXNhYmxlZCkgc2V0SXNQcmVzc2VkKHRydWUpOyBwcm9wcy5vblBvaW50ZXJEb3duPy4oZSk7IH19XG4gICAgICBvblBvaW50ZXJVcD17KGUpID0+IHsgc2V0SXNQcmVzc2VkKGZhbHNlKTsgcHJvcHMub25Qb2ludGVyVXA/LihlKTsgfX1cbiAgICAgIHN0eWxlPXt7XG4gICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLCBiYWNrZ3JvdW5kOiAnbm9uZScsIGJvcmRlcjogJ25vbmUnLCBwYWRkaW5nOiAwLCBtYXJnaW46ICcxMHB4JyxcbiAgICAgICAgY3Vyc29yOiBkaXNhYmxlZCA/ICdkZWZhdWx0JyA6ICdwb2ludGVyJyxcbiAgICAgICAgZmlsdGVyOiB1c2VIb3ZlckZpbHRlciA/ICdicmlnaHRuZXNzKDEuMiknIDogZGlzYWJsZWQgPyAnZ3JheXNjYWxlKDAuNiknIDogJ25vbmUnLFxuICAgICAgICB0cmFuc2l0aW9uOiAnZmlsdGVyIDAuMXMnLFxuICAgICAgICAuLi5zdHlsZSxcbiAgICAgIH19XG4gICAgPlxuICAgICAgPFNwcml0ZUljb24gbmFtZT17c3ByaXRlTmFtZX0gc2NhbGU9e3NjYWxlfSAvPlxuXG4gICAgICB7aWNvbiAmJiAoXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdhYnNvbHV0ZScsIHRvcDogJzUwJScsIGxlZnQ6ICc1MCUnLCB0cmFuc2Zvcm06IGB0cmFuc2xhdGUoLTUwJSwgJHt5T2Zmc2V0fSlgLCBkaXNwbGF5OiAnZmxleCcsIHBvaW50ZXJFdmVudHM6ICdub25lJyB9fT5cbiAgICAgICAgICA8U3ByaXRlSWNvbiBuYW1lPXtpY29ufSBzY2FsZT17aWNvblNjYWxlfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHt0ZXh0ICYmIChcbiAgICAgICAgPHNwYW4gc3R5bGU9e3tcbiAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAnNTAlJywgbGVmdDogJzUwJScsIHRyYW5zZm9ybTogYHRyYW5zbGF0ZSgtNTAlLCAke3lPZmZzZXR9KWAsXG4gICAgICAgICAgY29sb3I6IGRpc2FibGVkID8gJyM4YTdhNWEnIDogYmFzZU5hbWUgPT09ICdidXR0b25fcHJpbWFyeScgPyAnIzNiMjQxMCcgOiAnI2Y4ZTRiNScsXG4gICAgICAgICAgZm9udFNpemU6ICcxLjRyZW0nLCBmb250V2VpZ2h0OiA5MDAsIGxldHRlclNwYWNpbmc6IDAuNSxcbiAgICAgICAgICBmb250RmFtaWx5OiAnXCJUcmVidWNoZXQgTVNcIiwgXCJTZWdvZSBVSVwiLCBBcmlhbCwgc2Fucy1zZXJpZicsXG4gICAgICAgICAgdGV4dFNoYWRvdzogYmFzZU5hbWUgPT09ICdidXR0b25fcHJpbWFyeScgPyAnMCAxcHggMCByZ2JhKDI1NSwyMzAsMTYwLDAuNiknIDogJzAgMnB4IDAgcmdiYSgwLDAsMCwwLjYpJyxcbiAgICAgICAgICBwb2ludGVyRXZlbnRzOiAnbm9uZScsIHdoaXRlU3BhY2U6ICdub3dyYXAnLFxuICAgICAgICAgIC4uLnRleHRTdHlsZSxcbiAgICAgICAgfX0+XG4gICAgICAgICAge3RleHR9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICl9XG4gICAgPC9idXR0b24+XG4gICk7XG59O1xuIl19