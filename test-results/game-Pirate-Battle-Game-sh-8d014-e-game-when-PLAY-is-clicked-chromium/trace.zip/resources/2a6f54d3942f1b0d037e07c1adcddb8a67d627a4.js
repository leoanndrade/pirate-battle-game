import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { GameCanvas } from "/src/ui/components/GameCanvas.tsx";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/App.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
function App() {
	return /* @__PURE__ */ _jsxDEV("div", {
		style: {
			width: "100vw",
			height: "100vh",
			backgroundColor: "#000"
		},
		children: /* @__PURE__ */ _jsxDEV(GameCanvas, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7OztBQUUzQixTQUFTLE1BQU07Q0FDYixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxPQUFPO0dBQUUsT0FBTztHQUFTLFFBQVE7R0FBUyxpQkFBaUI7RUFBTztZQUNyRSx3QkFBQyxZQUFELENBQWE7Ozs7O0NBQ1Y7Ozs7O0FBRVQ7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdhbWVDYW52YXMgfSBmcm9tICcuL3VpL2NvbXBvbmVudHMvR2FtZUNhbnZhcyc7XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXt7IHdpZHRoOiAnMTAwdncnLCBoZWlnaHQ6ICcxMDB2aCcsIGJhY2tncm91bmRDb2xvcjogJyMwMDAnIH19PlxuICAgICAgPEdhbWVDYW52YXMgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl19