import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/components/menus/MenuKit.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=eccdfead";
var _jsxFileName = "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/MenuKit.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=eccdfead";
export const theme = {
	cream: "#f8e4b5",
	gold: "#f5c451",
	muted: "#c9c1ae",
	red: "#e88a7a",
	font: "\"Trebuchet MS\", \"Segoe UI\", Arial, sans-serif",
	titleShadow: "0 3px 0 rgba(0,0,0,0.45)"
};
export const Panel = ({ width, minHeight, children, style }) => /* @__PURE__ */ _jsxDEV("div", {
	style: {
		width,
		maxWidth: "96vw",
		minHeight,
		boxSizing: "border-box",
		borderStyle: "solid",
		borderWidth: 56,
		borderImageSource: "url(/assets/png/default/ui/menu/panel_menu.png)",
		borderImageSlice: "56 fill",
		borderImageRepeat: "stretch",
		display: "flex",
		flexDirection: "column",
		alignItems: "center",
		color: theme.cream,
		fontFamily: theme.font,
		...style
	},
	children
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 15,
	columnNumber: 3
}, this);
_c = Panel;
export const MenuScreen = ({ dim, children }) => /* @__PURE__ */ _jsxDEV("div", {
	style: {
		position: "absolute",
		inset: 0,
		overflow: "auto",
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		...dim ? { backgroundColor: "rgba(0,0,0,0.25)" } : {
			backgroundColor: "#1a4e76",
			backgroundImage: "url(/assets/png/default/tiles/tile_73.png)",
			backgroundRepeat: "repeat"
		}
	},
	children
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 30,
	columnNumber: 3
}, this);
_c2 = MenuScreen;
export const MenuTitle = ({ children, style }) => /* @__PURE__ */ _jsxDEV("h1", {
	style: {
		margin: 0,
		fontSize: "2.4rem",
		fontWeight: 900,
		letterSpacing: .5,
		color: theme.cream,
		textShadow: theme.titleShadow,
		...style
	},
	children
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 42,
	columnNumber: 3
}, this);
_c3 = MenuTitle;
export const formatClock = (sec) => {
	const s = Math.max(0, Math.round(sec));
	return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
};
const MONTHS = [
	"JAN",
	"FEB",
	"MAR",
	"APR",
	"MAY",
	"JUN",
	"JUL",
	"AUG",
	"SEP",
	"OCT",
	"NOV",
	"DEC"
];
export const formatDay = (iso) => {
	const d = new Date(iso);
	return `${String(d.getDate()).padStart(2, "0")} ${MONTHS[d.getMonth()]}`;
};
export const formatHour = (iso) => {
	const d = new Date(iso);
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
};
var _c, _c2, _c3;
$RefreshReg$(_c, "Panel");
$RefreshReg$(_c2, "MenuScreen");
$RefreshReg$(_c3, "MenuTitle");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ui/components/menus/MenuKit.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/MenuKit.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/MenuKit.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Projects VSCode/Git/pirate-battle-game/src/ui/components/menus/MenuKit.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsT0FBTyxNQUFNLFFBQVE7Q0FDbkIsT0FBTztDQUNQLE1BQU07Q0FDTixPQUFPO0NBQ1AsS0FBSztDQUNMLE1BQU07Q0FDTixhQUFhO0FBQ2Y7QUFFQSxPQUFPLE1BQU0sU0FBa0gsRUFDN0gsT0FBTyxXQUFXLFVBQVUsWUFFNUIsd0JBQUMsT0FBRDtDQUFLLE9BQU87RUFDVjtFQUFPLFVBQVU7RUFBUTtFQUFXLFdBQVc7RUFDL0MsYUFBYTtFQUFTLGFBQWE7RUFDbkMsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsU0FBUztFQUFRLGVBQWU7RUFBVSxZQUFZO0VBQ3RELE9BQU8sTUFBTTtFQUFPLFlBQVksTUFBTTtFQUN0QyxHQUFHO0NBQ0w7Q0FDRztBQUNFOzs7Ozs7QUFHUCxPQUFPLE1BQU0sY0FBc0UsRUFBRSxLQUFLLGVBQ3hGLHdCQUFDLE9BQUQ7Q0FBSyxPQUFPO0VBQ1YsVUFBVTtFQUFZLE9BQU87RUFBRyxVQUFVO0VBQzFDLFNBQVM7RUFBUSxnQkFBZ0I7RUFBVSxZQUFZO0VBQ3ZELEdBQUksTUFDQSxFQUFFLGlCQUFpQixtQkFBbUIsSUFDdEM7R0FBRSxpQkFBaUI7R0FBVyxpQkFBaUI7R0FBOEMsa0JBQWtCO0VBQVM7Q0FDOUg7Q0FDRztBQUNFOzs7Ozs7QUFHUCxPQUFPLE1BQU0sYUFBbUYsRUFBRSxVQUFVLFlBQzFHLHdCQUFDLE1BQUQ7Q0FBSSxPQUFPO0VBQ1QsUUFBUTtFQUFHLFVBQVU7RUFBVSxZQUFZO0VBQUssZUFBZTtFQUMvRCxPQUFPLE1BQU07RUFBTyxZQUFZLE1BQU07RUFBYSxHQUFHO0NBQ3hEO0NBQ0c7QUFDQzs7Ozs7O0FBR04sT0FBTyxNQUFNLGVBQWUsUUFBZ0I7Q0FDMUMsTUFBTSxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxHQUFHLENBQUM7Q0FDckMsT0FBTyxHQUFHLE9BQU8sS0FBSyxNQUFNLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLEdBQUcsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0FBQ3pGO0FBRUEsTUFBTSxTQUFTO0NBQUM7Q0FBTztDQUFPO0NBQU87Q0FBTztDQUFPO0NBQU87Q0FBTztDQUFPO0NBQU87Q0FBTztDQUFPO0FBQUs7QUFDbEcsT0FBTyxNQUFNLGFBQWEsUUFBZ0I7Q0FDeEMsTUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0NBQ3RCLE9BQU8sR0FBRyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLEdBQUcsT0FBTyxFQUFFLFNBQVM7QUFDdEU7QUFDQSxPQUFPLE1BQU0sY0FBYyxRQUFnQjtDQUN6QyxNQUFNLElBQUksSUFBSSxLQUFLLEdBQUc7Q0FDdEIsT0FBTyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztBQUMzRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNZW51S2l0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5leHBvcnQgY29uc3QgdGhlbWUgPSB7XG4gIGNyZWFtOiAnI2Y4ZTRiNScsXG4gIGdvbGQ6ICcjZjVjNDUxJyxcbiAgbXV0ZWQ6ICcjYzljMWFlJyxcbiAgcmVkOiAnI2U4OGE3YScsXG4gIGZvbnQ6ICdcIlRyZWJ1Y2hldCBNU1wiLCBcIlNlZ29lIFVJXCIsIEFyaWFsLCBzYW5zLXNlcmlmJyxcbiAgdGl0bGVTaGFkb3c6ICcwIDNweCAwIHJnYmEoMCwwLDAsMC40NSknLFxufTtcblxuZXhwb3J0IGNvbnN0IFBhbmVsOiBSZWFjdC5GQzx7IHdpZHRoOiBudW1iZXI7IG1pbkhlaWdodD86IG51bWJlcjsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTsgc3R5bGU/OiBSZWFjdC5DU1NQcm9wZXJ0aWVzIH0+ID0gKHtcbiAgd2lkdGgsIG1pbkhlaWdodCwgY2hpbGRyZW4sIHN0eWxlLFxufSkgPT4gKFxuICA8ZGl2IHN0eWxlPXt7XG4gICAgd2lkdGgsIG1heFdpZHRoOiAnOTZ2dycsIG1pbkhlaWdodCwgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgYm9yZGVyU3R5bGU6ICdzb2xpZCcsIGJvcmRlcldpZHRoOiA1NixcbiAgICBib3JkZXJJbWFnZVNvdXJjZTogJ3VybCgvYXNzZXRzL3BuZy9kZWZhdWx0L3VpL21lbnUvcGFuZWxfbWVudS5wbmcpJyxcbiAgICBib3JkZXJJbWFnZVNsaWNlOiAnNTYgZmlsbCcsXG4gICAgYm9yZGVySW1hZ2VSZXBlYXQ6ICdzdHJldGNoJyxcbiAgICBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcbiAgICBjb2xvcjogdGhlbWUuY3JlYW0sIGZvbnRGYW1pbHk6IHRoZW1lLmZvbnQsXG4gICAgLi4uc3R5bGUsXG4gIH19PlxuICAgIHtjaGlsZHJlbn1cbiAgPC9kaXY+XG4pO1xuXG5leHBvcnQgY29uc3QgTWVudVNjcmVlbjogUmVhY3QuRkM8eyBkaW0/OiBib29sZWFuOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0+ID0gKHsgZGltLCBjaGlsZHJlbiB9KSA9PiAoXG4gIDxkaXYgc3R5bGU9e3tcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJywgaW5zZXQ6IDAsIG92ZXJmbG93OiAnYXV0bycsXG4gICAgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGFsaWduSXRlbXM6ICdjZW50ZXInLFxuICAgIC4uLihkaW1cbiAgICAgID8geyBiYWNrZ3JvdW5kQ29sb3I6ICdyZ2JhKDAsMCwwLDAuMjUpJyB9XG4gICAgICA6IHsgYmFja2dyb3VuZENvbG9yOiAnIzFhNGU3NicsIGJhY2tncm91bmRJbWFnZTogJ3VybCgvYXNzZXRzL3BuZy9kZWZhdWx0L3RpbGVzL3RpbGVfNzMucG5nKScsIGJhY2tncm91bmRSZXBlYXQ6ICdyZXBlYXQnIH0pLFxuICB9fT5cbiAgICB7Y2hpbGRyZW59XG4gIDwvZGl2PlxuKTtcblxuZXhwb3J0IGNvbnN0IE1lbnVUaXRsZTogUmVhY3QuRkM8eyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlOyBzdHlsZT86IFJlYWN0LkNTU1Byb3BlcnRpZXMgfT4gPSAoeyBjaGlsZHJlbiwgc3R5bGUgfSkgPT4gKFxuICA8aDEgc3R5bGU9e3tcbiAgICBtYXJnaW46IDAsIGZvbnRTaXplOiAnMi40cmVtJywgZm9udFdlaWdodDogOTAwLCBsZXR0ZXJTcGFjaW5nOiAwLjUsXG4gICAgY29sb3I6IHRoZW1lLmNyZWFtLCB0ZXh0U2hhZG93OiB0aGVtZS50aXRsZVNoYWRvdywgLi4uc3R5bGUsXG4gIH19PlxuICAgIHtjaGlsZHJlbn1cbiAgPC9oMT5cbik7XG5cbmV4cG9ydCBjb25zdCBmb3JtYXRDbG9jayA9IChzZWM6IG51bWJlcikgPT4ge1xuICBjb25zdCBzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZChzZWMpKTtcbiAgcmV0dXJuIGAke1N0cmluZyhNYXRoLmZsb29yKHMgLyA2MCkpLnBhZFN0YXJ0KDIsICcwJyl9OiR7U3RyaW5nKHMgJSA2MCkucGFkU3RhcnQoMiwgJzAnKX1gO1xufTtcblxuY29uc3QgTU9OVEhTID0gWydKQU4nLCAnRkVCJywgJ01BUicsICdBUFInLCAnTUFZJywgJ0pVTicsICdKVUwnLCAnQVVHJywgJ1NFUCcsICdPQ1QnLCAnTk9WJywgJ0RFQyddO1xuZXhwb3J0IGNvbnN0IGZvcm1hdERheSA9IChpc286IHN0cmluZykgPT4ge1xuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgcmV0dXJuIGAke1N0cmluZyhkLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKX0gJHtNT05USFNbZC5nZXRNb250aCgpXX1gO1xufTtcbmV4cG9ydCBjb25zdCBmb3JtYXRIb3VyID0gKGlzbzogc3RyaW5nKSA9PiB7XG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShpc28pO1xuICByZXR1cm4gYCR7U3RyaW5nKGQuZ2V0SG91cnMoKSkucGFkU3RhcnQoMiwgJzAnKX06JHtTdHJpbmcoZC5nZXRNaW51dGVzKCkpLnBhZFN0YXJ0KDIsICcwJyl9YDtcbn07XG4iXX0=