import { A as BatchInterceptor, B as createServerErrorResponse, C as getRawSetCookie, D as isStringEqual, F as FetchRequest, G as createLogger, H as isResponseError, I as FetchResponse, J as Emitter, K as createRequestId, L as InterceptorError, M as decodeBuffer, N as encodeBuffer, P as toArrayBuffer, R as RequestController, S as devUtils, U as isResponseLike, V as isObject, W as Interceptor, X as invariant, Y as TypedEvent, Z as isNodeProcess, a as executeHandlers, b as InternalError, d as kAutoConnect, f as kConnect, g as patchesRegistry, h as hasConfigurableGlobal, i as HttpResponse, k as toPublicUrl, l as getSiblingHandlers, m as WebSocketInterceptor, n as isPassthroughResponse, q as formatRequest, t as isCommonAssetRequest, u as isSiblingHandler, v as isObject$1, x as cookieStore, y as RequestHandler, z as copyRawHeaders } from "/node_modules/.vite/deps/is-common-asset-request-D_lDqhHG.js?v=eccdfead";
//#region node_modules/until-async/lib/index.js
/**
* Gracefully handles a callback that returns a promise.
*
* @example
* await until(() => Promise.resolve(123))
* // [null, 123]
*
* await until(() => Promise.reject(new Error('Oops!')))
* // [new Error('Oops!'), null]
*/
async function until$1(callback) {
	try {
		return [null, await callback().catch((error) => {
			throw error;
		})];
	} catch (error) {
		return [error, null];
	}
}
//#endregion
//#region node_modules/msw/lib/_chunks/interceptor-source.js
var NetworkFrameEvent = class extends TypedEvent {
	frame;
	constructor(type, frame) {
		super(...[type, {}]);
		this.frame = frame;
	}
};
var NetworkSource = class {
	emitter;
	constructor() {
		this.emitter = new Emitter();
	}
	async queue(frame) {
		await this.emitter.emitAsPromise(new NetworkFrameEvent("frame", frame));
	}
	on(type, listener, options) {
		this.emitter.on(type, listener, options);
	}
	disable() {
		this.emitter.removeAllListeners();
	}
};
function addHandlerToGroup(groups, kind, handler) {
	(groups[kind] ||= []).push(handler);
}
function prependHandlersToGroup(groups, kind, overridesForKind) {
	const existingForKind = groups[kind];
	groups[kind] = existingForKind ? [...overridesForKind, ...existingForKind.filter((existingHandler) => {
		return !overridesForKind.includes(existingHandler);
	})] : overridesForKind;
}
function groupHandlersByKind(handlers) {
	const groups = {};
	const visitedHandlers = /* @__PURE__ */ new Set();
	const visit = (handler) => {
		if (visitedHandlers.has(handler)) return;
		visitedHandlers.add(handler);
		addHandlerToGroup(groups, handler.kind, handler);
		for (const sibling of getSiblingHandlers(handler)) visit(sibling);
	};
	for (const handler of handlers) visit(handler);
	return groups;
}
var HandlersController = class {
	getInitialState(initialHandlers) {
		invariant(this.#validateHandlers(initialHandlers), devUtils.formatMessage("Failed to apply given request handlers: invalid input. Did you forget to spread the request handlers Array?"));
		const normalizedInitialHandlers = groupHandlersByKind(initialHandlers);
		return {
			initialHandlers: normalizedInitialHandlers,
			handlers: { ...normalizedInitialHandlers }
		};
	}
	currentHandlers() {
		return Object.values(this.getState().handlers).flat().filter((handler) => handler != null);
	}
	/**
	* Return the list of explicitly registered handlers.
	* Unlike `currentHandlers()`, this excludes sibling handlers,
	* which are an implementation detail (e.g. the WebSocket upgrade
	* handler or the GraphQL subscription transport).
	*/
	listHandlers() {
		return this.currentHandlers().filter((handler) => {
			return !isSiblingHandler(handler);
		});
	}
	/**
	* Return the list of handlers of the given kind.
	*/
	getHandlersByKind(kind) {
		return this.getState().handlers[kind] || [];
	}
	use(nextHandlers) {
		invariant(this.#validateHandlers(nextHandlers), devUtils.formatMessage("[MSW] Failed to call \"use()\" with the given request handlers: invalid input. Did you forget to spread the array of request handlers?"));
		if (nextHandlers.length === 0) return;
		const { handlers } = this.getState();
		const overrides = groupHandlersByKind(nextHandlers);
		if (overrides.request) prependHandlersToGroup(handlers, "request", overrides.request);
		if (overrides.websocket) prependHandlersToGroup(handlers, "websocket", overrides.websocket);
		this.setState({ handlers });
	}
	reset(nextHandlers) {
		invariant(nextHandlers.length > 0 ? this.#validateHandlers(nextHandlers) : true, devUtils.formatMessage("Failed to replace initial handlers during reset: invalid handlers. Did you forget to spread the handlers array?"));
		for (const handler of this.currentHandlers()) handler.reset();
		const { initialHandlers } = this.getState();
		if (nextHandlers.length === 0) {
			this.setState({ handlers: { ...initialHandlers } });
			return;
		}
		const normalizedNextHandlers = groupHandlersByKind(nextHandlers);
		this.setState({
			initialHandlers: normalizedNextHandlers,
			handlers: { ...normalizedNextHandlers }
		});
	}
	restore() {
		for (const handler of this.currentHandlers()) handler.restore();
	}
	dispose() {
		const pendingDisposals = [];
		for (const handler of this.currentHandlers()) {
			const disposal = handler.dispose();
			if (disposal instanceof Promise) pendingDisposals.push(disposal);
		}
		if (pendingDisposals.length > 0) return Promise.all(pendingDisposals).then(() => {});
	}
	#validateHandlers(handlers) {
		return handlers.every((handler) => !Array.isArray(handler));
	}
};
var InMemoryHandlersController = class extends HandlersController {
	#handlers;
	#initialHandlers;
	constructor(initialHandlers) {
		super();
		const initialState = this.getInitialState(initialHandlers);
		this.#initialHandlers = initialState.initialHandlers;
		this.#handlers = initialState.handlers;
	}
	getState() {
		return {
			initialHandlers: this.#initialHandlers,
			handlers: this.#handlers
		};
	}
	setState(nextState) {
		if (nextState.initialHandlers) this.#initialHandlers = nextState.initialHandlers;
		if (nextState.handlers) this.#handlers = nextState.handlers;
	}
};
/**
* Creates an immutable copy of the given array.
*/
function toReadonlyArray(source) {
	const clone = [...source];
	Object.freeze(clone);
	return clone;
}
var Disposable = class {
	subscriptions = [];
	dispose() {
		let subscription;
		const errors = [];
		while (subscription = this.subscriptions.shift()) try {
			subscription();
		} catch (error) {
			if (error instanceof Error) errors.push(error);
		}
		if (errors.length > 0) console.error(new AggregateError(errors, devUtils.formatMessage("Failed to dispose of some side effects. This is likely an issue with MSW, please report it on GitHub: https://github.com/mswjs/msw/issues")));
	}
};
function colorlessPromiseAll(values) {
	const promises = [];
	for (const value of values) if (value instanceof Promise) promises.push(value);
	if (promises.length > 0) return Promise.all(promises).then(() => {});
}
/**
* Define a network instance with the given configuration.
* @example
* import { InterceptorSource } from 'msw/experimental'
* import { handlers } from './handlers'
*
* const network = defineNetwork({
*   sources: [new InterceptorSource({ interceptors })],
*   handlers,
* })
* await network.enable()
*/
function defineNetwork(options) {
	let readyState = 0;
	const events = new Emitter();
	const disposable = new Disposable();
	const deriveHandlersController = (handlers) => {
		return handlers instanceof HandlersController ? handlers : new InMemoryHandlersController(handlers || []);
	};
	let resolvedOptions = { ...options };
	/**
	* @note Create the handlers controller immediately because
	* certain setup APIs, like `setupServer`, don't await `.enable` (`.listen`).
	*/
	let handlersController = deriveHandlersController(resolvedOptions.handlers);
	return {
		get readyState() {
			return readyState;
		},
		events,
		configure(options) {
			invariant(readyState === 0, "Failed to call \"configure()\" on the network: cannot configure an already enabled network.");
			if (options.handlers && !Object.is(options.handlers, resolvedOptions.handlers)) handlersController = deriveHandlersController(options.handlers);
			resolvedOptions = {
				...resolvedOptions,
				...options
			};
		},
		enable() {
			invariant(readyState === 0, "Failed to call \"enable\" on the network: already enabled");
			readyState = 1;
			/**
			* @note Use a session object scoped to the current "enable()"
			* to prevent "frame.events" listeners from surviving across enable/disable cycles.
			* @see The note about `AbortController` below.
			*/
			const session = { active: true };
			disposable["subscriptions"].push(() => {
				session.active = false;
			});
			return colorlessPromiseAll(resolvedOptions.sources.map((source) => {
				/**
				* @note Preemptively disable the network source before enabling.
				* This intentionally calls only the prototype method that clears the
				* event listeners and nothing else. This prevents the "frame" listeners
				* from accumulating across enable/disable in case the source is a singleton.
				*/
				NetworkSource.prototype.disable.call(source);
				source.on("frame", async ({ frame }) => {
					frame.events.on("*", (event) => {
						/**
						* @note Prevent event forwarding manually and not via an AbortController
						* because certain runtimes, like Cloudflare, throw when referencing an
						* AbortController created in a different context. Bear in mind that the frame
						* events run in the patched request client context while the AbortController
						* is created outside, in the "defineNetwork" closure, which is a test context.
						*/
						if (!session.active) return;
						events.emit(event);
					});
					const handlers = frame.getHandlers(handlersController);
					await frame.resolve(handlers, resolvedOptions.onUnhandledFrame || "warn", resolvedOptions.context);
				});
				return source.enable();
			}));
		},
		disable() {
			invariant(readyState === 1, "Failed to call \"disable\" on the network: already disabled");
			readyState = 0;
			const handlersDisposal = handlersController.dispose();
			disposable.dispose();
			/**
			* @note Tear down the sources synchronously, never behind the
			* handlers disposal. `disable()` is not always awaited (e.g.
			* `server.close()` is synchronous), and a deferred teardown would
			* race any `enable()` that follows, disabling the sources that the
			* new session has just enabled.
			*/
			const sourcesDisposal = colorlessPromiseAll(resolvedOptions.sources.map((source) => source.disable()));
			/**
			* @note Await both disposals so neither rejection goes unobserved.
			* Chaining them would leave the source disposal floating whenever
			* the handlers disposal rejects.
			*/
			return handlersDisposal instanceof Promise ? Promise.all([handlersDisposal, sourcesDisposal]).then(() => {}) : sourcesDisposal;
		},
		use(...handlers) {
			handlersController.use(handlers);
		},
		resetHandlers(...handlers) {
			handlersController.reset(handlers);
		},
		restoreHandlers() {
			handlersController.restore();
		},
		listHandlers() {
			return toReadonlyArray(handlersController.listHandlers());
		}
	};
}
/**
* The base for the network frames. Extend this abstract class
* to implement custom network frames.
*/
var NetworkFrame = class {
	protocol;
	data;
	events;
	constructor(protocol, data) {
		this.protocol = protocol;
		this.data = data;
		this.events = new Emitter();
	}
};
async function storeResponseCookies(request, response) {
	if (cookieStore === null) return;
	for (const responseCookie of getRawSetCookie(response)) await cookieStore.setCookie(responseCookie, request.url);
}
function shouldBypassRequest(request) {
	return !!request.headers.get("accept")?.includes("msw/passthrough");
}
/**
* Remove the internal passthrough instruction from the request's `Accept` header.
*/
function deleteRequestPassthroughHeader(request) {
	const acceptHeader = request.headers.get("accept");
	/**
	* @note Remove the internal bypass request header.
	* In the browser, this is done by the worker script.
	* In Node.js, it has to be done here.
	*/
	if (acceptHeader) {
		const nextAcceptHeader = acceptHeader.replace(/(,\s+)?msw\/passthrough/, "");
		if (nextAcceptHeader) request.headers.set("accept", nextAcceptHeader);
		else request.headers.delete("accept");
	}
}
async function executeUnhandledFrameHandle(frame, handle) {
	const printStrategyMessage = async (strategy) => {
		if (strategy === "bypass") return;
		const message = await frame.getUnhandledMessage();
		switch (strategy) {
			case "warn": return devUtils.warn("Warning: %s", message);
			case "error": return devUtils.error("Error: %s", message);
		}
	};
	const applyStrategy = async (strategy) => {
		invariant.as(InternalError, strategy === "bypass" || strategy === "warn" || strategy === "error", devUtils.formatMessage("Failed to react to an unhandled network frame: unknown strategy \"%s\". Please provide one of the supported strategies (\"bypass\", \"warn\", \"error\") or a custom callback function as the value of the \"onUnhandledFrame\" option.", strategy));
		if (strategy === "bypass") return;
		await printStrategyMessage(strategy);
		if (strategy === "error") return Promise.reject(new InternalError(devUtils.formatMessage("Cannot bypass a request when using the \"error\" strategy for the \"onUnhandledFrame\" option.")));
	};
	if (typeof handle === "function") return handle({
		frame,
		defaults: {
			warn: printStrategyMessage.bind(null, "warn"),
			/**
			* @note The defaults only print the corresponding messages now.
			* They do not affect the frame resolution (e.g. do not error the frame).
			* That is only for backward compatibility reasons. In the future, these should
			* be an alias to `applyStrategy.bind(null, 'error')` instead.
			*/
			error: printStrategyMessage.bind(null, "error")
		}
	});
	/**
	* Ignore unhandled common HTTP assets.
	* @note Calling this here applies the common assets check
	* only to the scenarios when `onUnhandledFrame` was set to a predefined strategy.
	* When using a custom function, you need to check for common assets manually.
	*/
	if (frame instanceof HttpNetworkFrame && isCommonAssetRequest(frame.data.request)) return;
	return applyStrategy(handle);
}
var RequestEvent = class extends TypedEvent {
	requestId;
	request;
	constructor(type, data) {
		super(...[type, {}]);
		this.requestId = data.requestId;
		this.request = data.request;
	}
};
var ResponseEvent = class extends TypedEvent {
	requestId;
	request;
	response;
	constructor(type, data) {
		super(...[type, {}]);
		this.requestId = data.requestId;
		this.request = data.request;
		this.response = data.response;
	}
};
var UnhandledExceptionEvent = class extends TypedEvent {
	error;
	requestId;
	request;
	constructor(type, data) {
		super(...[type, {}]);
		this.error = data.error;
		this.requestId = data.requestId;
		this.request = data.request;
	}
};
var HttpNetworkFrame = class extends NetworkFrame {
	constructor(options) {
		const id = options.id || createRequestId();
		super("http", {
			id,
			request: options.request
		});
	}
	getHandlers(controller) {
		return controller.getHandlersByKind("request");
	}
	async getUnhandledMessage() {
		const { request } = this.data;
		const url = new URL(request.url);
		const publicUrl = toPublicUrl(url) + url.search;
		const requestBody = request.body == null ? null : await request.clone().text();
		return `intercepted a request without a matching request handler:${`\n\n  \u2022 ${request.method} ${publicUrl}\n\n${requestBody ? `  \u2022 Request body: ${requestBody}\n\n` : ""}`}If you still wish to intercept this unhandled request, please create a request handler for it.\nRead more: https://mswjs.io/docs/http/intercepting-requests`;
	}
	async resolve(handlers, onUnhandledFrame, resolutionContext) {
		const { id: requestId, request } = this.data;
		const requestCloneForLogs = resolutionContext?.quiet ? null : request.clone();
		this.events.emit(new RequestEvent("request:start", {
			requestId,
			request
		}));
		if (shouldBypassRequest(request)) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		const [lookupError, lookupResult] = await until$1(() => {
			return executeHandlers({
				requestId,
				request,
				handlers,
				resolutionContext: {
					baseUrl: resolutionContext?.baseUrl?.toString(),
					quiet: resolutionContext?.quiet
				}
			});
		});
		if (lookupError != null) {
			if (!this.events.emit(new UnhandledExceptionEvent("unhandledException", {
				error: lookupError,
				requestId,
				request
			}))) {
				console.error(lookupError);
				devUtils.error("Encountered an unhandled exception during the handler lookup for \"%s %s\". Please see the original error above.", request.method, request.url);
			}
			this.errorWith(lookupError);
			return null;
		}
		if (lookupResult == null) {
			/**
			* @note Unhandled CONNECT requests establish a tunnel through a proxy.
			* They are transport, not the request the developer cares about, so
			* they pass through silently regardless of the unhandled frame strategy.
			* The request sent through the tunnel gets its own resolution.
			*/
			if (isStringEqual(request.method, "CONNECT")) {
				this.events.emit(new RequestEvent("request:end", {
					requestId,
					request
				}));
				this.passthrough();
				return null;
			}
			this.events.emit(new RequestEvent("request:unhandled", {
				requestId,
				request
			}));
			/**
			* @note The unhandled frame handle must be executed during the request resolution
			* since it can influence it (e.g. error the request if the "error" startegy was used).
			*/
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			return false;
		}
		const { response, handler, parsedResult } = lookupResult;
		this.events.emit(new RequestEvent("request:match", {
			requestId,
			request
		}));
		if (response == null) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		if (isPassthroughResponse(response)) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		const responseCloneForLogs = resolutionContext?.quiet ? null : response.clone();
		await storeResponseCookies(request, response);
		this.respondWith(response);
		this.events.emit(new RequestEvent("request:end", {
			requestId,
			request
		}));
		if (!resolutionContext?.quiet) handler.log({
			request: requestCloneForLogs,
			response: responseCloneForLogs,
			parsedResult
		});
		return true;
	}
};
var WebSocketConnectionEvent = class extends TypedEvent {
	url;
	protocols;
	constructor(type, data) {
		super(...[type, {}]);
		this.url = data.url;
		this.protocols = data.protocols;
	}
};
var WebSocketErrorEvent = class extends WebSocketConnectionEvent {
	error;
	constructor(type, data) {
		super(type, data);
		this.error = data.error;
	}
};
var WebSocketNetworkFrame = class extends NetworkFrame {
	constructor(options) {
		super("ws", { connection: options.connection });
	}
	getHandlers(controller) {
		return controller.getHandlersByKind("websocket");
	}
	async resolve(handlers, onUnhandledFrame, resolutionContext) {
		const { connection } = this.data;
		this.events.emit(new WebSocketConnectionEvent("websocket:connection", {
			url: connection.client.url,
			protocols: connection.info.protocols
		}));
		const handleSocketError = (event) => {
			this.events.emit(new WebSocketErrorEvent("websocket:error", {
				url: connection.client.url,
				protocols: connection.info.protocols,
				error: getErrorFromEvent(event)
			}));
		};
		connection.client.socket.addEventListener("error", handleSocketError);
		connection.client.socket.addEventListener("close", () => {
			connection.client.socket.removeEventListener("error", handleSocketError);
		}, { once: true });
		if (handlers.length === 0) {
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			return false;
		}
		let hasMatchingHandlers = false;
		for (const handler of handlers) {
			const handlerConnection = await handler.run(connection, {
				baseUrl: resolutionContext?.baseUrl?.toString(),
				/**
				* @note Expose an emit-only reference to this frame's events
				* so the handlers can emit additional events not covered by
				* the frame (e.g. "graphql:subscription").
				*/
				events: this.events,
				/**
				* @note Do not emit the handler's "connection" event when running the handler.
				* Use the run only to get the resolved connection object.
				*/
				[kAutoConnect]: false
			});
			if (!handlerConnection) continue;
			hasMatchingHandlers = true;
			/**
			* @note Attach the WebSocket logger *before* emitting the handler's "connection" event.
			* Connection event listeners may perform actions that should be reflected in the logs
			* (e.g. closing the connection immediately). If the logger is attached after the connection,
			* those actions cannot be properly logged.
			*/
			const removeLogger = !resolutionContext?.quiet ? handler.log(connection) : void 0;
			try {
				if (!handler[kConnect](handlerConnection)) removeLogger?.();
			} catch (error) {
				if (!this.events.emit(new WebSocketErrorEvent("unhandledException", {
					error,
					url: connection.client.url,
					protocols: connection.info.protocols
				}))) {
					console.error(error);
					devUtils.error("Encountered an unhandled exception during the handler lookup for \"%s\". Please see the original error above.", connection.client.url);
				}
				/**
				* @note Throw the caught error so it gets picked up by WebSocketInterceptor.
				* It's the interceptor who translates handler errors to WebSocket closures.
				*/
				throw error;
			}
		}
		if (!hasMatchingHandlers) {
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			return false;
		}
		return true;
	}
	async getUnhandledMessage() {
		const { connection } = this.data;
		return `intercepted a WebSocket connection without a matching event handler:${`\n\n  \u2022 ${connection.client.url}\n\n`}If you still wish to intercept this unhandled connection, please create an event handler for it.\nRead more: https://mswjs.io/docs/websocket`;
	}
};
/**
* Extract the error from the given "error" event, if any.
* Supports both the `ErrorEvent.error` property and the `cause`
* property that MSW sets when erroring the connection itself.
*/
function getErrorFromEvent(event) {
	if ("error" in event && event.error != null) return event.error;
	if ("cause" in event && event.cause != null) return event.cause;
}
/**
* Create a network source from the given list of interceptors.
*/
var InterceptorSource = class extends NetworkSource {
	#interceptor;
	/**
	* @note Frames are keyed by the request instance, not the request ID.
	* The interceptor emits the same request instance on the "request"
	* and "response" events, so the frame can be looked up by identity.
	* A weak reference lets the frame be garbage collected alongside
	* its request once the request settles without producing a response
	* (e.g. a passthrough request failing with a network error).
	* @see https://github.com/mswjs/msw/issues/2792
	*/
	#frames;
	constructor(options) {
		super();
		this.#interceptor = new BatchInterceptor({
			name: "interceptor-source",
			interceptors: options.interceptors
		});
		this.#frames = /* @__PURE__ */ new WeakMap();
	}
	enable() {
		this.#interceptor.apply();
		this.#interceptor.on("request", this.#handleRequest.bind(this)).on("response", this.#handleResponse.bind(this)).on("connection", this.#handleWebSocketConnection.bind(this));
	}
	disable() {
		super.disable();
		this.#interceptor.dispose();
		/**
		* @todo We can also abort any pending frames here, given we implement
		* the `NetworkFrame.abort()` method.
		*/
		this.#frames = /* @__PURE__ */ new WeakMap();
	}
	async #handleRequest(event) {
		const { requestId, request, controller } = event;
		const httpFrame = new InterceptorHttpNetworkFrame({
			id: requestId,
			request,
			controller
		});
		this.#frames.set(request, httpFrame);
		await this.queue(httpFrame);
	}
	async #handleResponse({ requestId, request, response, responseType }) {
		const httpFrame = this.#frames.get(request);
		this.#frames.delete(request);
		if (httpFrame == null) return;
		queueMicrotask(() => {
			try {
				httpFrame.events.emit(new ResponseEvent(responseType === "mock" ? "response:mocked" : "response:bypass", {
					requestId,
					request,
					response
				}));
			} finally {
				/**
				* @note Remove any listeners from this frame.
				* Past this point, it won't emit anything. The removal is crucial
				* to prevent "rettime" from keeping the abort cleanup listeners internally.
				* @see https://github.com/mswjs/msw/issues/2735
				*/
				httpFrame.events.removeAllListeners();
			}
		});
	}
	async #handleWebSocketConnection(connection) {
		await this.queue(new InterceptorWebSocketNetworkFrame({ connection }));
	}
};
var InterceptorHttpNetworkFrame = class extends HttpNetworkFrame {
	#controller;
	constructor(options) {
		super({
			id: options.id,
			request: options.request
		});
		this.#controller = options.controller;
	}
	passthrough() {
		deleteRequestPassthroughHeader(this.data.request);
	}
	respondWith(response) {
		if (response) this.#controller.respondWith(response);
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		if (reason instanceof InternalError) this.#controller.errorWith(reason);
		throw reason;
	}
};
var InterceptorWebSocketNetworkFrame = class extends WebSocketNetworkFrame {
	/**
	* The in-process client connection, whose socket
	* the frame dispatches errors on.
	*/
	#client;
	constructor(args) {
		super({ connection: args.connection });
		this.#client = args.connection.client;
		/**
		* @note Provide a similar frame listener cleanup as for HTTP.
		* When the client connection closes, the handler can no longer be used.
		*/
		args.connection.client.addEventListener("close", () => {
			this.events.removeAllListeners();
		}, { once: true });
	}
	errorWith(reason) {
		if (reason instanceof Error) {
			/**
			* Use `client.errorWith(reason)` in the future.
			* @see https://github.com/mswjs/interceptors/issues/747
			*/
			const errorEvent = new Event("error");
			Object.defineProperty(errorEvent, "cause", {
				enumerable: true,
				configurable: false,
				value: reason
			});
			this.#client.socket.dispatchEvent(errorEvent);
		}
	}
	passthrough() {
		this.data.connection.server.connect();
	}
};
//#endregion
//#region node_modules/@open-draft/until/lib/index.js
/**
* Gracefully handles a callback that returns a promise.
*
* @example
* await until(() => Promise.resolve(123))
* // [null, 123]
*
* await until(() => Promise.reject(new Error('Oops!')))
* // [new Error('Oops!'), null]
*/
async function until(callback) {
	try {
		return [null, await callback().catch((error) => {
			throw error;
		})];
	} catch (error) {
		return [error, null];
	}
}
//#endregion
//#region node_modules/@mswjs/interceptors/lib/browser/handle-request-y7ajyve5.js
var HttpRequestEvent = class extends TypedEvent {
	constructor(data) {
		super(...["request", {}]);
		this.request = data.request;
		this.requestId = data.requestId;
		this.initiator = data.initiator;
		this.controller = data.controller;
	}
};
var HttpResponseEvent = class extends TypedEvent {
	constructor(data) {
		super(...["response", {}]);
		this.response = data.response;
		this.responseType = data.responseType;
		this.request = data.request;
		this.requestId = data.requestId;
		this.initiator = data.initiator;
	}
};
var UnhandledHttpException = class extends TypedEvent {
	constructor(data) {
		super(...["unhandledException", {}]);
		this.error = data.error;
		this.request = data.request;
		this.requestId = data.requestId;
		this.initiator = data.initiator;
		this.controller = data.controller;
	}
};
function isNodeLikeError(error) {
	if (error == null) return false;
	if (!(error instanceof Error)) return false;
	return "code" in error && "errno" in error;
}
async function handleRequest(options) {
	if (options.logger?.isEnabled("default")) formatRequest(options.request).then((message) => {
		options.logger?.info("[%s] %s", options.requestId, message);
	});
	const handleResponse = async (response) => {
		if (response instanceof Error) {
			await options.controller.errorWith(response);
			return true;
		}
		if (isResponseError(response)) {
			await options.controller.respondWith(response);
			return true;
		}
		/**
		* Handle normal responses or response-like objects.
		* @note This must come before the arbitrary object check
		* since Response instances are, in fact, objects.
		*/
		if (isResponseLike(response)) {
			await options.controller.respondWith(response);
			return true;
		}
		if (isObject(response)) {
			await options.controller.errorWith(response);
			return true;
		}
		return false;
	};
	const handleResponseError = async (error) => {
		if (error instanceof InterceptorError) throw resultError;
		if (isNodeLikeError(error)) {
			await options.controller.errorWith(error);
			return true;
		}
		if (error instanceof Response) return await handleResponse(error);
		return false;
	};
	const requestAbortPromise = Promise.withResolvers();
	let requestAbortReason;
	let isRequestAborted = false;
	const onAbort = () => {
		isRequestAborted = true;
		requestAbortReason = options.request.signal?.reason;
		requestAbortPromise.reject(requestAbortReason);
	};
	/**
	* @note `signal` is not always defined in React Native.
	*/
	if (options.request.signal) {
		if (options.request.signal.aborted) {
			await options.controller.errorWith(options.request.signal.reason);
			return;
		}
		options.request.signal.addEventListener("abort", onAbort, { once: true });
	}
	const [resultError] = await until(async () => {
		const requestEvent = new HttpRequestEvent({
			initiator: options.initiator,
			requestId: options.requestId,
			request: options.request,
			controller: options.controller
		});
		const requestListenersPromise = options.emitter.emitAsPromise(requestEvent);
		await Promise.race([
			requestAbortPromise.promise,
			requestListenersPromise,
			options.controller.handled
		]);
		/**
		* @note If the "request" listener has replaced the request instance,
		* propagate that mutation back to the underlying insterceptor.
		* This happens with XMLHttpRequest that replaces request instances
		* to correctly reflect the "withCredentials" option on the Fetch API request.
		*/
		if (requestEvent.request !== options.request) options.request = requestEvent.request;
	});
	options.request.signal?.removeEventListener("abort", onAbort);
	if (isRequestAborted) {
		await options.controller.errorWith(requestAbortReason);
		return;
	}
	if (resultError) {
		if (await handleResponseError(resultError)) return;
		if (options.emitter.listenerCount("unhandledException") > 0) {
			const unhandledExceptionController = new RequestController(options.request, {
				/**
				* @note Intentionally empty passthrough handle.
				* This controller is created within another controller and we only need
				* to know if `unhandledException` listeners handled the request.
				*/
				passthrough() {},
				async respondWith(response) {
					await handleResponse(response);
				},
				async errorWith(reason) {
					/**
					* @note Handle the result of the unhandled controller
					* in the same way as the original request controller.
					* The exception here is that thrown errors within the
					* "unhandledException" event do NOT result in another
					* emit of the same event. They are forwarded as-is.
					*/
					await options.controller.errorWith(reason);
				}
			});
			await options.emitter.emitAsPromise(new UnhandledHttpException({
				initiator: options.initiator,
				error: resultError,
				request: options.request,
				requestId: options.requestId,
				controller: unhandledExceptionController
			}));
			if (unhandledExceptionController.readyState !== RequestController.PENDING) return;
		}
		await options.controller.respondWith(createServerErrorResponse(resultError));
		return;
	}
	if (options.controller.readyState === RequestController.PENDING) return await options.controller.passthrough();
	return options.controller.handled;
}
//#endregion
//#region node_modules/@mswjs/interceptors/lib/browser/web-BRBQ3YPp.js
/**
* Concatenate two `Uint8Array` buffers.
*/
function concatArrayBuffer(left, right) {
	const result = new Uint8Array(left.byteLength + right.byteLength);
	result.set(left, 0);
	result.set(right, left.byteLength);
	return result;
}
var EventPolyfill = class {
	constructor(type, options) {
		this.NONE = 0;
		this.CAPTURING_PHASE = 1;
		this.AT_TARGET = 2;
		this.BUBBLING_PHASE = 3;
		this.type = "";
		this.srcElement = null;
		this.currentTarget = null;
		this.eventPhase = 0;
		this.isTrusted = true;
		this.composed = false;
		this.cancelable = true;
		this.defaultPrevented = false;
		this.bubbles = true;
		this.lengthComputable = true;
		this.loaded = 0;
		this.total = 0;
		this.cancelBubble = false;
		this.returnValue = true;
		this.type = type;
		this.target = options?.target || null;
		this.currentTarget = options?.currentTarget || null;
		this.timeStamp = Date.now();
	}
	composedPath() {
		return [];
	}
	initEvent(type, bubbles, cancelable) {
		this.type = type;
		this.bubbles = !!bubbles;
		this.cancelable = !!cancelable;
	}
	preventDefault() {
		this.defaultPrevented = true;
	}
	stopPropagation() {}
	stopImmediatePropagation() {}
};
var ProgressEventPolyfill = class extends EventPolyfill {
	constructor(type, init) {
		super(type);
		this.lengthComputable = init?.lengthComputable || false;
		this.composed = init?.composed || false;
		this.loaded = init?.loaded || 0;
		this.total = init?.total || 0;
	}
};
var SUPPORTS_PROGRESS_EVENT = typeof ProgressEvent !== "undefined";
function createEvent(target, type, init) {
	const progressEvents = [
		"error",
		"progress",
		"loadstart",
		"loadend",
		"load",
		"timeout",
		"abort"
	];
	/**
	* `ProgressEvent` is not supported in React Native.
	* @see https://github.com/mswjs/interceptors/issues/40
	*/
	const ProgressEventClass = SUPPORTS_PROGRESS_EVENT ? ProgressEvent : ProgressEventPolyfill;
	return progressEvents.includes(type) ? new ProgressEventClass(type, {
		lengthComputable: true,
		loaded: init?.loaded || 0,
		total: init?.total || 0
	}) : new EventPolyfill(type, {
		target,
		currentTarget: target
	});
}
/**
* Returns the source object of the given property on the target object
* (the target itself, any parent in its prototype, or null).
*/
function findPropertySource(target, propertyName) {
	if (!(propertyName in target)) return null;
	if (Object.prototype.hasOwnProperty.call(target, propertyName)) return target;
	const prototype = Reflect.getPrototypeOf(target);
	return prototype ? findPropertySource(prototype, propertyName) : null;
}
function createProxy(target, options) {
	return new Proxy(target, optionsToProxyHandler(options));
}
function optionsToProxyHandler(options) {
	const { constructorCall, methodCall, getProperty, setProperty } = options;
	const handler = {};
	if (typeof constructorCall !== "undefined") handler.construct = function(target, args, newTarget) {
		const next = Reflect.construct.bind(null, target, args, newTarget);
		return constructorCall.call(newTarget, args, next);
	};
	handler.set = function(target, propertyName, nextValue) {
		const next = () => {
			const propertySource = findPropertySource(target, propertyName) || target;
			const ownDescriptors = Reflect.getOwnPropertyDescriptor(propertySource, propertyName);
			if (typeof ownDescriptors?.set !== "undefined") {
				ownDescriptors.set.apply(target, [nextValue]);
				return true;
			}
			return Reflect.defineProperty(propertySource, propertyName, {
				writable: true,
				enumerable: true,
				configurable: true,
				value: nextValue
			});
		};
		if (typeof setProperty !== "undefined") return setProperty.call(target, [propertyName, nextValue], next);
		return next();
	};
	handler.get = function(target, propertyName, receiver) {
		/**
		* @note Using `Reflect.get()` here causes "TypeError: Illegal invocation".
		*/
		const next = () => target[propertyName];
		const value = typeof getProperty !== "undefined" ? getProperty.call(target, [propertyName, receiver], next) : next();
		if (typeof value === "function") return (...args) => {
			const next = value.bind(target, ...args);
			if (typeof methodCall !== "undefined") return methodCall.call(target, [propertyName, args], next);
			return next();
		};
		return value;
	};
	return handler;
}
function isDomParserSupportedType(type) {
	return [
		"application/xhtml+xml",
		"application/xml",
		"image/svg+xml",
		"text/html",
		"text/xml"
	].some((supportedType) => {
		return type.startsWith(supportedType);
	});
}
/**
* Parses a given string into JSON.
* Gracefully handles invalid JSON by returning `null`.
*/
function parseJson(data) {
	try {
		return JSON.parse(data);
	} catch (_) {
		return null;
	}
}
/**
* Creates a Fetch API `Response` instance from the given
* `XMLHttpRequest` instance and a response body.
*/
function createResponse(request, body) {
	/**
	* Handle XMLHttpRequest responses that must have null as the
	* response body when represented using Fetch API Response.
	* XMLHttpRequest response will always have an empty string
	* as the "request.response" in those cases, resulting in an error
	* when constructing a Response instance.
	* @see https://github.com/mswjs/interceptors/issues/379
	*/
	const responseBodyOrNull = FetchResponse.isResponseWithBody(request.status) ? body : null;
	return new FetchResponse(responseBodyOrNull, {
		url: request.responseURL,
		status: request.status,
		statusText: request.statusText,
		headers: createHeadersFromXMLHttpRequestHeaders(request.getAllResponseHeaders())
	});
}
function createHeadersFromXMLHttpRequestHeaders(headersString) {
	const headers = new Headers();
	const lines = headersString.split(/[\r\n]+/);
	for (const line of lines) {
		if (line.trim() === "") continue;
		const [name, ...parts] = line.split(": ");
		const value = parts.join(": ");
		headers.append(name, value);
	}
	return headers;
}
/**
* Return a total byte length of the given request/response body.
* If the `Content-Length` header is present, it will be used as the byte length.
*/
async function getBodyByteLength(input) {
	const explicitContentLength = input.headers.get("content-length");
	if (explicitContentLength != null && explicitContentLength !== "") return Number(explicitContentLength);
	return (await input.arrayBuffer()).byteLength;
}
var kIsRequestHandled = Symbol("kIsRequestHandled");
var kFetchRequest = Symbol("kFetchRequest");
var MAX_REDIRECTS = 20;
/**
* An `XMLHttpRequest` instance controller that allows us
* to handle any given request instance (e.g. responding to it).
*/
var XMLHttpRequestController = class {
	constructor(initialRequest, logger) {
		this.initialRequest = initialRequest;
		this.logger = logger;
		this.sync = false;
		this.method = "GET";
		this.url = null;
		this[kIsRequestHandled] = false;
		this.redirectCount = 0;
		this.events = /* @__PURE__ */ new Map();
		this.uploadEvents = /* @__PURE__ */ new Map();
		this.requestId = createRequestId();
		this.requestHeaders = new Headers();
		this.responseBuffer = /* @__PURE__ */ new Uint8Array();
		this.request = createProxy(initialRequest, { methodCall: ([methodName, args], invoke) => {
			switch (methodName) {
				case "open": {
					const [method, url, async] = args;
					this.sync = !(async ?? true);
					if (typeof url === "undefined") {
						this.method = "GET";
						this.url = toAbsoluteUrl(method);
					} else {
						this.method = method;
						this.url = toAbsoluteUrl(url);
					}
					this.logger.verbose("open %s %s", this.method, this.url.href);
					return invoke();
				}
				case "addEventListener": {
					const [eventName, listener] = args;
					this.registerEvent(eventName, listener);
					this.logger.verbose("addEventListener", eventName, listener);
					return invoke();
				}
				case "setRequestHeader": {
					const [name, value] = args;
					this.requestHeaders.set(name, value);
					this.logger.verbose("setRequestHeader", name, value);
					return invoke();
				}
				case "send": {
					const [body] = args;
					if (this.sync) {
						console.warn(`Failed to intercept an XMLHttpRequest (${this.method} ${this.url}): synchronous requests are not supported. This request will be performed as-is.`);
						return invoke();
					}
					this.request.addEventListener("load", () => {
						if (typeof this.onResponse !== "undefined") {
							const fetchResponse = createResponse(
								this.request,
								/**
								* The `response` property is the right way to read
								* the ambiguous response body, as the request's "responseType" may differ.
								* @see https://xhr.spec.whatwg.org/#the-response-attribute
								*/
								this.request.response
							);
							this.onResponse.call(this, {
								response: fetchResponse,
								responseType: this[kIsRequestHandled] ? "mock" : "original",
								request: fetchRequest,
								requestId: this.requestId
							});
						}
					});
					const requestBody = typeof body === "string" ? encodeBuffer(body) : body;
					const fetchRequest = this.toFetchApiRequest(requestBody);
					this[kFetchRequest] = fetchRequest.clone();
					/**
					* @note Start request handling on the next tick so that the user
					* could add event listeners for "loadend" before the interceptor fires it.
					*/
					queueMicrotask(() => {
						(this.onRequest?.call(this, {
							request: fetchRequest,
							requestId: this.requestId
						}) || Promise.resolve()).finally(() => {
							if (!this[kIsRequestHandled]) {
								this.logger.verbose("request callback settled but request has not been handled (readystate %d), performing as-is...", this.request.readyState);
								return invoke();
							}
						});
					});
					break;
				}
				default: return invoke();
			}
		} });
		/**
		* Proxy the `.upload` property to gather the event listeners/callbacks.
		*/
		define(this.request, "upload", createProxy(this.request.upload, {
			setProperty: ([propertyName, nextValue], invoke) => {
				switch (propertyName) {
					case "onloadstart":
					case "onprogress":
					case "onaboart":
					case "onerror":
					case "onload":
					case "ontimeout":
					case "onloadend": {
						const eventName = propertyName.slice(2);
						this.registerUploadEvent(eventName, nextValue);
					}
				}
				return invoke();
			},
			methodCall: ([methodName, args], invoke) => {
				switch (methodName) {
					case "addEventListener": {
						const [eventName, listener] = args;
						this.registerUploadEvent(eventName, listener);
						this.logger.verbose("upload.addEventListener", eventName, listener);
						return invoke();
					}
				}
			}
		}));
	}
	registerEvent(eventName, listener) {
		const nextEvents = (this.events.get(eventName) || []).concat(listener);
		this.events.set(eventName, nextEvents);
		this.logger.verbose("registered event \"%s\"", eventName, listener);
	}
	registerUploadEvent(eventName, listener) {
		const nextEvents = (this.uploadEvents.get(eventName) || []).concat(listener);
		this.uploadEvents.set(eventName, nextEvents);
		this.logger.verbose("registered upload event \"%s\"", eventName, listener);
	}
	/**
	* Responds to the current request with the given
	* Fetch API `Response` instance.
	*/
	async respondWith(response) {
		/**
		* @note Since `XMLHttpRequestController` delegates the handling of the responses
		* to the "load" event listener that doesn't distinguish between the mocked and original
		* responses, mark the request that had a mocked response with a corresponding symbol.
		*
		* Mark this request as having a mocked response immediately since
		* calculating request/response total body length is asynchronous.
		*/
		this[kIsRequestHandled] = true;
		this.logger.verbose("responding with a mocked response: %d %s", response.status, response.statusText);
		FetchResponse.setUrl(this.url.href, response);
		Object.defineProperties(this.request, {
			response: {
				enumerable: true,
				configurable: false,
				get: () => this.response
			},
			responseText: {
				enumerable: true,
				configurable: false,
				get: () => this.responseText
			},
			responseXML: {
				enumerable: true,
				configurable: false,
				get: () => this.responseXML
			}
		});
		this.trigger("loadstart", this.request, {
			loaded: 0,
			total: 0
		});
		let requestBodyTransmitted = 0;
		let uploadComplete = false;
		if (this[kFetchRequest]) {
			const requestBodyLength = await getBodyByteLength(this[kFetchRequest].clone());
			if (!uploadComplete) this.trigger("loadstart", this.request.upload, {
				loaded: 0,
				total: requestBodyLength
			});
			const processRequestBodyChunkLength = (bytesLength) => {
				requestBodyTransmitted += bytesLength;
				if (requestBodyTransmitted < requestBodyLength) this.trigger("progress", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
			};
			const processRequestEndOfBody = () => {
				uploadComplete = true;
				this.trigger("progress", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
				this.trigger("load", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
				this.trigger("loadend", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
			};
			if (this[kFetchRequest]?.body != null) {
				const reader = this[kFetchRequest].body.getReader();
				while (true) {
					const { value, done } = await reader.read();
					if (done) {
						processRequestEndOfBody();
						break;
					}
					processRequestBodyChunkLength(value.byteLength);
				}
			} else processRequestEndOfBody();
		}
		let timedOut = false;
		const responseReadController = new AbortController();
		const requestErrorSteps = (event) => {
			this.setReadyState(this.request.DONE);
			if (!uploadComplete) {
				this.trigger(event, this.request.upload, {
					loaded: 0,
					total: 0
				});
				this.trigger("loadend", this.request.upload, {
					loaded: 0,
					total: 0
				});
			}
			this.trigger(event, this.request, {
				loaded: 0,
				total: 0
			});
			this.trigger("loadend", this.request, {
				loaded: 0,
				total: 0
			});
		};
		const processResponse = async (response) => {
			const handleErrors = () => {
				if (timedOut) requestErrorSteps("timeout");
				else if (responseReadController.signal.aborted) requestErrorSteps("abort");
				else if (isResponseError(response)) requestErrorSteps("error");
			};
			handleErrors();
			define(this.request, "status", response.status);
			define(this.request, "statusText", response.statusText);
			if (!this.request.responseURL) define(this.request, "responseURL", response.url);
			if (isResponseError(response)) return;
			/**
			* @note The response body length is derived ONLY from the "content-length" header.
			* If that response header is not set, the "total" in all progress events must be 0.
			*/
			const responseBodyLength = Number(response.headers.get("content-length") ?? "0");
			this.setReadyState(this.request.HEADERS_RECEIVED);
			let receivedBytes = 0;
			let lastReceivedResponseBytesAt = performance.now();
			const processResponseBodyChunk = (bytesLength) => {
				receivedBytes += bytesLength;
				const now = performance.now();
				const shouldBuffer = now - lastReceivedResponseBytesAt <= 60 && receivedBytes < responseBodyLength;
				lastReceivedResponseBytesAt = now;
				if (shouldBuffer) return;
				if (this.request.readyState === this.request.HEADERS_RECEIVED) this.setReadyState(this.request.LOADING, false);
				this.trigger("readystatechange", this.request);
				this.trigger("progress", this.request, {
					loaded: receivedBytes,
					total: responseBodyLength
				});
			};
			const processResponseBodyError = () => {
				requestErrorSteps("error");
			};
			const processResponseEndOfBody = async () => {
				handleErrors();
				if (isResponseError(response)) return;
				let transmitted = receivedBytes;
				this.setReadyState(this.request.DONE);
				this.trigger("load", this.request, {
					loaded: transmitted,
					total: responseBodyLength
				});
				this.trigger("loadend", this.request, {
					loaded: transmitted,
					total: responseBodyLength
				});
			};
			if (response.body == null) processResponseEndOfBody();
			else {
				const reader = response.body.getReader();
				while (true) {
					if (responseReadController.signal.aborted) break;
					try {
						const { value, done } = await reader.read();
						if (done) {
							processResponseEndOfBody();
							return;
						}
						processResponseBodyChunk(value.byteLength);
						this.responseBuffer = concatArrayBuffer(this.responseBuffer, value);
					} catch {
						processResponseBodyError();
					}
				}
			}
		};
		const [redirectError, finalResponse] = await until(() => {
			return this.followRedirects(response);
		});
		if (redirectError) return;
		processResponse(finalResponse);
		if (this.request.timeout) setTimeout(() => {
			if (this.request.readyState !== this.request.DONE) {
				timedOut = true;
				responseReadController.abort();
			}
		}, this.request.timeout);
		this.request.getResponseHeader = new Proxy(this.request.getResponseHeader, { apply: (_, __, args) => {
			this.logger.verbose("getResponseHeader", args[0]);
			if (this.request.readyState < this.request.HEADERS_RECEIVED) {
				this.logger.verbose("headers not received yet, returning null");
				return null;
			}
			const headerValue = finalResponse.headers.get(args[0]);
			this.logger.verbose("resolved response header \"%s\" to", args[0], headerValue);
			return headerValue;
		} });
		this.request.getAllResponseHeaders = new Proxy(this.request.getAllResponseHeaders, { apply: () => {
			this.logger.verbose("getAllResponseHeaders");
			if (this.request.readyState < this.request.HEADERS_RECEIVED) {
				this.logger.verbose("headers not received yet, returning empty string");
				return "";
			}
			const allHeaders = Array.from(finalResponse.headers).map(([headerName, headerValue]) => {
				return `${headerName}: ${headerValue}`;
			}).join("\r\n");
			this.logger.verbose("resolved all response headers to", allHeaders);
			return allHeaders;
		} });
	}
	responseBufferToText() {
		return decodeBuffer(this.responseBuffer);
	}
	get response() {
		this.logger.verbose("getResponse (responseType: %s)", this.request.responseType);
		if (this.request.readyState !== this.request.DONE) return null;
		switch (this.request.responseType) {
			case "json": {
				const responseJson = parseJson(this.responseBufferToText());
				this.logger.verbose("resolved response JSON", responseJson);
				return responseJson;
			}
			case "arraybuffer": {
				const arrayBuffer = toArrayBuffer(this.responseBuffer);
				this.logger.verbose("resolved response ArrayBuffer", arrayBuffer);
				return arrayBuffer;
			}
			case "blob": {
				const mimeType = this.request.getResponseHeader("Content-Type") || "text/plain";
				const responseBlob = new Blob([this.responseBufferToText()], { type: mimeType });
				this.logger.verbose("resolved response Blob (mime type: %s)", responseBlob, mimeType);
				return responseBlob;
			}
			default: {
				const responseText = this.responseBufferToText();
				this.logger.verbose("resolving \"%s\" response type as text", this.request.responseType, responseText);
				return responseText;
			}
		}
	}
	get responseText() {
		/**
		* Throw when trying to read the response body as text when the
		* "responseType" doesn't expect text. This just respects the spec better.
		* @see https://xhr.spec.whatwg.org/#the-responsetext-attribute
		*/
		invariant(this.request.responseType === "" || this.request.responseType === "text", "InvalidStateError: The object is in invalid state.");
		if (this.request.readyState !== this.request.LOADING && this.request.readyState !== this.request.DONE) return "";
		const responseText = this.responseBufferToText();
		this.logger.verbose("getResponseText: \"%s\"", responseText);
		return responseText;
	}
	get responseXML() {
		invariant(this.request.responseType === "" || this.request.responseType === "document", "InvalidStateError: The object is in invalid state.");
		if (this.request.readyState !== this.request.DONE) return null;
		const contentType = this.request.getResponseHeader("Content-Type") || "";
		if (typeof DOMParser === "undefined") {
			console.warn("Cannot retrieve XMLHttpRequest response body as XML: DOMParser is not defined. You are likely using an environment that is not browser or does not polyfill browser globals correctly.");
			return null;
		}
		if (isDomParserSupportedType(contentType)) return new DOMParser().parseFromString(this.responseBufferToText(), contentType);
		return null;
	}
	async followRedirects(response) {
		const redirectLocation = response.headers.get("location");
		if (!redirectLocation || !FetchResponse.isRedirectResponse(response.status)) return response;
		this.redirectCount++;
		if (this.redirectCount > MAX_REDIRECTS) throw new Error("Too many redirects");
		const redirectUrl = new URL(redirectLocation, location.href);
		const redirectMethod = FetchResponse.isResponseWithBody(response.status) ? this.method : "GET";
		const redirectResponse = await new Promise((resolve, reject) => {
			const request = new XMLHttpRequest();
			request.responseType = this.request.responseType;
			request.addEventListener("load", () => {
				this.url = new URL(request.responseURL);
				resolve(createResponse(request, request.response));
			});
			request.addEventListener("error", () => {
				this.errorWith();
				reject(/* @__PURE__ */ new Error("Redirect request failed"));
			});
			request.open(redirectMethod, redirectUrl.href);
			request.send();
		});
		return this.followRedirects(redirectResponse);
	}
	errorWith(error) {
		/**
		* @note Mark this request as handled even if it received a mock error.
		* This prevents the controller from trying to perform this request as-is.
		*/
		this[kIsRequestHandled] = true;
		this.logger.verbose("responding with an error");
		this.setReadyState(this.request.DONE);
		this.trigger("error", this.request);
		this.trigger("loadend", this.request);
	}
	/**
	* Transitions this request's `readyState` to the given one.
	*/
	setReadyState(nextReadyState, triggerReadyStateChangeEvent = true) {
		this.logger.verbose("setReadyState: %d -> %d", this.request.readyState, nextReadyState);
		if (this.request.readyState === nextReadyState) {
			this.logger.verbose("ready state identical, skipping transition...");
			return;
		}
		define(this.request, "readyState", nextReadyState);
		this.logger.verbose("set readyState to: %d", nextReadyState);
		if (!triggerReadyStateChangeEvent) return;
		if (nextReadyState !== this.request.UNSENT) {
			this.logger.verbose("triggering \"readystatechange\" event...");
			this.trigger("readystatechange", this.request);
		}
	}
	/**
	* Triggers given event on the `XMLHttpRequest` instance.
	*/
	trigger(eventName, target, options) {
		const callback = target[`on${eventName}`];
		const event = createEvent(target, eventName, options);
		this.logger.verbose("trigger \"%s\"", eventName, options || "");
		if (typeof callback === "function") {
			this.logger.verbose("found a direct \"%s\" callback, calling...", eventName);
			callback.call(target, event);
		}
		const events = target instanceof XMLHttpRequestUpload ? this.uploadEvents : this.events;
		for (const [registeredEventName, listeners] of events) if (registeredEventName === eventName) {
			this.logger.verbose("found %d listener(s) for \"%s\" event, calling...", listeners.length, eventName);
			listeners.forEach((listener) => listener.call(target, event));
		}
	}
	/**
	* Converts this `XMLHttpRequest` instance into a Fetch API `Request` instance.
	*/
	toFetchApiRequest(body) {
		this.logger.verbose("converting request to a Fetch API Request...");
		const resolvedBody = body instanceof Document ? body.documentElement.innerText : body;
		const fetchRequest = new FetchRequest(this.url.href, {
			method: this.method,
			headers: this.requestHeaders,
			/**
			* @see https://xhr.spec.whatwg.org/#cross-origin-credentials
			*/
			credentials: this.request.withCredentials ? "include" : "same-origin",
			body: resolvedBody
		});
		const headers = fetchRequest.headers;
		define(fetchRequest, "headers", createProxy(headers, { methodCall: ([methodName, args], invoke) => {
			const result = invoke();
			switch (methodName) {
				case "append":
				case "set": {
					const [headerName, headerValue] = args;
					/**
					* @note Forward only the headers the Fetch API Request accepted.
					* Forbidden request headers (e.g. "Cookie") are dropped silently
					* by the request's headers guard, and forwarding them makes
					* the browser refuse them with an error in the console.
					*/
					if (headers.has(headerName)) this.request.setRequestHeader(headerName, headerValue);
					break;
				}
				case "delete": {
					const [headerName] = args;
					console.warn(`XMLHttpRequest: Cannot remove a "${headerName}" header from the Fetch API representation of the "${fetchRequest.method} ${fetchRequest.url}" request. XMLHttpRequest headers cannot be removed.`);
					break;
				}
			}
			return result;
		} }));
		this.logger.verbose("converted request to a Fetch API Request!", fetchRequest);
		return fetchRequest;
	}
};
function toAbsoluteUrl(url) {
	/**
	* @note XMLHttpRequest interceptor may run in environments
	* that implement XMLHttpRequest but don't implement "location"
	* (for example, React Native). If that's the case, return the
	* input URL as-is (nothing to be relative to).
	* @see https://github.com/mswjs/msw/issues/1777
	*/
	if (typeof location === "undefined") return new URL(url);
	return new URL(url.toString(), location.href);
}
function define(target, property, value) {
	Reflect.defineProperty(target, property, {
		writable: true,
		enumerable: true,
		value
	});
}
/**
* Create a proxied `XMLHttpRequest` class.
* The proxied class establishes spies on certain methods,
* allowing us to intercept requests and respond to them.
*/
function createXMLHttpRequestProxy({ emitter, logger }) {
	return new Proxy(globalThis.XMLHttpRequest, { construct(target, args, newTarget) {
		logger.verbose("constructed new XMLHttpRequest");
		const originalRequest = Reflect.construct(target, args, newTarget);
		/**
		* @note Forward prototype descriptors onto the proxied object.
		* XMLHttpRequest is implemented in JSDOM in a way that assigns
		* a bunch of descriptors, like "set responseType()" on the prototype.
		* With this propagation, we make sure that those descriptors trigger
		* when the user operates with the proxied request instance.
		*/
		const prototypeDescriptors = Object.getOwnPropertyDescriptors(target.prototype);
		for (const propertyName in prototypeDescriptors) Reflect.defineProperty(originalRequest, propertyName, prototypeDescriptors[propertyName]);
		const xhrRequestController = new XMLHttpRequestController(originalRequest, logger);
		xhrRequestController.onRequest = async function({ request, requestId }) {
			const controller = new RequestController(request, {
				passthrough: () => {
					this.logger.verbose("no mocked response received, performing request as-is...");
				},
				respondWith: async (response) => {
					await this.respondWith(response);
				},
				errorWith: (reason) => {
					this.logger.verbose("request errored %o", { error: reason });
					if (reason instanceof Error) this.errorWith(reason);
				}
			}, {
				logger,
				requestId
			});
			this.logger.verbose("awaiting mocked response");
			this.logger.verbose("emitting the \"request\" event for %s listener(s)...", emitter.listenerCount("request"));
			await handleRequest({
				initiator: this.request,
				request,
				requestId,
				controller,
				emitter,
				logger
			});
		};
		xhrRequestController.onResponse = async function({ response, responseType, request, requestId }) {
			this.logger.verbose("emitting the \"response\" event for %s listener(s)...", emitter.listenerCount("response"));
			await emitter.emitAsPromise(new HttpResponseEvent({
				initiator: this.request,
				response,
				responseType,
				request,
				requestId
			}));
		};
		return xhrRequestController.request;
	} });
}
var logger$1 = createLogger("xhr");
var XMLHttpRequestInterceptor = class extends Interceptor {
	static {
		this.symbol = Symbol.for("xhr-interceptor");
	}
	predicate() {
		return hasConfigurableGlobal("XMLHttpRequest");
	}
	setup() {
		logger$1.verbose("patching \"XMLHttpRequest\"...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "XMLHttpRequest", () => {
			return createXMLHttpRequestProxy({
				emitter: this.emitter,
				logger: logger$1
			});
		}));
		logger$1.verbose("global \"XMLHttpRequest\" patched!", globalThis.XMLHttpRequest.name);
	}
};
//#endregion
//#region node_modules/@mswjs/interceptors/lib/browser/web-CCLERSZF.js
function createNetworkError(cause) {
	return Object.assign(/* @__PURE__ */ new TypeError("Failed to fetch"), { cause });
}
var REQUEST_BODY_HEADERS = [
	"content-encoding",
	"content-language",
	"content-location",
	"content-type",
	"content-length"
];
var kRedirectCount = Symbol("kRedirectCount");
/**
* @see https://github.com/nodejs/undici/blob/a6dac3149c505b58d2e6d068b97f4dc993da55f0/lib/web/fetch/index.js#L1210
*/
async function followFetchRedirect(request, response) {
	if (response.status !== 303 && request.body != null) return Promise.reject(createNetworkError());
	const requestUrl = new URL(request.url);
	let locationUrl;
	try {
		locationUrl = new URL(response.headers.get("location"), request.url);
	} catch (error) {
		return Promise.reject(createNetworkError(error));
	}
	if (!(locationUrl.protocol === "http:" || locationUrl.protocol === "https:")) return Promise.reject(createNetworkError("URL scheme must be a HTTP(S) scheme"));
	if (Reflect.get(request, kRedirectCount) > 20) return Promise.reject(createNetworkError("redirect count exceeded"));
	Object.defineProperty(request, kRedirectCount, { value: (Reflect.get(request, kRedirectCount) || 0) + 1 });
	if (request.mode === "cors" && (locationUrl.username || locationUrl.password) && !sameOrigin(requestUrl, locationUrl)) return Promise.reject(createNetworkError("cross origin not allowed for request mode \"cors\""));
	const requestInit = {};
	if ([301, 302].includes(response.status) && request.method === "POST" || response.status === 303 && !["HEAD", "GET"].includes(request.method)) {
		requestInit.method = "GET";
		requestInit.body = null;
		REQUEST_BODY_HEADERS.forEach((headerName) => {
			request.headers.delete(headerName);
		});
	}
	if (!sameOrigin(requestUrl, locationUrl)) {
		request.headers.delete("authorization");
		request.headers.delete("proxy-authorization");
		request.headers.delete("cookie");
		request.headers.delete("host");
	}
	/**
	* @note Undici "safely" extracts the request body.
	* I suspect we cannot dispatch this request again
	* since its body has been read and the stream is locked.
	*/
	requestInit.headers = request.headers;
	const finalResponse = await fetch(new Request(locationUrl, requestInit));
	Object.defineProperty(finalResponse, "redirected", {
		value: true,
		configurable: true
	});
	return finalResponse;
}
/**
* @see https://github.com/nodejs/undici/blob/a6dac3149c505b58d2e6d068b97f4dc993da55f0/lib/web/fetch/util.js#L761
*/
function sameOrigin(left, right) {
	if (left.origin === right.origin && left.origin === "null") return true;
	if (left.protocol === right.protocol && left.hostname === right.hostname && left.port === right.port) return true;
	return false;
}
var BrotliDecompressionStream = class extends TransformStream {
	constructor() {
		console.warn("[Interceptors]: Brotli decompression of response streams is not supported in the browser");
		super({ transform(chunk, controller) {
			controller.enqueue(chunk);
		} });
	}
};
var PipelineStream = class extends TransformStream {
	constructor(transformStreams, ...strategies) {
		super({}, ...strategies);
		const readable = [super.readable, ...transformStreams].reduce((readable, transform) => readable.pipeThrough(transform));
		Object.defineProperty(this, "readable", { get() {
			return readable;
		} });
	}
};
function parseContentEncoding(contentEncoding) {
	return contentEncoding.toLowerCase().split(",").map((coding) => coding.trim());
}
function createDecompressionStream(contentEncoding) {
	return new PipelineStream(parseContentEncoding(contentEncoding).reduceRight((transformers, coding) => {
		if (coding === "gzip" || coding === "x-gzip") return transformers.concat(new DecompressionStream("gzip"));
		else if (coding === "deflate") return transformers.concat(new DecompressionStream("deflate"));
		else if (coding === "br") return transformers.concat(new BrotliDecompressionStream());
		else transformers.length = 0;
		return transformers;
	}, []));
}
/**
* Returns a boolean indicating whether the given response
* has a body encoded with a non-empty "content-encoding".
*/
function isCompressedResponse(response) {
	if (response.body === null) return false;
	const contentEncoding = response.headers.get("content-encoding");
	return contentEncoding !== null && contentEncoding.trim() !== "";
}
/**
* Decompresses the body of the given compressed response.
*/
function decompressResponse(response) {
	invariant(isCompressedResponse(response), "Failed to decompress a response: expected a response with a body and a non-empty \"content-encoding\" header");
	const decompressionStream = createDecompressionStream(response.headers.get("content-encoding"));
	response.body.pipeTo(decompressionStream.writable);
	return decompressionStream.readable;
}
/** Clone for observers without letting their unread body block caller cancellation. */
function cloneResponse(response) {
	const clone = FetchResponse.clone(response);
	if (!response.body || !clone.body) return [response, clone];
	const observer = wrapResponse(clone);
	return [wrapResponse(response, observer.cancel).response, observer.response];
}
function wrapResponse(response, onCancel) {
	const body = response.body;
	const reader = body.getReader();
	const cancel = (reason) => {
		return body.locked ? reader.cancel(reason) : body.cancel(reason);
	};
	const stream = new ReadableStream({
		async pull(controller) {
			try {
				const { done, value } = await reader.read();
				if (done) {
					controller.close();
					reader.releaseLock();
					return;
				}
				controller.enqueue(value);
			} catch (error) {
				controller.error(error);
				reader.releaseLock();
			}
		},
		async cancel(reason) {
			try {
				const cancellation = cancel(reason);
				if (onCancel) await Promise.all([cancellation, onCancel(reason)]);
				else cancellation.catch(() => {});
			} finally {
				reader.releaseLock();
			}
		}
	}, { highWaterMark: 0 });
	const wrappedResponse = new FetchResponse(stream, response);
	copyRawHeaders(response.headers, wrappedResponse.headers);
	Object.defineProperties(wrappedResponse, {
		type: { value: response.type },
		redirected: { value: response.redirected }
	});
	return {
		response: wrappedResponse,
		cancel
	};
}
var logger = createLogger("fetch");
/**
* Intercept `fetch` requests in the browser.
*/
var FetchInterceptor = class extends Interceptor {
	static {
		this.symbol = Symbol.for("fetch-interceptor");
	}
	predicate() {
		return hasConfigurableGlobal("fetch");
	}
	async setup() {
		logger.verbose("patching global fetch...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "fetch", (realFetch) => {
			return async (input, init) => {
				const requestId = createRequestId();
				/**
				* @note Resolve potentially relative request URL
				* against the present `location`. This is mainly
				* for native `fetch` in JSDOM.
				* @see https://github.com/mswjs/msw/issues/1625
				*/
				const resolvedInput = typeof input === "string" && typeof location !== "undefined" && !URL.canParse(input) ? new URL(input, location.href) : input;
				const request = new Request(resolvedInput, init);
				const responsePromise = Promise.withResolvers();
				const controller = new RequestController(request, {
					passthrough: async () => {
						logger.verbose("performing request as-is");
						/**
						* @note Perform a clone of the request instance, not the instance itself.
						* Performing a request consumes its body, and the "response" listener
						* must still be able to read it. The clone is created right before
						* the request is performed, so it preserves any modifications made
						* to the intercepted request in the "request" listener.
						*
						* This also keeps the request instance emitted on the "response" event
						* referentially equal to the one emitted on the "request" event
						* so the consumer can associate the two by identity.
						*/
						const requestClone = request.clone();
						const [responseError, originalResponse] = await until(() => realFetch(requestClone));
						if (responseError) return responsePromise.reject(responseError);
						logger.verbose("original fetch performed %o", originalResponse);
						if (this.emitter.listenerCount("response") > 0) {
							logger.verbose("emitting the \"response\" event");
							const [response, responseClone] = cloneResponse(originalResponse);
							await this.emitter.emitAsPromise(new HttpResponseEvent({
								initiator: request,
								request,
								requestId,
								response: responseClone,
								responseType: "original"
							}));
							responsePromise.resolve(response);
							return;
						}
						responsePromise.resolve(originalResponse);
					},
					respondWith: async (rawResponse) => {
						if (isResponseError(rawResponse)) {
							logger.verbose("request errored %o", { response: rawResponse });
							responsePromise.reject(createNetworkError(rawResponse));
							return;
						}
						/**
						* @note Forward the mocked response instance as-is. Wrapping it
						* in a new `Response` drops any runtime-specific state the
						* environment attached to it (e.g. the `webSocket` property
						* of a "101 Switching Protocols" response in workerd).
						* A plain `Response` is already guaranteed to be valid by the
						* environment, and a `FetchResponse` manages its own
						* non-configurable state (status, URL) across clones.
						*
						* The only exception is a compressed mocked response body:
						* a body cannot be swapped in place, so it must be a new instance.
						*/
						let response;
						if (isCompressedResponse(rawResponse)) {
							response = new FetchResponse(decompressResponse(rawResponse), {
								status: rawResponse.status,
								statusText: rawResponse.statusText,
								headers: rawResponse.headers
							});
							copyRawHeaders(rawResponse.headers, response.headers);
						} else response = rawResponse;
						FetchResponse.setUrl(request.url, response);
						/**
						* Undici's handling of following redirect responses.
						* Treat the "manual" redirect mode as a regular mocked response.
						* This way, the client can manually follow the redirect it receives.
						* @see https://github.com/nodejs/undici/blob/a6dac3149c505b58d2e6d068b97f4dc993da55f0/lib/web/fetch/index.js#L1173
						*/
						if (FetchResponse.isRedirectResponse(response.status)) {
							if (request.redirect === "error") {
								responsePromise.reject(createNetworkError("unexpected redirect"));
								return;
							}
							if (request.redirect === "follow") {
								followFetchRedirect(request, response).then((response) => {
									responsePromise.resolve(response);
								}, (reason) => {
									responsePromise.reject(reason);
								});
								return;
							}
						}
						if (this.emitter.listenerCount("response") > 0) {
							logger.verbose("emitting the \"response\" event");
							const [callerResponse, responseClone] = cloneResponse(response);
							await this.emitter.emitAsPromise(new HttpResponseEvent({
								initiator: request,
								response: responseClone,
								responseType: "mock",
								request,
								requestId
							}));
							responsePromise.resolve(callerResponse);
							return;
						}
						responsePromise.resolve(response);
					},
					errorWith: (reason) => {
						logger.verbose("request aborted %o", { reason });
						responsePromise.reject(reason);
					}
				}, {
					logger,
					requestId
				});
				logger.verbose("awaiting request resolution");
				logger.verbose("emitting the \"request\" event for %s listener(s)...", this.emitter.listenerCount("request"));
				/**
				* @note Give the consumer a chance to abort the request before
				* it is dispatched. Fetch queues the request processing as a
				* task, so a signal aborted synchronously after `fetch()` must
				* prevent the request from ever reaching the "request" listeners.
				* Without this, the first listener is invoked synchronously
				* within the `fetch()` call itself.
				*/
				await Promise.resolve();
				await handleRequest({
					initiator: request,
					request,
					requestId,
					emitter: this.emitter,
					controller,
					logger
				});
				return responsePromise.promise;
			};
		}));
		logger.verbose("global fetch patched: %s", globalThis.fetch.name);
	}
};
//#endregion
//#region node_modules/msw/lib/browser/index.js
/**
* Checks if the Service Worker API is supproted and available
* in the current browsing context.
*/
function supportsServiceWorker() {
	return typeof navigator !== "undefined" && "serviceWorker" in navigator && typeof location !== "undefined" && location.protocol !== "file:";
}
/**
* Returns a boolean indicating whether the current browser
* supports `ReadableStream` as a `Transferable` when posting
* messages.
*/
function supportsReadableStreamTransfer() {
	try {
		const stream = new ReadableStream({ start: (controller) => controller.close() });
		new MessageChannel().port1.postMessage(stream, [stream]);
		return true;
	} catch {
		return false;
	}
}
function toResponseInit(response) {
	return {
		status: response.status,
		statusText: response.statusText,
		headers: Object.fromEntries(response.headers.entries())
	};
}
/**
* Returns an absolute Service Worker URL based on the given
* relative URL (known during the registration).
*/
function getAbsoluteWorkerUrl(workerUrl) {
	return new URL(workerUrl, location.href).href;
}
/**
* Attempts to resolve a Service Worker instance from a given registration,
* regardless of its state (active, installing, waiting).
*/
function getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker) {
	return [
		registration.active,
		registration.installing,
		registration.waiting
	].filter((state) => {
		return state != null;
	}).find((worker) => {
		return findWorker(worker.scriptURL, absoluteWorkerUrl);
	}) || null;
}
/**
* Returns an active Service Worker instance.
* When not found, registers a new Service Worker.
*/
var getWorkerInstance = async (url, options = {}, findWorker) => {
	const absoluteWorkerUrl = getAbsoluteWorkerUrl(url);
	const mockRegistrations = await navigator.serviceWorker.getRegistrations().then((registrations) => registrations.filter((registration) => getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker)));
	if (!navigator.serviceWorker.controller && mockRegistrations.length > 0) location.reload();
	const [existingRegistration] = mockRegistrations;
	if (existingRegistration) {
		existingRegistration.update();
		return [getWorkerByRegistration(existingRegistration, absoluteWorkerUrl, findWorker), existingRegistration];
	}
	const [registrationError, registrationResult] = await until$1(async () => {
		const registration = await navigator.serviceWorker.register(url, options);
		return [getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker), registration];
	});
	if (registrationError) {
		if (registrationError.message.includes("(404)")) {
			const scopeUrl = new URL(options?.scope || "/", location.href);
			throw new Error(devUtils.formatMessage(`\
Failed to register a Service Worker for scope ('${scopeUrl.href}') with script ('${absoluteWorkerUrl}'): Service Worker script does not exist at the given path.

Did you forget to run "npx msw init <PUBLIC_DIR>"?

Learn more about creating the Service Worker script: https://mswjs.io/docs/cli/init`));
		}
		throw new Error(devUtils.formatMessage("Failed to register the Service Worker:\n\n%s", registrationError.message));
	}
	return registrationResult;
};
var SUPPORTS_SERVICE_WORKER = supportsServiceWorker();
var WorkerEvent = class extends TypedEvent {
	#workerEvent;
	constructor(workerEvent) {
		const type = workerEvent.data.type;
		const data = workerEvent.data.payload;
		/**
		* @note This is the only place we're mapping { type, payload }
		* message structure of the worker. The client references the
		* payload via `event.data`.
		*/
		super(type, { data });
		this.#workerEvent = workerEvent;
	}
	get ports() {
		return this.#workerEvent.ports;
	}
	/**
	* Reply directly to this event using its `MessagePort`.
	*/
	postMessage(type, ...rest) {
		this.#workerEvent.ports[0].postMessage({
			type,
			data: rest[0]
		}, { transfer: rest[1] });
	}
};
var WorkerChannel = class extends Emitter {
	#getWorker;
	#controller;
	constructor(options) {
		super();
		invariant(SUPPORTS_SERVICE_WORKER, "Failed to open a WorkerChannel: Service Worker is not supported in this environment.");
		this.#getWorker = options.getWorker;
		this.#controller = new AbortController();
		navigator.serviceWorker.addEventListener("message", async (event) => {
			const worker = await this.#getWorker();
			if (event.source != null && event.source !== worker) return;
			if (event.data && isObject$1(event.data) && "type" in event.data) this.emit(new WorkerEvent(event));
		}, { signal: this.#controller.signal });
	}
	/**
	* Send data to the Service Worker controlling this client.
	* This triggers the `message` event listener on ServiceWorkerGlobalScope.
	*/
	postMessage(type) {
		invariant(SUPPORTS_SERVICE_WORKER, "Failed to post message on a WorkerChannel: the Service Worker API is unavailable in this environment. This is likely an issue with MSW. Please report it on GitHub: https://github.com/mswjs/msw/issues");
		this.#getWorker().then((worker) => {
			worker.postMessage(type);
		});
	}
	/**
	* Terminal teardown. Removes the `navigator.serviceWorker` message listener
	* and all emitter subscriptions. The channel is not usable afterwards.
	*/
	terminate() {
		this.#controller.abort();
		this.removeAllListeners();
	}
};
/**
* Converts a given request received from the Service Worker
* into a Fetch `Request` instance.
*/
function deserializeRequest(serializedRequest) {
	return new FetchRequest(serializedRequest.url, { ...serializedRequest });
}
/**
* Print a warning if the given Service Worker registration has a scope
* outside of the current page's location. That is to help with debugging
* issues caused by the incorrectly registered Service Worker.
*/
function validateWorkerScope(registration) {
	if (!location.href.startsWith(registration.scope)) devUtils.warn(`Cannot intercept requests on this page because it's outside of the worker's scope ("${registration.scope}"). If you wish to mock API requests on this page, you must resolve this scope issue.

- (Recommended) Register the worker at the root level ("/") of your application.
- Set the "Service-Worker-Allowed" response header to allow out-of-scope workers.`);
}
function shouldInvalidateWorker(prevOptions, nextOptions) {
	return prevOptions.findWorker !== nextOptions.findWorker || prevOptions.serviceWorker.url !== nextOptions.serviceWorker.url || JSON.stringify(prevOptions.serviceWorker.options) !== JSON.stringify(nextOptions.serviceWorker.options);
}
var ServiceWorkerSource = class ServiceWorkerSource extends NetworkSource {
	static #current;
	/**
	* Create a new Service Worker source or reuse an existing one.
	* These sources act as a singleton and only get recreated if the options change.
	*/
	static async from(options) {
		if (ServiceWorkerSource.#current == null) ServiceWorkerSource.#current = new ServiceWorkerSource(options);
		else if (shouldInvalidateWorker(ServiceWorkerSource.#current.#options, options)) {
			await ServiceWorkerSource.#current.terminate();
			ServiceWorkerSource.#current = new ServiceWorkerSource(options);
		}
		return ServiceWorkerSource.#current;
	}
	#options;
	/**
	* @note We cannot use `WeakMap` here as request/response
	* identity cannot be preserved through the client-worker channel.
	*/
	#frames;
	#channel;
	#listenerController;
	#clientPromise;
	#keepAliveInterval;
	workerPromise;
	#workerResolvers;
	#workerState;
	constructor(options) {
		super();
		invariant(supportsServiceWorker(), "Failed to use Service Worker as the network source: the Service Worker API is not supported in this environment");
		this.#options = options;
		this.#frames = /* @__PURE__ */ new Map();
		this.#workerResolvers = Promise.withResolvers();
		this.workerPromise = this.#workerResolvers.promise;
		this.#workerState = "pending";
		this.#channel = new WorkerChannel({ getWorker: () => this.workerPromise.then(([worker]) => worker) });
	}
	async enable() {
		this.#channel.removeAllListeners();
		this.#frames.clear();
		this.#listenerController = new AbortController();
		const [worker, registration] = await this.#startWorker();
		if (worker.state !== "activated") {
			const controller = new AbortController();
			const activationPromise = Promise.withResolvers();
			activationPromise.promise.then(() => controller.abort());
			worker.addEventListener("statechange", () => {
				if (worker.state === "activated") activationPromise.resolve();
			}, { signal: controller.signal });
			await activationPromise.promise;
		}
		this.#channel.postMessage("MOCK_ACTIVATE");
		const clientConfirmationPromise = Promise.withResolvers();
		this.#clientPromise = clientConfirmationPromise.promise;
		this.#channel.once("MOCKING_ENABLED", (event) => {
			clientConfirmationPromise.resolve(event.data.client);
		});
		await clientConfirmationPromise.promise;
		if (!this.#options.quiet) this.#printStartMessage();
		return registration;
	}
	async disable() {
		/**
		* @note Do NOT call `super.disable()` because it removes any "frame" listeners
		* from this network source, effectively turning it off. The Service Worker source
		* is a bit special since it might process in-flight requests that have been performed
		* after it's been disabled.
		*/
		this.#listenerController?.abort();
		this.#listenerController = void 0;
		const closedPromise = Promise.withResolvers();
		this.#channel.once("CLIENT_CLOSED", () => closedPromise.resolve());
		this.#channel.postMessage("CLIENT_CLOSE");
		await closedPromise.promise;
		/**
		* @note Do NOT reset `workerPromise` here. The channel must continue to
		* resolve the currently registered SW so that any in-flight requests the
		* worker forwards after `stop()` can be answered with `PASSTHROUGH` by
		* `#handleRequest`. `#startWorker` swaps in a fresh deferred on re-enable.
		*/
		if (!this.#options.quiet) this.#printStopMessage();
	}
	/**
	* Terminal teardown. Unregisters the Service Worker, tears down the channel,
	* and clears timers. Called when the singleton is being replaced with one
	* that has different options. The instance is not usable afterwards.
	*/
	async terminate() {
		if (this.#keepAliveInterval != null) {
			clearInterval(this.#keepAliveInterval);
			this.#keepAliveInterval = void 0;
		}
		this.#frames.clear();
		this.#channel.terminate();
		this.#listenerController?.abort();
		this.#listenerController = void 0;
		if (this.#workerState === "fulfilled") {
			const [, registration] = await this.workerPromise;
			await registration.unregister();
		}
		if (ServiceWorkerSource.#current === this) ServiceWorkerSource.#current = void 0;
	}
	async #startWorker() {
		if (this.#keepAliveInterval) clearInterval(this.#keepAliveInterval);
		const workerUrl = this.#options.serviceWorker.url;
		const [worker, registration] = await getWorkerInstance(workerUrl, this.#options.serviceWorker.options, this.#options.findWorker || this.#defaultFindWorker);
		if (worker == null) {
			const missingWorkerMessage = this.#options?.findWorker ? devUtils.formatMessage(`Failed to locate the Service Worker registration using a custom "findWorker" predicate.

Please ensure that the custom predicate properly locates the Service Worker registration at "%s".
More details: https://mswjs.io/docs/api/setup-worker/start#findworker
     `, workerUrl) : devUtils.formatMessage(`Failed to locate the Service Worker registration.

This most likely means that the worker script URL "%s" cannot resolve against the actual public hostname (%s). This may happen if your application runs behind a proxy, or has a dynamic hostname.

Please consider using a custom "serviceWorker.url" option to point to the actual worker script location, or a custom "findWorker" option to resolve the Service Worker registration manually. More details: https://mswjs.io/docs/api/setup-worker/start`, workerUrl, location.host);
			throw new Error(missingWorkerMessage);
		}
		if (this.#workerState === "pending") {
			this.#workerResolvers.resolve([worker, registration]);
			this.#workerState = "fulfilled";
		} else {
			/**
			* @note Re-enable after `stop()`: the previous `workerPromise` is already
			* fulfilled and cannot be resolved again. Swap in a pre-resolved one so
			* `getWorker()` sees the new worker instance immediately.
			*/
			this.#workerResolvers = Promise.withResolvers();
			this.#workerResolvers.resolve([worker, registration]);
			this.workerPromise = this.#workerResolvers.promise;
		}
		this.#channel.on("REQUEST", this.#handleRequest.bind(this));
		this.#channel.on("RESPONSE", this.#handleResponse.bind(this));
		this.#channel.on("REQUEST_ERROR", this.#handleRequestError.bind(this));
		window.addEventListener("pagehide", (event) => {
			if (event.persisted) return;
			if (worker.state !== "redundant") this.#channel.postMessage("CLIENT_CLOSE");
			clearInterval(this.#keepAliveInterval);
			window.postMessage({ type: "msw/worker:stop" });
		}, { signal: this.#listenerController?.signal });
		await this.#checkWorkerIntegrity().catch((error) => {
			devUtils.error("Error while checking the worker script integrity. Please report this on GitHub (https://github.com/mswjs/msw/issues) and include the original error below.");
			console.error(error);
		});
		this.#keepAliveInterval = window.setInterval(() => {
			this.#channel.postMessage("KEEPALIVE_REQUEST");
		}, 5e3);
		if (!this.#options.quiet) validateWorkerScope(registration);
		return [worker, registration];
	}
	async #handleRequest(event) {
		const request = deserializeRequest(event.data);
		RequestHandler.cache.set(request, request.clone());
		const frame = new ServiceWorkerHttpNetworkFrame({
			event,
			request
		});
		this.#frames.set(event.data.id, frame);
		await this.queue(frame);
	}
	async #handleResponse(event) {
		const { request, response, isMockedResponse } = event.data;
		const frame = this.#frames.get(request.id);
		/**
		* CORS requests with `mode: "no-cors"` result in "opaque" responses.
		* That kind of responses cannot be manipulated in JavaScript due
		* to the security considerations.
		* @see https://fetch.spec.whatwg.org/#concept-filtered-response-opaque
		* @see https://github.com/mswjs/msw/issues/529
		*/
		if (response.type?.includes("opaque")) {
			this.#frames.delete(request.id);
			frame?.events.removeAllListeners();
			return;
		}
		this.#frames.delete(request.id);
		/**
		* @note A request frame will be missing in case of passthrough after the worker is stopped.
		* Creating a frame is costly so it's better to handle it as an edge case here.
		*/
		if (frame == null) return;
		const fetchRequest = deserializeRequest(request);
		const fetchResponse = response.status === 0 ? Response.error() : new FetchResponse(
			/**
			* Responses may be streams here, but when we create a response object
			* with null-body status codes, like 204, 205, 304 Response will
			* throw when passed a non-null body, so ensure it's null here
			* for those codes
			*/
			FetchResponse.isResponseWithBody(response.status) ? response.body : null,
			{
				...response,
				/**
				* Set response URL if it's not set already.
				* @see https://github.com/mswjs/msw/issues/2030
				* @see https://developer.mozilla.org/en-US/docs/Web/API/Response/url
				*/
				url: request.url
			}
		);
		try {
			frame.events.emit(new ResponseEvent(isMockedResponse ? "response:mocked" : "response:bypass", {
				requestId: frame.data.id,
				request: fetchRequest,
				response: fetchResponse,
				isMockedResponse
			}));
		} finally {
			frame.events.removeAllListeners();
		}
	}
	/**
	* @note A request can settle without ever producing a response
	* (e.g. a passthrough request failing with a network error).
	* The worker never sends the "RESPONSE" message for such requests,
	* so the frame must be released here to prevent it from being retained.
	* No "response:*" event is emitted, consistent with the Node.js source.
	* @see https://github.com/mswjs/msw/issues/2792
	*/
	#handleRequestError(event) {
		const { request } = event.data;
		const frame = this.#frames.get(request.id);
		this.#frames.delete(request.id);
		frame?.events.removeAllListeners();
	}
	#defaultFindWorker = (workerUrl, mockServiceWorkerUrl) => {
		return workerUrl === mockServiceWorkerUrl;
	};
	async #checkWorkerIntegrity() {
		const integrityCheckPromise = Promise.withResolvers();
		this.#channel.postMessage("INTEGRITY_CHECK_REQUEST");
		this.#channel.once("INTEGRITY_CHECK_RESPONSE", (event) => {
			const { checksum, packageVersion } = event.data;
			if (checksum !== "5cd5cf8b54c3a90f82960cedcd637772") devUtils.warn(`The currently registered Service Worker has been generated by a different version of MSW (${packageVersion}) and may not be fully compatible with the installed version.

It's recommended you update your worker script by running this command:

  \u2022 npx msw init <PUBLIC_DIR>

You can also automate this process and make the worker script update automatically upon the library installations. Read more: https://mswjs.io/docs/cli/init.`);
			integrityCheckPromise.resolve();
		});
		return integrityCheckPromise.promise;
	}
	async #printStartMessage() {
		if (this.#workerState === "rejected") return;
		invariant(this.#clientPromise != null, "[ServiceWorkerSource] Failed to print a start message: client confirmation not received");
		const client = await this.#clientPromise;
		const [worker, registration] = await this.workerPromise;
		console.groupCollapsed(`%c${devUtils.formatMessage("Mocking enabled.")}`, "color:orangered;font-weight:bold;");
		console.log("%cDocumentation: %chttps://mswjs.io/docs", "font-weight:bold", "font-weight:normal");
		console.log("Found an issue? https://github.com/mswjs/msw/issues");
		console.log("Worker script URL:", worker.scriptURL);
		console.log("Worker scope:", registration.scope);
		if (client) console.log("Client ID: %s (%s)", client.id, client.frameType);
		console.groupEnd();
	}
	#printStopMessage() {
		console.log(`%c${devUtils.formatMessage("Mocking disabled.")}`, "color:orangered;font-weight:bold;");
	}
};
var ServiceWorkerHttpNetworkFrame = class extends HttpNetworkFrame {
	#event;
	constructor(options) {
		super({ request: options.request });
		this.#event = options.event;
	}
	passthrough() {
		this.#event.postMessage("PASSTHROUGH", { request: { headers: Array.from(this.data.request.headers) } });
	}
	respondWith(response) {
		if (response) this.#respondWith(response);
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		devUtils.warn(`Uncaught exception in the request handler for "%s %s". This exception has been gracefully handled as a 500 response, however, it's strongly recommended to resolve this error, as it indicates a mistake in your code. If you wish to mock an error response, please see this guide: https://mswjs.io/docs/http/mocking-responses/error-responses`, this.data.request.method, this.data.request.url);
		const error = reason instanceof Error ? reason : new Error(reason?.toString() || "Request failure");
		this.respondWith(HttpResponse.json({
			name: error.name,
			message: error.message,
			stack: error.stack
		}, {
			status: 500,
			statusText: "Request Handler Error"
		}));
	}
	async #respondWith(response) {
		let responseBody;
		let transfer;
		const responseInit = toResponseInit(response);
		if (supportsReadableStreamTransfer()) {
			responseBody = response.body;
			transfer = response.body == null ? void 0 : [response.body];
		} else responseBody = response.body == null ? null : await response.clone().arrayBuffer();
		this.#event.postMessage("MOCK_RESPONSE", {
			...responseInit,
			body: responseBody
		}, transfer);
	}
};
var FallbackHttpSource = class extends InterceptorSource {
	options;
	constructor(options) {
		super({ interceptors: [new XMLHttpRequestInterceptor(), new FetchInterceptor()] });
		this.options = options;
	}
	enable() {
		super.enable();
		if (!this.options.quiet) this.#printStartMessage();
	}
	disable() {
		super.disable();
		if (!this.options.quiet) this.#printStopMessage();
	}
	#printStartMessage() {
		console.groupCollapsed(`%c${devUtils.formatMessage("Mocking enabled (fallback mode).")}`, "color:orangered;font-weight:bold;");
		console.log("%cDocumentation: %chttps://mswjs.io/docs", "font-weight:bold", "font-weight:normal");
		console.log("Found an issue? https://github.com/mswjs/msw/issues");
		console.groupEnd();
	}
	#printStopMessage() {
		console.log(`%c${devUtils.formatMessage("Mocking disabled.")}`, "color:orangered;font-weight:bold;");
	}
};
var DEFAULT_WORKER_URL = "/mockServiceWorker.js";
/**
* Sets up a requests interception in the browser with the given request handlers.
* @param {Array<AnyHandler>} handlers List of request handlers.
*
* @see {@link https://mswjs.io/docs/api/setup-worker `setupWorker()` API reference}
*/
function setupWorker(...handlers) {
	invariant(!isNodeProcess(), devUtils.formatMessage("Failed to execute `setupWorker` in a non-browser environment"));
	const network = defineNetwork({
		sources: [],
		handlers
	});
	return {
		get readyState() {
			return network.readyState;
		},
		async start(options) {
			invariant(network.readyState === 0, devUtils.formatMessage("Failed to call \"worker.start()\": the worker is already started. Remove the redundant \"worker.start()\" call."));
			const httpSource = supportsServiceWorker() ? await ServiceWorkerSource.from({
				serviceWorker: {
					url: options?.serviceWorker?.url?.toString() || DEFAULT_WORKER_URL,
					options: options?.serviceWorker?.options
				},
				findWorker: options?.findWorker,
				quiet: options?.quiet
			}) : new FallbackHttpSource({ quiet: options?.quiet });
			network.configure({
				sources: [httpSource, new InterceptorSource({ interceptors: [new WebSocketInterceptor()] })],
				onUnhandledFrame: options?.onUnhandledFrame ?? "warn",
				context: { quiet: options?.quiet }
			});
			await network.enable();
			if (httpSource instanceof ServiceWorkerSource) {
				const [, registration] = await httpSource.workerPromise;
				return registration;
			}
		},
		async stop() {
			await network.disable();
			window.postMessage({ type: "msw/worker:stop" });
		},
		events: network.events,
		use: network.use.bind(network),
		resetHandlers: network.resetHandlers.bind(network),
		restoreHandlers: network.restoreHandlers.bind(network),
		listHandlers: network.listHandlers.bind(network)
	};
}
function createDefaultNetworkOptions(workerUrl = "/mockServiceWorker.js") {
	return {
		sources: [supportsServiceWorker() ? new ServiceWorkerSource({ serviceWorker: { url: workerUrl } }) : new FallbackHttpSource({}), new InterceptorSource({ interceptors: [new WebSocketInterceptor()] })],
		onUnhandledFrame: "warn"
	};
}
var defaultNetworkOptions = createDefaultNetworkOptions();
//#endregion
export { createDefaultNetworkOptions, defaultNetworkOptions, setupWorker };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXN3X2Jyb3dzZXIuanMiLCJuYW1lcyI6WyJ1bnRpbCIsInVudGlsIiwibG9nZ2VyIiwidW50aWwiLCJpc09iamVjdCJdLCJzb3VyY2VzIjpbIi4uLy4uL3VudGlsLWFzeW5jL2xpYi9pbmRleC5qcyIsIi4uLy4uL21zdy9saWIvX2NodW5rcy9pbnRlcmNlcHRvci1zb3VyY2UuanMiLCIuLi8uLi9Ab3Blbi1kcmFmdC91bnRpbC9saWIvaW5kZXguanMiLCIuLi8uLi9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2hhbmRsZS1yZXF1ZXN0LXk3YWp5dmU1LmpzIiwiLi4vLi4vQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci93ZWItQlJCUTNZUHAuanMiLCIuLi8uLi9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL3dlYi1DQ0xFUlNaRi5qcyIsIi4uLy4uL21zdy9saWIvYnJvd3Nlci9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyNyZWdpb24gc3JjL2luZGV4LnRzXG4vKipcbiogR3JhY2VmdWxseSBoYW5kbGVzIGEgY2FsbGJhY2sgdGhhdCByZXR1cm5zIGEgcHJvbWlzZS5cbipcbiogQGV4YW1wbGVcbiogYXdhaXQgdW50aWwoKCkgPT4gUHJvbWlzZS5yZXNvbHZlKDEyMykpXG4qIC8vIFtudWxsLCAxMjNdXG4qXG4qIGF3YWl0IHVudGlsKCgpID0+IFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignT29wcyEnKSkpXG4qIC8vIFtuZXcgRXJyb3IoJ09vcHMhJyksIG51bGxdXG4qL1xuYXN5bmMgZnVuY3Rpb24gdW50aWwoY2FsbGJhY2spIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gW251bGwsIGF3YWl0IGNhbGxiYWNrKCkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9KV07XG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIFtlcnJvciwgbnVsbF07XG5cdH1cbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1bnRpbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgYyBhcyBpc1N0cmluZ0VxdWFsLCBkIGFzIGdldFJhd1NldENvb2tpZSwgaCBhcyBkZXZVdGlscywgbSBhcyBJbnRlcm5hbEVycm9yLCByIGFzIHRvUHVibGljVXJsLCB0IGFzIGNvb2tpZVN0b3JlIH0gZnJvbSBcIi4vY29va2llLXN0b3JlLmpzXCI7XG5pbXBvcnQgeyBuIGFzIGdldFNpYmxpbmdIYW5kbGVycywgbyBhcyBrQXV0b0Nvbm5lY3QsIHIgYXMgaXNTaWJsaW5nSGFuZGxlciwgcyBhcyBrQ29ubmVjdCB9IGZyb20gXCIuL2F0dGFjaC1zaWJsaW5nLWhhbmRsZXJzLmpzXCI7XG5pbXBvcnQgeyB0IGFzIGV4ZWN1dGVIYW5kbGVycyB9IGZyb20gXCIuL2V4ZWN1dGUtaGFuZGxlcnMuanNcIjtcbmltcG9ydCB7IGlzUGFzc3Rocm91Z2hSZXNwb25zZSB9IGZyb20gXCIuLi91dGlscy9wYXNzdGhyb3VnaC5qc1wiO1xuaW1wb3J0IHsgaXNDb21tb25Bc3NldFJlcXVlc3QgfSBmcm9tIFwiLi4vdXRpbHMvaXMtY29tbW9uLWFzc2V0LXJlcXVlc3QuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5pbXBvcnQgeyBCYXRjaEludGVyY2VwdG9yLCBjcmVhdGVSZXF1ZXN0SWQgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9yc1wiO1xuaW1wb3J0IHsgRW1pdHRlciwgVHlwZWRFdmVudCB9IGZyb20gXCJyZXR0aW1lXCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJ1bnRpbC1hc3luY1wiO1xuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9zb3VyY2VzL25ldHdvcmstc291cmNlLnRzXG52YXIgTmV0d29ya0ZyYW1lRXZlbnQgPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHRmcmFtZTtcblx0Y29uc3RydWN0b3IodHlwZSwgZnJhbWUpIHtcblx0XHRzdXBlciguLi5bdHlwZSwge31dKTtcblx0XHR0aGlzLmZyYW1lID0gZnJhbWU7XG5cdH1cbn07XG52YXIgTmV0d29ya1NvdXJjZSA9IGNsYXNzIHtcblx0ZW1pdHRlcjtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5lbWl0dGVyID0gbmV3IEVtaXR0ZXIoKTtcblx0fVxuXHRhc3luYyBxdWV1ZShmcmFtZSkge1xuXHRcdGF3YWl0IHRoaXMuZW1pdHRlci5lbWl0QXNQcm9taXNlKG5ldyBOZXR3b3JrRnJhbWVFdmVudChcImZyYW1lXCIsIGZyYW1lKSk7XG5cdH1cblx0b24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcblx0XHR0aGlzLmVtaXR0ZXIub24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuXHR9XG5cdGRpc2FibGUoKSB7XG5cdFx0dGhpcy5lbWl0dGVyLnJlbW92ZUFsbExpc3RlbmVycygpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZXhwZXJpbWVudGFsL2hhbmRsZXJzLWNvbnRyb2xsZXIudHNcbmZ1bmN0aW9uIGFkZEhhbmRsZXJUb0dyb3VwKGdyb3Vwcywga2luZCwgaGFuZGxlcikge1xuXHQoZ3JvdXBzW2tpbmRdIHx8PSBbXSkucHVzaChoYW5kbGVyKTtcbn1cbmZ1bmN0aW9uIHByZXBlbmRIYW5kbGVyc1RvR3JvdXAoZ3JvdXBzLCBraW5kLCBvdmVycmlkZXNGb3JLaW5kKSB7XG5cdGNvbnN0IGV4aXN0aW5nRm9yS2luZCA9IGdyb3Vwc1traW5kXTtcblx0Z3JvdXBzW2tpbmRdID0gZXhpc3RpbmdGb3JLaW5kID8gWy4uLm92ZXJyaWRlc0ZvcktpbmQsIC4uLmV4aXN0aW5nRm9yS2luZC5maWx0ZXIoKGV4aXN0aW5nSGFuZGxlcikgPT4ge1xuXHRcdHJldHVybiAhb3ZlcnJpZGVzRm9yS2luZC5pbmNsdWRlcyhleGlzdGluZ0hhbmRsZXIpO1xuXHR9KV0gOiBvdmVycmlkZXNGb3JLaW5kO1xufVxuZnVuY3Rpb24gZ3JvdXBIYW5kbGVyc0J5S2luZChoYW5kbGVycykge1xuXHRjb25zdCBncm91cHMgPSB7fTtcblx0Y29uc3QgdmlzaXRlZEhhbmRsZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3QgdmlzaXQgPSAoaGFuZGxlcikgPT4ge1xuXHRcdGlmICh2aXNpdGVkSGFuZGxlcnMuaGFzKGhhbmRsZXIpKSByZXR1cm47XG5cdFx0dmlzaXRlZEhhbmRsZXJzLmFkZChoYW5kbGVyKTtcblx0XHRhZGRIYW5kbGVyVG9Hcm91cChncm91cHMsIGhhbmRsZXIua2luZCwgaGFuZGxlcik7XG5cdFx0Zm9yIChjb25zdCBzaWJsaW5nIG9mIGdldFNpYmxpbmdIYW5kbGVycyhoYW5kbGVyKSkgdmlzaXQoc2libGluZyk7XG5cdH07XG5cdGZvciAoY29uc3QgaGFuZGxlciBvZiBoYW5kbGVycykgdmlzaXQoaGFuZGxlcik7XG5cdHJldHVybiBncm91cHM7XG59XG52YXIgSGFuZGxlcnNDb250cm9sbGVyID0gY2xhc3Mge1xuXHRnZXRJbml0aWFsU3RhdGUoaW5pdGlhbEhhbmRsZXJzKSB7XG5cdFx0aW52YXJpYW50KHRoaXMuI3ZhbGlkYXRlSGFuZGxlcnMoaW5pdGlhbEhhbmRsZXJzKSwgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIkZhaWxlZCB0byBhcHBseSBnaXZlbiByZXF1ZXN0IGhhbmRsZXJzOiBpbnZhbGlkIGlucHV0LiBEaWQgeW91IGZvcmdldCB0byBzcHJlYWQgdGhlIHJlcXVlc3QgaGFuZGxlcnMgQXJyYXk/XCIpKTtcblx0XHRjb25zdCBub3JtYWxpemVkSW5pdGlhbEhhbmRsZXJzID0gZ3JvdXBIYW5kbGVyc0J5S2luZChpbml0aWFsSGFuZGxlcnMpO1xuXHRcdHJldHVybiB7XG5cdFx0XHRpbml0aWFsSGFuZGxlcnM6IG5vcm1hbGl6ZWRJbml0aWFsSGFuZGxlcnMsXG5cdFx0XHRoYW5kbGVyczogeyAuLi5ub3JtYWxpemVkSW5pdGlhbEhhbmRsZXJzIH1cblx0XHR9O1xuXHR9XG5cdGN1cnJlbnRIYW5kbGVycygpIHtcblx0XHRyZXR1cm4gT2JqZWN0LnZhbHVlcyh0aGlzLmdldFN0YXRlKCkuaGFuZGxlcnMpLmZsYXQoKS5maWx0ZXIoKGhhbmRsZXIpID0+IGhhbmRsZXIgIT0gbnVsbCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJuIHRoZSBsaXN0IG9mIGV4cGxpY2l0bHkgcmVnaXN0ZXJlZCBoYW5kbGVycy5cblx0KiBVbmxpa2UgYGN1cnJlbnRIYW5kbGVycygpYCwgdGhpcyBleGNsdWRlcyBzaWJsaW5nIGhhbmRsZXJzLFxuXHQqIHdoaWNoIGFyZSBhbiBpbXBsZW1lbnRhdGlvbiBkZXRhaWwgKGUuZy4gdGhlIFdlYlNvY2tldCB1cGdyYWRlXG5cdCogaGFuZGxlciBvciB0aGUgR3JhcGhRTCBzdWJzY3JpcHRpb24gdHJhbnNwb3J0KS5cblx0Ki9cblx0bGlzdEhhbmRsZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLmN1cnJlbnRIYW5kbGVycygpLmZpbHRlcigoaGFuZGxlcikgPT4ge1xuXHRcdFx0cmV0dXJuICFpc1NpYmxpbmdIYW5kbGVyKGhhbmRsZXIpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybiB0aGUgbGlzdCBvZiBoYW5kbGVycyBvZiB0aGUgZ2l2ZW4ga2luZC5cblx0Ki9cblx0Z2V0SGFuZGxlcnNCeUtpbmQoa2luZCkge1xuXHRcdHJldHVybiB0aGlzLmdldFN0YXRlKCkuaGFuZGxlcnNba2luZF0gfHwgW107XG5cdH1cblx0dXNlKG5leHRIYW5kbGVycykge1xuXHRcdGludmFyaWFudCh0aGlzLiN2YWxpZGF0ZUhhbmRsZXJzKG5leHRIYW5kbGVycyksIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJbTVNXXSBGYWlsZWQgdG8gY2FsbCBcXFwidXNlKClcXFwiIHdpdGggdGhlIGdpdmVuIHJlcXVlc3QgaGFuZGxlcnM6IGludmFsaWQgaW5wdXQuIERpZCB5b3UgZm9yZ2V0IHRvIHNwcmVhZCB0aGUgYXJyYXkgb2YgcmVxdWVzdCBoYW5kbGVycz9cIikpO1xuXHRcdGlmIChuZXh0SGFuZGxlcnMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cdFx0Y29uc3QgeyBoYW5kbGVycyB9ID0gdGhpcy5nZXRTdGF0ZSgpO1xuXHRcdGNvbnN0IG92ZXJyaWRlcyA9IGdyb3VwSGFuZGxlcnNCeUtpbmQobmV4dEhhbmRsZXJzKTtcblx0XHRpZiAob3ZlcnJpZGVzLnJlcXVlc3QpIHByZXBlbmRIYW5kbGVyc1RvR3JvdXAoaGFuZGxlcnMsIFwicmVxdWVzdFwiLCBvdmVycmlkZXMucmVxdWVzdCk7XG5cdFx0aWYgKG92ZXJyaWRlcy53ZWJzb2NrZXQpIHByZXBlbmRIYW5kbGVyc1RvR3JvdXAoaGFuZGxlcnMsIFwid2Vic29ja2V0XCIsIG92ZXJyaWRlcy53ZWJzb2NrZXQpO1xuXHRcdHRoaXMuc2V0U3RhdGUoeyBoYW5kbGVycyB9KTtcblx0fVxuXHRyZXNldChuZXh0SGFuZGxlcnMpIHtcblx0XHRpbnZhcmlhbnQobmV4dEhhbmRsZXJzLmxlbmd0aCA+IDAgPyB0aGlzLiN2YWxpZGF0ZUhhbmRsZXJzKG5leHRIYW5kbGVycykgOiB0cnVlLCBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiRmFpbGVkIHRvIHJlcGxhY2UgaW5pdGlhbCBoYW5kbGVycyBkdXJpbmcgcmVzZXQ6IGludmFsaWQgaGFuZGxlcnMuIERpZCB5b3UgZm9yZ2V0IHRvIHNwcmVhZCB0aGUgaGFuZGxlcnMgYXJyYXk/XCIpKTtcblx0XHRmb3IgKGNvbnN0IGhhbmRsZXIgb2YgdGhpcy5jdXJyZW50SGFuZGxlcnMoKSkgaGFuZGxlci5yZXNldCgpO1xuXHRcdGNvbnN0IHsgaW5pdGlhbEhhbmRsZXJzIH0gPSB0aGlzLmdldFN0YXRlKCk7XG5cdFx0aWYgKG5leHRIYW5kbGVycy5sZW5ndGggPT09IDApIHtcblx0XHRcdHRoaXMuc2V0U3RhdGUoeyBoYW5kbGVyczogeyAuLi5pbml0aWFsSGFuZGxlcnMgfSB9KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3Qgbm9ybWFsaXplZE5leHRIYW5kbGVycyA9IGdyb3VwSGFuZGxlcnNCeUtpbmQobmV4dEhhbmRsZXJzKTtcblx0XHR0aGlzLnNldFN0YXRlKHtcblx0XHRcdGluaXRpYWxIYW5kbGVyczogbm9ybWFsaXplZE5leHRIYW5kbGVycyxcblx0XHRcdGhhbmRsZXJzOiB7IC4uLm5vcm1hbGl6ZWROZXh0SGFuZGxlcnMgfVxuXHRcdH0pO1xuXHR9XG5cdHJlc3RvcmUoKSB7XG5cdFx0Zm9yIChjb25zdCBoYW5kbGVyIG9mIHRoaXMuY3VycmVudEhhbmRsZXJzKCkpIGhhbmRsZXIucmVzdG9yZSgpO1xuXHR9XG5cdGRpc3Bvc2UoKSB7XG5cdFx0Y29uc3QgcGVuZGluZ0Rpc3Bvc2FscyA9IFtdO1xuXHRcdGZvciAoY29uc3QgaGFuZGxlciBvZiB0aGlzLmN1cnJlbnRIYW5kbGVycygpKSB7XG5cdFx0XHRjb25zdCBkaXNwb3NhbCA9IGhhbmRsZXIuZGlzcG9zZSgpO1xuXHRcdFx0aWYgKGRpc3Bvc2FsIGluc3RhbmNlb2YgUHJvbWlzZSkgcGVuZGluZ0Rpc3Bvc2Fscy5wdXNoKGRpc3Bvc2FsKTtcblx0XHR9XG5cdFx0aWYgKHBlbmRpbmdEaXNwb3NhbHMubGVuZ3RoID4gMCkgcmV0dXJuIFByb21pc2UuYWxsKHBlbmRpbmdEaXNwb3NhbHMpLnRoZW4oKCkgPT4ge30pO1xuXHR9XG5cdCN2YWxpZGF0ZUhhbmRsZXJzKGhhbmRsZXJzKSB7XG5cdFx0cmV0dXJuIGhhbmRsZXJzLmV2ZXJ5KChoYW5kbGVyKSA9PiAhQXJyYXkuaXNBcnJheShoYW5kbGVyKSk7XG5cdH1cbn07XG52YXIgSW5NZW1vcnlIYW5kbGVyc0NvbnRyb2xsZXIgPSBjbGFzcyBleHRlbmRzIEhhbmRsZXJzQ29udHJvbGxlciB7XG5cdCNoYW5kbGVycztcblx0I2luaXRpYWxIYW5kbGVycztcblx0Y29uc3RydWN0b3IoaW5pdGlhbEhhbmRsZXJzKSB7XG5cdFx0c3VwZXIoKTtcblx0XHRjb25zdCBpbml0aWFsU3RhdGUgPSB0aGlzLmdldEluaXRpYWxTdGF0ZShpbml0aWFsSGFuZGxlcnMpO1xuXHRcdHRoaXMuI2luaXRpYWxIYW5kbGVycyA9IGluaXRpYWxTdGF0ZS5pbml0aWFsSGFuZGxlcnM7XG5cdFx0dGhpcy4jaGFuZGxlcnMgPSBpbml0aWFsU3RhdGUuaGFuZGxlcnM7XG5cdH1cblx0Z2V0U3RhdGUoKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGluaXRpYWxIYW5kbGVyczogdGhpcy4jaW5pdGlhbEhhbmRsZXJzLFxuXHRcdFx0aGFuZGxlcnM6IHRoaXMuI2hhbmRsZXJzXG5cdFx0fTtcblx0fVxuXHRzZXRTdGF0ZShuZXh0U3RhdGUpIHtcblx0XHRpZiAobmV4dFN0YXRlLmluaXRpYWxIYW5kbGVycykgdGhpcy4jaW5pdGlhbEhhbmRsZXJzID0gbmV4dFN0YXRlLmluaXRpYWxIYW5kbGVycztcblx0XHRpZiAobmV4dFN0YXRlLmhhbmRsZXJzKSB0aGlzLiNoYW5kbGVycyA9IG5leHRTdGF0ZS5oYW5kbGVycztcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL2ludGVybmFsL3RvLXJlYWRvbmx5LWFycmF5LnRzXG4vKipcbiogQ3JlYXRlcyBhbiBpbW11dGFibGUgY29weSBvZiB0aGUgZ2l2ZW4gYXJyYXkuXG4qL1xuZnVuY3Rpb24gdG9SZWFkb25seUFycmF5KHNvdXJjZSkge1xuXHRjb25zdCBjbG9uZSA9IFsuLi5zb3VyY2VdO1xuXHRPYmplY3QuZnJlZXplKGNsb25lKTtcblx0cmV0dXJuIGNsb25lO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvaW50ZXJuYWwvZGlzcG9zYWJsZS50c1xudmFyIERpc3Bvc2FibGUgPSBjbGFzcyB7XG5cdHN1YnNjcmlwdGlvbnMgPSBbXTtcblx0ZGlzcG9zZSgpIHtcblx0XHRsZXQgc3Vic2NyaXB0aW9uO1xuXHRcdGNvbnN0IGVycm9ycyA9IFtdO1xuXHRcdHdoaWxlIChzdWJzY3JpcHRpb24gPSB0aGlzLnN1YnNjcmlwdGlvbnMuc2hpZnQoKSkgdHJ5IHtcblx0XHRcdHN1YnNjcmlwdGlvbigpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikgZXJyb3JzLnB1c2goZXJyb3IpO1xuXHRcdH1cblx0XHRpZiAoZXJyb3JzLmxlbmd0aCA+IDApIGNvbnNvbGUuZXJyb3IobmV3IEFnZ3JlZ2F0ZUVycm9yKGVycm9ycywgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIkZhaWxlZCB0byBkaXNwb3NlIG9mIHNvbWUgc2lkZSBlZmZlY3RzLiBUaGlzIGlzIGxpa2VseSBhbiBpc3N1ZSB3aXRoIE1TVywgcGxlYXNlIHJlcG9ydCBpdCBvbiBHaXRIdWI6IGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzXCIpKSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9leHBlcmltZW50YWwvZGVmaW5lLW5ldHdvcmsudHNcbmZ1bmN0aW9uIGNvbG9ybGVzc1Byb21pc2VBbGwodmFsdWVzKSB7XG5cdGNvbnN0IHByb21pc2VzID0gW107XG5cdGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVzKSBpZiAodmFsdWUgaW5zdGFuY2VvZiBQcm9taXNlKSBwcm9taXNlcy5wdXNoKHZhbHVlKTtcblx0aWYgKHByb21pc2VzLmxlbmd0aCA+IDApIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbigoKSA9PiB7fSk7XG59XG5sZXQgTmV0d29ya1JlYWR5U3RhdGUgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oTmV0d29ya1JlYWR5U3RhdGUpIHtcblx0TmV0d29ya1JlYWR5U3RhdGVbTmV0d29ya1JlYWR5U3RhdGVbXCJESVNBQkxFRFwiXSA9IDBdID0gXCJESVNBQkxFRFwiO1xuXHROZXR3b3JrUmVhZHlTdGF0ZVtOZXR3b3JrUmVhZHlTdGF0ZVtcIkVOQUJMRURcIl0gPSAxXSA9IFwiRU5BQkxFRFwiO1xuXHRyZXR1cm4gTmV0d29ya1JlYWR5U3RhdGU7XG59KHt9KTtcbi8qKlxuKiBEZWZpbmUgYSBuZXR3b3JrIGluc3RhbmNlIHdpdGggdGhlIGdpdmVuIGNvbmZpZ3VyYXRpb24uXG4qIEBleGFtcGxlXG4qIGltcG9ydCB7IEludGVyY2VwdG9yU291cmNlIH0gZnJvbSAnbXN3L2V4cGVyaW1lbnRhbCdcbiogaW1wb3J0IHsgaGFuZGxlcnMgfSBmcm9tICcuL2hhbmRsZXJzJ1xuKlxuKiBjb25zdCBuZXR3b3JrID0gZGVmaW5lTmV0d29yayh7XG4qICAgc291cmNlczogW25ldyBJbnRlcmNlcHRvclNvdXJjZSh7IGludGVyY2VwdG9ycyB9KV0sXG4qICAgaGFuZGxlcnMsXG4qIH0pXG4qIGF3YWl0IG5ldHdvcmsuZW5hYmxlKClcbiovXG5mdW5jdGlvbiBkZWZpbmVOZXR3b3JrKG9wdGlvbnMpIHtcblx0bGV0IHJlYWR5U3RhdGUgPSAwO1xuXHRjb25zdCBldmVudHMgPSBuZXcgRW1pdHRlcigpO1xuXHRjb25zdCBkaXNwb3NhYmxlID0gbmV3IERpc3Bvc2FibGUoKTtcblx0Y29uc3QgZGVyaXZlSGFuZGxlcnNDb250cm9sbGVyID0gKGhhbmRsZXJzKSA9PiB7XG5cdFx0cmV0dXJuIGhhbmRsZXJzIGluc3RhbmNlb2YgSGFuZGxlcnNDb250cm9sbGVyID8gaGFuZGxlcnMgOiBuZXcgSW5NZW1vcnlIYW5kbGVyc0NvbnRyb2xsZXIoaGFuZGxlcnMgfHwgW10pO1xuXHR9O1xuXHRsZXQgcmVzb2x2ZWRPcHRpb25zID0geyAuLi5vcHRpb25zIH07XG5cdC8qKlxuXHQqIEBub3RlIENyZWF0ZSB0aGUgaGFuZGxlcnMgY29udHJvbGxlciBpbW1lZGlhdGVseSBiZWNhdXNlXG5cdCogY2VydGFpbiBzZXR1cCBBUElzLCBsaWtlIGBzZXR1cFNlcnZlcmAsIGRvbid0IGF3YWl0IGAuZW5hYmxlYCAoYC5saXN0ZW5gKS5cblx0Ki9cblx0bGV0IGhhbmRsZXJzQ29udHJvbGxlciA9IGRlcml2ZUhhbmRsZXJzQ29udHJvbGxlcihyZXNvbHZlZE9wdGlvbnMuaGFuZGxlcnMpO1xuXHRyZXR1cm4ge1xuXHRcdGdldCByZWFkeVN0YXRlKCkge1xuXHRcdFx0cmV0dXJuIHJlYWR5U3RhdGU7XG5cdFx0fSxcblx0XHRldmVudHMsXG5cdFx0Y29uZmlndXJlKG9wdGlvbnMpIHtcblx0XHRcdGludmFyaWFudChyZWFkeVN0YXRlID09PSAwLCBcIkZhaWxlZCB0byBjYWxsIFxcXCJjb25maWd1cmUoKVxcXCIgb24gdGhlIG5ldHdvcms6IGNhbm5vdCBjb25maWd1cmUgYW4gYWxyZWFkeSBlbmFibGVkIG5ldHdvcmsuXCIpO1xuXHRcdFx0aWYgKG9wdGlvbnMuaGFuZGxlcnMgJiYgIU9iamVjdC5pcyhvcHRpb25zLmhhbmRsZXJzLCByZXNvbHZlZE9wdGlvbnMuaGFuZGxlcnMpKSBoYW5kbGVyc0NvbnRyb2xsZXIgPSBkZXJpdmVIYW5kbGVyc0NvbnRyb2xsZXIob3B0aW9ucy5oYW5kbGVycyk7XG5cdFx0XHRyZXNvbHZlZE9wdGlvbnMgPSB7XG5cdFx0XHRcdC4uLnJlc29sdmVkT3B0aW9ucyxcblx0XHRcdFx0Li4ub3B0aW9uc1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdGVuYWJsZSgpIHtcblx0XHRcdGludmFyaWFudChyZWFkeVN0YXRlID09PSAwLCBcIkZhaWxlZCB0byBjYWxsIFxcXCJlbmFibGVcXFwiIG9uIHRoZSBuZXR3b3JrOiBhbHJlYWR5IGVuYWJsZWRcIik7XG5cdFx0XHRyZWFkeVN0YXRlID0gMTtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBVc2UgYSBzZXNzaW9uIG9iamVjdCBzY29wZWQgdG8gdGhlIGN1cnJlbnQgXCJlbmFibGUoKVwiXG5cdFx0XHQqIHRvIHByZXZlbnQgXCJmcmFtZS5ldmVudHNcIiBsaXN0ZW5lcnMgZnJvbSBzdXJ2aXZpbmcgYWNyb3NzIGVuYWJsZS9kaXNhYmxlIGN5Y2xlcy5cblx0XHRcdCogQHNlZSBUaGUgbm90ZSBhYm91dCBgQWJvcnRDb250cm9sbGVyYCBiZWxvdy5cblx0XHRcdCovXG5cdFx0XHRjb25zdCBzZXNzaW9uID0geyBhY3RpdmU6IHRydWUgfTtcblx0XHRcdGRpc3Bvc2FibGVbXCJzdWJzY3JpcHRpb25zXCJdLnB1c2goKCkgPT4ge1xuXHRcdFx0XHRzZXNzaW9uLmFjdGl2ZSA9IGZhbHNlO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gY29sb3JsZXNzUHJvbWlzZUFsbChyZXNvbHZlZE9wdGlvbnMuc291cmNlcy5tYXAoKHNvdXJjZSkgPT4ge1xuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBQcmVlbXB0aXZlbHkgZGlzYWJsZSB0aGUgbmV0d29yayBzb3VyY2UgYmVmb3JlIGVuYWJsaW5nLlxuXHRcdFx0XHQqIFRoaXMgaW50ZW50aW9uYWxseSBjYWxscyBvbmx5IHRoZSBwcm90b3R5cGUgbWV0aG9kIHRoYXQgY2xlYXJzIHRoZVxuXHRcdFx0XHQqIGV2ZW50IGxpc3RlbmVycyBhbmQgbm90aGluZyBlbHNlLiBUaGlzIHByZXZlbnRzIHRoZSBcImZyYW1lXCIgbGlzdGVuZXJzXG5cdFx0XHRcdCogZnJvbSBhY2N1bXVsYXRpbmcgYWNyb3NzIGVuYWJsZS9kaXNhYmxlIGluIGNhc2UgdGhlIHNvdXJjZSBpcyBhIHNpbmdsZXRvbi5cblx0XHRcdFx0Ki9cblx0XHRcdFx0TmV0d29ya1NvdXJjZS5wcm90b3R5cGUuZGlzYWJsZS5jYWxsKHNvdXJjZSk7XG5cdFx0XHRcdHNvdXJjZS5vbihcImZyYW1lXCIsIGFzeW5jICh7IGZyYW1lIH0pID0+IHtcblx0XHRcdFx0XHRmcmFtZS5ldmVudHMub24oXCIqXCIsIChldmVudCkgPT4ge1xuXHRcdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0XHQqIEBub3RlIFByZXZlbnQgZXZlbnQgZm9yd2FyZGluZyBtYW51YWxseSBhbmQgbm90IHZpYSBhbiBBYm9ydENvbnRyb2xsZXJcblx0XHRcdFx0XHRcdCogYmVjYXVzZSBjZXJ0YWluIHJ1bnRpbWVzLCBsaWtlIENsb3VkZmxhcmUsIHRocm93IHdoZW4gcmVmZXJlbmNpbmcgYW5cblx0XHRcdFx0XHRcdCogQWJvcnRDb250cm9sbGVyIGNyZWF0ZWQgaW4gYSBkaWZmZXJlbnQgY29udGV4dC4gQmVhciBpbiBtaW5kIHRoYXQgdGhlIGZyYW1lXG5cdFx0XHRcdFx0XHQqIGV2ZW50cyBydW4gaW4gdGhlIHBhdGNoZWQgcmVxdWVzdCBjbGllbnQgY29udGV4dCB3aGlsZSB0aGUgQWJvcnRDb250cm9sbGVyXG5cdFx0XHRcdFx0XHQqIGlzIGNyZWF0ZWQgb3V0c2lkZSwgaW4gdGhlIFwiZGVmaW5lTmV0d29ya1wiIGNsb3N1cmUsIHdoaWNoIGlzIGEgdGVzdCBjb250ZXh0LlxuXHRcdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRcdGlmICghc2Vzc2lvbi5hY3RpdmUpIHJldHVybjtcblx0XHRcdFx0XHRcdGV2ZW50cy5lbWl0KGV2ZW50KTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb25zdCBoYW5kbGVycyA9IGZyYW1lLmdldEhhbmRsZXJzKGhhbmRsZXJzQ29udHJvbGxlcik7XG5cdFx0XHRcdFx0YXdhaXQgZnJhbWUucmVzb2x2ZShoYW5kbGVycywgcmVzb2x2ZWRPcHRpb25zLm9uVW5oYW5kbGVkRnJhbWUgfHwgXCJ3YXJuXCIsIHJlc29sdmVkT3B0aW9ucy5jb250ZXh0KTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHJldHVybiBzb3VyY2UuZW5hYmxlKCk7XG5cdFx0XHR9KSk7XG5cdFx0fSxcblx0XHRkaXNhYmxlKCkge1xuXHRcdFx0aW52YXJpYW50KHJlYWR5U3RhdGUgPT09IDEsIFwiRmFpbGVkIHRvIGNhbGwgXFxcImRpc2FibGVcXFwiIG9uIHRoZSBuZXR3b3JrOiBhbHJlYWR5IGRpc2FibGVkXCIpO1xuXHRcdFx0cmVhZHlTdGF0ZSA9IDA7XG5cdFx0XHRjb25zdCBoYW5kbGVyc0Rpc3Bvc2FsID0gaGFuZGxlcnNDb250cm9sbGVyLmRpc3Bvc2UoKTtcblx0XHRcdGRpc3Bvc2FibGUuZGlzcG9zZSgpO1xuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIFRlYXIgZG93biB0aGUgc291cmNlcyBzeW5jaHJvbm91c2x5LCBuZXZlciBiZWhpbmQgdGhlXG5cdFx0XHQqIGhhbmRsZXJzIGRpc3Bvc2FsLiBgZGlzYWJsZSgpYCBpcyBub3QgYWx3YXlzIGF3YWl0ZWQgKGUuZy5cblx0XHRcdCogYHNlcnZlci5jbG9zZSgpYCBpcyBzeW5jaHJvbm91cyksIGFuZCBhIGRlZmVycmVkIHRlYXJkb3duIHdvdWxkXG5cdFx0XHQqIHJhY2UgYW55IGBlbmFibGUoKWAgdGhhdCBmb2xsb3dzLCBkaXNhYmxpbmcgdGhlIHNvdXJjZXMgdGhhdCB0aGVcblx0XHRcdCogbmV3IHNlc3Npb24gaGFzIGp1c3QgZW5hYmxlZC5cblx0XHRcdCovXG5cdFx0XHRjb25zdCBzb3VyY2VzRGlzcG9zYWwgPSBjb2xvcmxlc3NQcm9taXNlQWxsKHJlc29sdmVkT3B0aW9ucy5zb3VyY2VzLm1hcCgoc291cmNlKSA9PiBzb3VyY2UuZGlzYWJsZSgpKSk7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgQXdhaXQgYm90aCBkaXNwb3NhbHMgc28gbmVpdGhlciByZWplY3Rpb24gZ29lcyB1bm9ic2VydmVkLlxuXHRcdFx0KiBDaGFpbmluZyB0aGVtIHdvdWxkIGxlYXZlIHRoZSBzb3VyY2UgZGlzcG9zYWwgZmxvYXRpbmcgd2hlbmV2ZXJcblx0XHRcdCogdGhlIGhhbmRsZXJzIGRpc3Bvc2FsIHJlamVjdHMuXG5cdFx0XHQqL1xuXHRcdFx0cmV0dXJuIGhhbmRsZXJzRGlzcG9zYWwgaW5zdGFuY2VvZiBQcm9taXNlID8gUHJvbWlzZS5hbGwoW2hhbmRsZXJzRGlzcG9zYWwsIHNvdXJjZXNEaXNwb3NhbF0pLnRoZW4oKCkgPT4ge30pIDogc291cmNlc0Rpc3Bvc2FsO1xuXHRcdH0sXG5cdFx0dXNlKC4uLmhhbmRsZXJzKSB7XG5cdFx0XHRoYW5kbGVyc0NvbnRyb2xsZXIudXNlKGhhbmRsZXJzKTtcblx0XHR9LFxuXHRcdHJlc2V0SGFuZGxlcnMoLi4uaGFuZGxlcnMpIHtcblx0XHRcdGhhbmRsZXJzQ29udHJvbGxlci5yZXNldChoYW5kbGVycyk7XG5cdFx0fSxcblx0XHRyZXN0b3JlSGFuZGxlcnMoKSB7XG5cdFx0XHRoYW5kbGVyc0NvbnRyb2xsZXIucmVzdG9yZSgpO1xuXHRcdH0sXG5cdFx0bGlzdEhhbmRsZXJzKCkge1xuXHRcdFx0cmV0dXJuIHRvUmVhZG9ubHlBcnJheShoYW5kbGVyc0NvbnRyb2xsZXIubGlzdEhhbmRsZXJzKCkpO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9mcmFtZXMvbmV0d29yay1mcmFtZS50c1xuLyoqXG4qIFRoZSBiYXNlIGZvciB0aGUgbmV0d29yayBmcmFtZXMuIEV4dGVuZCB0aGlzIGFic3RyYWN0IGNsYXNzXG4qIHRvIGltcGxlbWVudCBjdXN0b20gbmV0d29yayBmcmFtZXMuXG4qL1xudmFyIE5ldHdvcmtGcmFtZSA9IGNsYXNzIHtcblx0cHJvdG9jb2w7XG5cdGRhdGE7XG5cdGV2ZW50cztcblx0Y29uc3RydWN0b3IocHJvdG9jb2wsIGRhdGEpIHtcblx0XHR0aGlzLnByb3RvY29sID0gcHJvdG9jb2w7XG5cdFx0dGhpcy5kYXRhID0gZGF0YTtcblx0XHR0aGlzLmV2ZW50cyA9IG5ldyBFbWl0dGVyKCk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS91dGlscy9yZXF1ZXN0L3N0b3JlLXJlc3BvbnNlLWNvb2tpZXMudHNcbmFzeW5jIGZ1bmN0aW9uIHN0b3JlUmVzcG9uc2VDb29raWVzKHJlcXVlc3QsIHJlc3BvbnNlKSB7XG5cdGlmIChjb29raWVTdG9yZSA9PT0gbnVsbCkgcmV0dXJuO1xuXHRmb3IgKGNvbnN0IHJlc3BvbnNlQ29va2llIG9mIGdldFJhd1NldENvb2tpZShyZXNwb25zZSkpIGF3YWl0IGNvb2tpZVN0b3JlLnNldENvb2tpZShyZXNwb25zZUNvb2tpZSwgcmVxdWVzdC51cmwpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZXhwZXJpbWVudGFsL3JlcXVlc3QtdXRpbHMudHNcbmZ1bmN0aW9uIHNob3VsZEJ5cGFzc1JlcXVlc3QocmVxdWVzdCkge1xuXHRyZXR1cm4gISFyZXF1ZXN0LmhlYWRlcnMuZ2V0KFwiYWNjZXB0XCIpPy5pbmNsdWRlcyhcIm1zdy9wYXNzdGhyb3VnaFwiKTtcbn1cbi8qKlxuKiBSZW1vdmUgdGhlIGludGVybmFsIHBhc3N0aHJvdWdoIGluc3RydWN0aW9uIGZyb20gdGhlIHJlcXVlc3QncyBgQWNjZXB0YCBoZWFkZXIuXG4qL1xuZnVuY3Rpb24gZGVsZXRlUmVxdWVzdFBhc3N0aHJvdWdoSGVhZGVyKHJlcXVlc3QpIHtcblx0Y29uc3QgYWNjZXB0SGVhZGVyID0gcmVxdWVzdC5oZWFkZXJzLmdldChcImFjY2VwdFwiKTtcblx0LyoqXG5cdCogQG5vdGUgUmVtb3ZlIHRoZSBpbnRlcm5hbCBieXBhc3MgcmVxdWVzdCBoZWFkZXIuXG5cdCogSW4gdGhlIGJyb3dzZXIsIHRoaXMgaXMgZG9uZSBieSB0aGUgd29ya2VyIHNjcmlwdC5cblx0KiBJbiBOb2RlLmpzLCBpdCBoYXMgdG8gYmUgZG9uZSBoZXJlLlxuXHQqL1xuXHRpZiAoYWNjZXB0SGVhZGVyKSB7XG5cdFx0Y29uc3QgbmV4dEFjY2VwdEhlYWRlciA9IGFjY2VwdEhlYWRlci5yZXBsYWNlKC8oLFxccyspP21zd1xcL3Bhc3N0aHJvdWdoLywgXCJcIik7XG5cdFx0aWYgKG5leHRBY2NlcHRIZWFkZXIpIHJlcXVlc3QuaGVhZGVycy5zZXQoXCJhY2NlcHRcIiwgbmV4dEFjY2VwdEhlYWRlcik7XG5cdFx0ZWxzZSByZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwiYWNjZXB0XCIpO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9leHBlcmltZW50YWwvb24tdW5oYW5kbGVkLWZyYW1lLnRzXG5hc3luYyBmdW5jdGlvbiBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGUoZnJhbWUsIGhhbmRsZSkge1xuXHRjb25zdCBwcmludFN0cmF0ZWd5TWVzc2FnZSA9IGFzeW5jIChzdHJhdGVneSkgPT4ge1xuXHRcdGlmIChzdHJhdGVneSA9PT0gXCJieXBhc3NcIikgcmV0dXJuO1xuXHRcdGNvbnN0IG1lc3NhZ2UgPSBhd2FpdCBmcmFtZS5nZXRVbmhhbmRsZWRNZXNzYWdlKCk7XG5cdFx0c3dpdGNoIChzdHJhdGVneSkge1xuXHRcdFx0Y2FzZSBcIndhcm5cIjogcmV0dXJuIGRldlV0aWxzLndhcm4oXCJXYXJuaW5nOiAlc1wiLCBtZXNzYWdlKTtcblx0XHRcdGNhc2UgXCJlcnJvclwiOiByZXR1cm4gZGV2VXRpbHMuZXJyb3IoXCJFcnJvcjogJXNcIiwgbWVzc2FnZSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBhcHBseVN0cmF0ZWd5ID0gYXN5bmMgKHN0cmF0ZWd5KSA9PiB7XG5cdFx0aW52YXJpYW50LmFzKEludGVybmFsRXJyb3IsIHN0cmF0ZWd5ID09PSBcImJ5cGFzc1wiIHx8IHN0cmF0ZWd5ID09PSBcIndhcm5cIiB8fCBzdHJhdGVneSA9PT0gXCJlcnJvclwiLCBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiRmFpbGVkIHRvIHJlYWN0IHRvIGFuIHVuaGFuZGxlZCBuZXR3b3JrIGZyYW1lOiB1bmtub3duIHN0cmF0ZWd5IFxcXCIlc1xcXCIuIFBsZWFzZSBwcm92aWRlIG9uZSBvZiB0aGUgc3VwcG9ydGVkIHN0cmF0ZWdpZXMgKFxcXCJieXBhc3NcXFwiLCBcXFwid2FyblxcXCIsIFxcXCJlcnJvclxcXCIpIG9yIGEgY3VzdG9tIGNhbGxiYWNrIGZ1bmN0aW9uIGFzIHRoZSB2YWx1ZSBvZiB0aGUgXFxcIm9uVW5oYW5kbGVkRnJhbWVcXFwiIG9wdGlvbi5cIiwgc3RyYXRlZ3kpKTtcblx0XHRpZiAoc3RyYXRlZ3kgPT09IFwiYnlwYXNzXCIpIHJldHVybjtcblx0XHRhd2FpdCBwcmludFN0cmF0ZWd5TWVzc2FnZShzdHJhdGVneSk7XG5cdFx0aWYgKHN0cmF0ZWd5ID09PSBcImVycm9yXCIpIHJldHVybiBQcm9taXNlLnJlamVjdChuZXcgSW50ZXJuYWxFcnJvcihkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiQ2Fubm90IGJ5cGFzcyBhIHJlcXVlc3Qgd2hlbiB1c2luZyB0aGUgXFxcImVycm9yXFxcIiBzdHJhdGVneSBmb3IgdGhlIFxcXCJvblVuaGFuZGxlZEZyYW1lXFxcIiBvcHRpb24uXCIpKSk7XG5cdH07XG5cdGlmICh0eXBlb2YgaGFuZGxlID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBoYW5kbGUoe1xuXHRcdGZyYW1lLFxuXHRcdGRlZmF1bHRzOiB7XG5cdFx0XHR3YXJuOiBwcmludFN0cmF0ZWd5TWVzc2FnZS5iaW5kKG51bGwsIFwid2FyblwiKSxcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBUaGUgZGVmYXVsdHMgb25seSBwcmludCB0aGUgY29ycmVzcG9uZGluZyBtZXNzYWdlcyBub3cuXG5cdFx0XHQqIFRoZXkgZG8gbm90IGFmZmVjdCB0aGUgZnJhbWUgcmVzb2x1dGlvbiAoZS5nLiBkbyBub3QgZXJyb3IgdGhlIGZyYW1lKS5cblx0XHRcdCogVGhhdCBpcyBvbmx5IGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5IHJlYXNvbnMuIEluIHRoZSBmdXR1cmUsIHRoZXNlIHNob3VsZFxuXHRcdFx0KiBiZSBhbiBhbGlhcyB0byBgYXBwbHlTdHJhdGVneS5iaW5kKG51bGwsICdlcnJvcicpYCBpbnN0ZWFkLlxuXHRcdFx0Ki9cblx0XHRcdGVycm9yOiBwcmludFN0cmF0ZWd5TWVzc2FnZS5iaW5kKG51bGwsIFwiZXJyb3JcIilcblx0XHR9XG5cdH0pO1xuXHQvKipcblx0KiBJZ25vcmUgdW5oYW5kbGVkIGNvbW1vbiBIVFRQIGFzc2V0cy5cblx0KiBAbm90ZSBDYWxsaW5nIHRoaXMgaGVyZSBhcHBsaWVzIHRoZSBjb21tb24gYXNzZXRzIGNoZWNrXG5cdCogb25seSB0byB0aGUgc2NlbmFyaW9zIHdoZW4gYG9uVW5oYW5kbGVkRnJhbWVgIHdhcyBzZXQgdG8gYSBwcmVkZWZpbmVkIHN0cmF0ZWd5LlxuXHQqIFdoZW4gdXNpbmcgYSBjdXN0b20gZnVuY3Rpb24sIHlvdSBuZWVkIHRvIGNoZWNrIGZvciBjb21tb24gYXNzZXRzIG1hbnVhbGx5LlxuXHQqL1xuXHRpZiAoZnJhbWUgaW5zdGFuY2VvZiBIdHRwTmV0d29ya0ZyYW1lICYmIGlzQ29tbW9uQXNzZXRSZXF1ZXN0KGZyYW1lLmRhdGEucmVxdWVzdCkpIHJldHVybjtcblx0cmV0dXJuIGFwcGx5U3RyYXRlZ3koaGFuZGxlKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9mcmFtZXMvaHR0cC1mcmFtZS50c1xudmFyIFJlcXVlc3RFdmVudCA9IGNsYXNzIGV4dGVuZHMgVHlwZWRFdmVudCB7XG5cdHJlcXVlc3RJZDtcblx0cmVxdWVzdDtcblx0Y29uc3RydWN0b3IodHlwZSwgZGF0YSkge1xuXHRcdHN1cGVyKC4uLlt0eXBlLCB7fV0pO1xuXHRcdHRoaXMucmVxdWVzdElkID0gZGF0YS5yZXF1ZXN0SWQ7XG5cdFx0dGhpcy5yZXF1ZXN0ID0gZGF0YS5yZXF1ZXN0O1xuXHR9XG59O1xudmFyIFJlc3BvbnNlRXZlbnQgPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHRyZXF1ZXN0SWQ7XG5cdHJlcXVlc3Q7XG5cdHJlc3BvbnNlO1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBkYXRhKSB7XG5cdFx0c3VwZXIoLi4uW3R5cGUsIHt9XSk7XG5cdFx0dGhpcy5yZXF1ZXN0SWQgPSBkYXRhLnJlcXVlc3RJZDtcblx0XHR0aGlzLnJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG5cdFx0dGhpcy5yZXNwb25zZSA9IGRhdGEucmVzcG9uc2U7XG5cdH1cbn07XG52YXIgVW5oYW5kbGVkRXhjZXB0aW9uRXZlbnQgPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHRlcnJvcjtcblx0cmVxdWVzdElkO1xuXHRyZXF1ZXN0O1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBkYXRhKSB7XG5cdFx0c3VwZXIoLi4uW3R5cGUsIHt9XSk7XG5cdFx0dGhpcy5lcnJvciA9IGRhdGEuZXJyb3I7XG5cdFx0dGhpcy5yZXF1ZXN0SWQgPSBkYXRhLnJlcXVlc3RJZDtcblx0XHR0aGlzLnJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG5cdH1cbn07XG52YXIgSHR0cE5ldHdvcmtGcmFtZSA9IGNsYXNzIGV4dGVuZHMgTmV0d29ya0ZyYW1lIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdGNvbnN0IGlkID0gb3B0aW9ucy5pZCB8fCBjcmVhdGVSZXF1ZXN0SWQoKTtcblx0XHRzdXBlcihcImh0dHBcIiwge1xuXHRcdFx0aWQsXG5cdFx0XHRyZXF1ZXN0OiBvcHRpb25zLnJlcXVlc3Rcblx0XHR9KTtcblx0fVxuXHRnZXRIYW5kbGVycyhjb250cm9sbGVyKSB7XG5cdFx0cmV0dXJuIGNvbnRyb2xsZXIuZ2V0SGFuZGxlcnNCeUtpbmQoXCJyZXF1ZXN0XCIpO1xuXHR9XG5cdGFzeW5jIGdldFVuaGFuZGxlZE1lc3NhZ2UoKSB7XG5cdFx0Y29uc3QgeyByZXF1ZXN0IH0gPSB0aGlzLmRhdGE7XG5cdFx0Y29uc3QgdXJsID0gbmV3IFVSTChyZXF1ZXN0LnVybCk7XG5cdFx0Y29uc3QgcHVibGljVXJsID0gdG9QdWJsaWNVcmwodXJsKSArIHVybC5zZWFyY2g7XG5cdFx0Y29uc3QgcmVxdWVzdEJvZHkgPSByZXF1ZXN0LmJvZHkgPT0gbnVsbCA/IG51bGwgOiBhd2FpdCByZXF1ZXN0LmNsb25lKCkudGV4dCgpO1xuXHRcdHJldHVybiBgaW50ZXJjZXB0ZWQgYSByZXF1ZXN0IHdpdGhvdXQgYSBtYXRjaGluZyByZXF1ZXN0IGhhbmRsZXI6JHtgXFxuXFxuICBcXHUyMDIyICR7cmVxdWVzdC5tZXRob2R9ICR7cHVibGljVXJsfVxcblxcbiR7cmVxdWVzdEJvZHkgPyBgICBcXHUyMDIyIFJlcXVlc3QgYm9keTogJHtyZXF1ZXN0Qm9keX1cXG5cXG5gIDogXCJcIn1gfUlmIHlvdSBzdGlsbCB3aXNoIHRvIGludGVyY2VwdCB0aGlzIHVuaGFuZGxlZCByZXF1ZXN0LCBwbGVhc2UgY3JlYXRlIGEgcmVxdWVzdCBoYW5kbGVyIGZvciBpdC5cXG5SZWFkIG1vcmU6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9odHRwL2ludGVyY2VwdGluZy1yZXF1ZXN0c2A7XG5cdH1cblx0YXN5bmMgcmVzb2x2ZShoYW5kbGVycywgb25VbmhhbmRsZWRGcmFtZSwgcmVzb2x1dGlvbkNvbnRleHQpIHtcblx0XHRjb25zdCB7IGlkOiByZXF1ZXN0SWQsIHJlcXVlc3QgfSA9IHRoaXMuZGF0YTtcblx0XHRjb25zdCByZXF1ZXN0Q2xvbmVGb3JMb2dzID0gcmVzb2x1dGlvbkNvbnRleHQ/LnF1aWV0ID8gbnVsbCA6IHJlcXVlc3QuY2xvbmUoKTtcblx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0OnN0YXJ0XCIsIHtcblx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdHJlcXVlc3Rcblx0XHR9KSk7XG5cdFx0aWYgKHNob3VsZEJ5cGFzc1JlcXVlc3QocmVxdWVzdCkpIHtcblx0XHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRyZXF1ZXN0XG5cdFx0XHR9KSk7XG5cdFx0XHR0aGlzLnBhc3N0aHJvdWdoKCk7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdFx0Y29uc3QgW2xvb2t1cEVycm9yLCBsb29rdXBSZXN1bHRdID0gYXdhaXQgdW50aWwoKCkgPT4ge1xuXHRcdFx0cmV0dXJuIGV4ZWN1dGVIYW5kbGVycyh7XG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0aGFuZGxlcnMsXG5cdFx0XHRcdHJlc29sdXRpb25Db250ZXh0OiB7XG5cdFx0XHRcdFx0YmFzZVVybDogcmVzb2x1dGlvbkNvbnRleHQ/LmJhc2VVcmw/LnRvU3RyaW5nKCksXG5cdFx0XHRcdFx0cXVpZXQ6IHJlc29sdXRpb25Db250ZXh0Py5xdWlldFxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRpZiAobG9va3VwRXJyb3IgIT0gbnVsbCkge1xuXHRcdFx0aWYgKCF0aGlzLmV2ZW50cy5lbWl0KG5ldyBVbmhhbmRsZWRFeGNlcHRpb25FdmVudChcInVuaGFuZGxlZEV4Y2VwdGlvblwiLCB7XG5cdFx0XHRcdGVycm9yOiBsb29rdXBFcnJvcixcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRyZXF1ZXN0XG5cdFx0XHR9KSkpIHtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihsb29rdXBFcnJvcik7XG5cdFx0XHRcdGRldlV0aWxzLmVycm9yKFwiRW5jb3VudGVyZWQgYW4gdW5oYW5kbGVkIGV4Y2VwdGlvbiBkdXJpbmcgdGhlIGhhbmRsZXIgbG9va3VwIGZvciBcXFwiJXMgJXNcXFwiLiBQbGVhc2Ugc2VlIHRoZSBvcmlnaW5hbCBlcnJvciBhYm92ZS5cIiwgcmVxdWVzdC5tZXRob2QsIHJlcXVlc3QudXJsKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuZXJyb3JXaXRoKGxvb2t1cEVycm9yKTtcblx0XHRcdHJldHVybiBudWxsO1xuXHRcdH1cblx0XHRpZiAobG9va3VwUmVzdWx0ID09IG51bGwpIHtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBVbmhhbmRsZWQgQ09OTkVDVCByZXF1ZXN0cyBlc3RhYmxpc2ggYSB0dW5uZWwgdGhyb3VnaCBhIHByb3h5LlxuXHRcdFx0KiBUaGV5IGFyZSB0cmFuc3BvcnQsIG5vdCB0aGUgcmVxdWVzdCB0aGUgZGV2ZWxvcGVyIGNhcmVzIGFib3V0LCBzb1xuXHRcdFx0KiB0aGV5IHBhc3MgdGhyb3VnaCBzaWxlbnRseSByZWdhcmRsZXNzIG9mIHRoZSB1bmhhbmRsZWQgZnJhbWUgc3RyYXRlZ3kuXG5cdFx0XHQqIFRoZSByZXF1ZXN0IHNlbnQgdGhyb3VnaCB0aGUgdHVubmVsIGdldHMgaXRzIG93biByZXNvbHV0aW9uLlxuXHRcdFx0Ki9cblx0XHRcdGlmIChpc1N0cmluZ0VxdWFsKHJlcXVlc3QubWV0aG9kLCBcIkNPTk5FQ1RcIikpIHtcblx0XHRcdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDplbmRcIiwge1xuXHRcdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0XHRyZXF1ZXN0XG5cdFx0XHRcdH0pKTtcblx0XHRcdFx0dGhpcy5wYXNzdGhyb3VnaCgpO1xuXHRcdFx0XHRyZXR1cm4gbnVsbDtcblx0XHRcdH1cblx0XHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6dW5oYW5kbGVkXCIsIHtcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRyZXF1ZXN0XG5cdFx0XHR9KSk7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgVGhlIHVuaGFuZGxlZCBmcmFtZSBoYW5kbGUgbXVzdCBiZSBleGVjdXRlZCBkdXJpbmcgdGhlIHJlcXVlc3QgcmVzb2x1dGlvblxuXHRcdFx0KiBzaW5jZSBpdCBjYW4gaW5mbHVlbmNlIGl0IChlLmcuIGVycm9yIHRoZSByZXF1ZXN0IGlmIHRoZSBcImVycm9yXCIgc3RhcnRlZ3kgd2FzIHVzZWQpLlxuXHRcdFx0Ki9cblx0XHRcdGF3YWl0IGV4ZWN1dGVVbmhhbmRsZWRGcmFtZUhhbmRsZSh0aGlzLCBvblVuaGFuZGxlZEZyYW1lKS50aGVuKCgpID0+IHRoaXMucGFzc3Rocm91Z2goKSwgKGVycm9yKSA9PiB0aGlzLmVycm9yV2l0aChlcnJvcikpO1xuXHRcdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDplbmRcIiwge1xuXHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdHJlcXVlc3Rcblx0XHRcdH0pKTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0Y29uc3QgeyByZXNwb25zZSwgaGFuZGxlciwgcGFyc2VkUmVzdWx0IH0gPSBsb29rdXBSZXN1bHQ7XG5cdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDptYXRjaFwiLCB7XG5cdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRyZXF1ZXN0XG5cdFx0fSkpO1xuXHRcdGlmIChyZXNwb25zZSA9PSBudWxsKSB7XG5cdFx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0OmVuZFwiLCB7XG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0cmVxdWVzdFxuXHRcdFx0fSkpO1xuXHRcdFx0dGhpcy5wYXNzdGhyb3VnaCgpO1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHRcdGlmIChpc1Bhc3N0aHJvdWdoUmVzcG9uc2UocmVzcG9uc2UpKSB7XG5cdFx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0OmVuZFwiLCB7XG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0cmVxdWVzdFxuXHRcdFx0fSkpO1xuXHRcdFx0dGhpcy5wYXNzdGhyb3VnaCgpO1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHRcdGNvbnN0IHJlc3BvbnNlQ2xvbmVGb3JMb2dzID0gcmVzb2x1dGlvbkNvbnRleHQ/LnF1aWV0ID8gbnVsbCA6IHJlc3BvbnNlLmNsb25lKCk7XG5cdFx0YXdhaXQgc3RvcmVSZXNwb25zZUNvb2tpZXMocmVxdWVzdCwgcmVzcG9uc2UpO1xuXHRcdHRoaXMucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuXHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcblx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdHJlcXVlc3Rcblx0XHR9KSk7XG5cdFx0aWYgKCFyZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQpIGhhbmRsZXIubG9nKHtcblx0XHRcdHJlcXVlc3Q6IHJlcXVlc3RDbG9uZUZvckxvZ3MsXG5cdFx0XHRyZXNwb25zZTogcmVzcG9uc2VDbG9uZUZvckxvZ3MsXG5cdFx0XHRwYXJzZWRSZXN1bHRcblx0XHR9KTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9mcmFtZXMvd2Vic29ja2V0LWZyYW1lLnRzXG52YXIgV2ViU29ja2V0Q29ubmVjdGlvbkV2ZW50ID0gY2xhc3MgZXh0ZW5kcyBUeXBlZEV2ZW50IHtcblx0dXJsO1xuXHRwcm90b2NvbHM7XG5cdGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcblx0XHRzdXBlciguLi5bdHlwZSwge31dKTtcblx0XHR0aGlzLnVybCA9IGRhdGEudXJsO1xuXHRcdHRoaXMucHJvdG9jb2xzID0gZGF0YS5wcm90b2NvbHM7XG5cdH1cbn07XG52YXIgV2ViU29ja2V0RXJyb3JFdmVudCA9IGNsYXNzIGV4dGVuZHMgV2ViU29ja2V0Q29ubmVjdGlvbkV2ZW50IHtcblx0ZXJyb3I7XG5cdGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcblx0XHRzdXBlcih0eXBlLCBkYXRhKTtcblx0XHR0aGlzLmVycm9yID0gZGF0YS5lcnJvcjtcblx0fVxufTtcbnZhciBXZWJTb2NrZXROZXR3b3JrRnJhbWUgPSBjbGFzcyBleHRlbmRzIE5ldHdvcmtGcmFtZSB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcihcIndzXCIsIHsgY29ubmVjdGlvbjogb3B0aW9ucy5jb25uZWN0aW9uIH0pO1xuXHR9XG5cdGdldEhhbmRsZXJzKGNvbnRyb2xsZXIpIHtcblx0XHRyZXR1cm4gY29udHJvbGxlci5nZXRIYW5kbGVyc0J5S2luZChcIndlYnNvY2tldFwiKTtcblx0fVxuXHRhc3luYyByZXNvbHZlKGhhbmRsZXJzLCBvblVuaGFuZGxlZEZyYW1lLCByZXNvbHV0aW9uQ29udGV4dCkge1xuXHRcdGNvbnN0IHsgY29ubmVjdGlvbiB9ID0gdGhpcy5kYXRhO1xuXHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFdlYlNvY2tldENvbm5lY3Rpb25FdmVudChcIndlYnNvY2tldDpjb25uZWN0aW9uXCIsIHtcblx0XHRcdHVybDogY29ubmVjdGlvbi5jbGllbnQudXJsLFxuXHRcdFx0cHJvdG9jb2xzOiBjb25uZWN0aW9uLmluZm8ucHJvdG9jb2xzXG5cdFx0fSkpO1xuXHRcdGNvbnN0IGhhbmRsZVNvY2tldEVycm9yID0gKGV2ZW50KSA9PiB7XG5cdFx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBXZWJTb2NrZXRFcnJvckV2ZW50KFwid2Vic29ja2V0OmVycm9yXCIsIHtcblx0XHRcdFx0dXJsOiBjb25uZWN0aW9uLmNsaWVudC51cmwsXG5cdFx0XHRcdHByb3RvY29sczogY29ubmVjdGlvbi5pbmZvLnByb3RvY29scyxcblx0XHRcdFx0ZXJyb3I6IGdldEVycm9yRnJvbUV2ZW50KGV2ZW50KVxuXHRcdFx0fSkpO1xuXHRcdH07XG5cdFx0Y29ubmVjdGlvbi5jbGllbnQuc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCBoYW5kbGVTb2NrZXRFcnJvcik7XG5cdFx0Y29ubmVjdGlvbi5jbGllbnQuc29ja2V0LmFkZEV2ZW50TGlzdGVuZXIoXCJjbG9zZVwiLCAoKSA9PiB7XG5cdFx0XHRjb25uZWN0aW9uLmNsaWVudC5zb2NrZXQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIGhhbmRsZVNvY2tldEVycm9yKTtcblx0XHR9LCB7IG9uY2U6IHRydWUgfSk7XG5cdFx0aWYgKGhhbmRsZXJzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0YXdhaXQgZXhlY3V0ZVVuaGFuZGxlZEZyYW1lSGFuZGxlKHRoaXMsIG9uVW5oYW5kbGVkRnJhbWUpLnRoZW4oKCkgPT4gdGhpcy5wYXNzdGhyb3VnaCgpLCAoZXJyb3IpID0+IHRoaXMuZXJyb3JXaXRoKGVycm9yKSk7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdGxldCBoYXNNYXRjaGluZ0hhbmRsZXJzID0gZmFsc2U7XG5cdFx0Zm9yIChjb25zdCBoYW5kbGVyIG9mIGhhbmRsZXJzKSB7XG5cdFx0XHRjb25zdCBoYW5kbGVyQ29ubmVjdGlvbiA9IGF3YWl0IGhhbmRsZXIucnVuKGNvbm5lY3Rpb24sIHtcblx0XHRcdFx0YmFzZVVybDogcmVzb2x1dGlvbkNvbnRleHQ/LmJhc2VVcmw/LnRvU3RyaW5nKCksXG5cdFx0XHRcdC8qKlxuXHRcdFx0XHQqIEBub3RlIEV4cG9zZSBhbiBlbWl0LW9ubHkgcmVmZXJlbmNlIHRvIHRoaXMgZnJhbWUncyBldmVudHNcblx0XHRcdFx0KiBzbyB0aGUgaGFuZGxlcnMgY2FuIGVtaXQgYWRkaXRpb25hbCBldmVudHMgbm90IGNvdmVyZWQgYnlcblx0XHRcdFx0KiB0aGUgZnJhbWUgKGUuZy4gXCJncmFwaHFsOnN1YnNjcmlwdGlvblwiKS5cblx0XHRcdFx0Ki9cblx0XHRcdFx0ZXZlbnRzOiB0aGlzLmV2ZW50cyxcblx0XHRcdFx0LyoqXG5cdFx0XHRcdCogQG5vdGUgRG8gbm90IGVtaXQgdGhlIGhhbmRsZXIncyBcImNvbm5lY3Rpb25cIiBldmVudCB3aGVuIHJ1bm5pbmcgdGhlIGhhbmRsZXIuXG5cdFx0XHRcdCogVXNlIHRoZSBydW4gb25seSB0byBnZXQgdGhlIHJlc29sdmVkIGNvbm5lY3Rpb24gb2JqZWN0LlxuXHRcdFx0XHQqL1xuXHRcdFx0XHRba0F1dG9Db25uZWN0XTogZmFsc2Vcblx0XHRcdH0pO1xuXHRcdFx0aWYgKCFoYW5kbGVyQ29ubmVjdGlvbikgY29udGludWU7XG5cdFx0XHRoYXNNYXRjaGluZ0hhbmRsZXJzID0gdHJ1ZTtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBBdHRhY2ggdGhlIFdlYlNvY2tldCBsb2dnZXIgKmJlZm9yZSogZW1pdHRpbmcgdGhlIGhhbmRsZXIncyBcImNvbm5lY3Rpb25cIiBldmVudC5cblx0XHRcdCogQ29ubmVjdGlvbiBldmVudCBsaXN0ZW5lcnMgbWF5IHBlcmZvcm0gYWN0aW9ucyB0aGF0IHNob3VsZCBiZSByZWZsZWN0ZWQgaW4gdGhlIGxvZ3Ncblx0XHRcdCogKGUuZy4gY2xvc2luZyB0aGUgY29ubmVjdGlvbiBpbW1lZGlhdGVseSkuIElmIHRoZSBsb2dnZXIgaXMgYXR0YWNoZWQgYWZ0ZXIgdGhlIGNvbm5lY3Rpb24sXG5cdFx0XHQqIHRob3NlIGFjdGlvbnMgY2Fubm90IGJlIHByb3Blcmx5IGxvZ2dlZC5cblx0XHRcdCovXG5cdFx0XHRjb25zdCByZW1vdmVMb2dnZXIgPSAhcmVzb2x1dGlvbkNvbnRleHQ/LnF1aWV0ID8gaGFuZGxlci5sb2coY29ubmVjdGlvbikgOiB2b2lkIDA7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRpZiAoIWhhbmRsZXJba0Nvbm5lY3RdKGhhbmRsZXJDb25uZWN0aW9uKSkgcmVtb3ZlTG9nZ2VyPy4oKTtcblx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdGlmICghdGhpcy5ldmVudHMuZW1pdChuZXcgV2ViU29ja2V0RXJyb3JFdmVudChcInVuaGFuZGxlZEV4Y2VwdGlvblwiLCB7XG5cdFx0XHRcdFx0ZXJyb3IsXG5cdFx0XHRcdFx0dXJsOiBjb25uZWN0aW9uLmNsaWVudC51cmwsXG5cdFx0XHRcdFx0cHJvdG9jb2xzOiBjb25uZWN0aW9uLmluZm8ucHJvdG9jb2xzXG5cdFx0XHRcdH0pKSkge1xuXHRcdFx0XHRcdGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuXHRcdFx0XHRcdGRldlV0aWxzLmVycm9yKFwiRW5jb3VudGVyZWQgYW4gdW5oYW5kbGVkIGV4Y2VwdGlvbiBkdXJpbmcgdGhlIGhhbmRsZXIgbG9va3VwIGZvciBcXFwiJXNcXFwiLiBQbGVhc2Ugc2VlIHRoZSBvcmlnaW5hbCBlcnJvciBhYm92ZS5cIiwgY29ubmVjdGlvbi5jbGllbnQudXJsKTtcblx0XHRcdFx0fVxuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBUaHJvdyB0aGUgY2F1Z2h0IGVycm9yIHNvIGl0IGdldHMgcGlja2VkIHVwIGJ5IFdlYlNvY2tldEludGVyY2VwdG9yLlxuXHRcdFx0XHQqIEl0J3MgdGhlIGludGVyY2VwdG9yIHdobyB0cmFuc2xhdGVzIGhhbmRsZXIgZXJyb3JzIHRvIFdlYlNvY2tldCBjbG9zdXJlcy5cblx0XHRcdFx0Ki9cblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmICghaGFzTWF0Y2hpbmdIYW5kbGVycykge1xuXHRcdFx0YXdhaXQgZXhlY3V0ZVVuaGFuZGxlZEZyYW1lSGFuZGxlKHRoaXMsIG9uVW5oYW5kbGVkRnJhbWUpLnRoZW4oKCkgPT4gdGhpcy5wYXNzdGhyb3VnaCgpLCAoZXJyb3IpID0+IHRoaXMuZXJyb3JXaXRoKGVycm9yKSk7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdGFzeW5jIGdldFVuaGFuZGxlZE1lc3NhZ2UoKSB7XG5cdFx0Y29uc3QgeyBjb25uZWN0aW9uIH0gPSB0aGlzLmRhdGE7XG5cdFx0cmV0dXJuIGBpbnRlcmNlcHRlZCBhIFdlYlNvY2tldCBjb25uZWN0aW9uIHdpdGhvdXQgYSBtYXRjaGluZyBldmVudCBoYW5kbGVyOiR7YFxcblxcbiAgXFx1MjAyMiAke2Nvbm5lY3Rpb24uY2xpZW50LnVybH1cXG5cXG5gfUlmIHlvdSBzdGlsbCB3aXNoIHRvIGludGVyY2VwdCB0aGlzIHVuaGFuZGxlZCBjb25uZWN0aW9uLCBwbGVhc2UgY3JlYXRlIGFuIGV2ZW50IGhhbmRsZXIgZm9yIGl0LlxcblJlYWQgbW9yZTogaHR0cHM6Ly9tc3dqcy5pby9kb2NzL3dlYnNvY2tldGA7XG5cdH1cbn07XG4vKipcbiogRXh0cmFjdCB0aGUgZXJyb3IgZnJvbSB0aGUgZ2l2ZW4gXCJlcnJvclwiIGV2ZW50LCBpZiBhbnkuXG4qIFN1cHBvcnRzIGJvdGggdGhlIGBFcnJvckV2ZW50LmVycm9yYCBwcm9wZXJ0eSBhbmQgdGhlIGBjYXVzZWBcbiogcHJvcGVydHkgdGhhdCBNU1cgc2V0cyB3aGVuIGVycm9yaW5nIHRoZSBjb25uZWN0aW9uIGl0c2VsZi5cbiovXG5mdW5jdGlvbiBnZXRFcnJvckZyb21FdmVudChldmVudCkge1xuXHRpZiAoXCJlcnJvclwiIGluIGV2ZW50ICYmIGV2ZW50LmVycm9yICE9IG51bGwpIHJldHVybiBldmVudC5lcnJvcjtcblx0aWYgKFwiY2F1c2VcIiBpbiBldmVudCAmJiBldmVudC5jYXVzZSAhPSBudWxsKSByZXR1cm4gZXZlbnQuY2F1c2U7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9leHBlcmltZW50YWwvc291cmNlcy9pbnRlcmNlcHRvci1zb3VyY2UudHNcbi8qKlxuKiBDcmVhdGUgYSBuZXR3b3JrIHNvdXJjZSBmcm9tIHRoZSBnaXZlbiBsaXN0IG9mIGludGVyY2VwdG9ycy5cbiovXG52YXIgSW50ZXJjZXB0b3JTb3VyY2UgPSBjbGFzcyBleHRlbmRzIE5ldHdvcmtTb3VyY2Uge1xuXHQjaW50ZXJjZXB0b3I7XG5cdC8qKlxuXHQqIEBub3RlIEZyYW1lcyBhcmUga2V5ZWQgYnkgdGhlIHJlcXVlc3QgaW5zdGFuY2UsIG5vdCB0aGUgcmVxdWVzdCBJRC5cblx0KiBUaGUgaW50ZXJjZXB0b3IgZW1pdHMgdGhlIHNhbWUgcmVxdWVzdCBpbnN0YW5jZSBvbiB0aGUgXCJyZXF1ZXN0XCJcblx0KiBhbmQgXCJyZXNwb25zZVwiIGV2ZW50cywgc28gdGhlIGZyYW1lIGNhbiBiZSBsb29rZWQgdXAgYnkgaWRlbnRpdHkuXG5cdCogQSB3ZWFrIHJlZmVyZW5jZSBsZXRzIHRoZSBmcmFtZSBiZSBnYXJiYWdlIGNvbGxlY3RlZCBhbG9uZ3NpZGVcblx0KiBpdHMgcmVxdWVzdCBvbmNlIHRoZSByZXF1ZXN0IHNldHRsZXMgd2l0aG91dCBwcm9kdWNpbmcgYSByZXNwb25zZVxuXHQqIChlLmcuIGEgcGFzc3Rocm91Z2ggcmVxdWVzdCBmYWlsaW5nIHdpdGggYSBuZXR3b3JrIGVycm9yKS5cblx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzI3OTJcblx0Ki9cblx0I2ZyYW1lcztcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jaW50ZXJjZXB0b3IgPSBuZXcgQmF0Y2hJbnRlcmNlcHRvcih7XG5cdFx0XHRuYW1lOiBcImludGVyY2VwdG9yLXNvdXJjZVwiLFxuXHRcdFx0aW50ZXJjZXB0b3JzOiBvcHRpb25zLmludGVyY2VwdG9yc1xuXHRcdH0pO1xuXHRcdHRoaXMuI2ZyYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuXHR9XG5cdGVuYWJsZSgpIHtcblx0XHR0aGlzLiNpbnRlcmNlcHRvci5hcHBseSgpO1xuXHRcdHRoaXMuI2ludGVyY2VwdG9yLm9uKFwicmVxdWVzdFwiLCB0aGlzLiNoYW5kbGVSZXF1ZXN0LmJpbmQodGhpcykpLm9uKFwicmVzcG9uc2VcIiwgdGhpcy4jaGFuZGxlUmVzcG9uc2UuYmluZCh0aGlzKSkub24oXCJjb25uZWN0aW9uXCIsIHRoaXMuI2hhbmRsZVdlYlNvY2tldENvbm5lY3Rpb24uYmluZCh0aGlzKSk7XG5cdH1cblx0ZGlzYWJsZSgpIHtcblx0XHRzdXBlci5kaXNhYmxlKCk7XG5cdFx0dGhpcy4jaW50ZXJjZXB0b3IuZGlzcG9zZSgpO1xuXHRcdC8qKlxuXHRcdCogQHRvZG8gV2UgY2FuIGFsc28gYWJvcnQgYW55IHBlbmRpbmcgZnJhbWVzIGhlcmUsIGdpdmVuIHdlIGltcGxlbWVudFxuXHRcdCogdGhlIGBOZXR3b3JrRnJhbWUuYWJvcnQoKWAgbWV0aG9kLlxuXHRcdCovXG5cdFx0dGhpcy4jZnJhbWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdH1cblx0YXN5bmMgI2hhbmRsZVJlcXVlc3QoZXZlbnQpIHtcblx0XHRjb25zdCB7IHJlcXVlc3RJZCwgcmVxdWVzdCwgY29udHJvbGxlciB9ID0gZXZlbnQ7XG5cdFx0Y29uc3QgaHR0cEZyYW1lID0gbmV3IEludGVyY2VwdG9ySHR0cE5ldHdvcmtGcmFtZSh7XG5cdFx0XHRpZDogcmVxdWVzdElkLFxuXHRcdFx0cmVxdWVzdCxcblx0XHRcdGNvbnRyb2xsZXJcblx0XHR9KTtcblx0XHR0aGlzLiNmcmFtZXMuc2V0KHJlcXVlc3QsIGh0dHBGcmFtZSk7XG5cdFx0YXdhaXQgdGhpcy5xdWV1ZShodHRwRnJhbWUpO1xuXHR9XG5cdGFzeW5jICNoYW5kbGVSZXNwb25zZSh7IHJlcXVlc3RJZCwgcmVxdWVzdCwgcmVzcG9uc2UsIHJlc3BvbnNlVHlwZSB9KSB7XG5cdFx0Y29uc3QgaHR0cEZyYW1lID0gdGhpcy4jZnJhbWVzLmdldChyZXF1ZXN0KTtcblx0XHR0aGlzLiNmcmFtZXMuZGVsZXRlKHJlcXVlc3QpO1xuXHRcdGlmIChodHRwRnJhbWUgPT0gbnVsbCkgcmV0dXJuO1xuXHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGh0dHBGcmFtZS5ldmVudHMuZW1pdChuZXcgUmVzcG9uc2VFdmVudChyZXNwb25zZVR5cGUgPT09IFwibW9ja1wiID8gXCJyZXNwb25zZTptb2NrZWRcIiA6IFwicmVzcG9uc2U6YnlwYXNzXCIsIHtcblx0XHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0XHRyZXNwb25zZVxuXHRcdFx0XHR9KSk7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBSZW1vdmUgYW55IGxpc3RlbmVycyBmcm9tIHRoaXMgZnJhbWUuXG5cdFx0XHRcdCogUGFzdCB0aGlzIHBvaW50LCBpdCB3b24ndCBlbWl0IGFueXRoaW5nLiBUaGUgcmVtb3ZhbCBpcyBjcnVjaWFsXG5cdFx0XHRcdCogdG8gcHJldmVudCBcInJldHRpbWVcIiBmcm9tIGtlZXBpbmcgdGhlIGFib3J0IGNsZWFudXAgbGlzdGVuZXJzIGludGVybmFsbHkuXG5cdFx0XHRcdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlcy8yNzM1XG5cdFx0XHRcdCovXG5cdFx0XHRcdGh0dHBGcmFtZS5ldmVudHMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0YXN5bmMgI2hhbmRsZVdlYlNvY2tldENvbm5lY3Rpb24oY29ubmVjdGlvbikge1xuXHRcdGF3YWl0IHRoaXMucXVldWUobmV3IEludGVyY2VwdG9yV2ViU29ja2V0TmV0d29ya0ZyYW1lKHsgY29ubmVjdGlvbiB9KSk7XG5cdH1cbn07XG52YXIgSW50ZXJjZXB0b3JIdHRwTmV0d29ya0ZyYW1lID0gY2xhc3MgZXh0ZW5kcyBIdHRwTmV0d29ya0ZyYW1lIHtcblx0I2NvbnRyb2xsZXI7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcih7XG5cdFx0XHRpZDogb3B0aW9ucy5pZCxcblx0XHRcdHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdFxuXHRcdH0pO1xuXHRcdHRoaXMuI2NvbnRyb2xsZXIgPSBvcHRpb25zLmNvbnRyb2xsZXI7XG5cdH1cblx0cGFzc3Rocm91Z2goKSB7XG5cdFx0ZGVsZXRlUmVxdWVzdFBhc3N0aHJvdWdoSGVhZGVyKHRoaXMuZGF0YS5yZXF1ZXN0KTtcblx0fVxuXHRyZXNwb25kV2l0aChyZXNwb25zZSkge1xuXHRcdGlmIChyZXNwb25zZSkgdGhpcy4jY29udHJvbGxlci5yZXNwb25kV2l0aChyZXNwb25zZSk7XG5cdH1cblx0ZXJyb3JXaXRoKHJlYXNvbikge1xuXHRcdGlmIChyZWFzb24gaW5zdGFuY2VvZiBSZXNwb25zZSkgcmV0dXJuIHRoaXMucmVzcG9uZFdpdGgocmVhc29uKTtcblx0XHRpZiAocmVhc29uIGluc3RhbmNlb2YgSW50ZXJuYWxFcnJvcikgdGhpcy4jY29udHJvbGxlci5lcnJvcldpdGgocmVhc29uKTtcblx0XHR0aHJvdyByZWFzb247XG5cdH1cbn07XG52YXIgSW50ZXJjZXB0b3JXZWJTb2NrZXROZXR3b3JrRnJhbWUgPSBjbGFzcyBleHRlbmRzIFdlYlNvY2tldE5ldHdvcmtGcmFtZSB7XG5cdC8qKlxuXHQqIFRoZSBpbi1wcm9jZXNzIGNsaWVudCBjb25uZWN0aW9uLCB3aG9zZSBzb2NrZXRcblx0KiB0aGUgZnJhbWUgZGlzcGF0Y2hlcyBlcnJvcnMgb24uXG5cdCovXG5cdCNjbGllbnQ7XG5cdGNvbnN0cnVjdG9yKGFyZ3MpIHtcblx0XHRzdXBlcih7IGNvbm5lY3Rpb246IGFyZ3MuY29ubmVjdGlvbiB9KTtcblx0XHR0aGlzLiNjbGllbnQgPSBhcmdzLmNvbm5lY3Rpb24uY2xpZW50O1xuXHRcdC8qKlxuXHRcdCogQG5vdGUgUHJvdmlkZSBhIHNpbWlsYXIgZnJhbWUgbGlzdGVuZXIgY2xlYW51cCBhcyBmb3IgSFRUUC5cblx0XHQqIFdoZW4gdGhlIGNsaWVudCBjb25uZWN0aW9uIGNsb3NlcywgdGhlIGhhbmRsZXIgY2FuIG5vIGxvbmdlciBiZSB1c2VkLlxuXHRcdCovXG5cdFx0YXJncy5jb25uZWN0aW9uLmNsaWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgKCkgPT4ge1xuXHRcdFx0dGhpcy5ldmVudHMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG5cdFx0fSwgeyBvbmNlOiB0cnVlIH0pO1xuXHR9XG5cdGVycm9yV2l0aChyZWFzb24pIHtcblx0XHRpZiAocmVhc29uIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRcdC8qKlxuXHRcdFx0KiBVc2UgYGNsaWVudC5lcnJvcldpdGgocmVhc29uKWAgaW4gdGhlIGZ1dHVyZS5cblx0XHRcdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvaW50ZXJjZXB0b3JzL2lzc3Vlcy83NDdcblx0XHRcdCovXG5cdFx0XHRjb25zdCBlcnJvckV2ZW50ID0gbmV3IEV2ZW50KFwiZXJyb3JcIik7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXJyb3JFdmVudCwgXCJjYXVzZVwiLCB7XG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGNvbmZpZ3VyYWJsZTogZmFsc2UsXG5cdFx0XHRcdHZhbHVlOiByZWFzb25cblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jY2xpZW50LnNvY2tldC5kaXNwYXRjaEV2ZW50KGVycm9yRXZlbnQpO1xuXHRcdH1cblx0fVxuXHRwYXNzdGhyb3VnaCgpIHtcblx0XHR0aGlzLmRhdGEuY29ubmVjdGlvbi5zZXJ2ZXIuY29ubmVjdCgpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBOZXR3b3JrRnJhbWUgYXMgYSwgSGFuZGxlcnNDb250cm9sbGVyIGFzIGMsIFJlc3BvbnNlRXZlbnQgYXMgaSwgSW5NZW1vcnlIYW5kbGVyc0NvbnRyb2xsZXIgYXMgbCwgV2ViU29ja2V0TmV0d29ya0ZyYW1lIGFzIG4sIE5ldHdvcmtSZWFkeVN0YXRlIGFzIG8sIEh0dHBOZXR3b3JrRnJhbWUgYXMgciwgZGVmaW5lTmV0d29yayBhcyBzLCBJbnRlcmNlcHRvclNvdXJjZSBhcyB0LCBOZXR3b3JrU291cmNlIGFzIHUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW50ZXJjZXB0b3Itc291cmNlLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvaW5kZXgudHNcbi8qKlxuKiBHcmFjZWZ1bGx5IGhhbmRsZXMgYSBjYWxsYmFjayB0aGF0IHJldHVybnMgYSBwcm9taXNlLlxuKlxuKiBAZXhhbXBsZVxuKiBhd2FpdCB1bnRpbCgoKSA9PiBQcm9taXNlLnJlc29sdmUoMTIzKSlcbiogLy8gW251bGwsIDEyM11cbipcbiogYXdhaXQgdW50aWwoKCkgPT4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKCdPb3BzIScpKSlcbiogLy8gW25ldyBFcnJvcignT29wcyEnKSwgbnVsbF1cbiovXG5hc3luYyBmdW5jdGlvbiB1bnRpbChjYWxsYmFjaykge1xuXHR0cnkge1xuXHRcdHJldHVybiBbbnVsbCwgYXdhaXQgY2FsbGJhY2soKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdHRocm93IGVycm9yO1xuXHRcdH0pXTtcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRyZXR1cm4gW2Vycm9yLCBudWxsXTtcblx0fVxufVxuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVudGlsIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBpIGFzIGZvcm1hdFJlcXVlc3QgfSBmcm9tIFwiLi9jcmVhdGUtcmVxdWVzdC1pZC1Zb2JVbkpOTy5qc1wiO1xuaW1wb3J0IHsgYSBhcyBpc1Jlc3BvbnNlTGlrZSwgYyBhcyBSZXF1ZXN0Q29udHJvbGxlciwgaSBhcyBpc1Jlc3BvbnNlRXJyb3IsIGwgYXMgSW50ZXJjZXB0b3JFcnJvciwgbyBhcyBpc09iamVjdCwgciBhcyBjcmVhdGVTZXJ2ZXJFcnJvclJlc3BvbnNlIH0gZnJvbSBcIi4vZmV0Y2gtdXRpbHMtQzZQNmdMTG8uanNcIjtcbmltcG9ydCB7IFR5cGVkRXZlbnQgfSBmcm9tIFwicmV0dGltZVwiO1xuaW1wb3J0IHsgdW50aWwgfSBmcm9tIFwiQG9wZW4tZHJhZnQvdW50aWxcIjtcbi8vI3JlZ2lvbiBzcmMvZXZlbnRzL2h0dHAudHNcbnZhciBIdHRwUmVxdWVzdEV2ZW50ID0gY2xhc3MgZXh0ZW5kcyBUeXBlZEV2ZW50IHtcblx0Y29uc3RydWN0b3IoZGF0YSkge1xuXHRcdHN1cGVyKC4uLltcInJlcXVlc3RcIiwge31dKTtcblx0XHR0aGlzLnJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG5cdFx0dGhpcy5yZXF1ZXN0SWQgPSBkYXRhLnJlcXVlc3RJZDtcblx0XHR0aGlzLmluaXRpYXRvciA9IGRhdGEuaW5pdGlhdG9yO1xuXHRcdHRoaXMuY29udHJvbGxlciA9IGRhdGEuY29udHJvbGxlcjtcblx0fVxufTtcbnZhciBIdHRwUmVzcG9uc2VFdmVudCA9IGNsYXNzIGV4dGVuZHMgVHlwZWRFdmVudCB7XG5cdGNvbnN0cnVjdG9yKGRhdGEpIHtcblx0XHRzdXBlciguLi5bXCJyZXNwb25zZVwiLCB7fV0pO1xuXHRcdHRoaXMucmVzcG9uc2UgPSBkYXRhLnJlc3BvbnNlO1xuXHRcdHRoaXMucmVzcG9uc2VUeXBlID0gZGF0YS5yZXNwb25zZVR5cGU7XG5cdFx0dGhpcy5yZXF1ZXN0ID0gZGF0YS5yZXF1ZXN0O1xuXHRcdHRoaXMucmVxdWVzdElkID0gZGF0YS5yZXF1ZXN0SWQ7XG5cdFx0dGhpcy5pbml0aWF0b3IgPSBkYXRhLmluaXRpYXRvcjtcblx0fVxufTtcbnZhciBVbmhhbmRsZWRIdHRwRXhjZXB0aW9uID0gY2xhc3MgZXh0ZW5kcyBUeXBlZEV2ZW50IHtcblx0Y29uc3RydWN0b3IoZGF0YSkge1xuXHRcdHN1cGVyKC4uLltcInVuaGFuZGxlZEV4Y2VwdGlvblwiLCB7fV0pO1xuXHRcdHRoaXMuZXJyb3IgPSBkYXRhLmVycm9yO1xuXHRcdHRoaXMucmVxdWVzdCA9IGRhdGEucmVxdWVzdDtcblx0XHR0aGlzLnJlcXVlc3RJZCA9IGRhdGEucmVxdWVzdElkO1xuXHRcdHRoaXMuaW5pdGlhdG9yID0gZGF0YS5pbml0aWF0b3I7XG5cdFx0dGhpcy5jb250cm9sbGVyID0gZGF0YS5jb250cm9sbGVyO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2lzLW5vZGUtbGlrZS1lcnJvci50c1xuZnVuY3Rpb24gaXNOb2RlTGlrZUVycm9yKGVycm9yKSB7XG5cdGlmIChlcnJvciA9PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGlmICghKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBcImNvZGVcIiBpbiBlcnJvciAmJiBcImVycm5vXCIgaW4gZXJyb3I7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvaGFuZGxlLXJlcXVlc3QudHNcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZVJlcXVlc3Qob3B0aW9ucykge1xuXHRpZiAob3B0aW9ucy5sb2dnZXI/LmlzRW5hYmxlZChcImRlZmF1bHRcIikpIGZvcm1hdFJlcXVlc3Qob3B0aW9ucy5yZXF1ZXN0KS50aGVuKChtZXNzYWdlKSA9PiB7XG5cdFx0b3B0aW9ucy5sb2dnZXI/LmluZm8oXCJbJXNdICVzXCIsIG9wdGlvbnMucmVxdWVzdElkLCBtZXNzYWdlKTtcblx0fSk7XG5cdGNvbnN0IGhhbmRsZVJlc3BvbnNlID0gYXN5bmMgKHJlc3BvbnNlKSA9PiB7XG5cdFx0aWYgKHJlc3BvbnNlIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRcdGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5lcnJvcldpdGgocmVzcG9uc2UpO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdGlmIChpc1Jlc3BvbnNlRXJyb3IocmVzcG9uc2UpKSB7XG5cdFx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdC8qKlxuXHRcdCogSGFuZGxlIG5vcm1hbCByZXNwb25zZXMgb3IgcmVzcG9uc2UtbGlrZSBvYmplY3RzLlxuXHRcdCogQG5vdGUgVGhpcyBtdXN0IGNvbWUgYmVmb3JlIHRoZSBhcmJpdHJhcnkgb2JqZWN0IGNoZWNrXG5cdFx0KiBzaW5jZSBSZXNwb25zZSBpbnN0YW5jZXMgYXJlLCBpbiBmYWN0LCBvYmplY3RzLlxuXHRcdCovXG5cdFx0aWYgKGlzUmVzcG9uc2VMaWtlKHJlc3BvbnNlKSkge1xuXHRcdFx0YXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLnJlc3BvbmRXaXRoKHJlc3BvbnNlKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRpZiAoaXNPYmplY3QocmVzcG9uc2UpKSB7XG5cdFx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKHJlc3BvbnNlKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG5cdGNvbnN0IGhhbmRsZVJlc3BvbnNlRXJyb3IgPSBhc3luYyAoZXJyb3IpID0+IHtcblx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBJbnRlcmNlcHRvckVycm9yKSB0aHJvdyByZXN1bHRFcnJvcjtcblx0XHRpZiAoaXNOb2RlTGlrZUVycm9yKGVycm9yKSkge1xuXHRcdFx0YXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLmVycm9yV2l0aChlcnJvcik7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgUmVzcG9uc2UpIHJldHVybiBhd2FpdCBoYW5kbGVSZXNwb25zZShlcnJvcik7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9O1xuXHRjb25zdCByZXF1ZXN0QWJvcnRQcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdGxldCByZXF1ZXN0QWJvcnRSZWFzb247XG5cdGxldCBpc1JlcXVlc3RBYm9ydGVkID0gZmFsc2U7XG5cdGNvbnN0IG9uQWJvcnQgPSAoKSA9PiB7XG5cdFx0aXNSZXF1ZXN0QWJvcnRlZCA9IHRydWU7XG5cdFx0cmVxdWVzdEFib3J0UmVhc29uID0gb3B0aW9ucy5yZXF1ZXN0LnNpZ25hbD8ucmVhc29uO1xuXHRcdHJlcXVlc3RBYm9ydFByb21pc2UucmVqZWN0KHJlcXVlc3RBYm9ydFJlYXNvbik7XG5cdH07XG5cdC8qKlxuXHQqIEBub3RlIGBzaWduYWxgIGlzIG5vdCBhbHdheXMgZGVmaW5lZCBpbiBSZWFjdCBOYXRpdmUuXG5cdCovXG5cdGlmIChvcHRpb25zLnJlcXVlc3Quc2lnbmFsKSB7XG5cdFx0aWYgKG9wdGlvbnMucmVxdWVzdC5zaWduYWwuYWJvcnRlZCkge1xuXHRcdFx0YXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLmVycm9yV2l0aChvcHRpb25zLnJlcXVlc3Quc2lnbmFsLnJlYXNvbik7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdG9wdGlvbnMucmVxdWVzdC5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcblx0fVxuXHRjb25zdCBbcmVzdWx0RXJyb3JdID0gYXdhaXQgdW50aWwoYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IHJlcXVlc3RFdmVudCA9IG5ldyBIdHRwUmVxdWVzdEV2ZW50KHtcblx0XHRcdGluaXRpYXRvcjogb3B0aW9ucy5pbml0aWF0b3IsXG5cdFx0XHRyZXF1ZXN0SWQ6IG9wdGlvbnMucmVxdWVzdElkLFxuXHRcdFx0cmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0LFxuXHRcdFx0Y29udHJvbGxlcjogb3B0aW9ucy5jb250cm9sbGVyXG5cdFx0fSk7XG5cdFx0Y29uc3QgcmVxdWVzdExpc3RlbmVyc1Byb21pc2UgPSBvcHRpb25zLmVtaXR0ZXIuZW1pdEFzUHJvbWlzZShyZXF1ZXN0RXZlbnQpO1xuXHRcdGF3YWl0IFByb21pc2UucmFjZShbXG5cdFx0XHRyZXF1ZXN0QWJvcnRQcm9taXNlLnByb21pc2UsXG5cdFx0XHRyZXF1ZXN0TGlzdGVuZXJzUHJvbWlzZSxcblx0XHRcdG9wdGlvbnMuY29udHJvbGxlci5oYW5kbGVkXG5cdFx0XSk7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBJZiB0aGUgXCJyZXF1ZXN0XCIgbGlzdGVuZXIgaGFzIHJlcGxhY2VkIHRoZSByZXF1ZXN0IGluc3RhbmNlLFxuXHRcdCogcHJvcGFnYXRlIHRoYXQgbXV0YXRpb24gYmFjayB0byB0aGUgdW5kZXJseWluZyBpbnN0ZXJjZXB0b3IuXG5cdFx0KiBUaGlzIGhhcHBlbnMgd2l0aCBYTUxIdHRwUmVxdWVzdCB0aGF0IHJlcGxhY2VzIHJlcXVlc3QgaW5zdGFuY2VzXG5cdFx0KiB0byBjb3JyZWN0bHkgcmVmbGVjdCB0aGUgXCJ3aXRoQ3JlZGVudGlhbHNcIiBvcHRpb24gb24gdGhlIEZldGNoIEFQSSByZXF1ZXN0LlxuXHRcdCovXG5cdFx0aWYgKHJlcXVlc3RFdmVudC5yZXF1ZXN0ICE9PSBvcHRpb25zLnJlcXVlc3QpIG9wdGlvbnMucmVxdWVzdCA9IHJlcXVlc3RFdmVudC5yZXF1ZXN0O1xuXHR9KTtcblx0b3B0aW9ucy5yZXF1ZXN0LnNpZ25hbD8ucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQpO1xuXHRpZiAoaXNSZXF1ZXN0QWJvcnRlZCkge1xuXHRcdGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5lcnJvcldpdGgocmVxdWVzdEFib3J0UmVhc29uKTtcblx0XHRyZXR1cm47XG5cdH1cblx0aWYgKHJlc3VsdEVycm9yKSB7XG5cdFx0aWYgKGF3YWl0IGhhbmRsZVJlc3BvbnNlRXJyb3IocmVzdWx0RXJyb3IpKSByZXR1cm47XG5cdFx0aWYgKG9wdGlvbnMuZW1pdHRlci5saXN0ZW5lckNvdW50KFwidW5oYW5kbGVkRXhjZXB0aW9uXCIpID4gMCkge1xuXHRcdFx0Y29uc3QgdW5oYW5kbGVkRXhjZXB0aW9uQ29udHJvbGxlciA9IG5ldyBSZXF1ZXN0Q29udHJvbGxlcihvcHRpb25zLnJlcXVlc3QsIHtcblx0XHRcdFx0LyoqXG5cdFx0XHRcdCogQG5vdGUgSW50ZW50aW9uYWxseSBlbXB0eSBwYXNzdGhyb3VnaCBoYW5kbGUuXG5cdFx0XHRcdCogVGhpcyBjb250cm9sbGVyIGlzIGNyZWF0ZWQgd2l0aGluIGFub3RoZXIgY29udHJvbGxlciBhbmQgd2Ugb25seSBuZWVkXG5cdFx0XHRcdCogdG8ga25vdyBpZiBgdW5oYW5kbGVkRXhjZXB0aW9uYCBsaXN0ZW5lcnMgaGFuZGxlZCB0aGUgcmVxdWVzdC5cblx0XHRcdFx0Ki9cblx0XHRcdFx0cGFzc3Rocm91Z2goKSB7fSxcblx0XHRcdFx0YXN5bmMgcmVzcG9uZFdpdGgocmVzcG9uc2UpIHtcblx0XHRcdFx0XHRhd2FpdCBoYW5kbGVSZXNwb25zZShyZXNwb25zZSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdGFzeW5jIGVycm9yV2l0aChyZWFzb24pIHtcblx0XHRcdFx0XHQvKipcblx0XHRcdFx0XHQqIEBub3RlIEhhbmRsZSB0aGUgcmVzdWx0IG9mIHRoZSB1bmhhbmRsZWQgY29udHJvbGxlclxuXHRcdFx0XHRcdCogaW4gdGhlIHNhbWUgd2F5IGFzIHRoZSBvcmlnaW5hbCByZXF1ZXN0IGNvbnRyb2xsZXIuXG5cdFx0XHRcdFx0KiBUaGUgZXhjZXB0aW9uIGhlcmUgaXMgdGhhdCB0aHJvd24gZXJyb3JzIHdpdGhpbiB0aGVcblx0XHRcdFx0XHQqIFwidW5oYW5kbGVkRXhjZXB0aW9uXCIgZXZlbnQgZG8gTk9UIHJlc3VsdCBpbiBhbm90aGVyXG5cdFx0XHRcdFx0KiBlbWl0IG9mIHRoZSBzYW1lIGV2ZW50LiBUaGV5IGFyZSBmb3J3YXJkZWQgYXMtaXMuXG5cdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKHJlYXNvbik7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdFx0YXdhaXQgb3B0aW9ucy5lbWl0dGVyLmVtaXRBc1Byb21pc2UobmV3IFVuaGFuZGxlZEh0dHBFeGNlcHRpb24oe1xuXHRcdFx0XHRpbml0aWF0b3I6IG9wdGlvbnMuaW5pdGlhdG9yLFxuXHRcdFx0XHRlcnJvcjogcmVzdWx0RXJyb3IsXG5cdFx0XHRcdHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdCxcblx0XHRcdFx0cmVxdWVzdElkOiBvcHRpb25zLnJlcXVlc3RJZCxcblx0XHRcdFx0Y29udHJvbGxlcjogdW5oYW5kbGVkRXhjZXB0aW9uQ29udHJvbGxlclxuXHRcdFx0fSkpO1xuXHRcdFx0aWYgKHVuaGFuZGxlZEV4Y2VwdGlvbkNvbnRyb2xsZXIucmVhZHlTdGF0ZSAhPT0gUmVxdWVzdENvbnRyb2xsZXIuUEVORElORykgcmV0dXJuO1xuXHRcdH1cblx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIucmVzcG9uZFdpdGgoY3JlYXRlU2VydmVyRXJyb3JSZXNwb25zZShyZXN1bHRFcnJvcikpO1xuXHRcdHJldHVybjtcblx0fVxuXHRpZiAob3B0aW9ucy5jb250cm9sbGVyLnJlYWR5U3RhdGUgPT09IFJlcXVlc3RDb250cm9sbGVyLlBFTkRJTkcpIHJldHVybiBhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIucGFzc3Rocm91Z2goKTtcblx0cmV0dXJuIG9wdGlvbnMuY29udHJvbGxlci5oYW5kbGVkO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBIdHRwUmVzcG9uc2VFdmVudCBhcyBuLCBoYW5kbGVSZXF1ZXN0IGFzIHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aGFuZGxlLXJlcXVlc3QteTdhanl2ZTUuanMubWFwIiwiaW1wb3J0IHsgbiBhcyBJbnRlcmNlcHRvciwgciBhcyBjcmVhdGVMb2dnZXIsIHQgYXMgY3JlYXRlUmVxdWVzdElkIH0gZnJvbSBcIi4vY3JlYXRlLXJlcXVlc3QtaWQtWW9iVW5KTk8uanNcIjtcbmltcG9ydCB7IGMgYXMgUmVxdWVzdENvbnRyb2xsZXIsIGkgYXMgaXNSZXNwb25zZUVycm9yLCBuIGFzIEZldGNoUmVzcG9uc2UsIHQgYXMgRmV0Y2hSZXF1ZXN0IH0gZnJvbSBcIi4vZmV0Y2gtdXRpbHMtQzZQNmdMTG8uanNcIjtcbmltcG9ydCB7IG4gYXMgZW5jb2RlQnVmZmVyLCByIGFzIHRvQXJyYXlCdWZmZXIsIHQgYXMgZGVjb2RlQnVmZmVyIH0gZnJvbSBcIi4vYnVmZmVyLXV0aWxzLURKajdZekxHLmpzXCI7XG5pbXBvcnQgeyBuIGFzIEh0dHBSZXNwb25zZUV2ZW50LCB0IGFzIGhhbmRsZVJlcXVlc3QgfSBmcm9tIFwiLi9oYW5kbGUtcmVxdWVzdC15N2FqeXZlNS5qc1wiO1xuaW1wb3J0IHsgbiBhcyBwYXRjaGVzUmVnaXN0cnksIHQgYXMgaGFzQ29uZmlndXJhYmxlR2xvYmFsIH0gZnJvbSBcIi4vaGFzLWNvbmZpZ3VyYWJsZS1nbG9iYWwtQ2V3LWRZcWsuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJAb3Blbi1kcmFmdC91bnRpbFwiO1xuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QvdXRpbHMvY29uY2F0LWFycmF5LWJ1ZmZlci50c1xuLyoqXG4qIENvbmNhdGVuYXRlIHR3byBgVWludDhBcnJheWAgYnVmZmVycy5cbiovXG5mdW5jdGlvbiBjb25jYXRBcnJheUJ1ZmZlcihsZWZ0LCByaWdodCkge1xuXHRjb25zdCByZXN1bHQgPSBuZXcgVWludDhBcnJheShsZWZ0LmJ5dGVMZW5ndGggKyByaWdodC5ieXRlTGVuZ3RoKTtcblx0cmVzdWx0LnNldChsZWZ0LCAwKTtcblx0cmVzdWx0LnNldChyaWdodCwgbGVmdC5ieXRlTGVuZ3RoKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QvcG9seWZpbGxzL2V2ZW50LXBvbHlmaWxsLnRzXG52YXIgRXZlbnRQb2x5ZmlsbCA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IodHlwZSwgb3B0aW9ucykge1xuXHRcdHRoaXMuTk9ORSA9IDA7XG5cdFx0dGhpcy5DQVBUVVJJTkdfUEhBU0UgPSAxO1xuXHRcdHRoaXMuQVRfVEFSR0VUID0gMjtcblx0XHR0aGlzLkJVQkJMSU5HX1BIQVNFID0gMztcblx0XHR0aGlzLnR5cGUgPSBcIlwiO1xuXHRcdHRoaXMuc3JjRWxlbWVudCA9IG51bGw7XG5cdFx0dGhpcy5jdXJyZW50VGFyZ2V0ID0gbnVsbDtcblx0XHR0aGlzLmV2ZW50UGhhc2UgPSAwO1xuXHRcdHRoaXMuaXNUcnVzdGVkID0gdHJ1ZTtcblx0XHR0aGlzLmNvbXBvc2VkID0gZmFsc2U7XG5cdFx0dGhpcy5jYW5jZWxhYmxlID0gdHJ1ZTtcblx0XHR0aGlzLmRlZmF1bHRQcmV2ZW50ZWQgPSBmYWxzZTtcblx0XHR0aGlzLmJ1YmJsZXMgPSB0cnVlO1xuXHRcdHRoaXMubGVuZ3RoQ29tcHV0YWJsZSA9IHRydWU7XG5cdFx0dGhpcy5sb2FkZWQgPSAwO1xuXHRcdHRoaXMudG90YWwgPSAwO1xuXHRcdHRoaXMuY2FuY2VsQnViYmxlID0gZmFsc2U7XG5cdFx0dGhpcy5yZXR1cm5WYWx1ZSA9IHRydWU7XG5cdFx0dGhpcy50eXBlID0gdHlwZTtcblx0XHR0aGlzLnRhcmdldCA9IG9wdGlvbnM/LnRhcmdldCB8fCBudWxsO1xuXHRcdHRoaXMuY3VycmVudFRhcmdldCA9IG9wdGlvbnM/LmN1cnJlbnRUYXJnZXQgfHwgbnVsbDtcblx0XHR0aGlzLnRpbWVTdGFtcCA9IERhdGUubm93KCk7XG5cdH1cblx0Y29tcG9zZWRQYXRoKCkge1xuXHRcdHJldHVybiBbXTtcblx0fVxuXHRpbml0RXZlbnQodHlwZSwgYnViYmxlcywgY2FuY2VsYWJsZSkge1xuXHRcdHRoaXMudHlwZSA9IHR5cGU7XG5cdFx0dGhpcy5idWJibGVzID0gISFidWJibGVzO1xuXHRcdHRoaXMuY2FuY2VsYWJsZSA9ICEhY2FuY2VsYWJsZTtcblx0fVxuXHRwcmV2ZW50RGVmYXVsdCgpIHtcblx0XHR0aGlzLmRlZmF1bHRQcmV2ZW50ZWQgPSB0cnVlO1xuXHR9XG5cdHN0b3BQcm9wYWdhdGlvbigpIHt9XG5cdHN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpIHt9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC9wb2x5ZmlsbHMvcHJvZ3Jlc3MtZXZlbnQtcG9seWZpbGwudHNcbnZhciBQcm9ncmVzc0V2ZW50UG9seWZpbGwgPSBjbGFzcyBleHRlbmRzIEV2ZW50UG9seWZpbGwge1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBpbml0KSB7XG5cdFx0c3VwZXIodHlwZSk7XG5cdFx0dGhpcy5sZW5ndGhDb21wdXRhYmxlID0gaW5pdD8ubGVuZ3RoQ29tcHV0YWJsZSB8fCBmYWxzZTtcblx0XHR0aGlzLmNvbXBvc2VkID0gaW5pdD8uY29tcG9zZWQgfHwgZmFsc2U7XG5cdFx0dGhpcy5sb2FkZWQgPSBpbml0Py5sb2FkZWQgfHwgMDtcblx0XHR0aGlzLnRvdGFsID0gaW5pdD8udG90YWwgfHwgMDtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QvdXRpbHMvY3JlYXRlLWV2ZW50LnRzXG5jb25zdCBTVVBQT1JUU19QUk9HUkVTU19FVkVOVCA9IHR5cGVvZiBQcm9ncmVzc0V2ZW50ICE9PSBcInVuZGVmaW5lZFwiO1xuZnVuY3Rpb24gY3JlYXRlRXZlbnQodGFyZ2V0LCB0eXBlLCBpbml0KSB7XG5cdGNvbnN0IHByb2dyZXNzRXZlbnRzID0gW1xuXHRcdFwiZXJyb3JcIixcblx0XHRcInByb2dyZXNzXCIsXG5cdFx0XCJsb2Fkc3RhcnRcIixcblx0XHRcImxvYWRlbmRcIixcblx0XHRcImxvYWRcIixcblx0XHRcInRpbWVvdXRcIixcblx0XHRcImFib3J0XCJcblx0XTtcblx0LyoqXG5cdCogYFByb2dyZXNzRXZlbnRgIGlzIG5vdCBzdXBwb3J0ZWQgaW4gUmVhY3QgTmF0aXZlLlxuXHQqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL2ludGVyY2VwdG9ycy9pc3N1ZXMvNDBcblx0Ki9cblx0Y29uc3QgUHJvZ3Jlc3NFdmVudENsYXNzID0gU1VQUE9SVFNfUFJPR1JFU1NfRVZFTlQgPyBQcm9ncmVzc0V2ZW50IDogUHJvZ3Jlc3NFdmVudFBvbHlmaWxsO1xuXHRyZXR1cm4gcHJvZ3Jlc3NFdmVudHMuaW5jbHVkZXModHlwZSkgPyBuZXcgUHJvZ3Jlc3NFdmVudENsYXNzKHR5cGUsIHtcblx0XHRsZW5ndGhDb21wdXRhYmxlOiB0cnVlLFxuXHRcdGxvYWRlZDogaW5pdD8ubG9hZGVkIHx8IDAsXG5cdFx0dG90YWw6IGluaXQ/LnRvdGFsIHx8IDBcblx0fSkgOiBuZXcgRXZlbnRQb2x5ZmlsbCh0eXBlLCB7XG5cdFx0dGFyZ2V0LFxuXHRcdGN1cnJlbnRUYXJnZXQ6IHRhcmdldFxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9maW5kLXByb3BlcnR5LXNvdXJjZS50c1xuLyoqXG4qIFJldHVybnMgdGhlIHNvdXJjZSBvYmplY3Qgb2YgdGhlIGdpdmVuIHByb3BlcnR5IG9uIHRoZSB0YXJnZXQgb2JqZWN0XG4qICh0aGUgdGFyZ2V0IGl0c2VsZiwgYW55IHBhcmVudCBpbiBpdHMgcHJvdG90eXBlLCBvciBudWxsKS5cbiovXG5mdW5jdGlvbiBmaW5kUHJvcGVydHlTb3VyY2UodGFyZ2V0LCBwcm9wZXJ0eU5hbWUpIHtcblx0aWYgKCEocHJvcGVydHlOYW1lIGluIHRhcmdldCkpIHJldHVybiBudWxsO1xuXHRpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHRhcmdldCwgcHJvcGVydHlOYW1lKSkgcmV0dXJuIHRhcmdldDtcblx0Y29uc3QgcHJvdG90eXBlID0gUmVmbGVjdC5nZXRQcm90b3R5cGVPZih0YXJnZXQpO1xuXHRyZXR1cm4gcHJvdG90eXBlID8gZmluZFByb3BlcnR5U291cmNlKHByb3RvdHlwZSwgcHJvcGVydHlOYW1lKSA6IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvY3JlYXRlLXByb3h5LnRzXG5mdW5jdGlvbiBjcmVhdGVQcm94eSh0YXJnZXQsIG9wdGlvbnMpIHtcblx0cmV0dXJuIG5ldyBQcm94eSh0YXJnZXQsIG9wdGlvbnNUb1Byb3h5SGFuZGxlcihvcHRpb25zKSk7XG59XG5mdW5jdGlvbiBvcHRpb25zVG9Qcm94eUhhbmRsZXIob3B0aW9ucykge1xuXHRjb25zdCB7IGNvbnN0cnVjdG9yQ2FsbCwgbWV0aG9kQ2FsbCwgZ2V0UHJvcGVydHksIHNldFByb3BlcnR5IH0gPSBvcHRpb25zO1xuXHRjb25zdCBoYW5kbGVyID0ge307XG5cdGlmICh0eXBlb2YgY29uc3RydWN0b3JDYWxsICE9PSBcInVuZGVmaW5lZFwiKSBoYW5kbGVyLmNvbnN0cnVjdCA9IGZ1bmN0aW9uKHRhcmdldCwgYXJncywgbmV3VGFyZ2V0KSB7XG5cdFx0Y29uc3QgbmV4dCA9IFJlZmxlY3QuY29uc3RydWN0LmJpbmQobnVsbCwgdGFyZ2V0LCBhcmdzLCBuZXdUYXJnZXQpO1xuXHRcdHJldHVybiBjb25zdHJ1Y3RvckNhbGwuY2FsbChuZXdUYXJnZXQsIGFyZ3MsIG5leHQpO1xuXHR9O1xuXHRoYW5kbGVyLnNldCA9IGZ1bmN0aW9uKHRhcmdldCwgcHJvcGVydHlOYW1lLCBuZXh0VmFsdWUpIHtcblx0XHRjb25zdCBuZXh0ID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgcHJvcGVydHlTb3VyY2UgPSBmaW5kUHJvcGVydHlTb3VyY2UodGFyZ2V0LCBwcm9wZXJ0eU5hbWUpIHx8IHRhcmdldDtcblx0XHRcdGNvbnN0IG93bkRlc2NyaXB0b3JzID0gUmVmbGVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvcGVydHlTb3VyY2UsIHByb3BlcnR5TmFtZSk7XG5cdFx0XHRpZiAodHlwZW9mIG93bkRlc2NyaXB0b3JzPy5zZXQgIT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdFx0b3duRGVzY3JpcHRvcnMuc2V0LmFwcGx5KHRhcmdldCwgW25leHRWYWx1ZV0pO1xuXHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBSZWZsZWN0LmRlZmluZVByb3BlcnR5KHByb3BlcnR5U291cmNlLCBwcm9wZXJ0eU5hbWUsIHtcblx0XHRcdFx0d3JpdGFibGU6IHRydWUsXG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGNvbmZpZ3VyYWJsZTogdHJ1ZSxcblx0XHRcdFx0dmFsdWU6IG5leHRWYWx1ZVxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHRpZiAodHlwZW9mIHNldFByb3BlcnR5ICE9PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gc2V0UHJvcGVydHkuY2FsbCh0YXJnZXQsIFtwcm9wZXJ0eU5hbWUsIG5leHRWYWx1ZV0sIG5leHQpO1xuXHRcdHJldHVybiBuZXh0KCk7XG5cdH07XG5cdGhhbmRsZXIuZ2V0ID0gZnVuY3Rpb24odGFyZ2V0LCBwcm9wZXJ0eU5hbWUsIHJlY2VpdmVyKSB7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBVc2luZyBgUmVmbGVjdC5nZXQoKWAgaGVyZSBjYXVzZXMgXCJUeXBlRXJyb3I6IElsbGVnYWwgaW52b2NhdGlvblwiLlxuXHRcdCovXG5cdFx0Y29uc3QgbmV4dCA9ICgpID0+IHRhcmdldFtwcm9wZXJ0eU5hbWVdO1xuXHRcdGNvbnN0IHZhbHVlID0gdHlwZW9mIGdldFByb3BlcnR5ICE9PSBcInVuZGVmaW5lZFwiID8gZ2V0UHJvcGVydHkuY2FsbCh0YXJnZXQsIFtwcm9wZXJ0eU5hbWUsIHJlY2VpdmVyXSwgbmV4dCkgOiBuZXh0KCk7XG5cdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gKC4uLmFyZ3MpID0+IHtcblx0XHRcdGNvbnN0IG5leHQgPSB2YWx1ZS5iaW5kKHRhcmdldCwgLi4uYXJncyk7XG5cdFx0XHRpZiAodHlwZW9mIG1ldGhvZENhbGwgIT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBtZXRob2RDYWxsLmNhbGwodGFyZ2V0LCBbcHJvcGVydHlOYW1lLCBhcmdzXSwgbmV4dCk7XG5cdFx0XHRyZXR1cm4gbmV4dCgpO1xuXHRcdH07XG5cdFx0cmV0dXJuIHZhbHVlO1xuXHR9O1xuXHRyZXR1cm4gaGFuZGxlcjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QvdXRpbHMvaXMtZG9tLXBhcnNlci1zdXBwb3J0ZWQtdHlwZS50c1xuZnVuY3Rpb24gaXNEb21QYXJzZXJTdXBwb3J0ZWRUeXBlKHR5cGUpIHtcblx0cmV0dXJuIFtcblx0XHRcImFwcGxpY2F0aW9uL3hodG1sK3htbFwiLFxuXHRcdFwiYXBwbGljYXRpb24veG1sXCIsXG5cdFx0XCJpbWFnZS9zdmcreG1sXCIsXG5cdFx0XCJ0ZXh0L2h0bWxcIixcblx0XHRcInRleHQveG1sXCJcblx0XS5zb21lKChzdXBwb3J0ZWRUeXBlKSA9PiB7XG5cdFx0cmV0dXJuIHR5cGUuc3RhcnRzV2l0aChzdXBwb3J0ZWRUeXBlKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvcGFyc2UtanNvbi50c1xuLyoqXG4qIFBhcnNlcyBhIGdpdmVuIHN0cmluZyBpbnRvIEpTT04uXG4qIEdyYWNlZnVsbHkgaGFuZGxlcyBpbnZhbGlkIEpTT04gYnkgcmV0dXJuaW5nIGBudWxsYC5cbiovXG5mdW5jdGlvbiBwYXJzZUpzb24oZGF0YSkge1xuXHR0cnkge1xuXHRcdHJldHVybiBKU09OLnBhcnNlKGRhdGEpO1xuXHR9IGNhdGNoIChfKSB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QvdXRpbHMvY3JlYXRlLXJlc3BvbnNlLnRzXG4vKipcbiogQ3JlYXRlcyBhIEZldGNoIEFQSSBgUmVzcG9uc2VgIGluc3RhbmNlIGZyb20gdGhlIGdpdmVuXG4qIGBYTUxIdHRwUmVxdWVzdGAgaW5zdGFuY2UgYW5kIGEgcmVzcG9uc2UgYm9keS5cbiovXG5mdW5jdGlvbiBjcmVhdGVSZXNwb25zZShyZXF1ZXN0LCBib2R5KSB7XG5cdC8qKlxuXHQqIEhhbmRsZSBYTUxIdHRwUmVxdWVzdCByZXNwb25zZXMgdGhhdCBtdXN0IGhhdmUgbnVsbCBhcyB0aGVcblx0KiByZXNwb25zZSBib2R5IHdoZW4gcmVwcmVzZW50ZWQgdXNpbmcgRmV0Y2ggQVBJIFJlc3BvbnNlLlxuXHQqIFhNTEh0dHBSZXF1ZXN0IHJlc3BvbnNlIHdpbGwgYWx3YXlzIGhhdmUgYW4gZW1wdHkgc3RyaW5nXG5cdCogYXMgdGhlIFwicmVxdWVzdC5yZXNwb25zZVwiIGluIHRob3NlIGNhc2VzLCByZXN1bHRpbmcgaW4gYW4gZXJyb3Jcblx0KiB3aGVuIGNvbnN0cnVjdGluZyBhIFJlc3BvbnNlIGluc3RhbmNlLlxuXHQqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL2ludGVyY2VwdG9ycy9pc3N1ZXMvMzc5XG5cdCovXG5cdGNvbnN0IHJlc3BvbnNlQm9keU9yTnVsbCA9IEZldGNoUmVzcG9uc2UuaXNSZXNwb25zZVdpdGhCb2R5KHJlcXVlc3Quc3RhdHVzKSA/IGJvZHkgOiBudWxsO1xuXHRyZXR1cm4gbmV3IEZldGNoUmVzcG9uc2UocmVzcG9uc2VCb2R5T3JOdWxsLCB7XG5cdFx0dXJsOiByZXF1ZXN0LnJlc3BvbnNlVVJMLFxuXHRcdHN0YXR1czogcmVxdWVzdC5zdGF0dXMsXG5cdFx0c3RhdHVzVGV4dDogcmVxdWVzdC5zdGF0dXNUZXh0LFxuXHRcdGhlYWRlcnM6IGNyZWF0ZUhlYWRlcnNGcm9tWE1MSHR0cFJlcXVlc3RIZWFkZXJzKHJlcXVlc3QuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzKCkpXG5cdH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlSGVhZGVyc0Zyb21YTUxIdHRwUmVxdWVzdEhlYWRlcnMoaGVhZGVyc1N0cmluZykge1xuXHRjb25zdCBoZWFkZXJzID0gbmV3IEhlYWRlcnMoKTtcblx0Y29uc3QgbGluZXMgPSBoZWFkZXJzU3RyaW5nLnNwbGl0KC9bXFxyXFxuXSsvKTtcblx0Zm9yIChjb25zdCBsaW5lIG9mIGxpbmVzKSB7XG5cdFx0aWYgKGxpbmUudHJpbSgpID09PSBcIlwiKSBjb250aW51ZTtcblx0XHRjb25zdCBbbmFtZSwgLi4ucGFydHNdID0gbGluZS5zcGxpdChcIjogXCIpO1xuXHRcdGNvbnN0IHZhbHVlID0gcGFydHMuam9pbihcIjogXCIpO1xuXHRcdGhlYWRlcnMuYXBwZW5kKG5hbWUsIHZhbHVlKTtcblx0fVxuXHRyZXR1cm4gaGVhZGVycztcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QvdXRpbHMvZ2V0LWJvZHktYnl0ZS1sZW5ndGgudHNcbi8qKlxuKiBSZXR1cm4gYSB0b3RhbCBieXRlIGxlbmd0aCBvZiB0aGUgZ2l2ZW4gcmVxdWVzdC9yZXNwb25zZSBib2R5LlxuKiBJZiB0aGUgYENvbnRlbnQtTGVuZ3RoYCBoZWFkZXIgaXMgcHJlc2VudCwgaXQgd2lsbCBiZSB1c2VkIGFzIHRoZSBieXRlIGxlbmd0aC5cbiovXG5hc3luYyBmdW5jdGlvbiBnZXRCb2R5Qnl0ZUxlbmd0aChpbnB1dCkge1xuXHRjb25zdCBleHBsaWNpdENvbnRlbnRMZW5ndGggPSBpbnB1dC5oZWFkZXJzLmdldChcImNvbnRlbnQtbGVuZ3RoXCIpO1xuXHRpZiAoZXhwbGljaXRDb250ZW50TGVuZ3RoICE9IG51bGwgJiYgZXhwbGljaXRDb250ZW50TGVuZ3RoICE9PSBcIlwiKSByZXR1cm4gTnVtYmVyKGV4cGxpY2l0Q29udGVudExlbmd0aCk7XG5cdHJldHVybiAoYXdhaXQgaW5wdXQuYXJyYXlCdWZmZXIoKSkuYnl0ZUxlbmd0aDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QveG1sLWh0dHAtcmVxdWVzdC1jb250cm9sbGVyLnRzXG5jb25zdCBrSXNSZXF1ZXN0SGFuZGxlZCA9IFN5bWJvbChcImtJc1JlcXVlc3RIYW5kbGVkXCIpO1xuY29uc3Qga0ZldGNoUmVxdWVzdCA9IFN5bWJvbChcImtGZXRjaFJlcXVlc3RcIik7XG5jb25zdCBNQVhfUkVESVJFQ1RTID0gMjA7XG4vKipcbiogQW4gYFhNTEh0dHBSZXF1ZXN0YCBpbnN0YW5jZSBjb250cm9sbGVyIHRoYXQgYWxsb3dzIHVzXG4qIHRvIGhhbmRsZSBhbnkgZ2l2ZW4gcmVxdWVzdCBpbnN0YW5jZSAoZS5nLiByZXNwb25kaW5nIHRvIGl0KS5cbiovXG52YXIgWE1MSHR0cFJlcXVlc3RDb250cm9sbGVyID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcihpbml0aWFsUmVxdWVzdCwgbG9nZ2VyKSB7XG5cdFx0dGhpcy5pbml0aWFsUmVxdWVzdCA9IGluaXRpYWxSZXF1ZXN0O1xuXHRcdHRoaXMubG9nZ2VyID0gbG9nZ2VyO1xuXHRcdHRoaXMuc3luYyA9IGZhbHNlO1xuXHRcdHRoaXMubWV0aG9kID0gXCJHRVRcIjtcblx0XHR0aGlzLnVybCA9IG51bGw7XG5cdFx0dGhpc1trSXNSZXF1ZXN0SGFuZGxlZF0gPSBmYWxzZTtcblx0XHR0aGlzLnJlZGlyZWN0Q291bnQgPSAwO1xuXHRcdHRoaXMuZXZlbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLnVwbG9hZEV2ZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy5yZXF1ZXN0SWQgPSBjcmVhdGVSZXF1ZXN0SWQoKTtcblx0XHR0aGlzLnJlcXVlc3RIZWFkZXJzID0gbmV3IEhlYWRlcnMoKTtcblx0XHR0aGlzLnJlc3BvbnNlQnVmZmVyID0gLyogQF9fUFVSRV9fICovIG5ldyBVaW50OEFycmF5KCk7XG5cdFx0dGhpcy5yZXF1ZXN0ID0gY3JlYXRlUHJveHkoaW5pdGlhbFJlcXVlc3QsIHsgbWV0aG9kQ2FsbDogKFttZXRob2ROYW1lLCBhcmdzXSwgaW52b2tlKSA9PiB7XG5cdFx0XHRzd2l0Y2ggKG1ldGhvZE5hbWUpIHtcblx0XHRcdFx0Y2FzZSBcIm9wZW5cIjoge1xuXHRcdFx0XHRcdGNvbnN0IFttZXRob2QsIHVybCwgYXN5bmNdID0gYXJncztcblx0XHRcdFx0XHR0aGlzLnN5bmMgPSAhKGFzeW5jID8/IHRydWUpO1xuXHRcdFx0XHRcdGlmICh0eXBlb2YgdXJsID09PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0XHRcdFx0XHR0aGlzLm1ldGhvZCA9IFwiR0VUXCI7XG5cdFx0XHRcdFx0XHR0aGlzLnVybCA9IHRvQWJzb2x1dGVVcmwobWV0aG9kKTtcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0dGhpcy5tZXRob2QgPSBtZXRob2Q7XG5cdFx0XHRcdFx0XHR0aGlzLnVybCA9IHRvQWJzb2x1dGVVcmwodXJsKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcIm9wZW4gJXMgJXNcIiwgdGhpcy5tZXRob2QsIHRoaXMudXJsLmhyZWYpO1xuXHRcdFx0XHRcdHJldHVybiBpbnZva2UoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjYXNlIFwiYWRkRXZlbnRMaXN0ZW5lclwiOiB7XG5cdFx0XHRcdFx0Y29uc3QgW2V2ZW50TmFtZSwgbGlzdGVuZXJdID0gYXJncztcblx0XHRcdFx0XHR0aGlzLnJlZ2lzdGVyRXZlbnQoZXZlbnROYW1lLCBsaXN0ZW5lcik7XG5cdFx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImFkZEV2ZW50TGlzdGVuZXJcIiwgZXZlbnROYW1lLCBsaXN0ZW5lcik7XG5cdFx0XHRcdFx0cmV0dXJuIGludm9rZSgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhc2UgXCJzZXRSZXF1ZXN0SGVhZGVyXCI6IHtcblx0XHRcdFx0XHRjb25zdCBbbmFtZSwgdmFsdWVdID0gYXJncztcblx0XHRcdFx0XHR0aGlzLnJlcXVlc3RIZWFkZXJzLnNldChuYW1lLCB2YWx1ZSk7XG5cdFx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInNldFJlcXVlc3RIZWFkZXJcIiwgbmFtZSwgdmFsdWUpO1xuXHRcdFx0XHRcdHJldHVybiBpbnZva2UoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjYXNlIFwic2VuZFwiOiB7XG5cdFx0XHRcdFx0Y29uc3QgW2JvZHldID0gYXJncztcblx0XHRcdFx0XHRpZiAodGhpcy5zeW5jKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLndhcm4oYEZhaWxlZCB0byBpbnRlcmNlcHQgYW4gWE1MSHR0cFJlcXVlc3QgKCR7dGhpcy5tZXRob2R9ICR7dGhpcy51cmx9KTogc3luY2hyb25vdXMgcmVxdWVzdHMgYXJlIG5vdCBzdXBwb3J0ZWQuIFRoaXMgcmVxdWVzdCB3aWxsIGJlIHBlcmZvcm1lZCBhcy1pcy5gKTtcblx0XHRcdFx0XHRcdHJldHVybiBpbnZva2UoKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dGhpcy5yZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsICgpID0+IHtcblx0XHRcdFx0XHRcdGlmICh0eXBlb2YgdGhpcy5vblJlc3BvbnNlICE9PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IGZldGNoUmVzcG9uc2UgPSBjcmVhdGVSZXNwb25zZShcblx0XHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3QsXG5cdFx0XHRcdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0XHRcdFx0KiBUaGUgYHJlc3BvbnNlYCBwcm9wZXJ0eSBpcyB0aGUgcmlnaHQgd2F5IHRvIHJlYWRcblx0XHRcdFx0XHRcdFx0XHQqIHRoZSBhbWJpZ3VvdXMgcmVzcG9uc2UgYm9keSwgYXMgdGhlIHJlcXVlc3QncyBcInJlc3BvbnNlVHlwZVwiIG1heSBkaWZmZXIuXG5cdFx0XHRcdFx0XHRcdFx0KiBAc2VlIGh0dHBzOi8veGhyLnNwZWMud2hhdHdnLm9yZy8jdGhlLXJlc3BvbnNlLWF0dHJpYnV0ZVxuXHRcdFx0XHRcdFx0XHRcdCovXG5cdFx0XHRcdFx0XHRcdFx0dGhpcy5yZXF1ZXN0LnJlc3BvbnNlXG5cdFx0XHRcdFx0XHRcdCk7XG5cdFx0XHRcdFx0XHRcdHRoaXMub25SZXNwb25zZS5jYWxsKHRoaXMsIHtcblx0XHRcdFx0XHRcdFx0XHRyZXNwb25zZTogZmV0Y2hSZXNwb25zZSxcblx0XHRcdFx0XHRcdFx0XHRyZXNwb25zZVR5cGU6IHRoaXNba0lzUmVxdWVzdEhhbmRsZWRdID8gXCJtb2NrXCIgOiBcIm9yaWdpbmFsXCIsXG5cdFx0XHRcdFx0XHRcdFx0cmVxdWVzdDogZmV0Y2hSZXF1ZXN0LFxuXHRcdFx0XHRcdFx0XHRcdHJlcXVlc3RJZDogdGhpcy5yZXF1ZXN0SWRcblx0XHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0Y29uc3QgcmVxdWVzdEJvZHkgPSB0eXBlb2YgYm9keSA9PT0gXCJzdHJpbmdcIiA/IGVuY29kZUJ1ZmZlcihib2R5KSA6IGJvZHk7XG5cdFx0XHRcdFx0Y29uc3QgZmV0Y2hSZXF1ZXN0ID0gdGhpcy50b0ZldGNoQXBpUmVxdWVzdChyZXF1ZXN0Qm9keSk7XG5cdFx0XHRcdFx0dGhpc1trRmV0Y2hSZXF1ZXN0XSA9IGZldGNoUmVxdWVzdC5jbG9uZSgpO1xuXHRcdFx0XHRcdC8qKlxuXHRcdFx0XHRcdCogQG5vdGUgU3RhcnQgcmVxdWVzdCBoYW5kbGluZyBvbiB0aGUgbmV4dCB0aWNrIHNvIHRoYXQgdGhlIHVzZXJcblx0XHRcdFx0XHQqIGNvdWxkIGFkZCBldmVudCBsaXN0ZW5lcnMgZm9yIFwibG9hZGVuZFwiIGJlZm9yZSB0aGUgaW50ZXJjZXB0b3IgZmlyZXMgaXQuXG5cdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0XHRcdFx0XHQodGhpcy5vblJlcXVlc3Q/LmNhbGwodGhpcywge1xuXHRcdFx0XHRcdFx0XHRyZXF1ZXN0OiBmZXRjaFJlcXVlc3QsXG5cdFx0XHRcdFx0XHRcdHJlcXVlc3RJZDogdGhpcy5yZXF1ZXN0SWRcblx0XHRcdFx0XHRcdH0pIHx8IFByb21pc2UucmVzb2x2ZSgpKS5maW5hbGx5KCgpID0+IHtcblx0XHRcdFx0XHRcdFx0aWYgKCF0aGlzW2tJc1JlcXVlc3RIYW5kbGVkXSkge1xuXHRcdFx0XHRcdFx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZXF1ZXN0IGNhbGxiYWNrIHNldHRsZWQgYnV0IHJlcXVlc3QgaGFzIG5vdCBiZWVuIGhhbmRsZWQgKHJlYWR5c3RhdGUgJWQpLCBwZXJmb3JtaW5nIGFzLWlzLi4uXCIsIHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlKTtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm4gaW52b2tlKCk7XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGRlZmF1bHQ6IHJldHVybiBpbnZva2UoKTtcblx0XHRcdH1cblx0XHR9IH0pO1xuXHRcdC8qKlxuXHRcdCogUHJveHkgdGhlIGAudXBsb2FkYCBwcm9wZXJ0eSB0byBnYXRoZXIgdGhlIGV2ZW50IGxpc3RlbmVycy9jYWxsYmFja3MuXG5cdFx0Ki9cblx0XHRkZWZpbmUodGhpcy5yZXF1ZXN0LCBcInVwbG9hZFwiLCBjcmVhdGVQcm94eSh0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRzZXRQcm9wZXJ0eTogKFtwcm9wZXJ0eU5hbWUsIG5leHRWYWx1ZV0sIGludm9rZSkgPT4ge1xuXHRcdFx0XHRzd2l0Y2ggKHByb3BlcnR5TmFtZSkge1xuXHRcdFx0XHRcdGNhc2UgXCJvbmxvYWRzdGFydFwiOlxuXHRcdFx0XHRcdGNhc2UgXCJvbnByb2dyZXNzXCI6XG5cdFx0XHRcdFx0Y2FzZSBcIm9uYWJvYXJ0XCI6XG5cdFx0XHRcdFx0Y2FzZSBcIm9uZXJyb3JcIjpcblx0XHRcdFx0XHRjYXNlIFwib25sb2FkXCI6XG5cdFx0XHRcdFx0Y2FzZSBcIm9udGltZW91dFwiOlxuXHRcdFx0XHRcdGNhc2UgXCJvbmxvYWRlbmRcIjoge1xuXHRcdFx0XHRcdFx0Y29uc3QgZXZlbnROYW1lID0gcHJvcGVydHlOYW1lLnNsaWNlKDIpO1xuXHRcdFx0XHRcdFx0dGhpcy5yZWdpc3RlclVwbG9hZEV2ZW50KGV2ZW50TmFtZSwgbmV4dFZhbHVlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGludm9rZSgpO1xuXHRcdFx0fSxcblx0XHRcdG1ldGhvZENhbGw6IChbbWV0aG9kTmFtZSwgYXJnc10sIGludm9rZSkgPT4ge1xuXHRcdFx0XHRzd2l0Y2ggKG1ldGhvZE5hbWUpIHtcblx0XHRcdFx0XHRjYXNlIFwiYWRkRXZlbnRMaXN0ZW5lclwiOiB7XG5cdFx0XHRcdFx0XHRjb25zdCBbZXZlbnROYW1lLCBsaXN0ZW5lcl0gPSBhcmdzO1xuXHRcdFx0XHRcdFx0dGhpcy5yZWdpc3RlclVwbG9hZEV2ZW50KGV2ZW50TmFtZSwgbGlzdGVuZXIpO1xuXHRcdFx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInVwbG9hZC5hZGRFdmVudExpc3RlbmVyXCIsIGV2ZW50TmFtZSwgbGlzdGVuZXIpO1xuXHRcdFx0XHRcdFx0cmV0dXJuIGludm9rZSgpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pKTtcblx0fVxuXHRyZWdpc3RlckV2ZW50KGV2ZW50TmFtZSwgbGlzdGVuZXIpIHtcblx0XHRjb25zdCBuZXh0RXZlbnRzID0gKHRoaXMuZXZlbnRzLmdldChldmVudE5hbWUpIHx8IFtdKS5jb25jYXQobGlzdGVuZXIpO1xuXHRcdHRoaXMuZXZlbnRzLnNldChldmVudE5hbWUsIG5leHRFdmVudHMpO1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZWdpc3RlcmVkIGV2ZW50IFxcXCIlc1xcXCJcIiwgZXZlbnROYW1lLCBsaXN0ZW5lcik7XG5cdH1cblx0cmVnaXN0ZXJVcGxvYWRFdmVudChldmVudE5hbWUsIGxpc3RlbmVyKSB7XG5cdFx0Y29uc3QgbmV4dEV2ZW50cyA9ICh0aGlzLnVwbG9hZEV2ZW50cy5nZXQoZXZlbnROYW1lKSB8fCBbXSkuY29uY2F0KGxpc3RlbmVyKTtcblx0XHR0aGlzLnVwbG9hZEV2ZW50cy5zZXQoZXZlbnROYW1lLCBuZXh0RXZlbnRzKTtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVnaXN0ZXJlZCB1cGxvYWQgZXZlbnQgXFxcIiVzXFxcIlwiLCBldmVudE5hbWUsIGxpc3RlbmVyKTtcblx0fVxuXHQvKipcblx0KiBSZXNwb25kcyB0byB0aGUgY3VycmVudCByZXF1ZXN0IHdpdGggdGhlIGdpdmVuXG5cdCogRmV0Y2ggQVBJIGBSZXNwb25zZWAgaW5zdGFuY2UuXG5cdCovXG5cdGFzeW5jIHJlc3BvbmRXaXRoKHJlc3BvbnNlKSB7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBTaW5jZSBgWE1MSHR0cFJlcXVlc3RDb250cm9sbGVyYCBkZWxlZ2F0ZXMgdGhlIGhhbmRsaW5nIG9mIHRoZSByZXNwb25zZXNcblx0XHQqIHRvIHRoZSBcImxvYWRcIiBldmVudCBsaXN0ZW5lciB0aGF0IGRvZXNuJ3QgZGlzdGluZ3Vpc2ggYmV0d2VlbiB0aGUgbW9ja2VkIGFuZCBvcmlnaW5hbFxuXHRcdCogcmVzcG9uc2VzLCBtYXJrIHRoZSByZXF1ZXN0IHRoYXQgaGFkIGEgbW9ja2VkIHJlc3BvbnNlIHdpdGggYSBjb3JyZXNwb25kaW5nIHN5bWJvbC5cblx0XHQqXG5cdFx0KiBNYXJrIHRoaXMgcmVxdWVzdCBhcyBoYXZpbmcgYSBtb2NrZWQgcmVzcG9uc2UgaW1tZWRpYXRlbHkgc2luY2Vcblx0XHQqIGNhbGN1bGF0aW5nIHJlcXVlc3QvcmVzcG9uc2UgdG90YWwgYm9keSBsZW5ndGggaXMgYXN5bmNocm9ub3VzLlxuXHRcdCovXG5cdFx0dGhpc1trSXNSZXF1ZXN0SGFuZGxlZF0gPSB0cnVlO1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZXNwb25kaW5nIHdpdGggYSBtb2NrZWQgcmVzcG9uc2U6ICVkICVzXCIsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2Uuc3RhdHVzVGV4dCk7XG5cdFx0RmV0Y2hSZXNwb25zZS5zZXRVcmwodGhpcy51cmwuaHJlZiwgcmVzcG9uc2UpO1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHRoaXMucmVxdWVzdCwge1xuXHRcdFx0cmVzcG9uc2U6IHtcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiBmYWxzZSxcblx0XHRcdFx0Z2V0OiAoKSA9PiB0aGlzLnJlc3BvbnNlXG5cdFx0XHR9LFxuXHRcdFx0cmVzcG9uc2VUZXh0OiB7XG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGNvbmZpZ3VyYWJsZTogZmFsc2UsXG5cdFx0XHRcdGdldDogKCkgPT4gdGhpcy5yZXNwb25zZVRleHRcblx0XHRcdH0sXG5cdFx0XHRyZXNwb25zZVhNTDoge1xuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuXHRcdFx0XHRnZXQ6ICgpID0+IHRoaXMucmVzcG9uc2VYTUxcblx0XHRcdH1cblx0XHR9KTtcblx0XHR0aGlzLnRyaWdnZXIoXCJsb2Fkc3RhcnRcIiwgdGhpcy5yZXF1ZXN0LCB7XG5cdFx0XHRsb2FkZWQ6IDAsXG5cdFx0XHR0b3RhbDogMFxuXHRcdH0pO1xuXHRcdGxldCByZXF1ZXN0Qm9keVRyYW5zbWl0dGVkID0gMDtcblx0XHRsZXQgdXBsb2FkQ29tcGxldGUgPSBmYWxzZTtcblx0XHRpZiAodGhpc1trRmV0Y2hSZXF1ZXN0XSkge1xuXHRcdFx0Y29uc3QgcmVxdWVzdEJvZHlMZW5ndGggPSBhd2FpdCBnZXRCb2R5Qnl0ZUxlbmd0aCh0aGlzW2tGZXRjaFJlcXVlc3RdLmNsb25lKCkpO1xuXHRcdFx0aWYgKCF1cGxvYWRDb21wbGV0ZSkgdGhpcy50cmlnZ2VyKFwibG9hZHN0YXJ0XCIsIHRoaXMucmVxdWVzdC51cGxvYWQsIHtcblx0XHRcdFx0bG9hZGVkOiAwLFxuXHRcdFx0XHR0b3RhbDogcmVxdWVzdEJvZHlMZW5ndGhcblx0XHRcdH0pO1xuXHRcdFx0Y29uc3QgcHJvY2Vzc1JlcXVlc3RCb2R5Q2h1bmtMZW5ndGggPSAoYnl0ZXNMZW5ndGgpID0+IHtcblx0XHRcdFx0cmVxdWVzdEJvZHlUcmFuc21pdHRlZCArPSBieXRlc0xlbmd0aDtcblx0XHRcdFx0aWYgKHJlcXVlc3RCb2R5VHJhbnNtaXR0ZWQgPCByZXF1ZXN0Qm9keUxlbmd0aCkgdGhpcy50cmlnZ2VyKFwicHJvZ3Jlc3NcIiwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuXHRcdFx0XHRcdGxvYWRlZDogcmVxdWVzdEJvZHlUcmFuc21pdHRlZCxcblx0XHRcdFx0XHR0b3RhbDogcmVxdWVzdEJvZHlMZW5ndGhcblx0XHRcdFx0fSk7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcHJvY2Vzc1JlcXVlc3RFbmRPZkJvZHkgPSAoKSA9PiB7XG5cdFx0XHRcdHVwbG9hZENvbXBsZXRlID0gdHJ1ZTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwicHJvZ3Jlc3NcIiwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuXHRcdFx0XHRcdGxvYWRlZDogcmVxdWVzdEJvZHlUcmFuc21pdHRlZCxcblx0XHRcdFx0XHR0b3RhbDogcmVxdWVzdEJvZHlMZW5ndGhcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHRoaXMudHJpZ2dlcihcImxvYWRcIiwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuXHRcdFx0XHRcdGxvYWRlZDogcmVxdWVzdEJvZHlUcmFuc21pdHRlZCxcblx0XHRcdFx0XHR0b3RhbDogcmVxdWVzdEJvZHlMZW5ndGhcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHRoaXMudHJpZ2dlcihcImxvYWRlbmRcIiwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuXHRcdFx0XHRcdGxvYWRlZDogcmVxdWVzdEJvZHlUcmFuc21pdHRlZCxcblx0XHRcdFx0XHR0b3RhbDogcmVxdWVzdEJvZHlMZW5ndGhcblx0XHRcdFx0fSk7XG5cdFx0XHR9O1xuXHRcdFx0aWYgKHRoaXNba0ZldGNoUmVxdWVzdF0/LmJvZHkgIT0gbnVsbCkge1xuXHRcdFx0XHRjb25zdCByZWFkZXIgPSB0aGlzW2tGZXRjaFJlcXVlc3RdLmJvZHkuZ2V0UmVhZGVyKCk7XG5cdFx0XHRcdHdoaWxlICh0cnVlKSB7XG5cdFx0XHRcdFx0Y29uc3QgeyB2YWx1ZSwgZG9uZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcblx0XHRcdFx0XHRpZiAoZG9uZSkge1xuXHRcdFx0XHRcdFx0cHJvY2Vzc1JlcXVlc3RFbmRPZkJvZHkoKTtcblx0XHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRwcm9jZXNzUmVxdWVzdEJvZHlDaHVua0xlbmd0aCh2YWx1ZS5ieXRlTGVuZ3RoKTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHByb2Nlc3NSZXF1ZXN0RW5kT2ZCb2R5KCk7XG5cdFx0fVxuXHRcdGxldCB0aW1lZE91dCA9IGZhbHNlO1xuXHRcdGNvbnN0IHJlc3BvbnNlUmVhZENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0Y29uc3QgcmVxdWVzdEVycm9yU3RlcHMgPSAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuc2V0UmVhZHlTdGF0ZSh0aGlzLnJlcXVlc3QuRE9ORSk7XG5cdFx0XHRpZiAoIXVwbG9hZENvbXBsZXRlKSB7XG5cdFx0XHRcdHRoaXMudHJpZ2dlcihldmVudCwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuXHRcdFx0XHRcdGxvYWRlZDogMCxcblx0XHRcdFx0XHR0b3RhbDogMFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwibG9hZGVuZFwiLCB0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRcdFx0bG9hZGVkOiAwLFxuXHRcdFx0XHRcdHRvdGFsOiAwXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy50cmlnZ2VyKGV2ZW50LCB0aGlzLnJlcXVlc3QsIHtcblx0XHRcdFx0bG9hZGVkOiAwLFxuXHRcdFx0XHR0b3RhbDogMFxuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLnRyaWdnZXIoXCJsb2FkZW5kXCIsIHRoaXMucmVxdWVzdCwge1xuXHRcdFx0XHRsb2FkZWQ6IDAsXG5cdFx0XHRcdHRvdGFsOiAwXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdGNvbnN0IHByb2Nlc3NSZXNwb25zZSA9IGFzeW5jIChyZXNwb25zZSkgPT4ge1xuXHRcdFx0Y29uc3QgaGFuZGxlRXJyb3JzID0gKCkgPT4ge1xuXHRcdFx0XHRpZiAodGltZWRPdXQpIHJlcXVlc3RFcnJvclN0ZXBzKFwidGltZW91dFwiKTtcblx0XHRcdFx0ZWxzZSBpZiAocmVzcG9uc2VSZWFkQ29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgcmVxdWVzdEVycm9yU3RlcHMoXCJhYm9ydFwiKTtcblx0XHRcdFx0ZWxzZSBpZiAoaXNSZXNwb25zZUVycm9yKHJlc3BvbnNlKSkgcmVxdWVzdEVycm9yU3RlcHMoXCJlcnJvclwiKTtcblx0XHRcdH07XG5cdFx0XHRoYW5kbGVFcnJvcnMoKTtcblx0XHRcdGRlZmluZSh0aGlzLnJlcXVlc3QsIFwic3RhdHVzXCIsIHJlc3BvbnNlLnN0YXR1cyk7XG5cdFx0XHRkZWZpbmUodGhpcy5yZXF1ZXN0LCBcInN0YXR1c1RleHRcIiwgcmVzcG9uc2Uuc3RhdHVzVGV4dCk7XG5cdFx0XHRpZiAoIXRoaXMucmVxdWVzdC5yZXNwb25zZVVSTCkgZGVmaW5lKHRoaXMucmVxdWVzdCwgXCJyZXNwb25zZVVSTFwiLCByZXNwb25zZS51cmwpO1xuXHRcdFx0aWYgKGlzUmVzcG9uc2VFcnJvcihyZXNwb25zZSkpIHJldHVybjtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBUaGUgcmVzcG9uc2UgYm9keSBsZW5ndGggaXMgZGVyaXZlZCBPTkxZIGZyb20gdGhlIFwiY29udGVudC1sZW5ndGhcIiBoZWFkZXIuXG5cdFx0XHQqIElmIHRoYXQgcmVzcG9uc2UgaGVhZGVyIGlzIG5vdCBzZXQsIHRoZSBcInRvdGFsXCIgaW4gYWxsIHByb2dyZXNzIGV2ZW50cyBtdXN0IGJlIDAuXG5cdFx0XHQqL1xuXHRcdFx0Y29uc3QgcmVzcG9uc2VCb2R5TGVuZ3RoID0gTnVtYmVyKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC1sZW5ndGhcIikgPz8gXCIwXCIpO1xuXHRcdFx0dGhpcy5zZXRSZWFkeVN0YXRlKHRoaXMucmVxdWVzdC5IRUFERVJTX1JFQ0VJVkVEKTtcblx0XHRcdGxldCByZWNlaXZlZEJ5dGVzID0gMDtcblx0XHRcdGxldCBsYXN0UmVjZWl2ZWRSZXNwb25zZUJ5dGVzQXQgPSBwZXJmb3JtYW5jZS5ub3coKTtcblx0XHRcdGNvbnN0IHByb2Nlc3NSZXNwb25zZUJvZHlDaHVuayA9IChieXRlc0xlbmd0aCkgPT4ge1xuXHRcdFx0XHRyZWNlaXZlZEJ5dGVzICs9IGJ5dGVzTGVuZ3RoO1xuXHRcdFx0XHRjb25zdCBub3cgPSBwZXJmb3JtYW5jZS5ub3coKTtcblx0XHRcdFx0Y29uc3Qgc2hvdWxkQnVmZmVyID0gbm93IC0gbGFzdFJlY2VpdmVkUmVzcG9uc2VCeXRlc0F0IDw9IDYwICYmIHJlY2VpdmVkQnl0ZXMgPCByZXNwb25zZUJvZHlMZW5ndGg7XG5cdFx0XHRcdGxhc3RSZWNlaXZlZFJlc3BvbnNlQnl0ZXNBdCA9IG5vdztcblx0XHRcdFx0aWYgKHNob3VsZEJ1ZmZlcikgcmV0dXJuO1xuXHRcdFx0XHRpZiAodGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgPT09IHRoaXMucmVxdWVzdC5IRUFERVJTX1JFQ0VJVkVEKSB0aGlzLnNldFJlYWR5U3RhdGUodGhpcy5yZXF1ZXN0LkxPQURJTkcsIGZhbHNlKTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwicmVhZHlzdGF0ZWNoYW5nZVwiLCB0aGlzLnJlcXVlc3QpO1xuXHRcdFx0XHR0aGlzLnRyaWdnZXIoXCJwcm9ncmVzc1wiLCB0aGlzLnJlcXVlc3QsIHtcblx0XHRcdFx0XHRsb2FkZWQ6IHJlY2VpdmVkQnl0ZXMsXG5cdFx0XHRcdFx0dG90YWw6IHJlc3BvbnNlQm9keUxlbmd0aFxuXHRcdFx0XHR9KTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBwcm9jZXNzUmVzcG9uc2VCb2R5RXJyb3IgPSAoKSA9PiB7XG5cdFx0XHRcdHJlcXVlc3RFcnJvclN0ZXBzKFwiZXJyb3JcIik7XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcHJvY2Vzc1Jlc3BvbnNlRW5kT2ZCb2R5ID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRoYW5kbGVFcnJvcnMoKTtcblx0XHRcdFx0aWYgKGlzUmVzcG9uc2VFcnJvcihyZXNwb25zZSkpIHJldHVybjtcblx0XHRcdFx0bGV0IHRyYW5zbWl0dGVkID0gcmVjZWl2ZWRCeXRlcztcblx0XHRcdFx0dGhpcy5zZXRSZWFkeVN0YXRlKHRoaXMucmVxdWVzdC5ET05FKTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwibG9hZFwiLCB0aGlzLnJlcXVlc3QsIHtcblx0XHRcdFx0XHRsb2FkZWQ6IHRyYW5zbWl0dGVkLFxuXHRcdFx0XHRcdHRvdGFsOiByZXNwb25zZUJvZHlMZW5ndGhcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHRoaXMudHJpZ2dlcihcImxvYWRlbmRcIiwgdGhpcy5yZXF1ZXN0LCB7XG5cdFx0XHRcdFx0bG9hZGVkOiB0cmFuc21pdHRlZCxcblx0XHRcdFx0XHR0b3RhbDogcmVzcG9uc2VCb2R5TGVuZ3RoXG5cdFx0XHRcdH0pO1xuXHRcdFx0fTtcblx0XHRcdGlmIChyZXNwb25zZS5ib2R5ID09IG51bGwpIHByb2Nlc3NSZXNwb25zZUVuZE9mQm9keSgpO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGNvbnN0IHJlYWRlciA9IHJlc3BvbnNlLmJvZHkuZ2V0UmVhZGVyKCk7XG5cdFx0XHRcdHdoaWxlICh0cnVlKSB7XG5cdFx0XHRcdFx0aWYgKHJlc3BvbnNlUmVhZENvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIGJyZWFrO1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRjb25zdCB7IHZhbHVlLCBkb25lIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuXHRcdFx0XHRcdFx0aWYgKGRvbmUpIHtcblx0XHRcdFx0XHRcdFx0cHJvY2Vzc1Jlc3BvbnNlRW5kT2ZCb2R5KCk7XG5cdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHByb2Nlc3NSZXNwb25zZUJvZHlDaHVuayh2YWx1ZS5ieXRlTGVuZ3RoKTtcblx0XHRcdFx0XHRcdHRoaXMucmVzcG9uc2VCdWZmZXIgPSBjb25jYXRBcnJheUJ1ZmZlcih0aGlzLnJlc3BvbnNlQnVmZmVyLCB2YWx1ZSk7XG5cdFx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0XHRwcm9jZXNzUmVzcG9uc2VCb2R5RXJyb3IoKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9O1xuXHRcdGNvbnN0IFtyZWRpcmVjdEVycm9yLCBmaW5hbFJlc3BvbnNlXSA9IGF3YWl0IHVudGlsKCgpID0+IHtcblx0XHRcdHJldHVybiB0aGlzLmZvbGxvd1JlZGlyZWN0cyhyZXNwb25zZSk7XG5cdFx0fSk7XG5cdFx0aWYgKHJlZGlyZWN0RXJyb3IpIHJldHVybjtcblx0XHRwcm9jZXNzUmVzcG9uc2UoZmluYWxSZXNwb25zZSk7XG5cdFx0aWYgKHRoaXMucmVxdWVzdC50aW1lb3V0KSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gdGhpcy5yZXF1ZXN0LkRPTkUpIHtcblx0XHRcdFx0dGltZWRPdXQgPSB0cnVlO1xuXHRcdFx0XHRyZXNwb25zZVJlYWRDb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHR9XG5cdFx0fSwgdGhpcy5yZXF1ZXN0LnRpbWVvdXQpO1xuXHRcdHRoaXMucmVxdWVzdC5nZXRSZXNwb25zZUhlYWRlciA9IG5ldyBQcm94eSh0aGlzLnJlcXVlc3QuZ2V0UmVzcG9uc2VIZWFkZXIsIHsgYXBwbHk6IChfLCBfXywgYXJncykgPT4ge1xuXHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImdldFJlc3BvbnNlSGVhZGVyXCIsIGFyZ3NbMF0pO1xuXHRcdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlIDwgdGhpcy5yZXF1ZXN0LkhFQURFUlNfUkVDRUlWRUQpIHtcblx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImhlYWRlcnMgbm90IHJlY2VpdmVkIHlldCwgcmV0dXJuaW5nIG51bGxcIik7XG5cdFx0XHRcdHJldHVybiBudWxsO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgaGVhZGVyVmFsdWUgPSBmaW5hbFJlc3BvbnNlLmhlYWRlcnMuZ2V0KGFyZ3NbMF0pO1xuXHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc29sdmVkIHJlc3BvbnNlIGhlYWRlciBcXFwiJXNcXFwiIHRvXCIsIGFyZ3NbMF0sIGhlYWRlclZhbHVlKTtcblx0XHRcdHJldHVybiBoZWFkZXJWYWx1ZTtcblx0XHR9IH0pO1xuXHRcdHRoaXMucmVxdWVzdC5nZXRBbGxSZXNwb25zZUhlYWRlcnMgPSBuZXcgUHJveHkodGhpcy5yZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycywgeyBhcHBseTogKCkgPT4ge1xuXHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImdldEFsbFJlc3BvbnNlSGVhZGVyc1wiKTtcblx0XHRcdGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSA8IHRoaXMucmVxdWVzdC5IRUFERVJTX1JFQ0VJVkVEKSB7XG5cdFx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJoZWFkZXJzIG5vdCByZWNlaXZlZCB5ZXQsIHJldHVybmluZyBlbXB0eSBzdHJpbmdcIik7XG5cdFx0XHRcdHJldHVybiBcIlwiO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgYWxsSGVhZGVycyA9IEFycmF5LmZyb20oZmluYWxSZXNwb25zZS5oZWFkZXJzKS5tYXAoKFtoZWFkZXJOYW1lLCBoZWFkZXJWYWx1ZV0pID0+IHtcblx0XHRcdFx0cmV0dXJuIGAke2hlYWRlck5hbWV9OiAke2hlYWRlclZhbHVlfWA7XG5cdFx0XHR9KS5qb2luKFwiXFxyXFxuXCIpO1xuXHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc29sdmVkIGFsbCByZXNwb25zZSBoZWFkZXJzIHRvXCIsIGFsbEhlYWRlcnMpO1xuXHRcdFx0cmV0dXJuIGFsbEhlYWRlcnM7XG5cdFx0fSB9KTtcblx0fVxuXHRyZXNwb25zZUJ1ZmZlclRvVGV4dCgpIHtcblx0XHRyZXR1cm4gZGVjb2RlQnVmZmVyKHRoaXMucmVzcG9uc2VCdWZmZXIpO1xuXHR9XG5cdGdldCByZXNwb25zZSgpIHtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZ2V0UmVzcG9uc2UgKHJlc3BvbnNlVHlwZTogJXMpXCIsIHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUpO1xuXHRcdGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gdGhpcy5yZXF1ZXN0LkRPTkUpIHJldHVybiBudWxsO1xuXHRcdHN3aXRjaCAodGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSkge1xuXHRcdFx0Y2FzZSBcImpzb25cIjoge1xuXHRcdFx0XHRjb25zdCByZXNwb25zZUpzb24gPSBwYXJzZUpzb24odGhpcy5yZXNwb25zZUJ1ZmZlclRvVGV4dCgpKTtcblx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc29sdmVkIHJlc3BvbnNlIEpTT05cIiwgcmVzcG9uc2VKc29uKTtcblx0XHRcdFx0cmV0dXJuIHJlc3BvbnNlSnNvbjtcblx0XHRcdH1cblx0XHRcdGNhc2UgXCJhcnJheWJ1ZmZlclwiOiB7XG5cdFx0XHRcdGNvbnN0IGFycmF5QnVmZmVyID0gdG9BcnJheUJ1ZmZlcih0aGlzLnJlc3BvbnNlQnVmZmVyKTtcblx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc29sdmVkIHJlc3BvbnNlIEFycmF5QnVmZmVyXCIsIGFycmF5QnVmZmVyKTtcblx0XHRcdFx0cmV0dXJuIGFycmF5QnVmZmVyO1xuXHRcdFx0fVxuXHRcdFx0Y2FzZSBcImJsb2JcIjoge1xuXHRcdFx0XHRjb25zdCBtaW1lVHlwZSA9IHRoaXMucmVxdWVzdC5nZXRSZXNwb25zZUhlYWRlcihcIkNvbnRlbnQtVHlwZVwiKSB8fCBcInRleHQvcGxhaW5cIjtcblx0XHRcdFx0Y29uc3QgcmVzcG9uc2VCbG9iID0gbmV3IEJsb2IoW3RoaXMucmVzcG9uc2VCdWZmZXJUb1RleHQoKV0sIHsgdHlwZTogbWltZVR5cGUgfSk7XG5cdFx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZXNvbHZlZCByZXNwb25zZSBCbG9iIChtaW1lIHR5cGU6ICVzKVwiLCByZXNwb25zZUJsb2IsIG1pbWVUeXBlKTtcblx0XHRcdFx0cmV0dXJuIHJlc3BvbnNlQmxvYjtcblx0XHRcdH1cblx0XHRcdGRlZmF1bHQ6IHtcblx0XHRcdFx0Y29uc3QgcmVzcG9uc2VUZXh0ID0gdGhpcy5yZXNwb25zZUJ1ZmZlclRvVGV4dCgpO1xuXHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVzb2x2aW5nIFxcXCIlc1xcXCIgcmVzcG9uc2UgdHlwZSBhcyB0ZXh0XCIsIHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUsIHJlc3BvbnNlVGV4dCk7XG5cdFx0XHRcdHJldHVybiByZXNwb25zZVRleHQ7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGdldCByZXNwb25zZVRleHQoKSB7XG5cdFx0LyoqXG5cdFx0KiBUaHJvdyB3aGVuIHRyeWluZyB0byByZWFkIHRoZSByZXNwb25zZSBib2R5IGFzIHRleHQgd2hlbiB0aGVcblx0XHQqIFwicmVzcG9uc2VUeXBlXCIgZG9lc24ndCBleHBlY3QgdGV4dC4gVGhpcyBqdXN0IHJlc3BlY3RzIHRoZSBzcGVjIGJldHRlci5cblx0XHQqIEBzZWUgaHR0cHM6Ly94aHIuc3BlYy53aGF0d2cub3JnLyN0aGUtcmVzcG9uc2V0ZXh0LWF0dHJpYnV0ZVxuXHRcdCovXG5cdFx0aW52YXJpYW50KHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUgPT09IFwiXCIgfHwgdGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSA9PT0gXCJ0ZXh0XCIsIFwiSW52YWxpZFN0YXRlRXJyb3I6IFRoZSBvYmplY3QgaXMgaW4gaW52YWxpZCBzdGF0ZS5cIik7XG5cdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlICE9PSB0aGlzLnJlcXVlc3QuTE9BRElORyAmJiB0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gdGhpcy5yZXF1ZXN0LkRPTkUpIHJldHVybiBcIlwiO1xuXHRcdGNvbnN0IHJlc3BvbnNlVGV4dCA9IHRoaXMucmVzcG9uc2VCdWZmZXJUb1RleHQoKTtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZ2V0UmVzcG9uc2VUZXh0OiBcXFwiJXNcXFwiXCIsIHJlc3BvbnNlVGV4dCk7XG5cdFx0cmV0dXJuIHJlc3BvbnNlVGV4dDtcblx0fVxuXHRnZXQgcmVzcG9uc2VYTUwoKSB7XG5cdFx0aW52YXJpYW50KHRoaXMucmVxdWVzdC5yZXNwb25zZVR5cGUgPT09IFwiXCIgfHwgdGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSA9PT0gXCJkb2N1bWVudFwiLCBcIkludmFsaWRTdGF0ZUVycm9yOiBUaGUgb2JqZWN0IGlzIGluIGludmFsaWQgc3RhdGUuXCIpO1xuXHRcdGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gdGhpcy5yZXF1ZXN0LkRPTkUpIHJldHVybiBudWxsO1xuXHRcdGNvbnN0IGNvbnRlbnRUeXBlID0gdGhpcy5yZXF1ZXN0LmdldFJlc3BvbnNlSGVhZGVyKFwiQ29udGVudC1UeXBlXCIpIHx8IFwiXCI7XG5cdFx0aWYgKHR5cGVvZiBET01QYXJzZXIgPT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdGNvbnNvbGUud2FybihcIkNhbm5vdCByZXRyaWV2ZSBYTUxIdHRwUmVxdWVzdCByZXNwb25zZSBib2R5IGFzIFhNTDogRE9NUGFyc2VyIGlzIG5vdCBkZWZpbmVkLiBZb3UgYXJlIGxpa2VseSB1c2luZyBhbiBlbnZpcm9ubWVudCB0aGF0IGlzIG5vdCBicm93c2VyIG9yIGRvZXMgbm90IHBvbHlmaWxsIGJyb3dzZXIgZ2xvYmFscyBjb3JyZWN0bHkuXCIpO1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHRcdGlmIChpc0RvbVBhcnNlclN1cHBvcnRlZFR5cGUoY29udGVudFR5cGUpKSByZXR1cm4gbmV3IERPTVBhcnNlcigpLnBhcnNlRnJvbVN0cmluZyh0aGlzLnJlc3BvbnNlQnVmZmVyVG9UZXh0KCksIGNvbnRlbnRUeXBlKTtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxuXHRhc3luYyBmb2xsb3dSZWRpcmVjdHMocmVzcG9uc2UpIHtcblx0XHRjb25zdCByZWRpcmVjdExvY2F0aW9uID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoXCJsb2NhdGlvblwiKTtcblx0XHRpZiAoIXJlZGlyZWN0TG9jYXRpb24gfHwgIUZldGNoUmVzcG9uc2UuaXNSZWRpcmVjdFJlc3BvbnNlKHJlc3BvbnNlLnN0YXR1cykpIHJldHVybiByZXNwb25zZTtcblx0XHR0aGlzLnJlZGlyZWN0Q291bnQrKztcblx0XHRpZiAodGhpcy5yZWRpcmVjdENvdW50ID4gTUFYX1JFRElSRUNUUykgdGhyb3cgbmV3IEVycm9yKFwiVG9vIG1hbnkgcmVkaXJlY3RzXCIpO1xuXHRcdGNvbnN0IHJlZGlyZWN0VXJsID0gbmV3IFVSTChyZWRpcmVjdExvY2F0aW9uLCBsb2NhdGlvbi5ocmVmKTtcblx0XHRjb25zdCByZWRpcmVjdE1ldGhvZCA9IEZldGNoUmVzcG9uc2UuaXNSZXNwb25zZVdpdGhCb2R5KHJlc3BvbnNlLnN0YXR1cykgPyB0aGlzLm1ldGhvZCA6IFwiR0VUXCI7XG5cdFx0Y29uc3QgcmVkaXJlY3RSZXNwb25zZSA9IGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGNvbnN0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcblx0XHRcdHJlcXVlc3QucmVzcG9uc2VUeXBlID0gdGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZTtcblx0XHRcdHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIiwgKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnVybCA9IG5ldyBVUkwocmVxdWVzdC5yZXNwb25zZVVSTCk7XG5cdFx0XHRcdHJlc29sdmUoY3JlYXRlUmVzcG9uc2UocmVxdWVzdCwgcmVxdWVzdC5yZXNwb25zZSkpO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuZXJyb3JXaXRoKCk7XG5cdFx0XHRcdHJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiUmVkaXJlY3QgcmVxdWVzdCBmYWlsZWRcIikpO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXF1ZXN0Lm9wZW4ocmVkaXJlY3RNZXRob2QsIHJlZGlyZWN0VXJsLmhyZWYpO1xuXHRcdFx0cmVxdWVzdC5zZW5kKCk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHRoaXMuZm9sbG93UmVkaXJlY3RzKHJlZGlyZWN0UmVzcG9uc2UpO1xuXHR9XG5cdGVycm9yV2l0aChlcnJvcikge1xuXHRcdC8qKlxuXHRcdCogQG5vdGUgTWFyayB0aGlzIHJlcXVlc3QgYXMgaGFuZGxlZCBldmVuIGlmIGl0IHJlY2VpdmVkIGEgbW9jayBlcnJvci5cblx0XHQqIFRoaXMgcHJldmVudHMgdGhlIGNvbnRyb2xsZXIgZnJvbSB0cnlpbmcgdG8gcGVyZm9ybSB0aGlzIHJlcXVlc3QgYXMtaXMuXG5cdFx0Ki9cblx0XHR0aGlzW2tJc1JlcXVlc3RIYW5kbGVkXSA9IHRydWU7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc3BvbmRpbmcgd2l0aCBhbiBlcnJvclwiKTtcblx0XHR0aGlzLnNldFJlYWR5U3RhdGUodGhpcy5yZXF1ZXN0LkRPTkUpO1xuXHRcdHRoaXMudHJpZ2dlcihcImVycm9yXCIsIHRoaXMucmVxdWVzdCk7XG5cdFx0dGhpcy50cmlnZ2VyKFwibG9hZGVuZFwiLCB0aGlzLnJlcXVlc3QpO1xuXHR9XG5cdC8qKlxuXHQqIFRyYW5zaXRpb25zIHRoaXMgcmVxdWVzdCdzIGByZWFkeVN0YXRlYCB0byB0aGUgZ2l2ZW4gb25lLlxuXHQqL1xuXHRzZXRSZWFkeVN0YXRlKG5leHRSZWFkeVN0YXRlLCB0cmlnZ2VyUmVhZHlTdGF0ZUNoYW5nZUV2ZW50ID0gdHJ1ZSkge1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJzZXRSZWFkeVN0YXRlOiAlZCAtPiAlZFwiLCB0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSwgbmV4dFJlYWR5U3RhdGUpO1xuXHRcdGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSA9PT0gbmV4dFJlYWR5U3RhdGUpIHtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZWFkeSBzdGF0ZSBpZGVudGljYWwsIHNraXBwaW5nIHRyYW5zaXRpb24uLi5cIik7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGRlZmluZSh0aGlzLnJlcXVlc3QsIFwicmVhZHlTdGF0ZVwiLCBuZXh0UmVhZHlTdGF0ZSk7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInNldCByZWFkeVN0YXRlIHRvOiAlZFwiLCBuZXh0UmVhZHlTdGF0ZSk7XG5cdFx0aWYgKCF0cmlnZ2VyUmVhZHlTdGF0ZUNoYW5nZUV2ZW50KSByZXR1cm47XG5cdFx0aWYgKG5leHRSZWFkeVN0YXRlICE9PSB0aGlzLnJlcXVlc3QuVU5TRU5UKSB7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwidHJpZ2dlcmluZyBcXFwicmVhZHlzdGF0ZWNoYW5nZVxcXCIgZXZlbnQuLi5cIik7XG5cdFx0XHR0aGlzLnRyaWdnZXIoXCJyZWFkeXN0YXRlY2hhbmdlXCIsIHRoaXMucmVxdWVzdCk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFRyaWdnZXJzIGdpdmVuIGV2ZW50IG9uIHRoZSBgWE1MSHR0cFJlcXVlc3RgIGluc3RhbmNlLlxuXHQqL1xuXHR0cmlnZ2VyKGV2ZW50TmFtZSwgdGFyZ2V0LCBvcHRpb25zKSB7XG5cdFx0Y29uc3QgY2FsbGJhY2sgPSB0YXJnZXRbYG9uJHtldmVudE5hbWV9YF07XG5cdFx0Y29uc3QgZXZlbnQgPSBjcmVhdGVFdmVudCh0YXJnZXQsIGV2ZW50TmFtZSwgb3B0aW9ucyk7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInRyaWdnZXIgXFxcIiVzXFxcIlwiLCBldmVudE5hbWUsIG9wdGlvbnMgfHwgXCJcIik7XG5cdFx0aWYgKHR5cGVvZiBjYWxsYmFjayA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZm91bmQgYSBkaXJlY3QgXFxcIiVzXFxcIiBjYWxsYmFjaywgY2FsbGluZy4uLlwiLCBldmVudE5hbWUpO1xuXHRcdFx0Y2FsbGJhY2suY2FsbCh0YXJnZXQsIGV2ZW50KTtcblx0XHR9XG5cdFx0Y29uc3QgZXZlbnRzID0gdGFyZ2V0IGluc3RhbmNlb2YgWE1MSHR0cFJlcXVlc3RVcGxvYWQgPyB0aGlzLnVwbG9hZEV2ZW50cyA6IHRoaXMuZXZlbnRzO1xuXHRcdGZvciAoY29uc3QgW3JlZ2lzdGVyZWRFdmVudE5hbWUsIGxpc3RlbmVyc10gb2YgZXZlbnRzKSBpZiAocmVnaXN0ZXJlZEV2ZW50TmFtZSA9PT0gZXZlbnROYW1lKSB7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZm91bmQgJWQgbGlzdGVuZXIocykgZm9yIFxcXCIlc1xcXCIgZXZlbnQsIGNhbGxpbmcuLi5cIiwgbGlzdGVuZXJzLmxlbmd0aCwgZXZlbnROYW1lKTtcblx0XHRcdGxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4gbGlzdGVuZXIuY2FsbCh0YXJnZXQsIGV2ZW50KSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIENvbnZlcnRzIHRoaXMgYFhNTEh0dHBSZXF1ZXN0YCBpbnN0YW5jZSBpbnRvIGEgRmV0Y2ggQVBJIGBSZXF1ZXN0YCBpbnN0YW5jZS5cblx0Ki9cblx0dG9GZXRjaEFwaVJlcXVlc3QoYm9keSkge1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJjb252ZXJ0aW5nIHJlcXVlc3QgdG8gYSBGZXRjaCBBUEkgUmVxdWVzdC4uLlwiKTtcblx0XHRjb25zdCByZXNvbHZlZEJvZHkgPSBib2R5IGluc3RhbmNlb2YgRG9jdW1lbnQgPyBib2R5LmRvY3VtZW50RWxlbWVudC5pbm5lclRleHQgOiBib2R5O1xuXHRcdGNvbnN0IGZldGNoUmVxdWVzdCA9IG5ldyBGZXRjaFJlcXVlc3QodGhpcy51cmwuaHJlZiwge1xuXHRcdFx0bWV0aG9kOiB0aGlzLm1ldGhvZCxcblx0XHRcdGhlYWRlcnM6IHRoaXMucmVxdWVzdEhlYWRlcnMsXG5cdFx0XHQvKipcblx0XHRcdCogQHNlZSBodHRwczovL3hoci5zcGVjLndoYXR3Zy5vcmcvI2Nyb3NzLW9yaWdpbi1jcmVkZW50aWFsc1xuXHRcdFx0Ki9cblx0XHRcdGNyZWRlbnRpYWxzOiB0aGlzLnJlcXVlc3Qud2l0aENyZWRlbnRpYWxzID8gXCJpbmNsdWRlXCIgOiBcInNhbWUtb3JpZ2luXCIsXG5cdFx0XHRib2R5OiByZXNvbHZlZEJvZHlcblx0XHR9KTtcblx0XHRjb25zdCBoZWFkZXJzID0gZmV0Y2hSZXF1ZXN0LmhlYWRlcnM7XG5cdFx0ZGVmaW5lKGZldGNoUmVxdWVzdCwgXCJoZWFkZXJzXCIsIGNyZWF0ZVByb3h5KGhlYWRlcnMsIHsgbWV0aG9kQ2FsbDogKFttZXRob2ROYW1lLCBhcmdzXSwgaW52b2tlKSA9PiB7XG5cdFx0XHRjb25zdCByZXN1bHQgPSBpbnZva2UoKTtcblx0XHRcdHN3aXRjaCAobWV0aG9kTmFtZSkge1xuXHRcdFx0XHRjYXNlIFwiYXBwZW5kXCI6XG5cdFx0XHRcdGNhc2UgXCJzZXRcIjoge1xuXHRcdFx0XHRcdGNvbnN0IFtoZWFkZXJOYW1lLCBoZWFkZXJWYWx1ZV0gPSBhcmdzO1xuXHRcdFx0XHRcdC8qKlxuXHRcdFx0XHRcdCogQG5vdGUgRm9yd2FyZCBvbmx5IHRoZSBoZWFkZXJzIHRoZSBGZXRjaCBBUEkgUmVxdWVzdCBhY2NlcHRlZC5cblx0XHRcdFx0XHQqIEZvcmJpZGRlbiByZXF1ZXN0IGhlYWRlcnMgKGUuZy4gXCJDb29raWVcIikgYXJlIGRyb3BwZWQgc2lsZW50bHlcblx0XHRcdFx0XHQqIGJ5IHRoZSByZXF1ZXN0J3MgaGVhZGVycyBndWFyZCwgYW5kIGZvcndhcmRpbmcgdGhlbSBtYWtlc1xuXHRcdFx0XHRcdCogdGhlIGJyb3dzZXIgcmVmdXNlIHRoZW0gd2l0aCBhbiBlcnJvciBpbiB0aGUgY29uc29sZS5cblx0XHRcdFx0XHQqL1xuXHRcdFx0XHRcdGlmIChoZWFkZXJzLmhhcyhoZWFkZXJOYW1lKSkgdGhpcy5yZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoaGVhZGVyTmFtZSwgaGVhZGVyVmFsdWUpO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhc2UgXCJkZWxldGVcIjoge1xuXHRcdFx0XHRcdGNvbnN0IFtoZWFkZXJOYW1lXSA9IGFyZ3M7XG5cdFx0XHRcdFx0Y29uc29sZS53YXJuKGBYTUxIdHRwUmVxdWVzdDogQ2Fubm90IHJlbW92ZSBhIFwiJHtoZWFkZXJOYW1lfVwiIGhlYWRlciBmcm9tIHRoZSBGZXRjaCBBUEkgcmVwcmVzZW50YXRpb24gb2YgdGhlIFwiJHtmZXRjaFJlcXVlc3QubWV0aG9kfSAke2ZldGNoUmVxdWVzdC51cmx9XCIgcmVxdWVzdC4gWE1MSHR0cFJlcXVlc3QgaGVhZGVycyBjYW5ub3QgYmUgcmVtb3ZlZC5gKTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9IH0pKTtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiY29udmVydGVkIHJlcXVlc3QgdG8gYSBGZXRjaCBBUEkgUmVxdWVzdCFcIiwgZmV0Y2hSZXF1ZXN0KTtcblx0XHRyZXR1cm4gZmV0Y2hSZXF1ZXN0O1xuXHR9XG59O1xuZnVuY3Rpb24gdG9BYnNvbHV0ZVVybCh1cmwpIHtcblx0LyoqXG5cdCogQG5vdGUgWE1MSHR0cFJlcXVlc3QgaW50ZXJjZXB0b3IgbWF5IHJ1biBpbiBlbnZpcm9ubWVudHNcblx0KiB0aGF0IGltcGxlbWVudCBYTUxIdHRwUmVxdWVzdCBidXQgZG9uJ3QgaW1wbGVtZW50IFwibG9jYXRpb25cIlxuXHQqIChmb3IgZXhhbXBsZSwgUmVhY3QgTmF0aXZlKS4gSWYgdGhhdCdzIHRoZSBjYXNlLCByZXR1cm4gdGhlXG5cdCogaW5wdXQgVVJMIGFzLWlzIChub3RoaW5nIHRvIGJlIHJlbGF0aXZlIHRvKS5cblx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzE3Nzdcblx0Ki9cblx0aWYgKHR5cGVvZiBsb2NhdGlvbiA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIG5ldyBVUkwodXJsKTtcblx0cmV0dXJuIG5ldyBVUkwodXJsLnRvU3RyaW5nKCksIGxvY2F0aW9uLmhyZWYpO1xufVxuZnVuY3Rpb24gZGVmaW5lKHRhcmdldCwgcHJvcGVydHksIHZhbHVlKSB7XG5cdFJlZmxlY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBwcm9wZXJ0eSwge1xuXHRcdHdyaXRhYmxlOiB0cnVlLFxuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0dmFsdWVcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL1hNTEh0dHBSZXF1ZXN0L3htbC1odHRwLXJlcXVlc3QtcHJveHkudHNcbi8qKlxuKiBDcmVhdGUgYSBwcm94aWVkIGBYTUxIdHRwUmVxdWVzdGAgY2xhc3MuXG4qIFRoZSBwcm94aWVkIGNsYXNzIGVzdGFibGlzaGVzIHNwaWVzIG9uIGNlcnRhaW4gbWV0aG9kcyxcbiogYWxsb3dpbmcgdXMgdG8gaW50ZXJjZXB0IHJlcXVlc3RzIGFuZCByZXNwb25kIHRvIHRoZW0uXG4qL1xuZnVuY3Rpb24gY3JlYXRlWE1MSHR0cFJlcXVlc3RQcm94eSh7IGVtaXR0ZXIsIGxvZ2dlciB9KSB7XG5cdHJldHVybiBuZXcgUHJveHkoZ2xvYmFsVGhpcy5YTUxIdHRwUmVxdWVzdCwgeyBjb25zdHJ1Y3QodGFyZ2V0LCBhcmdzLCBuZXdUYXJnZXQpIHtcblx0XHRsb2dnZXIudmVyYm9zZShcImNvbnN0cnVjdGVkIG5ldyBYTUxIdHRwUmVxdWVzdFwiKTtcblx0XHRjb25zdCBvcmlnaW5hbFJlcXVlc3QgPSBSZWZsZWN0LmNvbnN0cnVjdCh0YXJnZXQsIGFyZ3MsIG5ld1RhcmdldCk7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBGb3J3YXJkIHByb3RvdHlwZSBkZXNjcmlwdG9ycyBvbnRvIHRoZSBwcm94aWVkIG9iamVjdC5cblx0XHQqIFhNTEh0dHBSZXF1ZXN0IGlzIGltcGxlbWVudGVkIGluIEpTRE9NIGluIGEgd2F5IHRoYXQgYXNzaWduc1xuXHRcdCogYSBidW5jaCBvZiBkZXNjcmlwdG9ycywgbGlrZSBcInNldCByZXNwb25zZVR5cGUoKVwiIG9uIHRoZSBwcm90b3R5cGUuXG5cdFx0KiBXaXRoIHRoaXMgcHJvcGFnYXRpb24sIHdlIG1ha2Ugc3VyZSB0aGF0IHRob3NlIGRlc2NyaXB0b3JzIHRyaWdnZXJcblx0XHQqIHdoZW4gdGhlIHVzZXIgb3BlcmF0ZXMgd2l0aCB0aGUgcHJveGllZCByZXF1ZXN0IGluc3RhbmNlLlxuXHRcdCovXG5cdFx0Y29uc3QgcHJvdG90eXBlRGVzY3JpcHRvcnMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0YXJnZXQucHJvdG90eXBlKTtcblx0XHRmb3IgKGNvbnN0IHByb3BlcnR5TmFtZSBpbiBwcm90b3R5cGVEZXNjcmlwdG9ycykgUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eShvcmlnaW5hbFJlcXVlc3QsIHByb3BlcnR5TmFtZSwgcHJvdG90eXBlRGVzY3JpcHRvcnNbcHJvcGVydHlOYW1lXSk7XG5cdFx0Y29uc3QgeGhyUmVxdWVzdENvbnRyb2xsZXIgPSBuZXcgWE1MSHR0cFJlcXVlc3RDb250cm9sbGVyKG9yaWdpbmFsUmVxdWVzdCwgbG9nZ2VyKTtcblx0XHR4aHJSZXF1ZXN0Q29udHJvbGxlci5vblJlcXVlc3QgPSBhc3luYyBmdW5jdGlvbih7IHJlcXVlc3QsIHJlcXVlc3RJZCB9KSB7XG5cdFx0XHRjb25zdCBjb250cm9sbGVyID0gbmV3IFJlcXVlc3RDb250cm9sbGVyKHJlcXVlc3QsIHtcblx0XHRcdFx0cGFzc3Rocm91Z2g6ICgpID0+IHtcblx0XHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwibm8gbW9ja2VkIHJlc3BvbnNlIHJlY2VpdmVkLCBwZXJmb3JtaW5nIHJlcXVlc3QgYXMtaXMuLi5cIik7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlc3BvbmRXaXRoOiBhc3luYyAocmVzcG9uc2UpID0+IHtcblx0XHRcdFx0XHRhd2FpdCB0aGlzLnJlc3BvbmRXaXRoKHJlc3BvbnNlKTtcblx0XHRcdFx0fSxcblx0XHRcdFx0ZXJyb3JXaXRoOiAocmVhc29uKSA9PiB7XG5cdFx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlcXVlc3QgZXJyb3JlZCAlb1wiLCB7IGVycm9yOiByZWFzb24gfSk7XG5cdFx0XHRcdFx0aWYgKHJlYXNvbiBpbnN0YW5jZW9mIEVycm9yKSB0aGlzLmVycm9yV2l0aChyZWFzb24pO1xuXHRcdFx0XHR9XG5cdFx0XHR9LCB7XG5cdFx0XHRcdGxvZ2dlcixcblx0XHRcdFx0cmVxdWVzdElkXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJhd2FpdGluZyBtb2NrZWQgcmVzcG9uc2VcIik7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZW1pdHRpbmcgdGhlIFxcXCJyZXF1ZXN0XFxcIiBldmVudCBmb3IgJXMgbGlzdGVuZXIocykuLi5cIiwgZW1pdHRlci5saXN0ZW5lckNvdW50KFwicmVxdWVzdFwiKSk7XG5cdFx0XHRhd2FpdCBoYW5kbGVSZXF1ZXN0KHtcblx0XHRcdFx0aW5pdGlhdG9yOiB0aGlzLnJlcXVlc3QsXG5cdFx0XHRcdHJlcXVlc3QsXG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0Y29udHJvbGxlcixcblx0XHRcdFx0ZW1pdHRlcixcblx0XHRcdFx0bG9nZ2VyXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHhoclJlcXVlc3RDb250cm9sbGVyLm9uUmVzcG9uc2UgPSBhc3luYyBmdW5jdGlvbih7IHJlc3BvbnNlLCByZXNwb25zZVR5cGUsIHJlcXVlc3QsIHJlcXVlc3RJZCB9KSB7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZW1pdHRpbmcgdGhlIFxcXCJyZXNwb25zZVxcXCIgZXZlbnQgZm9yICVzIGxpc3RlbmVyKHMpLi4uXCIsIGVtaXR0ZXIubGlzdGVuZXJDb3VudChcInJlc3BvbnNlXCIpKTtcblx0XHRcdGF3YWl0IGVtaXR0ZXIuZW1pdEFzUHJvbWlzZShuZXcgSHR0cFJlc3BvbnNlRXZlbnQoe1xuXHRcdFx0XHRpbml0aWF0b3I6IHRoaXMucmVxdWVzdCxcblx0XHRcdFx0cmVzcG9uc2UsXG5cdFx0XHRcdHJlc3BvbnNlVHlwZSxcblx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0cmVxdWVzdElkXG5cdFx0XHR9KSk7XG5cdFx0fTtcblx0XHRyZXR1cm4geGhyUmVxdWVzdENvbnRyb2xsZXIucmVxdWVzdDtcblx0fSB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3Qvd2ViLnRzXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVMb2dnZXIoXCJ4aHJcIik7XG52YXIgWE1MSHR0cFJlcXVlc3RJbnRlcmNlcHRvciA9IGNsYXNzIGV4dGVuZHMgSW50ZXJjZXB0b3Ige1xuXHRzdGF0aWMge1xuXHRcdHRoaXMuc3ltYm9sID0gU3ltYm9sLmZvcihcInhoci1pbnRlcmNlcHRvclwiKTtcblx0fVxuXHRwcmVkaWNhdGUoKSB7XG5cdFx0cmV0dXJuIGhhc0NvbmZpZ3VyYWJsZUdsb2JhbChcIlhNTEh0dHBSZXF1ZXN0XCIpO1xuXHR9XG5cdHNldHVwKCkge1xuXHRcdGxvZ2dlci52ZXJib3NlKFwicGF0Y2hpbmcgXFxcIlhNTEh0dHBSZXF1ZXN0XFxcIi4uLlwiKTtcblx0XHR0aGlzLnN1YnNjcmlwdGlvbnMucHVzaChwYXRjaGVzUmVnaXN0cnkuYXBwbHlQYXRjaChnbG9iYWxUaGlzLCBcIlhNTEh0dHBSZXF1ZXN0XCIsICgpID0+IHtcblx0XHRcdHJldHVybiBjcmVhdGVYTUxIdHRwUmVxdWVzdFByb3h5KHtcblx0XHRcdFx0ZW1pdHRlcjogdGhpcy5lbWl0dGVyLFxuXHRcdFx0XHRsb2dnZXJcblx0XHRcdH0pO1xuXHRcdH0pKTtcblx0XHRsb2dnZXIudmVyYm9zZShcImdsb2JhbCBcXFwiWE1MSHR0cFJlcXVlc3RcXFwiIHBhdGNoZWQhXCIsIGdsb2JhbFRoaXMuWE1MSHR0cFJlcXVlc3QubmFtZSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFhNTEh0dHBSZXF1ZXN0SW50ZXJjZXB0b3IgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD13ZWItQlJCUTNZUHAuanMubWFwIiwiaW1wb3J0IHsgbiBhcyBJbnRlcmNlcHRvciwgciBhcyBjcmVhdGVMb2dnZXIsIHQgYXMgY3JlYXRlUmVxdWVzdElkIH0gZnJvbSBcIi4vY3JlYXRlLXJlcXVlc3QtaWQtWW9iVW5KTk8uanNcIjtcbmltcG9ydCB7IGMgYXMgUmVxdWVzdENvbnRyb2xsZXIsIGkgYXMgaXNSZXNwb25zZUVycm9yLCBuIGFzIEZldGNoUmVzcG9uc2UsIHMgYXMgY29weVJhd0hlYWRlcnMgfSBmcm9tIFwiLi9mZXRjaC11dGlscy1DNlA2Z0xMby5qc1wiO1xuaW1wb3J0IHsgbiBhcyBIdHRwUmVzcG9uc2VFdmVudCwgdCBhcyBoYW5kbGVSZXF1ZXN0IH0gZnJvbSBcIi4vaGFuZGxlLXJlcXVlc3QteTdhanl2ZTUuanNcIjtcbmltcG9ydCB7IG4gYXMgcGF0Y2hlc1JlZ2lzdHJ5LCB0IGFzIGhhc0NvbmZpZ3VyYWJsZUdsb2JhbCB9IGZyb20gXCIuL2hhcy1jb25maWd1cmFibGUtZ2xvYmFsLUNldy1kWXFrLmpzXCI7XG5pbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwib3V0dmFyaWFudFwiO1xuaW1wb3J0IHsgdW50aWwgfSBmcm9tIFwiQG9wZW4tZHJhZnQvdW50aWxcIjtcbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL2ZldGNoL3V0aWxzL2NyZWF0ZS1uZXR3b3JrLWVycm9yLnRzXG5mdW5jdGlvbiBjcmVhdGVOZXR3b3JrRXJyb3IoY2F1c2UpIHtcblx0cmV0dXJuIE9iamVjdC5hc3NpZ24oLyogQF9fUFVSRV9fICovIG5ldyBUeXBlRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2hcIiksIHsgY2F1c2UgfSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL2ZldGNoL3V0aWxzL2ZvbGxvdy1yZWRpcmVjdC50c1xuY29uc3QgUkVRVUVTVF9CT0RZX0hFQURFUlMgPSBbXG5cdFwiY29udGVudC1lbmNvZGluZ1wiLFxuXHRcImNvbnRlbnQtbGFuZ3VhZ2VcIixcblx0XCJjb250ZW50LWxvY2F0aW9uXCIsXG5cdFwiY29udGVudC10eXBlXCIsXG5cdFwiY29udGVudC1sZW5ndGhcIlxuXTtcbmNvbnN0IGtSZWRpcmVjdENvdW50ID0gU3ltYm9sKFwia1JlZGlyZWN0Q291bnRcIik7XG4vKipcbiogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbm9kZWpzL3VuZGljaS9ibG9iL2E2ZGFjMzE0OWM1MDViNThkMmU2ZDA2OGI5N2Y0ZGM5OTNkYTU1ZjAvbGliL3dlYi9mZXRjaC9pbmRleC5qcyNMMTIxMFxuKi9cbmFzeW5jIGZ1bmN0aW9uIGZvbGxvd0ZldGNoUmVkaXJlY3QocmVxdWVzdCwgcmVzcG9uc2UpIHtcblx0aWYgKHJlc3BvbnNlLnN0YXR1cyAhPT0gMzAzICYmIHJlcXVlc3QuYm9keSAhPSBudWxsKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKCkpO1xuXHRjb25zdCByZXF1ZXN0VXJsID0gbmV3IFVSTChyZXF1ZXN0LnVybCk7XG5cdGxldCBsb2NhdGlvblVybDtcblx0dHJ5IHtcblx0XHRsb2NhdGlvblVybCA9IG5ldyBVUkwocmVzcG9uc2UuaGVhZGVycy5nZXQoXCJsb2NhdGlvblwiKSwgcmVxdWVzdC51cmwpO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBQcm9taXNlLnJlamVjdChjcmVhdGVOZXR3b3JrRXJyb3IoZXJyb3IpKTtcblx0fVxuXHRpZiAoIShsb2NhdGlvblVybC5wcm90b2NvbCA9PT0gXCJodHRwOlwiIHx8IGxvY2F0aW9uVXJsLnByb3RvY29sID09PSBcImh0dHBzOlwiKSkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihcIlVSTCBzY2hlbWUgbXVzdCBiZSBhIEhUVFAoUykgc2NoZW1lXCIpKTtcblx0aWYgKFJlZmxlY3QuZ2V0KHJlcXVlc3QsIGtSZWRpcmVjdENvdW50KSA+IDIwKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKFwicmVkaXJlY3QgY291bnQgZXhjZWVkZWRcIikpO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocmVxdWVzdCwga1JlZGlyZWN0Q291bnQsIHsgdmFsdWU6IChSZWZsZWN0LmdldChyZXF1ZXN0LCBrUmVkaXJlY3RDb3VudCkgfHwgMCkgKyAxIH0pO1xuXHRpZiAocmVxdWVzdC5tb2RlID09PSBcImNvcnNcIiAmJiAobG9jYXRpb25VcmwudXNlcm5hbWUgfHwgbG9jYXRpb25VcmwucGFzc3dvcmQpICYmICFzYW1lT3JpZ2luKHJlcXVlc3RVcmwsIGxvY2F0aW9uVXJsKSkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihcImNyb3NzIG9yaWdpbiBub3QgYWxsb3dlZCBmb3IgcmVxdWVzdCBtb2RlIFxcXCJjb3JzXFxcIlwiKSk7XG5cdGNvbnN0IHJlcXVlc3RJbml0ID0ge307XG5cdGlmIChbMzAxLCAzMDJdLmluY2x1ZGVzKHJlc3BvbnNlLnN0YXR1cykgJiYgcmVxdWVzdC5tZXRob2QgPT09IFwiUE9TVFwiIHx8IHJlc3BvbnNlLnN0YXR1cyA9PT0gMzAzICYmICFbXCJIRUFEXCIsIFwiR0VUXCJdLmluY2x1ZGVzKHJlcXVlc3QubWV0aG9kKSkge1xuXHRcdHJlcXVlc3RJbml0Lm1ldGhvZCA9IFwiR0VUXCI7XG5cdFx0cmVxdWVzdEluaXQuYm9keSA9IG51bGw7XG5cdFx0UkVRVUVTVF9CT0RZX0hFQURFUlMuZm9yRWFjaCgoaGVhZGVyTmFtZSkgPT4ge1xuXHRcdFx0cmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShoZWFkZXJOYW1lKTtcblx0XHR9KTtcblx0fVxuXHRpZiAoIXNhbWVPcmlnaW4ocmVxdWVzdFVybCwgbG9jYXRpb25VcmwpKSB7XG5cdFx0cmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShcImF1dGhvcml6YXRpb25cIik7XG5cdFx0cmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShcInByb3h5LWF1dGhvcml6YXRpb25cIik7XG5cdFx0cmVxdWVzdC5oZWFkZXJzLmRlbGV0ZShcImNvb2tpZVwiKTtcblx0XHRyZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwiaG9zdFwiKTtcblx0fVxuXHQvKipcblx0KiBAbm90ZSBVbmRpY2kgXCJzYWZlbHlcIiBleHRyYWN0cyB0aGUgcmVxdWVzdCBib2R5LlxuXHQqIEkgc3VzcGVjdCB3ZSBjYW5ub3QgZGlzcGF0Y2ggdGhpcyByZXF1ZXN0IGFnYWluXG5cdCogc2luY2UgaXRzIGJvZHkgaGFzIGJlZW4gcmVhZCBhbmQgdGhlIHN0cmVhbSBpcyBsb2NrZWQuXG5cdCovXG5cdHJlcXVlc3RJbml0LmhlYWRlcnMgPSByZXF1ZXN0LmhlYWRlcnM7XG5cdGNvbnN0IGZpbmFsUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChuZXcgUmVxdWVzdChsb2NhdGlvblVybCwgcmVxdWVzdEluaXQpKTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGZpbmFsUmVzcG9uc2UsIFwicmVkaXJlY3RlZFwiLCB7XG5cdFx0dmFsdWU6IHRydWUsXG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdH0pO1xuXHRyZXR1cm4gZmluYWxSZXNwb25zZTtcbn1cbi8qKlxuKiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9ub2RlanMvdW5kaWNpL2Jsb2IvYTZkYWMzMTQ5YzUwNWI1OGQyZTZkMDY4Yjk3ZjRkYzk5M2RhNTVmMC9saWIvd2ViL2ZldGNoL3V0aWwuanMjTDc2MVxuKi9cbmZ1bmN0aW9uIHNhbWVPcmlnaW4obGVmdCwgcmlnaHQpIHtcblx0aWYgKGxlZnQub3JpZ2luID09PSByaWdodC5vcmlnaW4gJiYgbGVmdC5vcmlnaW4gPT09IFwibnVsbFwiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKGxlZnQucHJvdG9jb2wgPT09IHJpZ2h0LnByb3RvY29sICYmIGxlZnQuaG9zdG5hbWUgPT09IHJpZ2h0Lmhvc3RuYW1lICYmIGxlZnQucG9ydCA9PT0gcmlnaHQucG9ydCkgcmV0dXJuIHRydWU7XG5cdHJldHVybiBmYWxzZTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvZmV0Y2gvdXRpbHMvYnJvdGxpLWRlY29tcHJlc3MuYnJvd3Nlci50c1xudmFyIEJyb3RsaURlY29tcHJlc3Npb25TdHJlYW0gPSBjbGFzcyBleHRlbmRzIFRyYW5zZm9ybVN0cmVhbSB7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdGNvbnNvbGUud2FybihcIltJbnRlcmNlcHRvcnNdOiBCcm90bGkgZGVjb21wcmVzc2lvbiBvZiByZXNwb25zZSBzdHJlYW1zIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhlIGJyb3dzZXJcIik7XG5cdFx0c3VwZXIoeyB0cmFuc2Zvcm0oY2h1bmssIGNvbnRyb2xsZXIpIHtcblx0XHRcdGNvbnRyb2xsZXIuZW5xdWV1ZShjaHVuayk7XG5cdFx0fSB9KTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvZmV0Y2gvdXRpbHMvZGVjb21wcmVzc2lvbi50c1xudmFyIFBpcGVsaW5lU3RyZWFtID0gY2xhc3MgZXh0ZW5kcyBUcmFuc2Zvcm1TdHJlYW0ge1xuXHRjb25zdHJ1Y3Rvcih0cmFuc2Zvcm1TdHJlYW1zLCAuLi5zdHJhdGVnaWVzKSB7XG5cdFx0c3VwZXIoe30sIC4uLnN0cmF0ZWdpZXMpO1xuXHRcdGNvbnN0IHJlYWRhYmxlID0gW3N1cGVyLnJlYWRhYmxlLCAuLi50cmFuc2Zvcm1TdHJlYW1zXS5yZWR1Y2UoKHJlYWRhYmxlLCB0cmFuc2Zvcm0pID0+IHJlYWRhYmxlLnBpcGVUaHJvdWdoKHRyYW5zZm9ybSkpO1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCBcInJlYWRhYmxlXCIsIHsgZ2V0KCkge1xuXHRcdFx0cmV0dXJuIHJlYWRhYmxlO1xuXHRcdH0gfSk7XG5cdH1cbn07XG5mdW5jdGlvbiBwYXJzZUNvbnRlbnRFbmNvZGluZyhjb250ZW50RW5jb2RpbmcpIHtcblx0cmV0dXJuIGNvbnRlbnRFbmNvZGluZy50b0xvd2VyQ2FzZSgpLnNwbGl0KFwiLFwiKS5tYXAoKGNvZGluZykgPT4gY29kaW5nLnRyaW0oKSk7XG59XG5mdW5jdGlvbiBjcmVhdGVEZWNvbXByZXNzaW9uU3RyZWFtKGNvbnRlbnRFbmNvZGluZykge1xuXHRyZXR1cm4gbmV3IFBpcGVsaW5lU3RyZWFtKHBhcnNlQ29udGVudEVuY29kaW5nKGNvbnRlbnRFbmNvZGluZykucmVkdWNlUmlnaHQoKHRyYW5zZm9ybWVycywgY29kaW5nKSA9PiB7XG5cdFx0aWYgKGNvZGluZyA9PT0gXCJnemlwXCIgfHwgY29kaW5nID09PSBcIngtZ3ppcFwiKSByZXR1cm4gdHJhbnNmb3JtZXJzLmNvbmNhdChuZXcgRGVjb21wcmVzc2lvblN0cmVhbShcImd6aXBcIikpO1xuXHRcdGVsc2UgaWYgKGNvZGluZyA9PT0gXCJkZWZsYXRlXCIpIHJldHVybiB0cmFuc2Zvcm1lcnMuY29uY2F0KG5ldyBEZWNvbXByZXNzaW9uU3RyZWFtKFwiZGVmbGF0ZVwiKSk7XG5cdFx0ZWxzZSBpZiAoY29kaW5nID09PSBcImJyXCIpIHJldHVybiB0cmFuc2Zvcm1lcnMuY29uY2F0KG5ldyBCcm90bGlEZWNvbXByZXNzaW9uU3RyZWFtKCkpO1xuXHRcdGVsc2UgdHJhbnNmb3JtZXJzLmxlbmd0aCA9IDA7XG5cdFx0cmV0dXJuIHRyYW5zZm9ybWVycztcblx0fSwgW10pKTtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgYm9vbGVhbiBpbmRpY2F0aW5nIHdoZXRoZXIgdGhlIGdpdmVuIHJlc3BvbnNlXG4qIGhhcyBhIGJvZHkgZW5jb2RlZCB3aXRoIGEgbm9uLWVtcHR5IFwiY29udGVudC1lbmNvZGluZ1wiLlxuKi9cbmZ1bmN0aW9uIGlzQ29tcHJlc3NlZFJlc3BvbnNlKHJlc3BvbnNlKSB7XG5cdGlmIChyZXNwb25zZS5ib2R5ID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IGNvbnRlbnRFbmNvZGluZyA9IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC1lbmNvZGluZ1wiKTtcblx0cmV0dXJuIGNvbnRlbnRFbmNvZGluZyAhPT0gbnVsbCAmJiBjb250ZW50RW5jb2RpbmcudHJpbSgpICE9PSBcIlwiO1xufVxuLyoqXG4qIERlY29tcHJlc3NlcyB0aGUgYm9keSBvZiB0aGUgZ2l2ZW4gY29tcHJlc3NlZCByZXNwb25zZS5cbiovXG5mdW5jdGlvbiBkZWNvbXByZXNzUmVzcG9uc2UocmVzcG9uc2UpIHtcblx0aW52YXJpYW50KGlzQ29tcHJlc3NlZFJlc3BvbnNlKHJlc3BvbnNlKSwgXCJGYWlsZWQgdG8gZGVjb21wcmVzcyBhIHJlc3BvbnNlOiBleHBlY3RlZCBhIHJlc3BvbnNlIHdpdGggYSBib2R5IGFuZCBhIG5vbi1lbXB0eSBcXFwiY29udGVudC1lbmNvZGluZ1xcXCIgaGVhZGVyXCIpO1xuXHRjb25zdCBkZWNvbXByZXNzaW9uU3RyZWFtID0gY3JlYXRlRGVjb21wcmVzc2lvblN0cmVhbShyZXNwb25zZS5oZWFkZXJzLmdldChcImNvbnRlbnQtZW5jb2RpbmdcIikpO1xuXHRyZXNwb25zZS5ib2R5LnBpcGVUbyhkZWNvbXByZXNzaW9uU3RyZWFtLndyaXRhYmxlKTtcblx0cmV0dXJuIGRlY29tcHJlc3Npb25TdHJlYW0ucmVhZGFibGU7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvY2xvbmUtcmVzcG9uc2UudHNcbi8qKiBDbG9uZSBmb3Igb2JzZXJ2ZXJzIHdpdGhvdXQgbGV0dGluZyB0aGVpciB1bnJlYWQgYm9keSBibG9jayBjYWxsZXIgY2FuY2VsbGF0aW9uLiAqL1xuZnVuY3Rpb24gY2xvbmVSZXNwb25zZShyZXNwb25zZSkge1xuXHRjb25zdCBjbG9uZSA9IEZldGNoUmVzcG9uc2UuY2xvbmUocmVzcG9uc2UpO1xuXHRpZiAoIXJlc3BvbnNlLmJvZHkgfHwgIWNsb25lLmJvZHkpIHJldHVybiBbcmVzcG9uc2UsIGNsb25lXTtcblx0Y29uc3Qgb2JzZXJ2ZXIgPSB3cmFwUmVzcG9uc2UoY2xvbmUpO1xuXHRyZXR1cm4gW3dyYXBSZXNwb25zZShyZXNwb25zZSwgb2JzZXJ2ZXIuY2FuY2VsKS5yZXNwb25zZSwgb2JzZXJ2ZXIucmVzcG9uc2VdO1xufVxuZnVuY3Rpb24gd3JhcFJlc3BvbnNlKHJlc3BvbnNlLCBvbkNhbmNlbCkge1xuXHRjb25zdCBib2R5ID0gcmVzcG9uc2UuYm9keTtcblx0Y29uc3QgcmVhZGVyID0gYm9keS5nZXRSZWFkZXIoKTtcblx0Y29uc3QgY2FuY2VsID0gKHJlYXNvbikgPT4ge1xuXHRcdHJldHVybiBib2R5LmxvY2tlZCA/IHJlYWRlci5jYW5jZWwocmVhc29uKSA6IGJvZHkuY2FuY2VsKHJlYXNvbik7XG5cdH07XG5cdGNvbnN0IHN0cmVhbSA9IG5ldyBSZWFkYWJsZVN0cmVhbSh7XG5cdFx0YXN5bmMgcHVsbChjb250cm9sbGVyKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCB7IGRvbmUsIHZhbHVlIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuXHRcdFx0XHRpZiAoZG9uZSkge1xuXHRcdFx0XHRcdGNvbnRyb2xsZXIuY2xvc2UoKTtcblx0XHRcdFx0XHRyZWFkZXIucmVsZWFzZUxvY2soKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29udHJvbGxlci5lbnF1ZXVlKHZhbHVlKTtcblx0XHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRcdGNvbnRyb2xsZXIuZXJyb3IoZXJyb3IpO1xuXHRcdFx0XHRyZWFkZXIucmVsZWFzZUxvY2soKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGFzeW5jIGNhbmNlbChyZWFzb24pIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IGNhbmNlbGxhdGlvbiA9IGNhbmNlbChyZWFzb24pO1xuXHRcdFx0XHRpZiAob25DYW5jZWwpIGF3YWl0IFByb21pc2UuYWxsKFtjYW5jZWxsYXRpb24sIG9uQ2FuY2VsKHJlYXNvbildKTtcblx0XHRcdFx0ZWxzZSBjYW5jZWxsYXRpb24uY2F0Y2goKCkgPT4ge30pO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0cmVhZGVyLnJlbGVhc2VMb2NrKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9LCB7IGhpZ2hXYXRlck1hcms6IDAgfSk7XG5cdGNvbnN0IHdyYXBwZWRSZXNwb25zZSA9IG5ldyBGZXRjaFJlc3BvbnNlKHN0cmVhbSwgcmVzcG9uc2UpO1xuXHRjb3B5UmF3SGVhZGVycyhyZXNwb25zZS5oZWFkZXJzLCB3cmFwcGVkUmVzcG9uc2UuaGVhZGVycyk7XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHdyYXBwZWRSZXNwb25zZSwge1xuXHRcdHR5cGU6IHsgdmFsdWU6IHJlc3BvbnNlLnR5cGUgfSxcblx0XHRyZWRpcmVjdGVkOiB7IHZhbHVlOiByZXNwb25zZS5yZWRpcmVjdGVkIH1cblx0fSk7XG5cdHJldHVybiB7XG5cdFx0cmVzcG9uc2U6IHdyYXBwZWRSZXNwb25zZSxcblx0XHRjYW5jZWxcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvZmV0Y2gvd2ViLnRzXG5jb25zdCBsb2dnZXIgPSBjcmVhdGVMb2dnZXIoXCJmZXRjaFwiKTtcbi8qKlxuKiBJbnRlcmNlcHQgYGZldGNoYCByZXF1ZXN0cyBpbiB0aGUgYnJvd3Nlci5cbiovXG52YXIgRmV0Y2hJbnRlcmNlcHRvciA9IGNsYXNzIGV4dGVuZHMgSW50ZXJjZXB0b3Ige1xuXHRzdGF0aWMge1xuXHRcdHRoaXMuc3ltYm9sID0gU3ltYm9sLmZvcihcImZldGNoLWludGVyY2VwdG9yXCIpO1xuXHR9XG5cdHByZWRpY2F0ZSgpIHtcblx0XHRyZXR1cm4gaGFzQ29uZmlndXJhYmxlR2xvYmFsKFwiZmV0Y2hcIik7XG5cdH1cblx0YXN5bmMgc2V0dXAoKSB7XG5cdFx0bG9nZ2VyLnZlcmJvc2UoXCJwYXRjaGluZyBnbG9iYWwgZmV0Y2guLi5cIik7XG5cdFx0dGhpcy5zdWJzY3JpcHRpb25zLnB1c2gocGF0Y2hlc1JlZ2lzdHJ5LmFwcGx5UGF0Y2goZ2xvYmFsVGhpcywgXCJmZXRjaFwiLCAocmVhbEZldGNoKSA9PiB7XG5cdFx0XHRyZXR1cm4gYXN5bmMgKGlucHV0LCBpbml0KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlcXVlc3RJZCA9IGNyZWF0ZVJlcXVlc3RJZCgpO1xuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBSZXNvbHZlIHBvdGVudGlhbGx5IHJlbGF0aXZlIHJlcXVlc3QgVVJMXG5cdFx0XHRcdCogYWdhaW5zdCB0aGUgcHJlc2VudCBgbG9jYXRpb25gLiBUaGlzIGlzIG1haW5seVxuXHRcdFx0XHQqIGZvciBuYXRpdmUgYGZldGNoYCBpbiBKU0RPTS5cblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzE2MjVcblx0XHRcdFx0Ki9cblx0XHRcdFx0Y29uc3QgcmVzb2x2ZWRJbnB1dCA9IHR5cGVvZiBpbnB1dCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgbG9jYXRpb24gIT09IFwidW5kZWZpbmVkXCIgJiYgIVVSTC5jYW5QYXJzZShpbnB1dCkgPyBuZXcgVVJMKGlucHV0LCBsb2NhdGlvbi5ocmVmKSA6IGlucHV0O1xuXHRcdFx0XHRjb25zdCByZXF1ZXN0ID0gbmV3IFJlcXVlc3QocmVzb2x2ZWRJbnB1dCwgaW5pdCk7XG5cdFx0XHRcdGNvbnN0IHJlc3BvbnNlUHJvbWlzZSA9IFByb21pc2Uud2l0aFJlc29sdmVycygpO1xuXHRcdFx0XHRjb25zdCBjb250cm9sbGVyID0gbmV3IFJlcXVlc3RDb250cm9sbGVyKHJlcXVlc3QsIHtcblx0XHRcdFx0XHRwYXNzdGhyb3VnaDogYXN5bmMgKCkgPT4ge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJwZXJmb3JtaW5nIHJlcXVlc3QgYXMtaXNcIik7XG5cdFx0XHRcdFx0XHQvKipcblx0XHRcdFx0XHRcdCogQG5vdGUgUGVyZm9ybSBhIGNsb25lIG9mIHRoZSByZXF1ZXN0IGluc3RhbmNlLCBub3QgdGhlIGluc3RhbmNlIGl0c2VsZi5cblx0XHRcdFx0XHRcdCogUGVyZm9ybWluZyBhIHJlcXVlc3QgY29uc3VtZXMgaXRzIGJvZHksIGFuZCB0aGUgXCJyZXNwb25zZVwiIGxpc3RlbmVyXG5cdFx0XHRcdFx0XHQqIG11c3Qgc3RpbGwgYmUgYWJsZSB0byByZWFkIGl0LiBUaGUgY2xvbmUgaXMgY3JlYXRlZCByaWdodCBiZWZvcmVcblx0XHRcdFx0XHRcdCogdGhlIHJlcXVlc3QgaXMgcGVyZm9ybWVkLCBzbyBpdCBwcmVzZXJ2ZXMgYW55IG1vZGlmaWNhdGlvbnMgbWFkZVxuXHRcdFx0XHRcdFx0KiB0byB0aGUgaW50ZXJjZXB0ZWQgcmVxdWVzdCBpbiB0aGUgXCJyZXF1ZXN0XCIgbGlzdGVuZXIuXG5cdFx0XHRcdFx0XHQqXG5cdFx0XHRcdFx0XHQqIFRoaXMgYWxzbyBrZWVwcyB0aGUgcmVxdWVzdCBpbnN0YW5jZSBlbWl0dGVkIG9uIHRoZSBcInJlc3BvbnNlXCIgZXZlbnRcblx0XHRcdFx0XHRcdCogcmVmZXJlbnRpYWxseSBlcXVhbCB0byB0aGUgb25lIGVtaXR0ZWQgb24gdGhlIFwicmVxdWVzdFwiIGV2ZW50XG5cdFx0XHRcdFx0XHQqIHNvIHRoZSBjb25zdW1lciBjYW4gYXNzb2NpYXRlIHRoZSB0d28gYnkgaWRlbnRpdHkuXG5cdFx0XHRcdFx0XHQqL1xuXHRcdFx0XHRcdFx0Y29uc3QgcmVxdWVzdENsb25lID0gcmVxdWVzdC5jbG9uZSgpO1xuXHRcdFx0XHRcdFx0Y29uc3QgW3Jlc3BvbnNlRXJyb3IsIG9yaWdpbmFsUmVzcG9uc2VdID0gYXdhaXQgdW50aWwoKCkgPT4gcmVhbEZldGNoKHJlcXVlc3RDbG9uZSkpO1xuXHRcdFx0XHRcdFx0aWYgKHJlc3BvbnNlRXJyb3IpIHJldHVybiByZXNwb25zZVByb21pc2UucmVqZWN0KHJlc3BvbnNlRXJyb3IpO1xuXHRcdFx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJvcmlnaW5hbCBmZXRjaCBwZXJmb3JtZWQgJW9cIiwgb3JpZ2luYWxSZXNwb25zZSk7XG5cdFx0XHRcdFx0XHRpZiAodGhpcy5lbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJyZXNwb25zZVwiKSA+IDApIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJlbWl0dGluZyB0aGUgXFxcInJlc3BvbnNlXFxcIiBldmVudFwiKTtcblx0XHRcdFx0XHRcdFx0Y29uc3QgW3Jlc3BvbnNlLCByZXNwb25zZUNsb25lXSA9IGNsb25lUmVzcG9uc2Uob3JpZ2luYWxSZXNwb25zZSk7XG5cdFx0XHRcdFx0XHRcdGF3YWl0IHRoaXMuZW1pdHRlci5lbWl0QXNQcm9taXNlKG5ldyBIdHRwUmVzcG9uc2VFdmVudCh7XG5cdFx0XHRcdFx0XHRcdFx0aW5pdGlhdG9yOiByZXF1ZXN0LFxuXHRcdFx0XHRcdFx0XHRcdHJlcXVlc3QsXG5cdFx0XHRcdFx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlOiByZXNwb25zZUNsb25lLFxuXHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlVHlwZTogXCJvcmlnaW5hbFwiXG5cdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdFx0cmVzcG9uc2VQcm9taXNlLnJlc29sdmUocmVzcG9uc2UpO1xuXHRcdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVzb2x2ZShvcmlnaW5hbFJlc3BvbnNlKTtcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdHJlc3BvbmRXaXRoOiBhc3luYyAocmF3UmVzcG9uc2UpID0+IHtcblx0XHRcdFx0XHRcdGlmIChpc1Jlc3BvbnNlRXJyb3IocmF3UmVzcG9uc2UpKSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci52ZXJib3NlKFwicmVxdWVzdCBlcnJvcmVkICVvXCIsIHsgcmVzcG9uc2U6IHJhd1Jlc3BvbnNlIH0pO1xuXHRcdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihyYXdSZXNwb25zZSkpO1xuXHRcdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHQvKipcblx0XHRcdFx0XHRcdCogQG5vdGUgRm9yd2FyZCB0aGUgbW9ja2VkIHJlc3BvbnNlIGluc3RhbmNlIGFzLWlzLiBXcmFwcGluZyBpdFxuXHRcdFx0XHRcdFx0KiBpbiBhIG5ldyBgUmVzcG9uc2VgIGRyb3BzIGFueSBydW50aW1lLXNwZWNpZmljIHN0YXRlIHRoZVxuXHRcdFx0XHRcdFx0KiBlbnZpcm9ubWVudCBhdHRhY2hlZCB0byBpdCAoZS5nLiB0aGUgYHdlYlNvY2tldGAgcHJvcGVydHlcblx0XHRcdFx0XHRcdCogb2YgYSBcIjEwMSBTd2l0Y2hpbmcgUHJvdG9jb2xzXCIgcmVzcG9uc2UgaW4gd29ya2VyZCkuXG5cdFx0XHRcdFx0XHQqIEEgcGxhaW4gYFJlc3BvbnNlYCBpcyBhbHJlYWR5IGd1YXJhbnRlZWQgdG8gYmUgdmFsaWQgYnkgdGhlXG5cdFx0XHRcdFx0XHQqIGVudmlyb25tZW50LCBhbmQgYSBgRmV0Y2hSZXNwb25zZWAgbWFuYWdlcyBpdHMgb3duXG5cdFx0XHRcdFx0XHQqIG5vbi1jb25maWd1cmFibGUgc3RhdGUgKHN0YXR1cywgVVJMKSBhY3Jvc3MgY2xvbmVzLlxuXHRcdFx0XHRcdFx0KlxuXHRcdFx0XHRcdFx0KiBUaGUgb25seSBleGNlcHRpb24gaXMgYSBjb21wcmVzc2VkIG1vY2tlZCByZXNwb25zZSBib2R5OlxuXHRcdFx0XHRcdFx0KiBhIGJvZHkgY2Fubm90IGJlIHN3YXBwZWQgaW4gcGxhY2UsIHNvIGl0IG11c3QgYmUgYSBuZXcgaW5zdGFuY2UuXG5cdFx0XHRcdFx0XHQqL1xuXHRcdFx0XHRcdFx0bGV0IHJlc3BvbnNlO1xuXHRcdFx0XHRcdFx0aWYgKGlzQ29tcHJlc3NlZFJlc3BvbnNlKHJhd1Jlc3BvbnNlKSkge1xuXHRcdFx0XHRcdFx0XHRyZXNwb25zZSA9IG5ldyBGZXRjaFJlc3BvbnNlKGRlY29tcHJlc3NSZXNwb25zZShyYXdSZXNwb25zZSksIHtcblx0XHRcdFx0XHRcdFx0XHRzdGF0dXM6IHJhd1Jlc3BvbnNlLnN0YXR1cyxcblx0XHRcdFx0XHRcdFx0XHRzdGF0dXNUZXh0OiByYXdSZXNwb25zZS5zdGF0dXNUZXh0LFxuXHRcdFx0XHRcdFx0XHRcdGhlYWRlcnM6IHJhd1Jlc3BvbnNlLmhlYWRlcnNcblx0XHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRcdGNvcHlSYXdIZWFkZXJzKHJhd1Jlc3BvbnNlLmhlYWRlcnMsIHJlc3BvbnNlLmhlYWRlcnMpO1xuXHRcdFx0XHRcdFx0fSBlbHNlIHJlc3BvbnNlID0gcmF3UmVzcG9uc2U7XG5cdFx0XHRcdFx0XHRGZXRjaFJlc3BvbnNlLnNldFVybChyZXF1ZXN0LnVybCwgcmVzcG9uc2UpO1xuXHRcdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0XHQqIFVuZGljaSdzIGhhbmRsaW5nIG9mIGZvbGxvd2luZyByZWRpcmVjdCByZXNwb25zZXMuXG5cdFx0XHRcdFx0XHQqIFRyZWF0IHRoZSBcIm1hbnVhbFwiIHJlZGlyZWN0IG1vZGUgYXMgYSByZWd1bGFyIG1vY2tlZCByZXNwb25zZS5cblx0XHRcdFx0XHRcdCogVGhpcyB3YXksIHRoZSBjbGllbnQgY2FuIG1hbnVhbGx5IGZvbGxvdyB0aGUgcmVkaXJlY3QgaXQgcmVjZWl2ZXMuXG5cdFx0XHRcdFx0XHQqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL25vZGVqcy91bmRpY2kvYmxvYi9hNmRhYzMxNDljNTA1YjU4ZDJlNmQwNjhiOTdmNGRjOTkzZGE1NWYwL2xpYi93ZWIvZmV0Y2gvaW5kZXguanMjTDExNzNcblx0XHRcdFx0XHRcdCovXG5cdFx0XHRcdFx0XHRpZiAoRmV0Y2hSZXNwb25zZS5pc1JlZGlyZWN0UmVzcG9uc2UocmVzcG9uc2Uuc3RhdHVzKSkge1xuXHRcdFx0XHRcdFx0XHRpZiAocmVxdWVzdC5yZWRpcmVjdCA9PT0gXCJlcnJvclwiKSB7XG5cdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2VQcm9taXNlLnJlamVjdChjcmVhdGVOZXR3b3JrRXJyb3IoXCJ1bmV4cGVjdGVkIHJlZGlyZWN0XCIpKTtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0aWYgKHJlcXVlc3QucmVkaXJlY3QgPT09IFwiZm9sbG93XCIpIHtcblx0XHRcdFx0XHRcdFx0XHRmb2xsb3dGZXRjaFJlZGlyZWN0KHJlcXVlc3QsIHJlc3BvbnNlKS50aGVuKChyZXNwb25zZSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2VQcm9taXNlLnJlc29sdmUocmVzcG9uc2UpO1xuXHRcdFx0XHRcdFx0XHRcdH0sIChyZWFzb24pID0+IHtcblx0XHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlUHJvbWlzZS5yZWplY3QocmVhc29uKTtcblx0XHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICh0aGlzLmVtaXR0ZXIubGlzdGVuZXJDb3VudChcInJlc3BvbnNlXCIpID4gMCkge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIudmVyYm9zZShcImVtaXR0aW5nIHRoZSBcXFwicmVzcG9uc2VcXFwiIGV2ZW50XCIpO1xuXHRcdFx0XHRcdFx0XHRjb25zdCBbY2FsbGVyUmVzcG9uc2UsIHJlc3BvbnNlQ2xvbmVdID0gY2xvbmVSZXNwb25zZShyZXNwb25zZSk7XG5cdFx0XHRcdFx0XHRcdGF3YWl0IHRoaXMuZW1pdHRlci5lbWl0QXNQcm9taXNlKG5ldyBIdHRwUmVzcG9uc2VFdmVudCh7XG5cdFx0XHRcdFx0XHRcdFx0aW5pdGlhdG9yOiByZXF1ZXN0LFxuXHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlOiByZXNwb25zZUNsb25lLFxuXHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlVHlwZTogXCJtb2NrXCIsXG5cdFx0XHRcdFx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0XHRcdFx0XHRyZXF1ZXN0SWRcblx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVzb2x2ZShjYWxsZXJSZXNwb25zZSk7XG5cdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc3BvbnNlUHJvbWlzZS5yZXNvbHZlKHJlc3BvbnNlKTtcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGVycm9yV2l0aDogKHJlYXNvbikgPT4ge1xuXHRcdFx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJyZXF1ZXN0IGFib3J0ZWQgJW9cIiwgeyByZWFzb24gfSk7XG5cdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVqZWN0KHJlYXNvbik7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9LCB7XG5cdFx0XHRcdFx0bG9nZ2VyLFxuXHRcdFx0XHRcdHJlcXVlc3RJZFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJhd2FpdGluZyByZXF1ZXN0IHJlc29sdXRpb25cIik7XG5cdFx0XHRcdGxvZ2dlci52ZXJib3NlKFwiZW1pdHRpbmcgdGhlIFxcXCJyZXF1ZXN0XFxcIiBldmVudCBmb3IgJXMgbGlzdGVuZXIocykuLi5cIiwgdGhpcy5lbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJyZXF1ZXN0XCIpKTtcblx0XHRcdFx0LyoqXG5cdFx0XHRcdCogQG5vdGUgR2l2ZSB0aGUgY29uc3VtZXIgYSBjaGFuY2UgdG8gYWJvcnQgdGhlIHJlcXVlc3QgYmVmb3JlXG5cdFx0XHRcdCogaXQgaXMgZGlzcGF0Y2hlZC4gRmV0Y2ggcXVldWVzIHRoZSByZXF1ZXN0IHByb2Nlc3NpbmcgYXMgYVxuXHRcdFx0XHQqIHRhc2ssIHNvIGEgc2lnbmFsIGFib3J0ZWQgc3luY2hyb25vdXNseSBhZnRlciBgZmV0Y2goKWAgbXVzdFxuXHRcdFx0XHQqIHByZXZlbnQgdGhlIHJlcXVlc3QgZnJvbSBldmVyIHJlYWNoaW5nIHRoZSBcInJlcXVlc3RcIiBsaXN0ZW5lcnMuXG5cdFx0XHRcdCogV2l0aG91dCB0aGlzLCB0aGUgZmlyc3QgbGlzdGVuZXIgaXMgaW52b2tlZCBzeW5jaHJvbm91c2x5XG5cdFx0XHRcdCogd2l0aGluIHRoZSBgZmV0Y2goKWAgY2FsbCBpdHNlbGYuXG5cdFx0XHRcdCovXG5cdFx0XHRcdGF3YWl0IFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdFx0XHRhd2FpdCBoYW5kbGVSZXF1ZXN0KHtcblx0XHRcdFx0XHRpbml0aWF0b3I6IHJlcXVlc3QsXG5cdFx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdFx0ZW1pdHRlcjogdGhpcy5lbWl0dGVyLFxuXHRcdFx0XHRcdGNvbnRyb2xsZXIsXG5cdFx0XHRcdFx0bG9nZ2VyXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRyZXR1cm4gcmVzcG9uc2VQcm9taXNlLnByb21pc2U7XG5cdFx0XHR9O1xuXHRcdH0pKTtcblx0XHRsb2dnZXIudmVyYm9zZShcImdsb2JhbCBmZXRjaCBwYXRjaGVkOiAlc1wiLCBnbG9iYWxUaGlzLmZldGNoLm5hbWUpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBGZXRjaEludGVyY2VwdG9yIGFzIHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d2ViLUNDTEVSU1pGLmpzLm1hcCIsImltcG9ydCB7IGggYXMgZGV2VXRpbHMgfSBmcm9tIFwiLi4vX2NodW5rcy9jb29raWUtc3RvcmUuanNcIjtcbmltcG9ydCB7IHQgYXMgUmVxdWVzdEhhbmRsZXIgfSBmcm9tIFwiLi4vX2NodW5rcy9yZXF1ZXN0LWhhbmRsZXIuanNcIjtcbmltcG9ydCB7IHQgYXMgaXNPYmplY3QgfSBmcm9tIFwiLi4vX2NodW5rcy9pcy1vYmplY3QuanNcIjtcbmltcG9ydCB7IHQgYXMgSHR0cFJlc3BvbnNlIH0gZnJvbSBcIi4uL19jaHVua3MvaHR0cC1yZXNwb25zZS5qc1wiO1xuaW1wb3J0IHsgaSBhcyBSZXNwb25zZUV2ZW50LCByIGFzIEh0dHBOZXR3b3JrRnJhbWUsIHMgYXMgZGVmaW5lTmV0d29yaywgdCBhcyBJbnRlcmNlcHRvclNvdXJjZSwgdSBhcyBOZXR3b3JrU291cmNlIH0gZnJvbSBcIi4uL19jaHVua3MvaW50ZXJjZXB0b3Itc291cmNlLmpzXCI7XG5pbXBvcnQgeyBpc05vZGVQcm9jZXNzIH0gZnJvbSBcImlzLW5vZGUtcHJvY2Vzc1wiO1xuaW1wb3J0IHsgaW52YXJpYW50IH0gZnJvbSBcIm91dHZhcmlhbnRcIjtcbmltcG9ydCB7IEZldGNoUmVxdWVzdCwgRmV0Y2hSZXNwb25zZSB9IGZyb20gXCJAbXN3anMvaW50ZXJjZXB0b3JzXCI7XG5pbXBvcnQgeyBFbWl0dGVyLCBUeXBlZEV2ZW50IH0gZnJvbSBcInJldHRpbWVcIjtcbmltcG9ydCB7IFdlYlNvY2tldEludGVyY2VwdG9yIH0gZnJvbSBcIkBtc3dqcy9pbnRlcmNlcHRvcnMvV2ViU29ja2V0XCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJ1bnRpbC1hc3luY1wiO1xuaW1wb3J0IHsgWE1MSHR0cFJlcXVlc3RJbnRlcmNlcHRvciB9IGZyb20gXCJAbXN3anMvaW50ZXJjZXB0b3JzL1hNTEh0dHBSZXF1ZXN0XCI7XG5pbXBvcnQgeyBGZXRjaEludGVyY2VwdG9yIH0gZnJvbSBcIkBtc3dqcy9pbnRlcmNlcHRvcnMvZmV0Y2hcIjtcbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci91dGlscy9zdXBwb3J0cy50c1xuLyoqXG4qIENoZWNrcyBpZiB0aGUgU2VydmljZSBXb3JrZXIgQVBJIGlzIHN1cHByb3RlZCBhbmQgYXZhaWxhYmxlXG4qIGluIHRoZSBjdXJyZW50IGJyb3dzaW5nIGNvbnRleHQuXG4qL1xuZnVuY3Rpb24gc3VwcG9ydHNTZXJ2aWNlV29ya2VyKCkge1xuXHRyZXR1cm4gdHlwZW9mIG5hdmlnYXRvciAhPT0gXCJ1bmRlZmluZWRcIiAmJiBcInNlcnZpY2VXb3JrZXJcIiBpbiBuYXZpZ2F0b3IgJiYgdHlwZW9mIGxvY2F0aW9uICE9PSBcInVuZGVmaW5lZFwiICYmIGxvY2F0aW9uLnByb3RvY29sICE9PSBcImZpbGU6XCI7XG59XG4vKipcbiogUmV0dXJucyBhIGJvb2xlYW4gaW5kaWNhdGluZyB3aGV0aGVyIHRoZSBjdXJyZW50IGJyb3dzZXJcbiogc3VwcG9ydHMgYFJlYWRhYmxlU3RyZWFtYCBhcyBhIGBUcmFuc2ZlcmFibGVgIHdoZW4gcG9zdGluZ1xuKiBtZXNzYWdlcy5cbiovXG5mdW5jdGlvbiBzdXBwb3J0c1JlYWRhYmxlU3RyZWFtVHJhbnNmZXIoKSB7XG5cdHRyeSB7XG5cdFx0Y29uc3Qgc3RyZWFtID0gbmV3IFJlYWRhYmxlU3RyZWFtKHsgc3RhcnQ6IChjb250cm9sbGVyKSA9PiBjb250cm9sbGVyLmNsb3NlKCkgfSk7XG5cdFx0bmV3IE1lc3NhZ2VDaGFubmVsKCkucG9ydDEucG9zdE1lc3NhZ2Uoc3RyZWFtLCBbc3RyZWFtXSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvdG8tcmVzcG9uc2UtaW5pdC50c1xuZnVuY3Rpb24gdG9SZXNwb25zZUluaXQocmVzcG9uc2UpIHtcblx0cmV0dXJuIHtcblx0XHRzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyxcblx0XHRzdGF0dXNUZXh0OiByZXNwb25zZS5zdGF0dXNUZXh0LFxuXHRcdGhlYWRlcnM6IE9iamVjdC5mcm9tRW50cmllcyhyZXNwb25zZS5oZWFkZXJzLmVudHJpZXMoKSlcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL2dldC1hYnNvbHV0ZS13b3JrZXItdXJsLnRzXG4vKipcbiogUmV0dXJucyBhbiBhYnNvbHV0ZSBTZXJ2aWNlIFdvcmtlciBVUkwgYmFzZWQgb24gdGhlIGdpdmVuXG4qIHJlbGF0aXZlIFVSTCAoa25vd24gZHVyaW5nIHRoZSByZWdpc3RyYXRpb24pLlxuKi9cbmZ1bmN0aW9uIGdldEFic29sdXRlV29ya2VyVXJsKHdvcmtlclVybCkge1xuXHRyZXR1cm4gbmV3IFVSTCh3b3JrZXJVcmwsIGxvY2F0aW9uLmhyZWYpLmhyZWY7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci91dGlscy9nZXQtd29ya2VyLWJ5LXJlZ2lzdHJhdGlvbi50c1xuLyoqXG4qIEF0dGVtcHRzIHRvIHJlc29sdmUgYSBTZXJ2aWNlIFdvcmtlciBpbnN0YW5jZSBmcm9tIGEgZ2l2ZW4gcmVnaXN0cmF0aW9uLFxuKiByZWdhcmRsZXNzIG9mIGl0cyBzdGF0ZSAoYWN0aXZlLCBpbnN0YWxsaW5nLCB3YWl0aW5nKS5cbiovXG5mdW5jdGlvbiBnZXRXb3JrZXJCeVJlZ2lzdHJhdGlvbihyZWdpc3RyYXRpb24sIGFic29sdXRlV29ya2VyVXJsLCBmaW5kV29ya2VyKSB7XG5cdHJldHVybiBbXG5cdFx0cmVnaXN0cmF0aW9uLmFjdGl2ZSxcblx0XHRyZWdpc3RyYXRpb24uaW5zdGFsbGluZyxcblx0XHRyZWdpc3RyYXRpb24ud2FpdGluZ1xuXHRdLmZpbHRlcigoc3RhdGUpID0+IHtcblx0XHRyZXR1cm4gc3RhdGUgIT0gbnVsbDtcblx0fSkuZmluZCgod29ya2VyKSA9PiB7XG5cdFx0cmV0dXJuIGZpbmRXb3JrZXIod29ya2VyLnNjcmlwdFVSTCwgYWJzb2x1dGVXb3JrZXJVcmwpO1xuXHR9KSB8fCBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvdXRpbHMvZ2V0LXdvcmtlci1pbnN0YW5jZS50c1xuLyoqXG4qIFJldHVybnMgYW4gYWN0aXZlIFNlcnZpY2UgV29ya2VyIGluc3RhbmNlLlxuKiBXaGVuIG5vdCBmb3VuZCwgcmVnaXN0ZXJzIGEgbmV3IFNlcnZpY2UgV29ya2VyLlxuKi9cbmNvbnN0IGdldFdvcmtlckluc3RhbmNlID0gYXN5bmMgKHVybCwgb3B0aW9ucyA9IHt9LCBmaW5kV29ya2VyKSA9PiB7XG5cdGNvbnN0IGFic29sdXRlV29ya2VyVXJsID0gZ2V0QWJzb2x1dGVXb3JrZXJVcmwodXJsKTtcblx0Y29uc3QgbW9ja1JlZ2lzdHJhdGlvbnMgPSBhd2FpdCBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5nZXRSZWdpc3RyYXRpb25zKCkudGhlbigocmVnaXN0cmF0aW9ucykgPT4gcmVnaXN0cmF0aW9ucy5maWx0ZXIoKHJlZ2lzdHJhdGlvbikgPT4gZ2V0V29ya2VyQnlSZWdpc3RyYXRpb24ocmVnaXN0cmF0aW9uLCBhYnNvbHV0ZVdvcmtlclVybCwgZmluZFdvcmtlcikpKTtcblx0aWYgKCFuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5jb250cm9sbGVyICYmIG1vY2tSZWdpc3RyYXRpb25zLmxlbmd0aCA+IDApIGxvY2F0aW9uLnJlbG9hZCgpO1xuXHRjb25zdCBbZXhpc3RpbmdSZWdpc3RyYXRpb25dID0gbW9ja1JlZ2lzdHJhdGlvbnM7XG5cdGlmIChleGlzdGluZ1JlZ2lzdHJhdGlvbikge1xuXHRcdGV4aXN0aW5nUmVnaXN0cmF0aW9uLnVwZGF0ZSgpO1xuXHRcdHJldHVybiBbZ2V0V29ya2VyQnlSZWdpc3RyYXRpb24oZXhpc3RpbmdSZWdpc3RyYXRpb24sIGFic29sdXRlV29ya2VyVXJsLCBmaW5kV29ya2VyKSwgZXhpc3RpbmdSZWdpc3RyYXRpb25dO1xuXHR9XG5cdGNvbnN0IFtyZWdpc3RyYXRpb25FcnJvciwgcmVnaXN0cmF0aW9uUmVzdWx0XSA9IGF3YWl0IHVudGlsKGFzeW5jICgpID0+IHtcblx0XHRjb25zdCByZWdpc3RyYXRpb24gPSBhd2FpdCBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5yZWdpc3Rlcih1cmwsIG9wdGlvbnMpO1xuXHRcdHJldHVybiBbZ2V0V29ya2VyQnlSZWdpc3RyYXRpb24ocmVnaXN0cmF0aW9uLCBhYnNvbHV0ZVdvcmtlclVybCwgZmluZFdvcmtlciksIHJlZ2lzdHJhdGlvbl07XG5cdH0pO1xuXHRpZiAocmVnaXN0cmF0aW9uRXJyb3IpIHtcblx0XHRpZiAocmVnaXN0cmF0aW9uRXJyb3IubWVzc2FnZS5pbmNsdWRlcyhcIig0MDQpXCIpKSB7XG5cdFx0XHRjb25zdCBzY29wZVVybCA9IG5ldyBVUkwob3B0aW9ucz8uc2NvcGUgfHwgXCIvXCIsIGxvY2F0aW9uLmhyZWYpO1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoYFxcXG5GYWlsZWQgdG8gcmVnaXN0ZXIgYSBTZXJ2aWNlIFdvcmtlciBmb3Igc2NvcGUgKCcke3Njb3BlVXJsLmhyZWZ9Jykgd2l0aCBzY3JpcHQgKCcke2Fic29sdXRlV29ya2VyVXJsfScpOiBTZXJ2aWNlIFdvcmtlciBzY3JpcHQgZG9lcyBub3QgZXhpc3QgYXQgdGhlIGdpdmVuIHBhdGguXG5cbkRpZCB5b3UgZm9yZ2V0IHRvIHJ1biBcIm5weCBtc3cgaW5pdCA8UFVCTElDX0RJUj5cIj9cblxuTGVhcm4gbW9yZSBhYm91dCBjcmVhdGluZyB0aGUgU2VydmljZSBXb3JrZXIgc2NyaXB0OiBodHRwczovL21zd2pzLmlvL2RvY3MvY2xpL2luaXRgKSk7XG5cdFx0fVxuXHRcdHRocm93IG5ldyBFcnJvcihkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiRmFpbGVkIHRvIHJlZ2lzdGVyIHRoZSBTZXJ2aWNlIFdvcmtlcjpcXG5cXG4lc1wiLCByZWdpc3RyYXRpb25FcnJvci5tZXNzYWdlKSk7XG5cdH1cblx0cmV0dXJuIHJlZ2lzdHJhdGlvblJlc3VsdDtcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci91dGlscy93b3JrZXItY2hhbm5lbC50c1xuY29uc3QgU1VQUE9SVFNfU0VSVklDRV9XT1JLRVIgPSBzdXBwb3J0c1NlcnZpY2VXb3JrZXIoKTtcbnZhciBXb3JrZXJFdmVudCA9IGNsYXNzIGV4dGVuZHMgVHlwZWRFdmVudCB7XG5cdCN3b3JrZXJFdmVudDtcblx0Y29uc3RydWN0b3Iod29ya2VyRXZlbnQpIHtcblx0XHRjb25zdCB0eXBlID0gd29ya2VyRXZlbnQuZGF0YS50eXBlO1xuXHRcdGNvbnN0IGRhdGEgPSB3b3JrZXJFdmVudC5kYXRhLnBheWxvYWQ7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBUaGlzIGlzIHRoZSBvbmx5IHBsYWNlIHdlJ3JlIG1hcHBpbmcgeyB0eXBlLCBwYXlsb2FkIH1cblx0XHQqIG1lc3NhZ2Ugc3RydWN0dXJlIG9mIHRoZSB3b3JrZXIuIFRoZSBjbGllbnQgcmVmZXJlbmNlcyB0aGVcblx0XHQqIHBheWxvYWQgdmlhIGBldmVudC5kYXRhYC5cblx0XHQqL1xuXHRcdHN1cGVyKHR5cGUsIHsgZGF0YSB9KTtcblx0XHR0aGlzLiN3b3JrZXJFdmVudCA9IHdvcmtlckV2ZW50O1xuXHR9XG5cdGdldCBwb3J0cygpIHtcblx0XHRyZXR1cm4gdGhpcy4jd29ya2VyRXZlbnQucG9ydHM7XG5cdH1cblx0LyoqXG5cdCogUmVwbHkgZGlyZWN0bHkgdG8gdGhpcyBldmVudCB1c2luZyBpdHMgYE1lc3NhZ2VQb3J0YC5cblx0Ki9cblx0cG9zdE1lc3NhZ2UodHlwZSwgLi4ucmVzdCkge1xuXHRcdHRoaXMuI3dvcmtlckV2ZW50LnBvcnRzWzBdLnBvc3RNZXNzYWdlKHtcblx0XHRcdHR5cGUsXG5cdFx0XHRkYXRhOiByZXN0WzBdXG5cdFx0fSwgeyB0cmFuc2ZlcjogcmVzdFsxXSB9KTtcblx0fVxufTtcbnZhciBXb3JrZXJDaGFubmVsID0gY2xhc3MgZXh0ZW5kcyBFbWl0dGVyIHtcblx0I2dldFdvcmtlcjtcblx0I2NvbnRyb2xsZXI7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcigpO1xuXHRcdGludmFyaWFudChTVVBQT1JUU19TRVJWSUNFX1dPUktFUiwgXCJGYWlsZWQgdG8gb3BlbiBhIFdvcmtlckNoYW5uZWw6IFNlcnZpY2UgV29ya2VyIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudC5cIik7XG5cdFx0dGhpcy4jZ2V0V29ya2VyID0gb3B0aW9ucy5nZXRXb3JrZXI7XG5cdFx0dGhpcy4jY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRuYXZpZ2F0b3Iuc2VydmljZVdvcmtlci5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBhc3luYyAoZXZlbnQpID0+IHtcblx0XHRcdGNvbnN0IHdvcmtlciA9IGF3YWl0IHRoaXMuI2dldFdvcmtlcigpO1xuXHRcdFx0aWYgKGV2ZW50LnNvdXJjZSAhPSBudWxsICYmIGV2ZW50LnNvdXJjZSAhPT0gd29ya2VyKSByZXR1cm47XG5cdFx0XHRpZiAoZXZlbnQuZGF0YSAmJiBpc09iamVjdChldmVudC5kYXRhKSAmJiBcInR5cGVcIiBpbiBldmVudC5kYXRhKSB0aGlzLmVtaXQobmV3IFdvcmtlckV2ZW50KGV2ZW50KSk7XG5cdFx0fSwgeyBzaWduYWw6IHRoaXMuI2NvbnRyb2xsZXIuc2lnbmFsIH0pO1xuXHR9XG5cdC8qKlxuXHQqIFNlbmQgZGF0YSB0byB0aGUgU2VydmljZSBXb3JrZXIgY29udHJvbGxpbmcgdGhpcyBjbGllbnQuXG5cdCogVGhpcyB0cmlnZ2VycyB0aGUgYG1lc3NhZ2VgIGV2ZW50IGxpc3RlbmVyIG9uIFNlcnZpY2VXb3JrZXJHbG9iYWxTY29wZS5cblx0Ki9cblx0cG9zdE1lc3NhZ2UodHlwZSkge1xuXHRcdGludmFyaWFudChTVVBQT1JUU19TRVJWSUNFX1dPUktFUiwgXCJGYWlsZWQgdG8gcG9zdCBtZXNzYWdlIG9uIGEgV29ya2VyQ2hhbm5lbDogdGhlIFNlcnZpY2UgV29ya2VyIEFQSSBpcyB1bmF2YWlsYWJsZSBpbiB0aGlzIGVudmlyb25tZW50LiBUaGlzIGlzIGxpa2VseSBhbiBpc3N1ZSB3aXRoIE1TVy4gUGxlYXNlIHJlcG9ydCBpdCBvbiBHaXRIdWI6IGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzXCIpO1xuXHRcdHRoaXMuI2dldFdvcmtlcigpLnRoZW4oKHdvcmtlcikgPT4ge1xuXHRcdFx0d29ya2VyLnBvc3RNZXNzYWdlKHR5cGUpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFRlcm1pbmFsIHRlYXJkb3duLiBSZW1vdmVzIHRoZSBgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXJgIG1lc3NhZ2UgbGlzdGVuZXJcblx0KiBhbmQgYWxsIGVtaXR0ZXIgc3Vic2NyaXB0aW9ucy4gVGhlIGNoYW5uZWwgaXMgbm90IHVzYWJsZSBhZnRlcndhcmRzLlxuXHQqL1xuXHR0ZXJtaW5hdGUoKSB7XG5cdFx0dGhpcy4jY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci91dGlscy9kZXNlcmlhbGl6ZS1yZXF1ZXN0LnRzXG4vKipcbiogQ29udmVydHMgYSBnaXZlbiByZXF1ZXN0IHJlY2VpdmVkIGZyb20gdGhlIFNlcnZpY2UgV29ya2VyXG4qIGludG8gYSBGZXRjaCBgUmVxdWVzdGAgaW5zdGFuY2UuXG4qL1xuZnVuY3Rpb24gZGVzZXJpYWxpemVSZXF1ZXN0KHNlcmlhbGl6ZWRSZXF1ZXN0KSB7XG5cdHJldHVybiBuZXcgRmV0Y2hSZXF1ZXN0KHNlcmlhbGl6ZWRSZXF1ZXN0LnVybCwgeyAuLi5zZXJpYWxpemVkUmVxdWVzdCB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL3ZhbGlkYXRlLXdvcmtlci1zY29wZS50c1xuLyoqXG4qIFByaW50IGEgd2FybmluZyBpZiB0aGUgZ2l2ZW4gU2VydmljZSBXb3JrZXIgcmVnaXN0cmF0aW9uIGhhcyBhIHNjb3BlXG4qIG91dHNpZGUgb2YgdGhlIGN1cnJlbnQgcGFnZSdzIGxvY2F0aW9uLiBUaGF0IGlzIHRvIGhlbHAgd2l0aCBkZWJ1Z2dpbmdcbiogaXNzdWVzIGNhdXNlZCBieSB0aGUgaW5jb3JyZWN0bHkgcmVnaXN0ZXJlZCBTZXJ2aWNlIFdvcmtlci5cbiovXG5mdW5jdGlvbiB2YWxpZGF0ZVdvcmtlclNjb3BlKHJlZ2lzdHJhdGlvbikge1xuXHRpZiAoIWxvY2F0aW9uLmhyZWYuc3RhcnRzV2l0aChyZWdpc3RyYXRpb24uc2NvcGUpKSBkZXZVdGlscy53YXJuKGBDYW5ub3QgaW50ZXJjZXB0IHJlcXVlc3RzIG9uIHRoaXMgcGFnZSBiZWNhdXNlIGl0J3Mgb3V0c2lkZSBvZiB0aGUgd29ya2VyJ3Mgc2NvcGUgKFwiJHtyZWdpc3RyYXRpb24uc2NvcGV9XCIpLiBJZiB5b3Ugd2lzaCB0byBtb2NrIEFQSSByZXF1ZXN0cyBvbiB0aGlzIHBhZ2UsIHlvdSBtdXN0IHJlc29sdmUgdGhpcyBzY29wZSBpc3N1ZS5cblxuLSAoUmVjb21tZW5kZWQpIFJlZ2lzdGVyIHRoZSB3b3JrZXIgYXQgdGhlIHJvb3QgbGV2ZWwgKFwiL1wiKSBvZiB5b3VyIGFwcGxpY2F0aW9uLlxuLSBTZXQgdGhlIFwiU2VydmljZS1Xb3JrZXItQWxsb3dlZFwiIHJlc3BvbnNlIGhlYWRlciB0byBhbGxvdyBvdXQtb2Ytc2NvcGUgd29ya2Vycy5gKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL3Nob3VsZC1pbnZhbGlkYXRlLXdvcmtlci50c1xuZnVuY3Rpb24gc2hvdWxkSW52YWxpZGF0ZVdvcmtlcihwcmV2T3B0aW9ucywgbmV4dE9wdGlvbnMpIHtcblx0cmV0dXJuIHByZXZPcHRpb25zLmZpbmRXb3JrZXIgIT09IG5leHRPcHRpb25zLmZpbmRXb3JrZXIgfHwgcHJldk9wdGlvbnMuc2VydmljZVdvcmtlci51cmwgIT09IG5leHRPcHRpb25zLnNlcnZpY2VXb3JrZXIudXJsIHx8IEpTT04uc3RyaW5naWZ5KHByZXZPcHRpb25zLnNlcnZpY2VXb3JrZXIub3B0aW9ucykgIT09IEpTT04uc3RyaW5naWZ5KG5leHRPcHRpb25zLnNlcnZpY2VXb3JrZXIub3B0aW9ucyk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci9zb3VyY2VzL3NlcnZpY2Utd29ya2VyLXNvdXJjZS50c1xudmFyIFNlcnZpY2VXb3JrZXJTb3VyY2UgPSBjbGFzcyBTZXJ2aWNlV29ya2VyU291cmNlIGV4dGVuZHMgTmV0d29ya1NvdXJjZSB7XG5cdHN0YXRpYyAjY3VycmVudDtcblx0LyoqXG5cdCogQ3JlYXRlIGEgbmV3IFNlcnZpY2UgV29ya2VyIHNvdXJjZSBvciByZXVzZSBhbiBleGlzdGluZyBvbmUuXG5cdCogVGhlc2Ugc291cmNlcyBhY3QgYXMgYSBzaW5nbGV0b24gYW5kIG9ubHkgZ2V0IHJlY3JlYXRlZCBpZiB0aGUgb3B0aW9ucyBjaGFuZ2UuXG5cdCovXG5cdHN0YXRpYyBhc3luYyBmcm9tKG9wdGlvbnMpIHtcblx0XHRpZiAoU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudCA9PSBudWxsKSBTZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50ID0gbmV3IFNlcnZpY2VXb3JrZXJTb3VyY2Uob3B0aW9ucyk7XG5cdFx0ZWxzZSBpZiAoc2hvdWxkSW52YWxpZGF0ZVdvcmtlcihTZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50LiNvcHRpb25zLCBvcHRpb25zKSkge1xuXHRcdFx0YXdhaXQgU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudC50ZXJtaW5hdGUoKTtcblx0XHRcdFNlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQgPSBuZXcgU2VydmljZVdvcmtlclNvdXJjZShvcHRpb25zKTtcblx0XHR9XG5cdFx0cmV0dXJuIFNlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQ7XG5cdH1cblx0I29wdGlvbnM7XG5cdC8qKlxuXHQqIEBub3RlIFdlIGNhbm5vdCB1c2UgYFdlYWtNYXBgIGhlcmUgYXMgcmVxdWVzdC9yZXNwb25zZVxuXHQqIGlkZW50aXR5IGNhbm5vdCBiZSBwcmVzZXJ2ZWQgdGhyb3VnaCB0aGUgY2xpZW50LXdvcmtlciBjaGFubmVsLlxuXHQqL1xuXHQjZnJhbWVzO1xuXHQjY2hhbm5lbDtcblx0I2xpc3RlbmVyQ29udHJvbGxlcjtcblx0I2NsaWVudFByb21pc2U7XG5cdCNrZWVwQWxpdmVJbnRlcnZhbDtcblx0d29ya2VyUHJvbWlzZTtcblx0I3dvcmtlclJlc29sdmVycztcblx0I3dvcmtlclN0YXRlO1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHRpbnZhcmlhbnQoc3VwcG9ydHNTZXJ2aWNlV29ya2VyKCksIFwiRmFpbGVkIHRvIHVzZSBTZXJ2aWNlIFdvcmtlciBhcyB0aGUgbmV0d29yayBzb3VyY2U6IHRoZSBTZXJ2aWNlIFdvcmtlciBBUEkgaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50XCIpO1xuXHRcdHRoaXMuI29wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMuI2ZyYW1lcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jd29ya2VyUmVzb2x2ZXJzID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0dGhpcy53b3JrZXJQcm9taXNlID0gdGhpcy4jd29ya2VyUmVzb2x2ZXJzLnByb21pc2U7XG5cdFx0dGhpcy4jd29ya2VyU3RhdGUgPSBcInBlbmRpbmdcIjtcblx0XHR0aGlzLiNjaGFubmVsID0gbmV3IFdvcmtlckNoYW5uZWwoeyBnZXRXb3JrZXI6ICgpID0+IHRoaXMud29ya2VyUHJvbWlzZS50aGVuKChbd29ya2VyXSkgPT4gd29ya2VyKSB9KTtcblx0fVxuXHRhc3luYyBlbmFibGUoKSB7XG5cdFx0dGhpcy4jY2hhbm5lbC5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcblx0XHR0aGlzLiNmcmFtZXMuY2xlYXIoKTtcblx0XHR0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0Y29uc3QgW3dvcmtlciwgcmVnaXN0cmF0aW9uXSA9IGF3YWl0IHRoaXMuI3N0YXJ0V29ya2VyKCk7XG5cdFx0aWYgKHdvcmtlci5zdGF0ZSAhPT0gXCJhY3RpdmF0ZWRcIikge1xuXHRcdFx0Y29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRcdGNvbnN0IGFjdGl2YXRpb25Qcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0XHRhY3RpdmF0aW9uUHJvbWlzZS5wcm9taXNlLnRoZW4oKCkgPT4gY29udHJvbGxlci5hYm9ydCgpKTtcblx0XHRcdHdvcmtlci5hZGRFdmVudExpc3RlbmVyKFwic3RhdGVjaGFuZ2VcIiwgKCkgPT4ge1xuXHRcdFx0XHRpZiAod29ya2VyLnN0YXRlID09PSBcImFjdGl2YXRlZFwiKSBhY3RpdmF0aW9uUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHR9LCB7IHNpZ25hbDogY29udHJvbGxlci5zaWduYWwgfSk7XG5cdFx0XHRhd2FpdCBhY3RpdmF0aW9uUHJvbWlzZS5wcm9taXNlO1xuXHRcdH1cblx0XHR0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiTU9DS19BQ1RJVkFURVwiKTtcblx0XHRjb25zdCBjbGllbnRDb25maXJtYXRpb25Qcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0dGhpcy4jY2xpZW50UHJvbWlzZSA9IGNsaWVudENvbmZpcm1hdGlvblByb21pc2UucHJvbWlzZTtcblx0XHR0aGlzLiNjaGFubmVsLm9uY2UoXCJNT0NLSU5HX0VOQUJMRURcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRjbGllbnRDb25maXJtYXRpb25Qcm9taXNlLnJlc29sdmUoZXZlbnQuZGF0YS5jbGllbnQpO1xuXHRcdH0pO1xuXHRcdGF3YWl0IGNsaWVudENvbmZpcm1hdGlvblByb21pc2UucHJvbWlzZTtcblx0XHRpZiAoIXRoaXMuI29wdGlvbnMucXVpZXQpIHRoaXMuI3ByaW50U3RhcnRNZXNzYWdlKCk7XG5cdFx0cmV0dXJuIHJlZ2lzdHJhdGlvbjtcblx0fVxuXHRhc3luYyBkaXNhYmxlKCkge1xuXHRcdC8qKlxuXHRcdCogQG5vdGUgRG8gTk9UIGNhbGwgYHN1cGVyLmRpc2FibGUoKWAgYmVjYXVzZSBpdCByZW1vdmVzIGFueSBcImZyYW1lXCIgbGlzdGVuZXJzXG5cdFx0KiBmcm9tIHRoaXMgbmV0d29yayBzb3VyY2UsIGVmZmVjdGl2ZWx5IHR1cm5pbmcgaXQgb2ZmLiBUaGUgU2VydmljZSBXb3JrZXIgc291cmNlXG5cdFx0KiBpcyBhIGJpdCBzcGVjaWFsIHNpbmNlIGl0IG1pZ2h0IHByb2Nlc3MgaW4tZmxpZ2h0IHJlcXVlc3RzIHRoYXQgaGF2ZSBiZWVuIHBlcmZvcm1lZFxuXHRcdCogYWZ0ZXIgaXQncyBiZWVuIGRpc2FibGVkLlxuXHRcdCovXG5cdFx0dGhpcy4jbGlzdGVuZXJDb250cm9sbGVyPy5hYm9ydCgpO1xuXHRcdHRoaXMuI2xpc3RlbmVyQ29udHJvbGxlciA9IHZvaWQgMDtcblx0XHRjb25zdCBjbG9zZWRQcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0dGhpcy4jY2hhbm5lbC5vbmNlKFwiQ0xJRU5UX0NMT1NFRFwiLCAoKSA9PiBjbG9zZWRQcm9taXNlLnJlc29sdmUoKSk7XG5cdFx0dGhpcy4jY2hhbm5lbC5wb3N0TWVzc2FnZShcIkNMSUVOVF9DTE9TRVwiKTtcblx0XHRhd2FpdCBjbG9zZWRQcm9taXNlLnByb21pc2U7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBEbyBOT1QgcmVzZXQgYHdvcmtlclByb21pc2VgIGhlcmUuIFRoZSBjaGFubmVsIG11c3QgY29udGludWUgdG9cblx0XHQqIHJlc29sdmUgdGhlIGN1cnJlbnRseSByZWdpc3RlcmVkIFNXIHNvIHRoYXQgYW55IGluLWZsaWdodCByZXF1ZXN0cyB0aGVcblx0XHQqIHdvcmtlciBmb3J3YXJkcyBhZnRlciBgc3RvcCgpYCBjYW4gYmUgYW5zd2VyZWQgd2l0aCBgUEFTU1RIUk9VR0hgIGJ5XG5cdFx0KiBgI2hhbmRsZVJlcXVlc3RgLiBgI3N0YXJ0V29ya2VyYCBzd2FwcyBpbiBhIGZyZXNoIGRlZmVycmVkIG9uIHJlLWVuYWJsZS5cblx0XHQqL1xuXHRcdGlmICghdGhpcy4jb3B0aW9ucy5xdWlldCkgdGhpcy4jcHJpbnRTdG9wTWVzc2FnZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFRlcm1pbmFsIHRlYXJkb3duLiBVbnJlZ2lzdGVycyB0aGUgU2VydmljZSBXb3JrZXIsIHRlYXJzIGRvd24gdGhlIGNoYW5uZWwsXG5cdCogYW5kIGNsZWFycyB0aW1lcnMuIENhbGxlZCB3aGVuIHRoZSBzaW5nbGV0b24gaXMgYmVpbmcgcmVwbGFjZWQgd2l0aCBvbmVcblx0KiB0aGF0IGhhcyBkaWZmZXJlbnQgb3B0aW9ucy4gVGhlIGluc3RhbmNlIGlzIG5vdCB1c2FibGUgYWZ0ZXJ3YXJkcy5cblx0Ki9cblx0YXN5bmMgdGVybWluYXRlKCkge1xuXHRcdGlmICh0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCAhPSBudWxsKSB7XG5cdFx0XHRjbGVhckludGVydmFsKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsKTtcblx0XHRcdHRoaXMuI2tlZXBBbGl2ZUludGVydmFsID0gdm9pZCAwO1xuXHRcdH1cblx0XHR0aGlzLiNmcmFtZXMuY2xlYXIoKTtcblx0XHR0aGlzLiNjaGFubmVsLnRlcm1pbmF0ZSgpO1xuXHRcdHRoaXMuI2xpc3RlbmVyQ29udHJvbGxlcj8uYWJvcnQoKTtcblx0XHR0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXIgPSB2b2lkIDA7XG5cdFx0aWYgKHRoaXMuI3dvcmtlclN0YXRlID09PSBcImZ1bGZpbGxlZFwiKSB7XG5cdFx0XHRjb25zdCBbLCByZWdpc3RyYXRpb25dID0gYXdhaXQgdGhpcy53b3JrZXJQcm9taXNlO1xuXHRcdFx0YXdhaXQgcmVnaXN0cmF0aW9uLnVucmVnaXN0ZXIoKTtcblx0XHR9XG5cdFx0aWYgKFNlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQgPT09IHRoaXMpIFNlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQgPSB2b2lkIDA7XG5cdH1cblx0YXN5bmMgI3N0YXJ0V29ya2VyKCkge1xuXHRcdGlmICh0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCkgY2xlYXJJbnRlcnZhbCh0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCk7XG5cdFx0Y29uc3Qgd29ya2VyVXJsID0gdGhpcy4jb3B0aW9ucy5zZXJ2aWNlV29ya2VyLnVybDtcblx0XHRjb25zdCBbd29ya2VyLCByZWdpc3RyYXRpb25dID0gYXdhaXQgZ2V0V29ya2VySW5zdGFuY2Uod29ya2VyVXJsLCB0aGlzLiNvcHRpb25zLnNlcnZpY2VXb3JrZXIub3B0aW9ucywgdGhpcy4jb3B0aW9ucy5maW5kV29ya2VyIHx8IHRoaXMuI2RlZmF1bHRGaW5kV29ya2VyKTtcblx0XHRpZiAod29ya2VyID09IG51bGwpIHtcblx0XHRcdGNvbnN0IG1pc3NpbmdXb3JrZXJNZXNzYWdlID0gdGhpcy4jb3B0aW9ucz8uZmluZFdvcmtlciA/IGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoYEZhaWxlZCB0byBsb2NhdGUgdGhlIFNlcnZpY2UgV29ya2VyIHJlZ2lzdHJhdGlvbiB1c2luZyBhIGN1c3RvbSBcImZpbmRXb3JrZXJcIiBwcmVkaWNhdGUuXG5cblBsZWFzZSBlbnN1cmUgdGhhdCB0aGUgY3VzdG9tIHByZWRpY2F0ZSBwcm9wZXJseSBsb2NhdGVzIHRoZSBTZXJ2aWNlIFdvcmtlciByZWdpc3RyYXRpb24gYXQgXCIlc1wiLlxuTW9yZSBkZXRhaWxzOiBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL3NldHVwLXdvcmtlci9zdGFydCNmaW5kd29ya2VyXG4gICAgIGAsIHdvcmtlclVybCkgOiBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKGBGYWlsZWQgdG8gbG9jYXRlIHRoZSBTZXJ2aWNlIFdvcmtlciByZWdpc3RyYXRpb24uXG5cblRoaXMgbW9zdCBsaWtlbHkgbWVhbnMgdGhhdCB0aGUgd29ya2VyIHNjcmlwdCBVUkwgXCIlc1wiIGNhbm5vdCByZXNvbHZlIGFnYWluc3QgdGhlIGFjdHVhbCBwdWJsaWMgaG9zdG5hbWUgKCVzKS4gVGhpcyBtYXkgaGFwcGVuIGlmIHlvdXIgYXBwbGljYXRpb24gcnVucyBiZWhpbmQgYSBwcm94eSwgb3IgaGFzIGEgZHluYW1pYyBob3N0bmFtZS5cblxuUGxlYXNlIGNvbnNpZGVyIHVzaW5nIGEgY3VzdG9tIFwic2VydmljZVdvcmtlci51cmxcIiBvcHRpb24gdG8gcG9pbnQgdG8gdGhlIGFjdHVhbCB3b3JrZXIgc2NyaXB0IGxvY2F0aW9uLCBvciBhIGN1c3RvbSBcImZpbmRXb3JrZXJcIiBvcHRpb24gdG8gcmVzb2x2ZSB0aGUgU2VydmljZSBXb3JrZXIgcmVnaXN0cmF0aW9uIG1hbnVhbGx5LiBNb3JlIGRldGFpbHM6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvc2V0dXAtd29ya2VyL3N0YXJ0YCwgd29ya2VyVXJsLCBsb2NhdGlvbi5ob3N0KTtcblx0XHRcdHRocm93IG5ldyBFcnJvcihtaXNzaW5nV29ya2VyTWVzc2FnZSk7XG5cdFx0fVxuXHRcdGlmICh0aGlzLiN3b3JrZXJTdGF0ZSA9PT0gXCJwZW5kaW5nXCIpIHtcblx0XHRcdHRoaXMuI3dvcmtlclJlc29sdmVycy5yZXNvbHZlKFt3b3JrZXIsIHJlZ2lzdHJhdGlvbl0pO1xuXHRcdFx0dGhpcy4jd29ya2VyU3RhdGUgPSBcImZ1bGZpbGxlZFwiO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgUmUtZW5hYmxlIGFmdGVyIGBzdG9wKClgOiB0aGUgcHJldmlvdXMgYHdvcmtlclByb21pc2VgIGlzIGFscmVhZHlcblx0XHRcdCogZnVsZmlsbGVkIGFuZCBjYW5ub3QgYmUgcmVzb2x2ZWQgYWdhaW4uIFN3YXAgaW4gYSBwcmUtcmVzb2x2ZWQgb25lIHNvXG5cdFx0XHQqIGBnZXRXb3JrZXIoKWAgc2VlcyB0aGUgbmV3IHdvcmtlciBpbnN0YW5jZSBpbW1lZGlhdGVseS5cblx0XHRcdCovXG5cdFx0XHR0aGlzLiN3b3JrZXJSZXNvbHZlcnMgPSBQcm9taXNlLndpdGhSZXNvbHZlcnMoKTtcblx0XHRcdHRoaXMuI3dvcmtlclJlc29sdmVycy5yZXNvbHZlKFt3b3JrZXIsIHJlZ2lzdHJhdGlvbl0pO1xuXHRcdFx0dGhpcy53b3JrZXJQcm9taXNlID0gdGhpcy4jd29ya2VyUmVzb2x2ZXJzLnByb21pc2U7XG5cdFx0fVxuXHRcdHRoaXMuI2NoYW5uZWwub24oXCJSRVFVRVNUXCIsIHRoaXMuI2hhbmRsZVJlcXVlc3QuYmluZCh0aGlzKSk7XG5cdFx0dGhpcy4jY2hhbm5lbC5vbihcIlJFU1BPTlNFXCIsIHRoaXMuI2hhbmRsZVJlc3BvbnNlLmJpbmQodGhpcykpO1xuXHRcdHRoaXMuI2NoYW5uZWwub24oXCJSRVFVRVNUX0VSUk9SXCIsIHRoaXMuI2hhbmRsZVJlcXVlc3RFcnJvci5iaW5kKHRoaXMpKTtcblx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKGV2ZW50LnBlcnNpc3RlZCkgcmV0dXJuO1xuXHRcdFx0aWYgKHdvcmtlci5zdGF0ZSAhPT0gXCJyZWR1bmRhbnRcIikgdGhpcy4jY2hhbm5lbC5wb3N0TWVzc2FnZShcIkNMSUVOVF9DTE9TRVwiKTtcblx0XHRcdGNsZWFySW50ZXJ2YWwodGhpcy4ja2VlcEFsaXZlSW50ZXJ2YWwpO1xuXHRcdFx0d2luZG93LnBvc3RNZXNzYWdlKHsgdHlwZTogXCJtc3cvd29ya2VyOnN0b3BcIiB9KTtcblx0XHR9LCB7IHNpZ25hbDogdGhpcy4jbGlzdGVuZXJDb250cm9sbGVyPy5zaWduYWwgfSk7XG5cdFx0YXdhaXQgdGhpcy4jY2hlY2tXb3JrZXJJbnRlZ3JpdHkoKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdGRldlV0aWxzLmVycm9yKFwiRXJyb3Igd2hpbGUgY2hlY2tpbmcgdGhlIHdvcmtlciBzY3JpcHQgaW50ZWdyaXR5LiBQbGVhc2UgcmVwb3J0IHRoaXMgb24gR2l0SHViIChodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3VlcykgYW5kIGluY2x1ZGUgdGhlIG9yaWdpbmFsIGVycm9yIGJlbG93LlwiKTtcblx0XHRcdGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xuXHRcdH0pO1xuXHRcdHRoaXMuI2tlZXBBbGl2ZUludGVydmFsID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHtcblx0XHRcdHRoaXMuI2NoYW5uZWwucG9zdE1lc3NhZ2UoXCJLRUVQQUxJVkVfUkVRVUVTVFwiKTtcblx0XHR9LCA1ZTMpO1xuXHRcdGlmICghdGhpcy4jb3B0aW9ucy5xdWlldCkgdmFsaWRhdGVXb3JrZXJTY29wZShyZWdpc3RyYXRpb24pO1xuXHRcdHJldHVybiBbd29ya2VyLCByZWdpc3RyYXRpb25dO1xuXHR9XG5cdGFzeW5jICNoYW5kbGVSZXF1ZXN0KGV2ZW50KSB7XG5cdFx0Y29uc3QgcmVxdWVzdCA9IGRlc2VyaWFsaXplUmVxdWVzdChldmVudC5kYXRhKTtcblx0XHRSZXF1ZXN0SGFuZGxlci5jYWNoZS5zZXQocmVxdWVzdCwgcmVxdWVzdC5jbG9uZSgpKTtcblx0XHRjb25zdCBmcmFtZSA9IG5ldyBTZXJ2aWNlV29ya2VySHR0cE5ldHdvcmtGcmFtZSh7XG5cdFx0XHRldmVudCxcblx0XHRcdHJlcXVlc3Rcblx0XHR9KTtcblx0XHR0aGlzLiNmcmFtZXMuc2V0KGV2ZW50LmRhdGEuaWQsIGZyYW1lKTtcblx0XHRhd2FpdCB0aGlzLnF1ZXVlKGZyYW1lKTtcblx0fVxuXHRhc3luYyAjaGFuZGxlUmVzcG9uc2UoZXZlbnQpIHtcblx0XHRjb25zdCB7IHJlcXVlc3QsIHJlc3BvbnNlLCBpc01vY2tlZFJlc3BvbnNlIH0gPSBldmVudC5kYXRhO1xuXHRcdGNvbnN0IGZyYW1lID0gdGhpcy4jZnJhbWVzLmdldChyZXF1ZXN0LmlkKTtcblx0XHQvKipcblx0XHQqIENPUlMgcmVxdWVzdHMgd2l0aCBgbW9kZTogXCJuby1jb3JzXCJgIHJlc3VsdCBpbiBcIm9wYXF1ZVwiIHJlc3BvbnNlcy5cblx0XHQqIFRoYXQga2luZCBvZiByZXNwb25zZXMgY2Fubm90IGJlIG1hbmlwdWxhdGVkIGluIEphdmFTY3JpcHQgZHVlXG5cdFx0KiB0byB0aGUgc2VjdXJpdHkgY29uc2lkZXJhdGlvbnMuXG5cdFx0KiBAc2VlIGh0dHBzOi8vZmV0Y2guc3BlYy53aGF0d2cub3JnLyNjb25jZXB0LWZpbHRlcmVkLXJlc3BvbnNlLW9wYXF1ZVxuXHRcdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlcy81Mjlcblx0XHQqL1xuXHRcdGlmIChyZXNwb25zZS50eXBlPy5pbmNsdWRlcyhcIm9wYXF1ZVwiKSkge1xuXHRcdFx0dGhpcy4jZnJhbWVzLmRlbGV0ZShyZXF1ZXN0LmlkKTtcblx0XHRcdGZyYW1lPy5ldmVudHMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHRoaXMuI2ZyYW1lcy5kZWxldGUocmVxdWVzdC5pZCk7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBBIHJlcXVlc3QgZnJhbWUgd2lsbCBiZSBtaXNzaW5nIGluIGNhc2Ugb2YgcGFzc3Rocm91Z2ggYWZ0ZXIgdGhlIHdvcmtlciBpcyBzdG9wcGVkLlxuXHRcdCogQ3JlYXRpbmcgYSBmcmFtZSBpcyBjb3N0bHkgc28gaXQncyBiZXR0ZXIgdG8gaGFuZGxlIGl0IGFzIGFuIGVkZ2UgY2FzZSBoZXJlLlxuXHRcdCovXG5cdFx0aWYgKGZyYW1lID09IG51bGwpIHJldHVybjtcblx0XHRjb25zdCBmZXRjaFJlcXVlc3QgPSBkZXNlcmlhbGl6ZVJlcXVlc3QocmVxdWVzdCk7XG5cdFx0Y29uc3QgZmV0Y2hSZXNwb25zZSA9IHJlc3BvbnNlLnN0YXR1cyA9PT0gMCA/IFJlc3BvbnNlLmVycm9yKCkgOiBuZXcgRmV0Y2hSZXNwb25zZShcblx0XHRcdC8qKlxuXHRcdFx0KiBSZXNwb25zZXMgbWF5IGJlIHN0cmVhbXMgaGVyZSwgYnV0IHdoZW4gd2UgY3JlYXRlIGEgcmVzcG9uc2Ugb2JqZWN0XG5cdFx0XHQqIHdpdGggbnVsbC1ib2R5IHN0YXR1cyBjb2RlcywgbGlrZSAyMDQsIDIwNSwgMzA0IFJlc3BvbnNlIHdpbGxcblx0XHRcdCogdGhyb3cgd2hlbiBwYXNzZWQgYSBub24tbnVsbCBib2R5LCBzbyBlbnN1cmUgaXQncyBudWxsIGhlcmVcblx0XHRcdCogZm9yIHRob3NlIGNvZGVzXG5cdFx0XHQqL1xuXHRcdFx0RmV0Y2hSZXNwb25zZS5pc1Jlc3BvbnNlV2l0aEJvZHkocmVzcG9uc2Uuc3RhdHVzKSA/IHJlc3BvbnNlLmJvZHkgOiBudWxsLFxuXHRcdFx0e1xuXHRcdFx0XHQuLi5yZXNwb25zZSxcblx0XHRcdFx0LyoqXG5cdFx0XHRcdCogU2V0IHJlc3BvbnNlIFVSTCBpZiBpdCdzIG5vdCBzZXQgYWxyZWFkeS5cblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzIwMzBcblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9SZXNwb25zZS91cmxcblx0XHRcdFx0Ki9cblx0XHRcdFx0dXJsOiByZXF1ZXN0LnVybFxuXHRcdFx0fVxuXHRcdCk7XG5cdFx0dHJ5IHtcblx0XHRcdGZyYW1lLmV2ZW50cy5lbWl0KG5ldyBSZXNwb25zZUV2ZW50KGlzTW9ja2VkUmVzcG9uc2UgPyBcInJlc3BvbnNlOm1vY2tlZFwiIDogXCJyZXNwb25zZTpieXBhc3NcIiwge1xuXHRcdFx0XHRyZXF1ZXN0SWQ6IGZyYW1lLmRhdGEuaWQsXG5cdFx0XHRcdHJlcXVlc3Q6IGZldGNoUmVxdWVzdCxcblx0XHRcdFx0cmVzcG9uc2U6IGZldGNoUmVzcG9uc2UsXG5cdFx0XHRcdGlzTW9ja2VkUmVzcG9uc2Vcblx0XHRcdH0pKTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0ZnJhbWUuZXZlbnRzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBAbm90ZSBBIHJlcXVlc3QgY2FuIHNldHRsZSB3aXRob3V0IGV2ZXIgcHJvZHVjaW5nIGEgcmVzcG9uc2Vcblx0KiAoZS5nLiBhIHBhc3N0aHJvdWdoIHJlcXVlc3QgZmFpbGluZyB3aXRoIGEgbmV0d29yayBlcnJvcikuXG5cdCogVGhlIHdvcmtlciBuZXZlciBzZW5kcyB0aGUgXCJSRVNQT05TRVwiIG1lc3NhZ2UgZm9yIHN1Y2ggcmVxdWVzdHMsXG5cdCogc28gdGhlIGZyYW1lIG11c3QgYmUgcmVsZWFzZWQgaGVyZSB0byBwcmV2ZW50IGl0IGZyb20gYmVpbmcgcmV0YWluZWQuXG5cdCogTm8gXCJyZXNwb25zZToqXCIgZXZlbnQgaXMgZW1pdHRlZCwgY29uc2lzdGVudCB3aXRoIHRoZSBOb2RlLmpzIHNvdXJjZS5cblx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzI3OTJcblx0Ki9cblx0I2hhbmRsZVJlcXVlc3RFcnJvcihldmVudCkge1xuXHRcdGNvbnN0IHsgcmVxdWVzdCB9ID0gZXZlbnQuZGF0YTtcblx0XHRjb25zdCBmcmFtZSA9IHRoaXMuI2ZyYW1lcy5nZXQocmVxdWVzdC5pZCk7XG5cdFx0dGhpcy4jZnJhbWVzLmRlbGV0ZShyZXF1ZXN0LmlkKTtcblx0XHRmcmFtZT8uZXZlbnRzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuXHR9XG5cdCNkZWZhdWx0RmluZFdvcmtlciA9ICh3b3JrZXJVcmwsIG1vY2tTZXJ2aWNlV29ya2VyVXJsKSA9PiB7XG5cdFx0cmV0dXJuIHdvcmtlclVybCA9PT0gbW9ja1NlcnZpY2VXb3JrZXJVcmw7XG5cdH07XG5cdGFzeW5jICNjaGVja1dvcmtlckludGVncml0eSgpIHtcblx0XHRjb25zdCBpbnRlZ3JpdHlDaGVja1Byb21pc2UgPSBQcm9taXNlLndpdGhSZXNvbHZlcnMoKTtcblx0XHR0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiSU5URUdSSVRZX0NIRUNLX1JFUVVFU1RcIik7XG5cdFx0dGhpcy4jY2hhbm5lbC5vbmNlKFwiSU5URUdSSVRZX0NIRUNLX1JFU1BPTlNFXCIsIChldmVudCkgPT4ge1xuXHRcdFx0Y29uc3QgeyBjaGVja3N1bSwgcGFja2FnZVZlcnNpb24gfSA9IGV2ZW50LmRhdGE7XG5cdFx0XHRpZiAoY2hlY2tzdW0gIT09IFwiNWNkNWNmOGI1NGMzYTkwZjgyOTYwY2VkY2Q2Mzc3NzJcIikgZGV2VXRpbHMud2FybihgVGhlIGN1cnJlbnRseSByZWdpc3RlcmVkIFNlcnZpY2UgV29ya2VyIGhhcyBiZWVuIGdlbmVyYXRlZCBieSBhIGRpZmZlcmVudCB2ZXJzaW9uIG9mIE1TVyAoJHtwYWNrYWdlVmVyc2lvbn0pIGFuZCBtYXkgbm90IGJlIGZ1bGx5IGNvbXBhdGlibGUgd2l0aCB0aGUgaW5zdGFsbGVkIHZlcnNpb24uXG5cbkl0J3MgcmVjb21tZW5kZWQgeW91IHVwZGF0ZSB5b3VyIHdvcmtlciBzY3JpcHQgYnkgcnVubmluZyB0aGlzIGNvbW1hbmQ6XG5cbiAgXFx1MjAyMiBucHggbXN3IGluaXQgPFBVQkxJQ19ESVI+XG5cbllvdSBjYW4gYWxzbyBhdXRvbWF0ZSB0aGlzIHByb2Nlc3MgYW5kIG1ha2UgdGhlIHdvcmtlciBzY3JpcHQgdXBkYXRlIGF1dG9tYXRpY2FsbHkgdXBvbiB0aGUgbGlicmFyeSBpbnN0YWxsYXRpb25zLiBSZWFkIG1vcmU6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9jbGkvaW5pdC5gKTtcblx0XHRcdGludGVncml0eUNoZWNrUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIGludGVncml0eUNoZWNrUHJvbWlzZS5wcm9taXNlO1xuXHR9XG5cdGFzeW5jICNwcmludFN0YXJ0TWVzc2FnZSgpIHtcblx0XHRpZiAodGhpcy4jd29ya2VyU3RhdGUgPT09IFwicmVqZWN0ZWRcIikgcmV0dXJuO1xuXHRcdGludmFyaWFudCh0aGlzLiNjbGllbnRQcm9taXNlICE9IG51bGwsIFwiW1NlcnZpY2VXb3JrZXJTb3VyY2VdIEZhaWxlZCB0byBwcmludCBhIHN0YXJ0IG1lc3NhZ2U6IGNsaWVudCBjb25maXJtYXRpb24gbm90IHJlY2VpdmVkXCIpO1xuXHRcdGNvbnN0IGNsaWVudCA9IGF3YWl0IHRoaXMuI2NsaWVudFByb21pc2U7XG5cdFx0Y29uc3QgW3dvcmtlciwgcmVnaXN0cmF0aW9uXSA9IGF3YWl0IHRoaXMud29ya2VyUHJvbWlzZTtcblx0XHRjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGAlYyR7ZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIk1vY2tpbmcgZW5hYmxlZC5cIil9YCwgXCJjb2xvcjpvcmFuZ2VyZWQ7Zm9udC13ZWlnaHQ6Ym9sZDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY0RvY3VtZW50YXRpb246ICVjaHR0cHM6Ly9tc3dqcy5pby9kb2NzXCIsIFwiZm9udC13ZWlnaHQ6Ym9sZFwiLCBcImZvbnQtd2VpZ2h0Om5vcm1hbFwiKTtcblx0XHRjb25zb2xlLmxvZyhcIkZvdW5kIGFuIGlzc3VlPyBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlc1wiKTtcblx0XHRjb25zb2xlLmxvZyhcIldvcmtlciBzY3JpcHQgVVJMOlwiLCB3b3JrZXIuc2NyaXB0VVJMKTtcblx0XHRjb25zb2xlLmxvZyhcIldvcmtlciBzY29wZTpcIiwgcmVnaXN0cmF0aW9uLnNjb3BlKTtcblx0XHRpZiAoY2xpZW50KSBjb25zb2xlLmxvZyhcIkNsaWVudCBJRDogJXMgKCVzKVwiLCBjbGllbnQuaWQsIGNsaWVudC5mcmFtZVR5cGUpO1xuXHRcdGNvbnNvbGUuZ3JvdXBFbmQoKTtcblx0fVxuXHQjcHJpbnRTdG9wTWVzc2FnZSgpIHtcblx0XHRjb25zb2xlLmxvZyhgJWMke2RldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJNb2NraW5nIGRpc2FibGVkLlwiKX1gLCBcImNvbG9yOm9yYW5nZXJlZDtmb250LXdlaWdodDpib2xkO1wiKTtcblx0fVxufTtcbnZhciBTZXJ2aWNlV29ya2VySHR0cE5ldHdvcmtGcmFtZSA9IGNsYXNzIGV4dGVuZHMgSHR0cE5ldHdvcmtGcmFtZSB7XG5cdCNldmVudDtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKHsgcmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0IH0pO1xuXHRcdHRoaXMuI2V2ZW50ID0gb3B0aW9ucy5ldmVudDtcblx0fVxuXHRwYXNzdGhyb3VnaCgpIHtcblx0XHR0aGlzLiNldmVudC5wb3N0TWVzc2FnZShcIlBBU1NUSFJPVUdIXCIsIHsgcmVxdWVzdDogeyBoZWFkZXJzOiBBcnJheS5mcm9tKHRoaXMuZGF0YS5yZXF1ZXN0LmhlYWRlcnMpIH0gfSk7XG5cdH1cblx0cmVzcG9uZFdpdGgocmVzcG9uc2UpIHtcblx0XHRpZiAocmVzcG9uc2UpIHRoaXMuI3Jlc3BvbmRXaXRoKHJlc3BvbnNlKTtcblx0fVxuXHRlcnJvcldpdGgocmVhc29uKSB7XG5cdFx0aWYgKHJlYXNvbiBpbnN0YW5jZW9mIFJlc3BvbnNlKSByZXR1cm4gdGhpcy5yZXNwb25kV2l0aChyZWFzb24pO1xuXHRcdGRldlV0aWxzLndhcm4oYFVuY2F1Z2h0IGV4Y2VwdGlvbiBpbiB0aGUgcmVxdWVzdCBoYW5kbGVyIGZvciBcIiVzICVzXCIuIFRoaXMgZXhjZXB0aW9uIGhhcyBiZWVuIGdyYWNlZnVsbHkgaGFuZGxlZCBhcyBhIDUwMCByZXNwb25zZSwgaG93ZXZlciwgaXQncyBzdHJvbmdseSByZWNvbW1lbmRlZCB0byByZXNvbHZlIHRoaXMgZXJyb3IsIGFzIGl0IGluZGljYXRlcyBhIG1pc3Rha2UgaW4geW91ciBjb2RlLiBJZiB5b3Ugd2lzaCB0byBtb2NrIGFuIGVycm9yIHJlc3BvbnNlLCBwbGVhc2Ugc2VlIHRoaXMgZ3VpZGU6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9odHRwL21vY2tpbmctcmVzcG9uc2VzL2Vycm9yLXJlc3BvbnNlc2AsIHRoaXMuZGF0YS5yZXF1ZXN0Lm1ldGhvZCwgdGhpcy5kYXRhLnJlcXVlc3QudXJsKTtcblx0XHRjb25zdCBlcnJvciA9IHJlYXNvbiBpbnN0YW5jZW9mIEVycm9yID8gcmVhc29uIDogbmV3IEVycm9yKHJlYXNvbj8udG9TdHJpbmcoKSB8fCBcIlJlcXVlc3QgZmFpbHVyZVwiKTtcblx0XHR0aGlzLnJlc3BvbmRXaXRoKEh0dHBSZXNwb25zZS5qc29uKHtcblx0XHRcdG5hbWU6IGVycm9yLm5hbWUsXG5cdFx0XHRtZXNzYWdlOiBlcnJvci5tZXNzYWdlLFxuXHRcdFx0c3RhY2s6IGVycm9yLnN0YWNrXG5cdFx0fSwge1xuXHRcdFx0c3RhdHVzOiA1MDAsXG5cdFx0XHRzdGF0dXNUZXh0OiBcIlJlcXVlc3QgSGFuZGxlciBFcnJvclwiXG5cdFx0fSkpO1xuXHR9XG5cdGFzeW5jICNyZXNwb25kV2l0aChyZXNwb25zZSkge1xuXHRcdGxldCByZXNwb25zZUJvZHk7XG5cdFx0bGV0IHRyYW5zZmVyO1xuXHRcdGNvbnN0IHJlc3BvbnNlSW5pdCA9IHRvUmVzcG9uc2VJbml0KHJlc3BvbnNlKTtcblx0XHRpZiAoc3VwcG9ydHNSZWFkYWJsZVN0cmVhbVRyYW5zZmVyKCkpIHtcblx0XHRcdHJlc3BvbnNlQm9keSA9IHJlc3BvbnNlLmJvZHk7XG5cdFx0XHR0cmFuc2ZlciA9IHJlc3BvbnNlLmJvZHkgPT0gbnVsbCA/IHZvaWQgMCA6IFtyZXNwb25zZS5ib2R5XTtcblx0XHR9IGVsc2UgcmVzcG9uc2VCb2R5ID0gcmVzcG9uc2UuYm9keSA9PSBudWxsID8gbnVsbCA6IGF3YWl0IHJlc3BvbnNlLmNsb25lKCkuYXJyYXlCdWZmZXIoKTtcblx0XHR0aGlzLiNldmVudC5wb3N0TWVzc2FnZShcIk1PQ0tfUkVTUE9OU0VcIiwge1xuXHRcdFx0Li4ucmVzcG9uc2VJbml0LFxuXHRcdFx0Ym9keTogcmVzcG9uc2VCb2R5XG5cdFx0fSwgdHJhbnNmZXIpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvc291cmNlcy9mYWxsYmFjay1odHRwLXNvdXJjZS50c1xudmFyIEZhbGxiYWNrSHR0cFNvdXJjZSA9IGNsYXNzIGV4dGVuZHMgSW50ZXJjZXB0b3JTb3VyY2Uge1xuXHRvcHRpb25zO1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoeyBpbnRlcmNlcHRvcnM6IFtuZXcgWE1MSHR0cFJlcXVlc3RJbnRlcmNlcHRvcigpLCBuZXcgRmV0Y2hJbnRlcmNlcHRvcigpXSB9KTtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXHR9XG5cdGVuYWJsZSgpIHtcblx0XHRzdXBlci5lbmFibGUoKTtcblx0XHRpZiAoIXRoaXMub3B0aW9ucy5xdWlldCkgdGhpcy4jcHJpbnRTdGFydE1lc3NhZ2UoKTtcblx0fVxuXHRkaXNhYmxlKCkge1xuXHRcdHN1cGVyLmRpc2FibGUoKTtcblx0XHRpZiAoIXRoaXMub3B0aW9ucy5xdWlldCkgdGhpcy4jcHJpbnRTdG9wTWVzc2FnZSgpO1xuXHR9XG5cdCNwcmludFN0YXJ0TWVzc2FnZSgpIHtcblx0XHRjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGAlYyR7ZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIk1vY2tpbmcgZW5hYmxlZCAoZmFsbGJhY2sgbW9kZSkuXCIpfWAsIFwiY29sb3I6b3JhbmdlcmVkO2ZvbnQtd2VpZ2h0OmJvbGQ7XCIpO1xuXHRcdGNvbnNvbGUubG9nKFwiJWNEb2N1bWVudGF0aW9uOiAlY2h0dHBzOi8vbXN3anMuaW8vZG9jc1wiLCBcImZvbnQtd2VpZ2h0OmJvbGRcIiwgXCJmb250LXdlaWdodDpub3JtYWxcIik7XG5cdFx0Y29uc29sZS5sb2coXCJGb3VuZCBhbiBpc3N1ZT8gaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXNcIik7XG5cdFx0Y29uc29sZS5ncm91cEVuZCgpO1xuXHR9XG5cdCNwcmludFN0b3BNZXNzYWdlKCkge1xuXHRcdGNvbnNvbGUubG9nKGAlYyR7ZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIk1vY2tpbmcgZGlzYWJsZWQuXCIpfWAsIFwiY29sb3I6b3JhbmdlcmVkO2ZvbnQtd2VpZ2h0OmJvbGQ7XCIpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvc2V0dXAtd29ya2VyLnRzXG5jb25zdCBERUZBVUxUX1dPUktFUl9VUkwgPSBcIi9tb2NrU2VydmljZVdvcmtlci5qc1wiO1xuLyoqXG4qIFNldHMgdXAgYSByZXF1ZXN0cyBpbnRlcmNlcHRpb24gaW4gdGhlIGJyb3dzZXIgd2l0aCB0aGUgZ2l2ZW4gcmVxdWVzdCBoYW5kbGVycy5cbiogQHBhcmFtIHtBcnJheTxBbnlIYW5kbGVyPn0gaGFuZGxlcnMgTGlzdCBvZiByZXF1ZXN0IGhhbmRsZXJzLlxuKlxuKiBAc2VlIHtAbGluayBodHRwczovL21zd2pzLmlvL2RvY3MvYXBpL3NldHVwLXdvcmtlciBgc2V0dXBXb3JrZXIoKWAgQVBJIHJlZmVyZW5jZX1cbiovXG5mdW5jdGlvbiBzZXR1cFdvcmtlciguLi5oYW5kbGVycykge1xuXHRpbnZhcmlhbnQoIWlzTm9kZVByb2Nlc3MoKSwgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIkZhaWxlZCB0byBleGVjdXRlIGBzZXR1cFdvcmtlcmAgaW4gYSBub24tYnJvd3NlciBlbnZpcm9ubWVudFwiKSk7XG5cdGNvbnN0IG5ldHdvcmsgPSBkZWZpbmVOZXR3b3JrKHtcblx0XHRzb3VyY2VzOiBbXSxcblx0XHRoYW5kbGVyc1xuXHR9KTtcblx0cmV0dXJuIHtcblx0XHRnZXQgcmVhZHlTdGF0ZSgpIHtcblx0XHRcdHJldHVybiBuZXR3b3JrLnJlYWR5U3RhdGU7XG5cdFx0fSxcblx0XHRhc3luYyBzdGFydChvcHRpb25zKSB7XG5cdFx0XHRpbnZhcmlhbnQobmV0d29yay5yZWFkeVN0YXRlID09PSAwLCBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiRmFpbGVkIHRvIGNhbGwgXFxcIndvcmtlci5zdGFydCgpXFxcIjogdGhlIHdvcmtlciBpcyBhbHJlYWR5IHN0YXJ0ZWQuIFJlbW92ZSB0aGUgcmVkdW5kYW50IFxcXCJ3b3JrZXIuc3RhcnQoKVxcXCIgY2FsbC5cIikpO1xuXHRcdFx0Y29uc3QgaHR0cFNvdXJjZSA9IHN1cHBvcnRzU2VydmljZVdvcmtlcigpID8gYXdhaXQgU2VydmljZVdvcmtlclNvdXJjZS5mcm9tKHtcblx0XHRcdFx0c2VydmljZVdvcmtlcjoge1xuXHRcdFx0XHRcdHVybDogb3B0aW9ucz8uc2VydmljZVdvcmtlcj8udXJsPy50b1N0cmluZygpIHx8IERFRkFVTFRfV09SS0VSX1VSTCxcblx0XHRcdFx0XHRvcHRpb25zOiBvcHRpb25zPy5zZXJ2aWNlV29ya2VyPy5vcHRpb25zXG5cdFx0XHRcdH0sXG5cdFx0XHRcdGZpbmRXb3JrZXI6IG9wdGlvbnM/LmZpbmRXb3JrZXIsXG5cdFx0XHRcdHF1aWV0OiBvcHRpb25zPy5xdWlldFxuXHRcdFx0fSkgOiBuZXcgRmFsbGJhY2tIdHRwU291cmNlKHsgcXVpZXQ6IG9wdGlvbnM/LnF1aWV0IH0pO1xuXHRcdFx0bmV0d29yay5jb25maWd1cmUoe1xuXHRcdFx0XHRzb3VyY2VzOiBbaHR0cFNvdXJjZSwgbmV3IEludGVyY2VwdG9yU291cmNlKHsgaW50ZXJjZXB0b3JzOiBbbmV3IFdlYlNvY2tldEludGVyY2VwdG9yKCldIH0pXSxcblx0XHRcdFx0b25VbmhhbmRsZWRGcmFtZTogb3B0aW9ucz8ub25VbmhhbmRsZWRGcmFtZSA/PyBcIndhcm5cIixcblx0XHRcdFx0Y29udGV4dDogeyBxdWlldDogb3B0aW9ucz8ucXVpZXQgfVxuXHRcdFx0fSk7XG5cdFx0XHRhd2FpdCBuZXR3b3JrLmVuYWJsZSgpO1xuXHRcdFx0aWYgKGh0dHBTb3VyY2UgaW5zdGFuY2VvZiBTZXJ2aWNlV29ya2VyU291cmNlKSB7XG5cdFx0XHRcdGNvbnN0IFssIHJlZ2lzdHJhdGlvbl0gPSBhd2FpdCBodHRwU291cmNlLndvcmtlclByb21pc2U7XG5cdFx0XHRcdHJldHVybiByZWdpc3RyYXRpb247XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRhc3luYyBzdG9wKCkge1xuXHRcdFx0YXdhaXQgbmV0d29yay5kaXNhYmxlKCk7XG5cdFx0XHR3aW5kb3cucG9zdE1lc3NhZ2UoeyB0eXBlOiBcIm1zdy93b3JrZXI6c3RvcFwiIH0pO1xuXHRcdH0sXG5cdFx0ZXZlbnRzOiBuZXR3b3JrLmV2ZW50cyxcblx0XHR1c2U6IG5ldHdvcmsudXNlLmJpbmQobmV0d29yayksXG5cdFx0cmVzZXRIYW5kbGVyczogbmV0d29yay5yZXNldEhhbmRsZXJzLmJpbmQobmV0d29yayksXG5cdFx0cmVzdG9yZUhhbmRsZXJzOiBuZXR3b3JrLnJlc3RvcmVIYW5kbGVycy5iaW5kKG5ldHdvcmspLFxuXHRcdGxpc3RIYW5kbGVyczogbmV0d29yay5saXN0SGFuZGxlcnMuYmluZChuZXR3b3JrKVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvZGVmYXVsdC1uZXR3b3JrLW9wdGlvbnMudHNcbmZ1bmN0aW9uIGNyZWF0ZURlZmF1bHROZXR3b3JrT3B0aW9ucyh3b3JrZXJVcmwgPSBcIi9tb2NrU2VydmljZVdvcmtlci5qc1wiKSB7XG5cdHJldHVybiB7XG5cdFx0c291cmNlczogW3N1cHBvcnRzU2VydmljZVdvcmtlcigpID8gbmV3IFNlcnZpY2VXb3JrZXJTb3VyY2UoeyBzZXJ2aWNlV29ya2VyOiB7IHVybDogd29ya2VyVXJsIH0gfSkgOiBuZXcgRmFsbGJhY2tIdHRwU291cmNlKHt9KSwgbmV3IEludGVyY2VwdG9yU291cmNlKHsgaW50ZXJjZXB0b3JzOiBbbmV3IFdlYlNvY2tldEludGVyY2VwdG9yKCldIH0pXSxcblx0XHRvblVuaGFuZGxlZEZyYW1lOiBcIndhcm5cIlxuXHR9O1xufVxuY29uc3QgZGVmYXVsdE5ldHdvcmtPcHRpb25zID0gY3JlYXRlRGVmYXVsdE5ldHdvcmtPcHRpb25zKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZURlZmF1bHROZXR3b3JrT3B0aW9ucywgZGVmYXVsdE5ldHdvcmtPcHRpb25zLCBzZXR1cFdvcmtlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQVdBLGVBQWVBLFFBQU0sVUFBVTtDQUM5QixJQUFJO0VBQ0gsT0FBTyxDQUFDLE1BQU0sTUFBTSxTQUFTLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDL0MsTUFBTTtFQUNQLENBQUMsQ0FBQztDQUNILFNBQVMsT0FBTztFQUNmLE9BQU8sQ0FBQyxPQUFPLElBQUk7Q0FDcEI7QUFDRDs7O0FDVEEsSUFBSSxvQkFBb0IsY0FBYyxXQUFXO0NBQ2hEO0NBQ0EsWUFBWSxNQUFNLE9BQU87RUFDeEIsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuQixLQUFLLFFBQVE7Q0FDZDtBQUNEO0FBQ0EsSUFBSSxnQkFBZ0IsTUFBTTtDQUN6QjtDQUNBLGNBQWM7RUFDYixLQUFLLFVBQVUsSUFBSSxRQUFRO0NBQzVCO0NBQ0EsTUFBTSxNQUFNLE9BQU87RUFDbEIsTUFBTSxLQUFLLFFBQVEsY0FBYyxJQUFJLGtCQUFrQixTQUFTLEtBQUssQ0FBQztDQUN2RTtDQUNBLEdBQUcsTUFBTSxVQUFVLFNBQVM7RUFDM0IsS0FBSyxRQUFRLEdBQUcsTUFBTSxVQUFVLE9BQU87Q0FDeEM7Q0FDQSxVQUFVO0VBQ1QsS0FBSyxRQUFRLG1CQUFtQjtDQUNqQztBQUNEO0FBR0EsU0FBUyxrQkFBa0IsUUFBUSxNQUFNLFNBQVM7Q0FDakQsQ0FBQyxPQUFPLFVBQVUsQ0FBQyxFQUFBLENBQUcsS0FBSyxPQUFPO0FBQ25DO0FBQ0EsU0FBUyx1QkFBdUIsUUFBUSxNQUFNLGtCQUFrQjtDQUMvRCxNQUFNLGtCQUFrQixPQUFPO0NBQy9CLE9BQU8sUUFBUSxrQkFBa0IsQ0FBQyxHQUFHLGtCQUFrQixHQUFHLGdCQUFnQixRQUFRLG9CQUFvQjtFQUNyRyxPQUFPLENBQUMsaUJBQWlCLFNBQVMsZUFBZTtDQUNsRCxDQUFDLENBQUMsSUFBSTtBQUNQO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVTtDQUN0QyxNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLGtDQUFrQyxJQUFJLElBQUk7Q0FDaEQsTUFBTSxTQUFTLFlBQVk7RUFDMUIsSUFBSSxnQkFBZ0IsSUFBSSxPQUFPLEdBQUc7RUFDbEMsZ0JBQWdCLElBQUksT0FBTztFQUMzQixrQkFBa0IsUUFBUSxRQUFRLE1BQU0sT0FBTztFQUMvQyxLQUFLLE1BQU0sV0FBVyxtQkFBbUIsT0FBTyxHQUFHLE1BQU0sT0FBTztDQUNqRTtDQUNBLEtBQUssTUFBTSxXQUFXLFVBQVUsTUFBTSxPQUFPO0NBQzdDLE9BQU87QUFDUjtBQUNBLElBQUkscUJBQXFCLE1BQU07Q0FDOUIsZ0JBQWdCLGlCQUFpQjtFQUNoQyxVQUFVLEtBQUssa0JBQWtCLGVBQWUsR0FBRyxTQUFTLGNBQWMsNkdBQTZHLENBQUM7RUFDeEwsTUFBTSw0QkFBNEIsb0JBQW9CLGVBQWU7RUFDckUsT0FBTztHQUNOLGlCQUFpQjtHQUNqQixVQUFVLEVBQUUsR0FBRywwQkFBMEI7RUFDMUM7Q0FDRDtDQUNBLGtCQUFrQjtFQUNqQixPQUFPLE9BQU8sT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsWUFBWSxXQUFXLElBQUk7Q0FDMUY7Ozs7Ozs7Q0FPQSxlQUFlO0VBQ2QsT0FBTyxLQUFLLGdCQUFnQixDQUFDLENBQUMsUUFBUSxZQUFZO0dBQ2pELE9BQU8sQ0FBQyxpQkFBaUIsT0FBTztFQUNqQyxDQUFDO0NBQ0Y7Ozs7Q0FJQSxrQkFBa0IsTUFBTTtFQUN2QixPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsU0FBUyxTQUFTLENBQUM7Q0FDM0M7Q0FDQSxJQUFJLGNBQWM7RUFDakIsVUFBVSxLQUFLLGtCQUFrQixZQUFZLEdBQUcsU0FBUyxjQUFjLHdJQUF3SSxDQUFDO0VBQ2hOLElBQUksYUFBYSxXQUFXLEdBQUc7RUFDL0IsTUFBTSxFQUFFLGFBQWEsS0FBSyxTQUFTO0VBQ25DLE1BQU0sWUFBWSxvQkFBb0IsWUFBWTtFQUNsRCxJQUFJLFVBQVUsU0FBUyx1QkFBdUIsVUFBVSxXQUFXLFVBQVUsT0FBTztFQUNwRixJQUFJLFVBQVUsV0FBVyx1QkFBdUIsVUFBVSxhQUFhLFVBQVUsU0FBUztFQUMxRixLQUFLLFNBQVMsRUFBRSxTQUFTLENBQUM7Q0FDM0I7Q0FDQSxNQUFNLGNBQWM7RUFDbkIsVUFBVSxhQUFhLFNBQVMsSUFBSSxLQUFLLGtCQUFrQixZQUFZLElBQUksTUFBTSxTQUFTLGNBQWMsaUhBQWlILENBQUM7RUFDMU4sS0FBSyxNQUFNLFdBQVcsS0FBSyxnQkFBZ0IsR0FBRyxRQUFRLE1BQU07RUFDNUQsTUFBTSxFQUFFLG9CQUFvQixLQUFLLFNBQVM7RUFDMUMsSUFBSSxhQUFhLFdBQVcsR0FBRztHQUM5QixLQUFLLFNBQVMsRUFBRSxVQUFVLEVBQUUsR0FBRyxnQkFBZ0IsRUFBRSxDQUFDO0dBQ2xEO0VBQ0Q7RUFDQSxNQUFNLHlCQUF5QixvQkFBb0IsWUFBWTtFQUMvRCxLQUFLLFNBQVM7R0FDYixpQkFBaUI7R0FDakIsVUFBVSxFQUFFLEdBQUcsdUJBQXVCO0VBQ3ZDLENBQUM7Q0FDRjtDQUNBLFVBQVU7RUFDVCxLQUFLLE1BQU0sV0FBVyxLQUFLLGdCQUFnQixHQUFHLFFBQVEsUUFBUTtDQUMvRDtDQUNBLFVBQVU7RUFDVCxNQUFNLG1CQUFtQixDQUFDO0VBQzFCLEtBQUssTUFBTSxXQUFXLEtBQUssZ0JBQWdCLEdBQUc7R0FDN0MsTUFBTSxXQUFXLFFBQVEsUUFBUTtHQUNqQyxJQUFJLG9CQUFvQixTQUFTLGlCQUFpQixLQUFLLFFBQVE7RUFDaEU7RUFDQSxJQUFJLGlCQUFpQixTQUFTLEdBQUcsT0FBTyxRQUFRLElBQUksZ0JBQWdCLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztDQUNwRjtDQUNBLGtCQUFrQixVQUFVO0VBQzNCLE9BQU8sU0FBUyxPQUFPLFlBQVksQ0FBQyxNQUFNLFFBQVEsT0FBTyxDQUFDO0NBQzNEO0FBQ0Q7QUFDQSxJQUFJLDZCQUE2QixjQUFjLG1CQUFtQjtDQUNqRTtDQUNBO0NBQ0EsWUFBWSxpQkFBaUI7RUFDNUIsTUFBTTtFQUNOLE1BQU0sZUFBZSxLQUFLLGdCQUFnQixlQUFlO0VBQ3pELEtBQUssbUJBQW1CLGFBQWE7RUFDckMsS0FBSyxZQUFZLGFBQWE7Q0FDL0I7Q0FDQSxXQUFXO0VBQ1YsT0FBTztHQUNOLGlCQUFpQixLQUFLO0dBQ3RCLFVBQVUsS0FBSztFQUNoQjtDQUNEO0NBQ0EsU0FBUyxXQUFXO0VBQ25CLElBQUksVUFBVSxpQkFBaUIsS0FBSyxtQkFBbUIsVUFBVTtFQUNqRSxJQUFJLFVBQVUsVUFBVSxLQUFLLFlBQVksVUFBVTtDQUNwRDtBQUNEOzs7O0FBTUEsU0FBUyxnQkFBZ0IsUUFBUTtDQUNoQyxNQUFNLFFBQVEsQ0FBQyxHQUFHLE1BQU07Q0FDeEIsT0FBTyxPQUFPLEtBQUs7Q0FDbkIsT0FBTztBQUNSO0FBR0EsSUFBSSxhQUFhLE1BQU07Q0FDdEIsZ0JBQWdCLENBQUM7Q0FDakIsVUFBVTtFQUNULElBQUk7RUFDSixNQUFNLFNBQVMsQ0FBQztFQUNoQixPQUFPLGVBQWUsS0FBSyxjQUFjLE1BQU0sR0FBRyxJQUFJO0dBQ3JELGFBQWE7RUFDZCxTQUFTLE9BQU87R0FDZixJQUFJLGlCQUFpQixPQUFPLE9BQU8sS0FBSyxLQUFLO0VBQzlDO0VBQ0EsSUFBSSxPQUFPLFNBQVMsR0FBRyxRQUFRLE1BQU0sSUFBSSxlQUFlLFFBQVEsU0FBUyxjQUFjLDJJQUEySSxDQUFDLENBQUM7Q0FDck87QUFDRDtBQUdBLFNBQVMsb0JBQW9CLFFBQVE7Q0FDcEMsTUFBTSxXQUFXLENBQUM7Q0FDbEIsS0FBSyxNQUFNLFNBQVMsUUFBUSxJQUFJLGlCQUFpQixTQUFTLFNBQVMsS0FBSyxLQUFLO0NBQzdFLElBQUksU0FBUyxTQUFTLEdBQUcsT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDcEU7Ozs7Ozs7Ozs7Ozs7QUFrQkEsU0FBUyxjQUFjLFNBQVM7Q0FDL0IsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sU0FBUyxJQUFJLFFBQVE7Q0FDM0IsTUFBTSxhQUFhLElBQUksV0FBVztDQUNsQyxNQUFNLDRCQUE0QixhQUFhO0VBQzlDLE9BQU8sb0JBQW9CLHFCQUFxQixXQUFXLElBQUksMkJBQTJCLFlBQVksQ0FBQyxDQUFDO0NBQ3pHO0NBQ0EsSUFBSSxrQkFBa0IsRUFBRSxHQUFHLFFBQVE7Ozs7O0NBS25DLElBQUkscUJBQXFCLHlCQUF5QixnQkFBZ0IsUUFBUTtDQUMxRSxPQUFPO0VBQ04sSUFBSSxhQUFhO0dBQ2hCLE9BQU87RUFDUjtFQUNBO0VBQ0EsVUFBVSxTQUFTO0dBQ2xCLFVBQVUsZUFBZSxHQUFHLDZGQUE2RjtHQUN6SCxJQUFJLFFBQVEsWUFBWSxDQUFDLE9BQU8sR0FBRyxRQUFRLFVBQVUsZ0JBQWdCLFFBQVEsR0FBRyxxQkFBcUIseUJBQXlCLFFBQVEsUUFBUTtHQUM5SSxrQkFBa0I7SUFDakIsR0FBRztJQUNILEdBQUc7R0FDSjtFQUNEO0VBQ0EsU0FBUztHQUNSLFVBQVUsZUFBZSxHQUFHLDJEQUEyRDtHQUN2RixhQUFhOzs7Ozs7R0FNYixNQUFNLFVBQVUsRUFBRSxRQUFRLEtBQUs7R0FDL0IsV0FBVyxnQkFBZ0IsQ0FBQyxXQUFXO0lBQ3RDLFFBQVEsU0FBUztHQUNsQixDQUFDO0dBQ0QsT0FBTyxvQkFBb0IsZ0JBQWdCLFFBQVEsS0FBSyxXQUFXOzs7Ozs7O0lBT2xFLGNBQWMsVUFBVSxRQUFRLEtBQUssTUFBTTtJQUMzQyxPQUFPLEdBQUcsU0FBUyxPQUFPLEVBQUUsWUFBWTtLQUN2QyxNQUFNLE9BQU8sR0FBRyxNQUFNLFVBQVU7Ozs7Ozs7O01BUS9CLElBQUksQ0FBQyxRQUFRLFFBQVE7TUFDckIsT0FBTyxLQUFLLEtBQUs7S0FDbEIsQ0FBQztLQUNELE1BQU0sV0FBVyxNQUFNLFlBQVksa0JBQWtCO0tBQ3JELE1BQU0sTUFBTSxRQUFRLFVBQVUsZ0JBQWdCLG9CQUFvQixRQUFRLGdCQUFnQixPQUFPO0lBQ2xHLENBQUM7SUFDRCxPQUFPLE9BQU8sT0FBTztHQUN0QixDQUFDLENBQUM7RUFDSDtFQUNBLFVBQVU7R0FDVCxVQUFVLGVBQWUsR0FBRyw2REFBNkQ7R0FDekYsYUFBYTtHQUNiLE1BQU0sbUJBQW1CLG1CQUFtQixRQUFRO0dBQ3BELFdBQVcsUUFBUTs7Ozs7Ozs7R0FRbkIsTUFBTSxrQkFBa0Isb0JBQW9CLGdCQUFnQixRQUFRLEtBQUssV0FBVyxPQUFPLFFBQVEsQ0FBQyxDQUFDOzs7Ozs7R0FNckcsT0FBTyw0QkFBNEIsVUFBVSxRQUFRLElBQUksQ0FBQyxrQkFBa0IsZUFBZSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJO0VBQ2hIO0VBQ0EsSUFBSSxHQUFHLFVBQVU7R0FDaEIsbUJBQW1CLElBQUksUUFBUTtFQUNoQztFQUNBLGNBQWMsR0FBRyxVQUFVO0dBQzFCLG1CQUFtQixNQUFNLFFBQVE7RUFDbEM7RUFDQSxrQkFBa0I7R0FDakIsbUJBQW1CLFFBQVE7RUFDNUI7RUFDQSxlQUFlO0dBQ2QsT0FBTyxnQkFBZ0IsbUJBQW1CLGFBQWEsQ0FBQztFQUN6RDtDQUNEO0FBQ0Q7Ozs7O0FBT0EsSUFBSSxlQUFlLE1BQU07Q0FDeEI7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxVQUFVLE1BQU07RUFDM0IsS0FBSyxXQUFXO0VBQ2hCLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUyxJQUFJLFFBQVE7Q0FDM0I7QUFDRDtBQUdBLGVBQWUscUJBQXFCLFNBQVMsVUFBVTtDQUN0RCxJQUFJLGdCQUFnQixNQUFNO0NBQzFCLEtBQUssTUFBTSxrQkFBa0IsZ0JBQWdCLFFBQVEsR0FBRyxNQUFNLFlBQVksVUFBVSxnQkFBZ0IsUUFBUSxHQUFHO0FBQ2hIO0FBR0EsU0FBUyxvQkFBb0IsU0FBUztDQUNyQyxPQUFPLENBQUMsQ0FBQyxRQUFRLFFBQVEsSUFBSSxRQUFRLENBQUMsRUFBRSxTQUFTLGlCQUFpQjtBQUNuRTs7OztBQUlBLFNBQVMsK0JBQStCLFNBQVM7Q0FDaEQsTUFBTSxlQUFlLFFBQVEsUUFBUSxJQUFJLFFBQVE7Ozs7OztDQU1qRCxJQUFJLGNBQWM7RUFDakIsTUFBTSxtQkFBbUIsYUFBYSxRQUFRLDJCQUEyQixFQUFFO0VBQzNFLElBQUksa0JBQWtCLFFBQVEsUUFBUSxJQUFJLFVBQVUsZ0JBQWdCO09BQy9ELFFBQVEsUUFBUSxPQUFPLFFBQVE7Q0FDckM7QUFDRDtBQUdBLGVBQWUsNEJBQTRCLE9BQU8sUUFBUTtDQUN6RCxNQUFNLHVCQUF1QixPQUFPLGFBQWE7RUFDaEQsSUFBSSxhQUFhLFVBQVU7RUFDM0IsTUFBTSxVQUFVLE1BQU0sTUFBTSxvQkFBb0I7RUFDaEQsUUFBUSxVQUFSO0dBQ0MsS0FBSyxRQUFRLE9BQU8sU0FBUyxLQUFLLGVBQWUsT0FBTztHQUN4RCxLQUFLLFNBQVMsT0FBTyxTQUFTLE1BQU0sYUFBYSxPQUFPO0VBQ3pEO0NBQ0Q7Q0FDQSxNQUFNLGdCQUFnQixPQUFPLGFBQWE7RUFDekMsVUFBVSxHQUFHLGVBQWUsYUFBYSxZQUFZLGFBQWEsVUFBVSxhQUFhLFNBQVMsU0FBUyxjQUFjLDJPQUEyTyxRQUFRLENBQUM7RUFDN1csSUFBSSxhQUFhLFVBQVU7RUFDM0IsTUFBTSxxQkFBcUIsUUFBUTtFQUNuQyxJQUFJLGFBQWEsU0FBUyxPQUFPLFFBQVEsT0FBTyxJQUFJLGNBQWMsU0FBUyxjQUFjLGdHQUFnRyxDQUFDLENBQUM7Q0FDNUw7Q0FDQSxJQUFJLE9BQU8sV0FBVyxZQUFZLE9BQU8sT0FBTztFQUMvQztFQUNBLFVBQVU7R0FDVCxNQUFNLHFCQUFxQixLQUFLLE1BQU0sTUFBTTs7Ozs7OztHQU81QyxPQUFPLHFCQUFxQixLQUFLLE1BQU0sT0FBTztFQUMvQztDQUNELENBQUM7Ozs7Ozs7Q0FPRCxJQUFJLGlCQUFpQixvQkFBb0IscUJBQXFCLE1BQU0sS0FBSyxPQUFPLEdBQUc7Q0FDbkYsT0FBTyxjQUFjLE1BQU07QUFDNUI7QUFHQSxJQUFJLGVBQWUsY0FBYyxXQUFXO0NBQzNDO0NBQ0E7Q0FDQSxZQUFZLE1BQU0sTUFBTTtFQUN2QixNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25CLEtBQUssWUFBWSxLQUFLO0VBQ3RCLEtBQUssVUFBVSxLQUFLO0NBQ3JCO0FBQ0Q7QUFDQSxJQUFJLGdCQUFnQixjQUFjLFdBQVc7Q0FDNUM7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxNQUFNLE1BQU07RUFDdkIsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFVBQVUsS0FBSztFQUNwQixLQUFLLFdBQVcsS0FBSztDQUN0QjtBQUNEO0FBQ0EsSUFBSSwwQkFBMEIsY0FBYyxXQUFXO0NBQ3REO0NBQ0E7Q0FDQTtDQUNBLFlBQVksTUFBTSxNQUFNO0VBQ3ZCLE1BQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDbkIsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxVQUFVLEtBQUs7Q0FDckI7QUFDRDtBQUNBLElBQUksbUJBQW1CLGNBQWMsYUFBYTtDQUNqRCxZQUFZLFNBQVM7RUFDcEIsTUFBTSxLQUFLLFFBQVEsTUFBTSxnQkFBZ0I7RUFDekMsTUFBTSxRQUFRO0dBQ2I7R0FDQSxTQUFTLFFBQVE7RUFDbEIsQ0FBQztDQUNGO0NBQ0EsWUFBWSxZQUFZO0VBQ3ZCLE9BQU8sV0FBVyxrQkFBa0IsU0FBUztDQUM5QztDQUNBLE1BQU0sc0JBQXNCO0VBQzNCLE1BQU0sRUFBRSxZQUFZLEtBQUs7RUFDekIsTUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLEdBQUc7RUFDL0IsTUFBTSxZQUFZLFlBQVksR0FBRyxJQUFJLElBQUk7RUFDekMsTUFBTSxjQUFjLFFBQVEsUUFBUSxPQUFPLE9BQU8sTUFBTSxRQUFRLE1BQU0sQ0FBQyxDQUFDLEtBQUs7RUFDN0UsT0FBTyw0REFBNEQsZ0JBQWdCLFFBQVEsT0FBTyxHQUFHLFVBQVUsTUFBTSxjQUFjLDBCQUEwQixZQUFZLFFBQVEsS0FBSztDQUN2TDtDQUNBLE1BQU0sUUFBUSxVQUFVLGtCQUFrQixtQkFBbUI7RUFDNUQsTUFBTSxFQUFFLElBQUksV0FBVyxZQUFZLEtBQUs7RUFDeEMsTUFBTSxzQkFBc0IsbUJBQW1CLFFBQVEsT0FBTyxRQUFRLE1BQU07RUFDNUUsS0FBSyxPQUFPLEtBQUssSUFBSSxhQUFhLGlCQUFpQjtHQUNsRDtHQUNBO0VBQ0QsQ0FBQyxDQUFDO0VBQ0YsSUFBSSxvQkFBb0IsT0FBTyxHQUFHO0dBQ2pDLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxlQUFlO0lBQ2hEO0lBQ0E7R0FDRCxDQUFDLENBQUM7R0FDRixLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNSO0VBQ0EsTUFBTSxDQUFDLGFBQWEsZ0JBQWdCLE1BQU1DLGNBQVk7R0FDckQsT0FBTyxnQkFBZ0I7SUFDdEI7SUFDQTtJQUNBO0lBQ0EsbUJBQW1CO0tBQ2xCLFNBQVMsbUJBQW1CLFNBQVMsU0FBUztLQUM5QyxPQUFPLG1CQUFtQjtJQUMzQjtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsSUFBSSxlQUFlLE1BQU07R0FDeEIsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLElBQUksd0JBQXdCLHNCQUFzQjtJQUN2RSxPQUFPO0lBQ1A7SUFDQTtHQUNELENBQUMsQ0FBQyxHQUFHO0lBQ0osUUFBUSxNQUFNLFdBQVc7SUFDekIsU0FBUyxNQUFNLG9IQUFvSCxRQUFRLFFBQVEsUUFBUSxHQUFHO0dBQy9KO0dBQ0EsS0FBSyxVQUFVLFdBQVc7R0FDMUIsT0FBTztFQUNSO0VBQ0EsSUFBSSxnQkFBZ0IsTUFBTTs7Ozs7OztHQU96QixJQUFJLGNBQWMsUUFBUSxRQUFRLFNBQVMsR0FBRztJQUM3QyxLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEsZUFBZTtLQUNoRDtLQUNBO0lBQ0QsQ0FBQyxDQUFDO0lBQ0YsS0FBSyxZQUFZO0lBQ2pCLE9BQU87R0FDUjtHQUNBLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxxQkFBcUI7SUFDdEQ7SUFDQTtHQUNELENBQUMsQ0FBQzs7Ozs7R0FLRixNQUFNLDRCQUE0QixNQUFNLGdCQUFnQixDQUFDLENBQUMsV0FBVyxLQUFLLFlBQVksSUFBSSxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUM7R0FDekgsS0FBSyxPQUFPLEtBQUssSUFBSSxhQUFhLGVBQWU7SUFDaEQ7SUFDQTtHQUNELENBQUMsQ0FBQztHQUNGLE9BQU87RUFDUjtFQUNBLE1BQU0sRUFBRSxVQUFVLFNBQVMsaUJBQWlCO0VBQzVDLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxpQkFBaUI7R0FDbEQ7R0FDQTtFQUNELENBQUMsQ0FBQztFQUNGLElBQUksWUFBWSxNQUFNO0dBQ3JCLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxlQUFlO0lBQ2hEO0lBQ0E7R0FDRCxDQUFDLENBQUM7R0FDRixLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNSO0VBQ0EsSUFBSSxzQkFBc0IsUUFBUSxHQUFHO0dBQ3BDLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxlQUFlO0lBQ2hEO0lBQ0E7R0FDRCxDQUFDLENBQUM7R0FDRixLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNSO0VBQ0EsTUFBTSx1QkFBdUIsbUJBQW1CLFFBQVEsT0FBTyxTQUFTLE1BQU07RUFDOUUsTUFBTSxxQkFBcUIsU0FBUyxRQUFRO0VBQzVDLEtBQUssWUFBWSxRQUFRO0VBQ3pCLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxlQUFlO0dBQ2hEO0dBQ0E7RUFDRCxDQUFDLENBQUM7RUFDRixJQUFJLENBQUMsbUJBQW1CLE9BQU8sUUFBUSxJQUFJO0dBQzFDLFNBQVM7R0FDVCxVQUFVO0dBQ1Y7RUFDRCxDQUFDO0VBQ0QsT0FBTztDQUNSO0FBQ0Q7QUFHQSxJQUFJLDJCQUEyQixjQUFjLFdBQVc7Q0FDdkQ7Q0FDQTtDQUNBLFlBQVksTUFBTSxNQUFNO0VBQ3ZCLE1BQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDbkIsS0FBSyxNQUFNLEtBQUs7RUFDaEIsS0FBSyxZQUFZLEtBQUs7Q0FDdkI7QUFDRDtBQUNBLElBQUksc0JBQXNCLGNBQWMseUJBQXlCO0NBQ2hFO0NBQ0EsWUFBWSxNQUFNLE1BQU07RUFDdkIsTUFBTSxNQUFNLElBQUk7RUFDaEIsS0FBSyxRQUFRLEtBQUs7Q0FDbkI7QUFDRDtBQUNBLElBQUksd0JBQXdCLGNBQWMsYUFBYTtDQUN0RCxZQUFZLFNBQVM7RUFDcEIsTUFBTSxNQUFNLEVBQUUsWUFBWSxRQUFRLFdBQVcsQ0FBQztDQUMvQztDQUNBLFlBQVksWUFBWTtFQUN2QixPQUFPLFdBQVcsa0JBQWtCLFdBQVc7Q0FDaEQ7Q0FDQSxNQUFNLFFBQVEsVUFBVSxrQkFBa0IsbUJBQW1CO0VBQzVELE1BQU0sRUFBRSxlQUFlLEtBQUs7RUFDNUIsS0FBSyxPQUFPLEtBQUssSUFBSSx5QkFBeUIsd0JBQXdCO0dBQ3JFLEtBQUssV0FBVyxPQUFPO0dBQ3ZCLFdBQVcsV0FBVyxLQUFLO0VBQzVCLENBQUMsQ0FBQztFQUNGLE1BQU0scUJBQXFCLFVBQVU7R0FDcEMsS0FBSyxPQUFPLEtBQUssSUFBSSxvQkFBb0IsbUJBQW1CO0lBQzNELEtBQUssV0FBVyxPQUFPO0lBQ3ZCLFdBQVcsV0FBVyxLQUFLO0lBQzNCLE9BQU8sa0JBQWtCLEtBQUs7R0FDL0IsQ0FBQyxDQUFDO0VBQ0g7RUFDQSxXQUFXLE9BQU8sT0FBTyxpQkFBaUIsU0FBUyxpQkFBaUI7RUFDcEUsV0FBVyxPQUFPLE9BQU8saUJBQWlCLGVBQWU7R0FDeEQsV0FBVyxPQUFPLE9BQU8sb0JBQW9CLFNBQVMsaUJBQWlCO0VBQ3hFLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztFQUNqQixJQUFJLFNBQVMsV0FBVyxHQUFHO0dBQzFCLE1BQU0sNEJBQTRCLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxXQUFXLEtBQUssWUFBWSxJQUFJLFVBQVUsS0FBSyxVQUFVLEtBQUssQ0FBQztHQUN6SCxPQUFPO0VBQ1I7RUFDQSxJQUFJLHNCQUFzQjtFQUMxQixLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQy9CLE1BQU0sb0JBQW9CLE1BQU0sUUFBUSxJQUFJLFlBQVk7SUFDdkQsU0FBUyxtQkFBbUIsU0FBUyxTQUFTOzs7Ozs7SUFNOUMsUUFBUSxLQUFLOzs7OztLQUtaLGVBQWU7R0FDakIsQ0FBQztHQUNELElBQUksQ0FBQyxtQkFBbUI7R0FDeEIsc0JBQXNCOzs7Ozs7O0dBT3RCLE1BQU0sZUFBZSxDQUFDLG1CQUFtQixRQUFRLFFBQVEsSUFBSSxVQUFVLElBQUksS0FBSztHQUNoRixJQUFJO0lBQ0gsSUFBSSxDQUFDLFFBQVEsU0FBUyxDQUFDLGlCQUFpQixHQUFHLGVBQWU7R0FDM0QsU0FBUyxPQUFPO0lBQ2YsSUFBSSxDQUFDLEtBQUssT0FBTyxLQUFLLElBQUksb0JBQW9CLHNCQUFzQjtLQUNuRTtLQUNBLEtBQUssV0FBVyxPQUFPO0tBQ3ZCLFdBQVcsV0FBVyxLQUFLO0lBQzVCLENBQUMsQ0FBQyxHQUFHO0tBQ0osUUFBUSxNQUFNLEtBQUs7S0FDbkIsU0FBUyxNQUFNLGlIQUFpSCxXQUFXLE9BQU8sR0FBRztJQUN0Sjs7Ozs7SUFLQSxNQUFNO0dBQ1A7RUFDRDtFQUNBLElBQUksQ0FBQyxxQkFBcUI7R0FDekIsTUFBTSw0QkFBNEIsTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFdBQVcsS0FBSyxZQUFZLElBQUksVUFBVSxLQUFLLFVBQVUsS0FBSyxDQUFDO0dBQ3pILE9BQU87RUFDUjtFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sc0JBQXNCO0VBQzNCLE1BQU0sRUFBRSxlQUFlLEtBQUs7RUFDNUIsT0FBTyx1RUFBdUUsZ0JBQWdCLFdBQVcsT0FBTyxJQUFJLE1BQU07Q0FDM0g7QUFDRDs7Ozs7O0FBTUEsU0FBUyxrQkFBa0IsT0FBTztDQUNqQyxJQUFJLFdBQVcsU0FBUyxNQUFNLFNBQVMsTUFBTSxPQUFPLE1BQU07Q0FDMUQsSUFBSSxXQUFXLFNBQVMsTUFBTSxTQUFTLE1BQU0sT0FBTyxNQUFNO0FBQzNEOzs7O0FBTUEsSUFBSSxvQkFBb0IsY0FBYyxjQUFjO0NBQ25EOzs7Ozs7Ozs7O0NBVUE7Q0FDQSxZQUFZLFNBQVM7RUFDcEIsTUFBTTtFQUNOLEtBQUssZUFBZSxJQUFJLGlCQUFpQjtHQUN4QyxNQUFNO0dBQ04sY0FBYyxRQUFRO0VBQ3ZCLENBQUM7RUFDRCxLQUFLLDBCQUEwQixJQUFJLFFBQVE7Q0FDNUM7Q0FDQSxTQUFTO0VBQ1IsS0FBSyxhQUFhLE1BQU07RUFDeEIsS0FBSyxhQUFhLEdBQUcsV0FBVyxLQUFLLGVBQWUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBWSxLQUFLLGdCQUFnQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxjQUFjLEtBQUssMkJBQTJCLEtBQUssSUFBSSxDQUFDO0NBQzVLO0NBQ0EsVUFBVTtFQUNULE1BQU0sUUFBUTtFQUNkLEtBQUssYUFBYSxRQUFROzs7OztFQUsxQixLQUFLLDBCQUEwQixJQUFJLFFBQVE7Q0FDNUM7Q0FDQSxNQUFNLGVBQWUsT0FBTztFQUMzQixNQUFNLEVBQUUsV0FBVyxTQUFTLGVBQWU7RUFDM0MsTUFBTSxZQUFZLElBQUksNEJBQTRCO0dBQ2pELElBQUk7R0FDSjtHQUNBO0VBQ0QsQ0FBQztFQUNELEtBQUssUUFBUSxJQUFJLFNBQVMsU0FBUztFQUNuQyxNQUFNLEtBQUssTUFBTSxTQUFTO0NBQzNCO0NBQ0EsTUFBTSxnQkFBZ0IsRUFBRSxXQUFXLFNBQVMsVUFBVSxnQkFBZ0I7RUFDckUsTUFBTSxZQUFZLEtBQUssUUFBUSxJQUFJLE9BQU87RUFDMUMsS0FBSyxRQUFRLE9BQU8sT0FBTztFQUMzQixJQUFJLGFBQWEsTUFBTTtFQUN2QixxQkFBcUI7R0FDcEIsSUFBSTtJQUNILFVBQVUsT0FBTyxLQUFLLElBQUksY0FBYyxpQkFBaUIsU0FBUyxvQkFBb0IsbUJBQW1CO0tBQ3hHO0tBQ0E7S0FDQTtJQUNELENBQUMsQ0FBQztHQUNILFVBQVU7Ozs7Ozs7SUFPVCxVQUFVLE9BQU8sbUJBQW1CO0dBQ3JDO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsTUFBTSwyQkFBMkIsWUFBWTtFQUM1QyxNQUFNLEtBQUssTUFBTSxJQUFJLGlDQUFpQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0NBQ3RFO0FBQ0Q7QUFDQSxJQUFJLDhCQUE4QixjQUFjLGlCQUFpQjtDQUNoRTtDQUNBLFlBQVksU0FBUztFQUNwQixNQUFNO0dBQ0wsSUFBSSxRQUFRO0dBQ1osU0FBUyxRQUFRO0VBQ2xCLENBQUM7RUFDRCxLQUFLLGNBQWMsUUFBUTtDQUM1QjtDQUNBLGNBQWM7RUFDYiwrQkFBK0IsS0FBSyxLQUFLLE9BQU87Q0FDakQ7Q0FDQSxZQUFZLFVBQVU7RUFDckIsSUFBSSxVQUFVLEtBQUssWUFBWSxZQUFZLFFBQVE7Q0FDcEQ7Q0FDQSxVQUFVLFFBQVE7RUFDakIsSUFBSSxrQkFBa0IsVUFBVSxPQUFPLEtBQUssWUFBWSxNQUFNO0VBQzlELElBQUksa0JBQWtCLGVBQWUsS0FBSyxZQUFZLFVBQVUsTUFBTTtFQUN0RSxNQUFNO0NBQ1A7QUFDRDtBQUNBLElBQUksbUNBQW1DLGNBQWMsc0JBQXNCOzs7OztDQUsxRTtDQUNBLFlBQVksTUFBTTtFQUNqQixNQUFNLEVBQUUsWUFBWSxLQUFLLFdBQVcsQ0FBQztFQUNyQyxLQUFLLFVBQVUsS0FBSyxXQUFXOzs7OztFQUsvQixLQUFLLFdBQVcsT0FBTyxpQkFBaUIsZUFBZTtHQUN0RCxLQUFLLE9BQU8sbUJBQW1CO0VBQ2hDLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUNsQjtDQUNBLFVBQVUsUUFBUTtFQUNqQixJQUFJLGtCQUFrQixPQUFPOzs7OztHQUs1QixNQUFNLGFBQWEsSUFBSSxNQUFNLE9BQU87R0FDcEMsT0FBTyxlQUFlLFlBQVksU0FBUztJQUMxQyxZQUFZO0lBQ1osY0FBYztJQUNkLE9BQU87R0FDUixDQUFDO0dBQ0QsS0FBSyxRQUFRLE9BQU8sY0FBYyxVQUFVO0VBQzdDO0NBQ0Q7Q0FDQSxjQUFjO0VBQ2IsS0FBSyxLQUFLLFdBQVcsT0FBTyxRQUFRO0NBQ3JDO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7QUNsdkJBLGVBQWUsTUFBTSxVQUFVO0NBQzlCLElBQUk7RUFDSCxPQUFPLENBQUMsTUFBTSxNQUFNLFNBQVMsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUMvQyxNQUFNO0VBQ1AsQ0FBQyxDQUFDO0NBQ0gsU0FBUyxPQUFPO0VBQ2YsT0FBTyxDQUFDLE9BQU8sSUFBSTtDQUNwQjtBQUNEOzs7QUNkQSxJQUFJLG1CQUFtQixjQUFjLFdBQVc7Q0FDL0MsWUFBWSxNQUFNO0VBQ2pCLE1BQU0sR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7RUFDeEIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxhQUFhLEtBQUs7Q0FDeEI7QUFDRDtBQUNBLElBQUksb0JBQW9CLGNBQWMsV0FBVztDQUNoRCxZQUFZLE1BQU07RUFDakIsTUFBTSxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUN6QixLQUFLLFdBQVcsS0FBSztFQUNyQixLQUFLLGVBQWUsS0FBSztFQUN6QixLQUFLLFVBQVUsS0FBSztFQUNwQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFlBQVksS0FBSztDQUN2QjtBQUNEO0FBQ0EsSUFBSSx5QkFBeUIsY0FBYyxXQUFXO0NBQ3JELFlBQVksTUFBTTtFQUNqQixNQUFNLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7RUFDbkMsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxhQUFhLEtBQUs7Q0FDeEI7QUFDRDtBQUdBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDL0IsSUFBSSxTQUFTLE1BQU0sT0FBTztDQUMxQixJQUFJLEVBQUUsaUJBQWlCLFFBQVEsT0FBTztDQUN0QyxPQUFPLFVBQVUsU0FBUyxXQUFXO0FBQ3RDO0FBR0EsZUFBZSxjQUFjLFNBQVM7Q0FDckMsSUFBSSxRQUFRLFFBQVEsVUFBVSxTQUFTLEdBQUcsY0FBYyxRQUFRLE9BQU8sQ0FBQyxDQUFDLE1BQU0sWUFBWTtFQUMxRixRQUFRLFFBQVEsS0FBSyxXQUFXLFFBQVEsV0FBVyxPQUFPO0NBQzNELENBQUM7Q0FDRCxNQUFNLGlCQUFpQixPQUFPLGFBQWE7RUFDMUMsSUFBSSxvQkFBb0IsT0FBTztHQUM5QixNQUFNLFFBQVEsV0FBVyxVQUFVLFFBQVE7R0FDM0MsT0FBTztFQUNSO0VBQ0EsSUFBSSxnQkFBZ0IsUUFBUSxHQUFHO0dBQzlCLE1BQU0sUUFBUSxXQUFXLFlBQVksUUFBUTtHQUM3QyxPQUFPO0VBQ1I7Ozs7OztFQU1BLElBQUksZUFBZSxRQUFRLEdBQUc7R0FDN0IsTUFBTSxRQUFRLFdBQVcsWUFBWSxRQUFRO0dBQzdDLE9BQU87RUFDUjtFQUNBLElBQUksU0FBUyxRQUFRLEdBQUc7R0FDdkIsTUFBTSxRQUFRLFdBQVcsVUFBVSxRQUFRO0dBQzNDLE9BQU87RUFDUjtFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sc0JBQXNCLE9BQU8sVUFBVTtFQUM1QyxJQUFJLGlCQUFpQixrQkFBa0IsTUFBTTtFQUM3QyxJQUFJLGdCQUFnQixLQUFLLEdBQUc7R0FDM0IsTUFBTSxRQUFRLFdBQVcsVUFBVSxLQUFLO0dBQ3hDLE9BQU87RUFDUjtFQUNBLElBQUksaUJBQWlCLFVBQVUsT0FBTyxNQUFNLGVBQWUsS0FBSztFQUNoRSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLHNCQUFzQixRQUFRLGNBQWM7Q0FDbEQsSUFBSTtDQUNKLElBQUksbUJBQW1CO0NBQ3ZCLE1BQU0sZ0JBQWdCO0VBQ3JCLG1CQUFtQjtFQUNuQixxQkFBcUIsUUFBUSxRQUFRLFFBQVE7RUFDN0Msb0JBQW9CLE9BQU8sa0JBQWtCO0NBQzlDOzs7O0NBSUEsSUFBSSxRQUFRLFFBQVEsUUFBUTtFQUMzQixJQUFJLFFBQVEsUUFBUSxPQUFPLFNBQVM7R0FDbkMsTUFBTSxRQUFRLFdBQVcsVUFBVSxRQUFRLFFBQVEsT0FBTyxNQUFNO0dBQ2hFO0VBQ0Q7RUFDQSxRQUFRLFFBQVEsT0FBTyxpQkFBaUIsU0FBUyxTQUFTLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDekU7Q0FDQSxNQUFNLENBQUMsZUFBZSxNQUFNLE1BQU0sWUFBWTtFQUM3QyxNQUFNLGVBQWUsSUFBSSxpQkFBaUI7R0FDekMsV0FBVyxRQUFRO0dBQ25CLFdBQVcsUUFBUTtHQUNuQixTQUFTLFFBQVE7R0FDakIsWUFBWSxRQUFRO0VBQ3JCLENBQUM7RUFDRCxNQUFNLDBCQUEwQixRQUFRLFFBQVEsY0FBYyxZQUFZO0VBQzFFLE1BQU0sUUFBUSxLQUFLO0dBQ2xCLG9CQUFvQjtHQUNwQjtHQUNBLFFBQVEsV0FBVztFQUNwQixDQUFDOzs7Ozs7O0VBT0QsSUFBSSxhQUFhLFlBQVksUUFBUSxTQUFTLFFBQVEsVUFBVSxhQUFhO0NBQzlFLENBQUM7Q0FDRCxRQUFRLFFBQVEsUUFBUSxvQkFBb0IsU0FBUyxPQUFPO0NBQzVELElBQUksa0JBQWtCO0VBQ3JCLE1BQU0sUUFBUSxXQUFXLFVBQVUsa0JBQWtCO0VBQ3JEO0NBQ0Q7Q0FDQSxJQUFJLGFBQWE7RUFDaEIsSUFBSSxNQUFNLG9CQUFvQixXQUFXLEdBQUc7RUFDNUMsSUFBSSxRQUFRLFFBQVEsY0FBYyxvQkFBb0IsSUFBSSxHQUFHO0dBQzVELE1BQU0sK0JBQStCLElBQUksa0JBQWtCLFFBQVEsU0FBUzs7Ozs7O0lBTTNFLGNBQWMsQ0FBQztJQUNmLE1BQU0sWUFBWSxVQUFVO0tBQzNCLE1BQU0sZUFBZSxRQUFRO0lBQzlCO0lBQ0EsTUFBTSxVQUFVLFFBQVE7Ozs7Ozs7O0tBUXZCLE1BQU0sUUFBUSxXQUFXLFVBQVUsTUFBTTtJQUMxQztHQUNELENBQUM7R0FDRCxNQUFNLFFBQVEsUUFBUSxjQUFjLElBQUksdUJBQXVCO0lBQzlELFdBQVcsUUFBUTtJQUNuQixPQUFPO0lBQ1AsU0FBUyxRQUFRO0lBQ2pCLFdBQVcsUUFBUTtJQUNuQixZQUFZO0dBQ2IsQ0FBQyxDQUFDO0dBQ0YsSUFBSSw2QkFBNkIsZUFBZSxrQkFBa0IsU0FBUztFQUM1RTtFQUNBLE1BQU0sUUFBUSxXQUFXLFlBQVksMEJBQTBCLFdBQVcsQ0FBQztFQUMzRTtDQUNEO0NBQ0EsSUFBSSxRQUFRLFdBQVcsZUFBZSxrQkFBa0IsU0FBUyxPQUFPLE1BQU0sUUFBUSxXQUFXLFlBQVk7Q0FDN0csT0FBTyxRQUFRLFdBQVc7QUFDM0I7Ozs7OztBQ3ZKQSxTQUFTLGtCQUFrQixNQUFNLE9BQU87Q0FDdkMsTUFBTSxTQUFTLElBQUksV0FBVyxLQUFLLGFBQWEsTUFBTSxVQUFVO0NBQ2hFLE9BQU8sSUFBSSxNQUFNLENBQUM7Q0FDbEIsT0FBTyxJQUFJLE9BQU8sS0FBSyxVQUFVO0NBQ2pDLE9BQU87QUFDUjtBQUdBLElBQUksZ0JBQWdCLE1BQU07Q0FDekIsWUFBWSxNQUFNLFNBQVM7RUFDMUIsS0FBSyxPQUFPO0VBQ1osS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssT0FBTztFQUNaLEtBQUssYUFBYTtFQUNsQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVztFQUNoQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxRQUFRO0VBQ2IsS0FBSyxlQUFlO0VBQ3BCLEtBQUssY0FBYztFQUNuQixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVMsU0FBUyxVQUFVO0VBQ2pDLEtBQUssZ0JBQWdCLFNBQVMsaUJBQWlCO0VBQy9DLEtBQUssWUFBWSxLQUFLLElBQUk7Q0FDM0I7Q0FDQSxlQUFlO0VBQ2QsT0FBTyxDQUFDO0NBQ1Q7Q0FDQSxVQUFVLE1BQU0sU0FBUyxZQUFZO0VBQ3BDLEtBQUssT0FBTztFQUNaLEtBQUssVUFBVSxDQUFDLENBQUM7RUFDakIsS0FBSyxhQUFhLENBQUMsQ0FBQztDQUNyQjtDQUNBLGlCQUFpQjtFQUNoQixLQUFLLG1CQUFtQjtDQUN6QjtDQUNBLGtCQUFrQixDQUFDO0NBQ25CLDJCQUEyQixDQUFDO0FBQzdCO0FBR0EsSUFBSSx3QkFBd0IsY0FBYyxjQUFjO0NBQ3ZELFlBQVksTUFBTSxNQUFNO0VBQ3ZCLE1BQU0sSUFBSTtFQUNWLEtBQUssbUJBQW1CLE1BQU0sb0JBQW9CO0VBQ2xELEtBQUssV0FBVyxNQUFNLFlBQVk7RUFDbEMsS0FBSyxTQUFTLE1BQU0sVUFBVTtFQUM5QixLQUFLLFFBQVEsTUFBTSxTQUFTO0NBQzdCO0FBQ0Q7QUFHQSxJQUFNLDBCQUEwQixPQUFPLGtCQUFrQjtBQUN6RCxTQUFTLFlBQVksUUFBUSxNQUFNLE1BQU07Q0FDeEMsTUFBTSxpQkFBaUI7RUFDdEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDs7Ozs7Q0FLQSxNQUFNLHFCQUFxQiwwQkFBMEIsZ0JBQWdCO0NBQ3JFLE9BQU8sZUFBZSxTQUFTLElBQUksSUFBSSxJQUFJLG1CQUFtQixNQUFNO0VBQ25FLGtCQUFrQjtFQUNsQixRQUFRLE1BQU0sVUFBVTtFQUN4QixPQUFPLE1BQU0sU0FBUztDQUN2QixDQUFDLElBQUksSUFBSSxjQUFjLE1BQU07RUFDNUI7RUFDQSxlQUFlO0NBQ2hCLENBQUM7QUFDRjs7Ozs7QUFPQSxTQUFTLG1CQUFtQixRQUFRLGNBQWM7Q0FDakQsSUFBSSxFQUFFLGdCQUFnQixTQUFTLE9BQU87Q0FDdEMsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsWUFBWSxHQUFHLE9BQU87Q0FDdkUsTUFBTSxZQUFZLFFBQVEsZUFBZSxNQUFNO0NBQy9DLE9BQU8sWUFBWSxtQkFBbUIsV0FBVyxZQUFZLElBQUk7QUFDbEU7QUFHQSxTQUFTLFlBQVksUUFBUSxTQUFTO0NBQ3JDLE9BQU8sSUFBSSxNQUFNLFFBQVEsc0JBQXNCLE9BQU8sQ0FBQztBQUN4RDtBQUNBLFNBQVMsc0JBQXNCLFNBQVM7Q0FDdkMsTUFBTSxFQUFFLGlCQUFpQixZQUFZLGFBQWEsZ0JBQWdCO0NBQ2xFLE1BQU0sVUFBVSxDQUFDO0NBQ2pCLElBQUksT0FBTyxvQkFBb0IsYUFBYSxRQUFRLFlBQVksU0FBUyxRQUFRLE1BQU0sV0FBVztFQUNqRyxNQUFNLE9BQU8sUUFBUSxVQUFVLEtBQUssTUFBTSxRQUFRLE1BQU0sU0FBUztFQUNqRSxPQUFPLGdCQUFnQixLQUFLLFdBQVcsTUFBTSxJQUFJO0NBQ2xEO0NBQ0EsUUFBUSxNQUFNLFNBQVMsUUFBUSxjQUFjLFdBQVc7RUFDdkQsTUFBTSxhQUFhO0dBQ2xCLE1BQU0saUJBQWlCLG1CQUFtQixRQUFRLFlBQVksS0FBSztHQUNuRSxNQUFNLGlCQUFpQixRQUFRLHlCQUF5QixnQkFBZ0IsWUFBWTtHQUNwRixJQUFJLE9BQU8sZ0JBQWdCLFFBQVEsYUFBYTtJQUMvQyxlQUFlLElBQUksTUFBTSxRQUFRLENBQUMsU0FBUyxDQUFDO0lBQzVDLE9BQU87R0FDUjtHQUNBLE9BQU8sUUFBUSxlQUFlLGdCQUFnQixjQUFjO0lBQzNELFVBQVU7SUFDVixZQUFZO0lBQ1osY0FBYztJQUNkLE9BQU87R0FDUixDQUFDO0VBQ0Y7RUFDQSxJQUFJLE9BQU8sZ0JBQWdCLGFBQWEsT0FBTyxZQUFZLEtBQUssUUFBUSxDQUFDLGNBQWMsU0FBUyxHQUFHLElBQUk7RUFDdkcsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxRQUFRLE1BQU0sU0FBUyxRQUFRLGNBQWMsVUFBVTs7OztFQUl0RCxNQUFNLGFBQWEsT0FBTztFQUMxQixNQUFNLFFBQVEsT0FBTyxnQkFBZ0IsY0FBYyxZQUFZLEtBQUssUUFBUSxDQUFDLGNBQWMsUUFBUSxHQUFHLElBQUksSUFBSSxLQUFLO0VBQ25ILElBQUksT0FBTyxVQUFVLFlBQVksUUFBUSxHQUFHLFNBQVM7R0FDcEQsTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLEdBQUcsSUFBSTtHQUN2QyxJQUFJLE9BQU8sZUFBZSxhQUFhLE9BQU8sV0FBVyxLQUFLLFFBQVEsQ0FBQyxjQUFjLElBQUksR0FBRyxJQUFJO0dBQ2hHLE9BQU8sS0FBSztFQUNiO0VBQ0EsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBR0EsU0FBUyx5QkFBeUIsTUFBTTtDQUN2QyxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUMsQ0FBQyxNQUFNLGtCQUFrQjtFQUN6QixPQUFPLEtBQUssV0FBVyxhQUFhO0NBQ3JDLENBQUM7QUFDRjs7Ozs7QUFPQSxTQUFTLFVBQVUsTUFBTTtDQUN4QixJQUFJO0VBQ0gsT0FBTyxLQUFLLE1BQU0sSUFBSTtDQUN2QixTQUFTLEdBQUc7RUFDWCxPQUFPO0NBQ1I7QUFDRDs7Ozs7QUFPQSxTQUFTLGVBQWUsU0FBUyxNQUFNOzs7Ozs7Ozs7Q0FTdEMsTUFBTSxxQkFBcUIsY0FBYyxtQkFBbUIsUUFBUSxNQUFNLElBQUksT0FBTztDQUNyRixPQUFPLElBQUksY0FBYyxvQkFBb0I7RUFDNUMsS0FBSyxRQUFRO0VBQ2IsUUFBUSxRQUFRO0VBQ2hCLFlBQVksUUFBUTtFQUNwQixTQUFTLHVDQUF1QyxRQUFRLHNCQUFzQixDQUFDO0NBQ2hGLENBQUM7QUFDRjtBQUNBLFNBQVMsdUNBQXVDLGVBQWU7Q0FDOUQsTUFBTSxVQUFVLElBQUksUUFBUTtDQUM1QixNQUFNLFFBQVEsY0FBYyxNQUFNLFNBQVM7Q0FDM0MsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN6QixJQUFJLEtBQUssS0FBSyxNQUFNLElBQUk7RUFDeEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLEtBQUssTUFBTSxJQUFJO0VBQ3hDLE1BQU0sUUFBUSxNQUFNLEtBQUssSUFBSTtFQUM3QixRQUFRLE9BQU8sTUFBTSxLQUFLO0NBQzNCO0NBQ0EsT0FBTztBQUNSOzs7OztBQU9BLGVBQWUsa0JBQWtCLE9BQU87Q0FDdkMsTUFBTSx3QkFBd0IsTUFBTSxRQUFRLElBQUksZ0JBQWdCO0NBQ2hFLElBQUkseUJBQXlCLFFBQVEsMEJBQTBCLElBQUksT0FBTyxPQUFPLHFCQUFxQjtDQUN0RyxRQUFRLE1BQU0sTUFBTSxZQUFZLEVBQUEsQ0FBRztBQUNwQztBQUdBLElBQU0sb0JBQW9CLE9BQU8sbUJBQW1CO0FBQ3BELElBQU0sZ0JBQWdCLE9BQU8sZUFBZTtBQUM1QyxJQUFNLGdCQUFnQjs7Ozs7QUFLdEIsSUFBSSwyQkFBMkIsTUFBTTtDQUNwQyxZQUFZLGdCQUFnQixRQUFRO0VBQ25DLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssU0FBUztFQUNkLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUztFQUNkLEtBQUssTUFBTTtFQUNYLEtBQUsscUJBQXFCO0VBQzFCLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUsseUJBQXlCLElBQUksSUFBSTtFQUN0QyxLQUFLLCtCQUErQixJQUFJLElBQUk7RUFDNUMsS0FBSyxZQUFZLGdCQUFnQjtFQUNqQyxLQUFLLGlCQUFpQixJQUFJLFFBQVE7RUFDbEMsS0FBSyxpQ0FBaUMsSUFBSSxXQUFXO0VBQ3JELEtBQUssVUFBVSxZQUFZLGdCQUFnQixFQUFFLGFBQWEsQ0FBQyxZQUFZLE9BQU8sV0FBVztHQUN4RixRQUFRLFlBQVI7SUFDQyxLQUFLLFFBQVE7S0FDWixNQUFNLENBQUMsUUFBUSxLQUFLLFNBQVM7S0FDN0IsS0FBSyxPQUFPLEVBQUUsU0FBUztLQUN2QixJQUFJLE9BQU8sUUFBUSxhQUFhO01BQy9CLEtBQUssU0FBUztNQUNkLEtBQUssTUFBTSxjQUFjLE1BQU07S0FDaEMsT0FBTztNQUNOLEtBQUssU0FBUztNQUNkLEtBQUssTUFBTSxjQUFjLEdBQUc7S0FDN0I7S0FDQSxLQUFLLE9BQU8sUUFBUSxjQUFjLEtBQUssUUFBUSxLQUFLLElBQUksSUFBSTtLQUM1RCxPQUFPLE9BQU87SUFDZjtJQUNBLEtBQUssb0JBQW9CO0tBQ3hCLE1BQU0sQ0FBQyxXQUFXLFlBQVk7S0FDOUIsS0FBSyxjQUFjLFdBQVcsUUFBUTtLQUN0QyxLQUFLLE9BQU8sUUFBUSxvQkFBb0IsV0FBVyxRQUFRO0tBQzNELE9BQU8sT0FBTztJQUNmO0lBQ0EsS0FBSyxvQkFBb0I7S0FDeEIsTUFBTSxDQUFDLE1BQU0sU0FBUztLQUN0QixLQUFLLGVBQWUsSUFBSSxNQUFNLEtBQUs7S0FDbkMsS0FBSyxPQUFPLFFBQVEsb0JBQW9CLE1BQU0sS0FBSztLQUNuRCxPQUFPLE9BQU87SUFDZjtJQUNBLEtBQUssUUFBUTtLQUNaLE1BQU0sQ0FBQyxRQUFRO0tBQ2YsSUFBSSxLQUFLLE1BQU07TUFDZCxRQUFRLEtBQUssMENBQTBDLEtBQUssT0FBTyxHQUFHLEtBQUssSUFBSSxpRkFBaUY7TUFDaEssT0FBTyxPQUFPO0tBQ2Y7S0FDQSxLQUFLLFFBQVEsaUJBQWlCLGNBQWM7TUFDM0MsSUFBSSxPQUFPLEtBQUssZUFBZSxhQUFhO09BQzNDLE1BQU0sZ0JBQWdCO1FBQ3JCLEtBQUs7Ozs7OztRQU1MLEtBQUssUUFBUTtPQUNkO09BQ0EsS0FBSyxXQUFXLEtBQUssTUFBTTtRQUMxQixVQUFVO1FBQ1YsY0FBYyxLQUFLLHFCQUFxQixTQUFTO1FBQ2pELFNBQVM7UUFDVCxXQUFXLEtBQUs7T0FDakIsQ0FBQztNQUNGO0tBQ0QsQ0FBQztLQUNELE1BQU0sY0FBYyxPQUFPLFNBQVMsV0FBVyxhQUFhLElBQUksSUFBSTtLQUNwRSxNQUFNLGVBQWUsS0FBSyxrQkFBa0IsV0FBVztLQUN2RCxLQUFLLGlCQUFpQixhQUFhLE1BQU07Ozs7O0tBS3pDLHFCQUFxQjtNQUNwQixDQUFDLEtBQUssV0FBVyxLQUFLLE1BQU07T0FDM0IsU0FBUztPQUNULFdBQVcsS0FBSztNQUNqQixDQUFDLEtBQUssUUFBUSxRQUFRLEVBQUEsQ0FBRyxjQUFjO09BQ3RDLElBQUksQ0FBQyxLQUFLLG9CQUFvQjtRQUM3QixLQUFLLE9BQU8sUUFBUSxrR0FBa0csS0FBSyxRQUFRLFVBQVU7UUFDN0ksT0FBTyxPQUFPO09BQ2Y7TUFDRCxDQUFDO0tBQ0YsQ0FBQztLQUNEO0lBQ0Q7SUFDQSxTQUFTLE9BQU8sT0FBTztHQUN4QjtFQUNELEVBQUUsQ0FBQzs7OztFQUlILE9BQU8sS0FBSyxTQUFTLFVBQVUsWUFBWSxLQUFLLFFBQVEsUUFBUTtHQUMvRCxjQUFjLENBQUMsY0FBYyxZQUFZLFdBQVc7SUFDbkQsUUFBUSxjQUFSO0tBQ0MsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSyxhQUFhO01BQ2pCLE1BQU0sWUFBWSxhQUFhLE1BQU0sQ0FBQztNQUN0QyxLQUFLLG9CQUFvQixXQUFXLFNBQVM7S0FDOUM7SUFDRDtJQUNBLE9BQU8sT0FBTztHQUNmO0dBQ0EsYUFBYSxDQUFDLFlBQVksT0FBTyxXQUFXO0lBQzNDLFFBQVEsWUFBUjtLQUNDLEtBQUssb0JBQW9CO01BQ3hCLE1BQU0sQ0FBQyxXQUFXLFlBQVk7TUFDOUIsS0FBSyxvQkFBb0IsV0FBVyxRQUFRO01BQzVDLEtBQUssT0FBTyxRQUFRLDJCQUEyQixXQUFXLFFBQVE7TUFDbEUsT0FBTyxPQUFPO0tBQ2Y7SUFDRDtHQUNEO0VBQ0QsQ0FBQyxDQUFDO0NBQ0g7Q0FDQSxjQUFjLFdBQVcsVUFBVTtFQUNsQyxNQUFNLGNBQWMsS0FBSyxPQUFPLElBQUksU0FBUyxLQUFLLENBQUMsRUFBQSxDQUFHLE9BQU8sUUFBUTtFQUNyRSxLQUFLLE9BQU8sSUFBSSxXQUFXLFVBQVU7RUFDckMsS0FBSyxPQUFPLFFBQVEsMkJBQTJCLFdBQVcsUUFBUTtDQUNuRTtDQUNBLG9CQUFvQixXQUFXLFVBQVU7RUFDeEMsTUFBTSxjQUFjLEtBQUssYUFBYSxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUEsQ0FBRyxPQUFPLFFBQVE7RUFDM0UsS0FBSyxhQUFhLElBQUksV0FBVyxVQUFVO0VBQzNDLEtBQUssT0FBTyxRQUFRLGtDQUFrQyxXQUFXLFFBQVE7Q0FDMUU7Ozs7O0NBS0EsTUFBTSxZQUFZLFVBQVU7Ozs7Ozs7OztFQVMzQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLE9BQU8sUUFBUSw0Q0FBNEMsU0FBUyxRQUFRLFNBQVMsVUFBVTtFQUNwRyxjQUFjLE9BQU8sS0FBSyxJQUFJLE1BQU0sUUFBUTtFQUM1QyxPQUFPLGlCQUFpQixLQUFLLFNBQVM7R0FDckMsVUFBVTtJQUNULFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxLQUFLO0dBQ2pCO0dBQ0EsY0FBYztJQUNiLFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxLQUFLO0dBQ2pCO0dBQ0EsYUFBYTtJQUNaLFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxLQUFLO0dBQ2pCO0VBQ0QsQ0FBQztFQUNELEtBQUssUUFBUSxhQUFhLEtBQUssU0FBUztHQUN2QyxRQUFRO0dBQ1IsT0FBTztFQUNSLENBQUM7RUFDRCxJQUFJLHlCQUF5QjtFQUM3QixJQUFJLGlCQUFpQjtFQUNyQixJQUFJLEtBQUssZ0JBQWdCO0dBQ3hCLE1BQU0sb0JBQW9CLE1BQU0sa0JBQWtCLEtBQUssY0FBYyxDQUFDLE1BQU0sQ0FBQztHQUM3RSxJQUFJLENBQUMsZ0JBQWdCLEtBQUssUUFBUSxhQUFhLEtBQUssUUFBUSxRQUFRO0lBQ25FLFFBQVE7SUFDUixPQUFPO0dBQ1IsQ0FBQztHQUNELE1BQU0saUNBQWlDLGdCQUFnQjtJQUN0RCwwQkFBMEI7SUFDMUIsSUFBSSx5QkFBeUIsbUJBQW1CLEtBQUssUUFBUSxZQUFZLEtBQUssUUFBUSxRQUFRO0tBQzdGLFFBQVE7S0FDUixPQUFPO0lBQ1IsQ0FBQztHQUNGO0dBQ0EsTUFBTSxnQ0FBZ0M7SUFDckMsaUJBQWlCO0lBQ2pCLEtBQUssUUFBUSxZQUFZLEtBQUssUUFBUSxRQUFRO0tBQzdDLFFBQVE7S0FDUixPQUFPO0lBQ1IsQ0FBQztJQUNELEtBQUssUUFBUSxRQUFRLEtBQUssUUFBUSxRQUFRO0tBQ3pDLFFBQVE7S0FDUixPQUFPO0lBQ1IsQ0FBQztJQUNELEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxRQUFRO0tBQzVDLFFBQVE7S0FDUixPQUFPO0lBQ1IsQ0FBQztHQUNGO0dBQ0EsSUFBSSxLQUFLLGNBQWMsRUFBRSxRQUFRLE1BQU07SUFDdEMsTUFBTSxTQUFTLEtBQUssY0FBYyxDQUFDLEtBQUssVUFBVTtJQUNsRCxPQUFPLE1BQU07S0FDWixNQUFNLEVBQUUsT0FBTyxTQUFTLE1BQU0sT0FBTyxLQUFLO0tBQzFDLElBQUksTUFBTTtNQUNULHdCQUF3QjtNQUN4QjtLQUNEO0tBQ0EsOEJBQThCLE1BQU0sVUFBVTtJQUMvQztHQUNELE9BQU8sd0JBQXdCO0VBQ2hDO0VBQ0EsSUFBSSxXQUFXO0VBQ2YsTUFBTSx5QkFBeUIsSUFBSSxnQkFBZ0I7RUFDbkQsTUFBTSxxQkFBcUIsVUFBVTtHQUNwQyxLQUFLLGNBQWMsS0FBSyxRQUFRLElBQUk7R0FDcEMsSUFBSSxDQUFDLGdCQUFnQjtJQUNwQixLQUFLLFFBQVEsT0FBTyxLQUFLLFFBQVEsUUFBUTtLQUN4QyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7SUFDRCxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsUUFBUTtLQUM1QyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLEtBQUssUUFBUSxPQUFPLEtBQUssU0FBUztJQUNqQyxRQUFRO0lBQ1IsT0FBTztHQUNSLENBQUM7R0FDRCxLQUFLLFFBQVEsV0FBVyxLQUFLLFNBQVM7SUFDckMsUUFBUTtJQUNSLE9BQU87R0FDUixDQUFDO0VBQ0Y7RUFDQSxNQUFNLGtCQUFrQixPQUFPLGFBQWE7R0FDM0MsTUFBTSxxQkFBcUI7SUFDMUIsSUFBSSxVQUFVLGtCQUFrQixTQUFTO1NBQ3BDLElBQUksdUJBQXVCLE9BQU8sU0FBUyxrQkFBa0IsT0FBTztTQUNwRSxJQUFJLGdCQUFnQixRQUFRLEdBQUcsa0JBQWtCLE9BQU87R0FDOUQ7R0FDQSxhQUFhO0dBQ2IsT0FBTyxLQUFLLFNBQVMsVUFBVSxTQUFTLE1BQU07R0FDOUMsT0FBTyxLQUFLLFNBQVMsY0FBYyxTQUFTLFVBQVU7R0FDdEQsSUFBSSxDQUFDLEtBQUssUUFBUSxhQUFhLE9BQU8sS0FBSyxTQUFTLGVBQWUsU0FBUyxHQUFHO0dBQy9FLElBQUksZ0JBQWdCLFFBQVEsR0FBRzs7Ozs7R0FLL0IsTUFBTSxxQkFBcUIsT0FBTyxTQUFTLFFBQVEsSUFBSSxnQkFBZ0IsS0FBSyxHQUFHO0dBQy9FLEtBQUssY0FBYyxLQUFLLFFBQVEsZ0JBQWdCO0dBQ2hELElBQUksZ0JBQWdCO0dBQ3BCLElBQUksOEJBQThCLFlBQVksSUFBSTtHQUNsRCxNQUFNLDRCQUE0QixnQkFBZ0I7SUFDakQsaUJBQWlCO0lBQ2pCLE1BQU0sTUFBTSxZQUFZLElBQUk7SUFDNUIsTUFBTSxlQUFlLE1BQU0sK0JBQStCLE1BQU0sZ0JBQWdCO0lBQ2hGLDhCQUE4QjtJQUM5QixJQUFJLGNBQWM7SUFDbEIsSUFBSSxLQUFLLFFBQVEsZUFBZSxLQUFLLFFBQVEsa0JBQWtCLEtBQUssY0FBYyxLQUFLLFFBQVEsU0FBUyxLQUFLO0lBQzdHLEtBQUssUUFBUSxvQkFBb0IsS0FBSyxPQUFPO0lBQzdDLEtBQUssUUFBUSxZQUFZLEtBQUssU0FBUztLQUN0QyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLE1BQU0saUNBQWlDO0lBQ3RDLGtCQUFrQixPQUFPO0dBQzFCO0dBQ0EsTUFBTSwyQkFBMkIsWUFBWTtJQUM1QyxhQUFhO0lBQ2IsSUFBSSxnQkFBZ0IsUUFBUSxHQUFHO0lBQy9CLElBQUksY0FBYztJQUNsQixLQUFLLGNBQWMsS0FBSyxRQUFRLElBQUk7SUFDcEMsS0FBSyxRQUFRLFFBQVEsS0FBSyxTQUFTO0tBQ2xDLFFBQVE7S0FDUixPQUFPO0lBQ1IsQ0FBQztJQUNELEtBQUssUUFBUSxXQUFXLEtBQUssU0FBUztLQUNyQyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLElBQUksU0FBUyxRQUFRLE1BQU0seUJBQXlCO1FBQy9DO0lBQ0osTUFBTSxTQUFTLFNBQVMsS0FBSyxVQUFVO0lBQ3ZDLE9BQU8sTUFBTTtLQUNaLElBQUksdUJBQXVCLE9BQU8sU0FBUztLQUMzQyxJQUFJO01BQ0gsTUFBTSxFQUFFLE9BQU8sU0FBUyxNQUFNLE9BQU8sS0FBSztNQUMxQyxJQUFJLE1BQU07T0FDVCx5QkFBeUI7T0FDekI7TUFDRDtNQUNBLHlCQUF5QixNQUFNLFVBQVU7TUFDekMsS0FBSyxpQkFBaUIsa0JBQWtCLEtBQUssZ0JBQWdCLEtBQUs7S0FDbkUsUUFBUTtNQUNQLHlCQUF5QjtLQUMxQjtJQUNEO0dBQ0Q7RUFDRDtFQUNBLE1BQU0sQ0FBQyxlQUFlLGlCQUFpQixNQUFNLFlBQVk7R0FDeEQsT0FBTyxLQUFLLGdCQUFnQixRQUFRO0VBQ3JDLENBQUM7RUFDRCxJQUFJLGVBQWU7RUFDbkIsZ0JBQWdCLGFBQWE7RUFDN0IsSUFBSSxLQUFLLFFBQVEsU0FBUyxpQkFBaUI7R0FDMUMsSUFBSSxLQUFLLFFBQVEsZUFBZSxLQUFLLFFBQVEsTUFBTTtJQUNsRCxXQUFXO0lBQ1gsdUJBQXVCLE1BQU07R0FDOUI7RUFDRCxHQUFHLEtBQUssUUFBUSxPQUFPO0VBQ3ZCLEtBQUssUUFBUSxvQkFBb0IsSUFBSSxNQUFNLEtBQUssUUFBUSxtQkFBbUIsRUFBRSxRQUFRLEdBQUcsSUFBSSxTQUFTO0dBQ3BHLEtBQUssT0FBTyxRQUFRLHFCQUFxQixLQUFLLEVBQUU7R0FDaEQsSUFBSSxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsa0JBQWtCO0lBQzVELEtBQUssT0FBTyxRQUFRLDBDQUEwQztJQUM5RCxPQUFPO0dBQ1I7R0FDQSxNQUFNLGNBQWMsY0FBYyxRQUFRLElBQUksS0FBSyxFQUFFO0dBQ3JELEtBQUssT0FBTyxRQUFRLHNDQUFzQyxLQUFLLElBQUksV0FBVztHQUM5RSxPQUFPO0VBQ1IsRUFBRSxDQUFDO0VBQ0gsS0FBSyxRQUFRLHdCQUF3QixJQUFJLE1BQU0sS0FBSyxRQUFRLHVCQUF1QixFQUFFLGFBQWE7R0FDakcsS0FBSyxPQUFPLFFBQVEsdUJBQXVCO0dBQzNDLElBQUksS0FBSyxRQUFRLGFBQWEsS0FBSyxRQUFRLGtCQUFrQjtJQUM1RCxLQUFLLE9BQU8sUUFBUSxrREFBa0Q7SUFDdEUsT0FBTztHQUNSO0dBQ0EsTUFBTSxhQUFhLE1BQU0sS0FBSyxjQUFjLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLGlCQUFpQjtJQUN2RixPQUFPLEdBQUcsV0FBVyxJQUFJO0dBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTTtHQUNkLEtBQUssT0FBTyxRQUFRLG9DQUFvQyxVQUFVO0dBQ2xFLE9BQU87RUFDUixFQUFFLENBQUM7Q0FDSjtDQUNBLHVCQUF1QjtFQUN0QixPQUFPLGFBQWEsS0FBSyxjQUFjO0NBQ3hDO0NBQ0EsSUFBSSxXQUFXO0VBQ2QsS0FBSyxPQUFPLFFBQVEsa0NBQWtDLEtBQUssUUFBUSxZQUFZO0VBQy9FLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxRQUFRLE1BQU0sT0FBTztFQUMxRCxRQUFRLEtBQUssUUFBUSxjQUFyQjtHQUNDLEtBQUssUUFBUTtJQUNaLE1BQU0sZUFBZSxVQUFVLEtBQUsscUJBQXFCLENBQUM7SUFDMUQsS0FBSyxPQUFPLFFBQVEsMEJBQTBCLFlBQVk7SUFDMUQsT0FBTztHQUNSO0dBQ0EsS0FBSyxlQUFlO0lBQ25CLE1BQU0sY0FBYyxjQUFjLEtBQUssY0FBYztJQUNyRCxLQUFLLE9BQU8sUUFBUSxpQ0FBaUMsV0FBVztJQUNoRSxPQUFPO0dBQ1I7R0FDQSxLQUFLLFFBQVE7SUFDWixNQUFNLFdBQVcsS0FBSyxRQUFRLGtCQUFrQixjQUFjLEtBQUs7SUFDbkUsTUFBTSxlQUFlLElBQUksS0FBSyxDQUFDLEtBQUsscUJBQXFCLENBQUMsR0FBRyxFQUFFLE1BQU0sU0FBUyxDQUFDO0lBQy9FLEtBQUssT0FBTyxRQUFRLDBDQUEwQyxjQUFjLFFBQVE7SUFDcEYsT0FBTztHQUNSO0dBQ0EsU0FBUztJQUNSLE1BQU0sZUFBZSxLQUFLLHFCQUFxQjtJQUMvQyxLQUFLLE9BQU8sUUFBUSwwQ0FBMEMsS0FBSyxRQUFRLGNBQWMsWUFBWTtJQUNyRyxPQUFPO0dBQ1I7RUFDRDtDQUNEO0NBQ0EsSUFBSSxlQUFlOzs7Ozs7RUFNbEIsVUFBVSxLQUFLLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxRQUFRLGlCQUFpQixRQUFRLG9EQUFvRDtFQUN4SSxJQUFJLEtBQUssUUFBUSxlQUFlLEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxlQUFlLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDOUcsTUFBTSxlQUFlLEtBQUsscUJBQXFCO0VBQy9DLEtBQUssT0FBTyxRQUFRLDJCQUEyQixZQUFZO0VBQzNELE9BQU87Q0FDUjtDQUNBLElBQUksY0FBYztFQUNqQixVQUFVLEtBQUssUUFBUSxpQkFBaUIsTUFBTSxLQUFLLFFBQVEsaUJBQWlCLFlBQVksb0RBQW9EO0VBQzVJLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxRQUFRLE1BQU0sT0FBTztFQUMxRCxNQUFNLGNBQWMsS0FBSyxRQUFRLGtCQUFrQixjQUFjLEtBQUs7RUFDdEUsSUFBSSxPQUFPLGNBQWMsYUFBYTtHQUNyQyxRQUFRLEtBQUssd0xBQXdMO0dBQ3JNLE9BQU87RUFDUjtFQUNBLElBQUkseUJBQXlCLFdBQVcsR0FBRyxPQUFPLElBQUksVUFBVSxDQUFDLENBQUMsZ0JBQWdCLEtBQUsscUJBQXFCLEdBQUcsV0FBVztFQUMxSCxPQUFPO0NBQ1I7Q0FDQSxNQUFNLGdCQUFnQixVQUFVO0VBQy9CLE1BQU0sbUJBQW1CLFNBQVMsUUFBUSxJQUFJLFVBQVU7RUFDeEQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGNBQWMsbUJBQW1CLFNBQVMsTUFBTSxHQUFHLE9BQU87RUFDcEYsS0FBSztFQUNMLElBQUksS0FBSyxnQkFBZ0IsZUFBZSxNQUFNLElBQUksTUFBTSxvQkFBb0I7RUFDNUUsTUFBTSxjQUFjLElBQUksSUFBSSxrQkFBa0IsU0FBUyxJQUFJO0VBQzNELE1BQU0saUJBQWlCLGNBQWMsbUJBQW1CLFNBQVMsTUFBTSxJQUFJLEtBQUssU0FBUztFQUN6RixNQUFNLG1CQUFtQixNQUFNLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDL0QsTUFBTSxVQUFVLElBQUksZUFBZTtHQUNuQyxRQUFRLGVBQWUsS0FBSyxRQUFRO0dBQ3BDLFFBQVEsaUJBQWlCLGNBQWM7SUFDdEMsS0FBSyxNQUFNLElBQUksSUFBSSxRQUFRLFdBQVc7SUFDdEMsUUFBUSxlQUFlLFNBQVMsUUFBUSxRQUFRLENBQUM7R0FDbEQsQ0FBQztHQUNELFFBQVEsaUJBQWlCLGVBQWU7SUFDdkMsS0FBSyxVQUFVO0lBQ2YsdUJBQXVCLElBQUksTUFBTSx5QkFBeUIsQ0FBQztHQUM1RCxDQUFDO0dBQ0QsUUFBUSxLQUFLLGdCQUFnQixZQUFZLElBQUk7R0FDN0MsUUFBUSxLQUFLO0VBQ2QsQ0FBQztFQUNELE9BQU8sS0FBSyxnQkFBZ0IsZ0JBQWdCO0NBQzdDO0NBQ0EsVUFBVSxPQUFPOzs7OztFQUtoQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLE9BQU8sUUFBUSwwQkFBMEI7RUFDOUMsS0FBSyxjQUFjLEtBQUssUUFBUSxJQUFJO0VBQ3BDLEtBQUssUUFBUSxTQUFTLEtBQUssT0FBTztFQUNsQyxLQUFLLFFBQVEsV0FBVyxLQUFLLE9BQU87Q0FDckM7Ozs7Q0FJQSxjQUFjLGdCQUFnQiwrQkFBK0IsTUFBTTtFQUNsRSxLQUFLLE9BQU8sUUFBUSwyQkFBMkIsS0FBSyxRQUFRLFlBQVksY0FBYztFQUN0RixJQUFJLEtBQUssUUFBUSxlQUFlLGdCQUFnQjtHQUMvQyxLQUFLLE9BQU8sUUFBUSwrQ0FBK0M7R0FDbkU7RUFDRDtFQUNBLE9BQU8sS0FBSyxTQUFTLGNBQWMsY0FBYztFQUNqRCxLQUFLLE9BQU8sUUFBUSx5QkFBeUIsY0FBYztFQUMzRCxJQUFJLENBQUMsOEJBQThCO0VBQ25DLElBQUksbUJBQW1CLEtBQUssUUFBUSxRQUFRO0dBQzNDLEtBQUssT0FBTyxRQUFRLDBDQUEwQztHQUM5RCxLQUFLLFFBQVEsb0JBQW9CLEtBQUssT0FBTztFQUM5QztDQUNEOzs7O0NBSUEsUUFBUSxXQUFXLFFBQVEsU0FBUztFQUNuQyxNQUFNLFdBQVcsT0FBTyxLQUFLO0VBQzdCLE1BQU0sUUFBUSxZQUFZLFFBQVEsV0FBVyxPQUFPO0VBQ3BELEtBQUssT0FBTyxRQUFRLGtCQUFrQixXQUFXLFdBQVcsRUFBRTtFQUM5RCxJQUFJLE9BQU8sYUFBYSxZQUFZO0dBQ25DLEtBQUssT0FBTyxRQUFRLDhDQUE4QyxTQUFTO0dBQzNFLFNBQVMsS0FBSyxRQUFRLEtBQUs7RUFDNUI7RUFDQSxNQUFNLFNBQVMsa0JBQWtCLHVCQUF1QixLQUFLLGVBQWUsS0FBSztFQUNqRixLQUFLLE1BQU0sQ0FBQyxxQkFBcUIsY0FBYyxRQUFRLElBQUksd0JBQXdCLFdBQVc7R0FDN0YsS0FBSyxPQUFPLFFBQVEscURBQXFELFVBQVUsUUFBUSxTQUFTO0dBQ3BHLFVBQVUsU0FBUyxhQUFhLFNBQVMsS0FBSyxRQUFRLEtBQUssQ0FBQztFQUM3RDtDQUNEOzs7O0NBSUEsa0JBQWtCLE1BQU07RUFDdkIsS0FBSyxPQUFPLFFBQVEsOENBQThDO0VBQ2xFLE1BQU0sZUFBZSxnQkFBZ0IsV0FBVyxLQUFLLGdCQUFnQixZQUFZO0VBQ2pGLE1BQU0sZUFBZSxJQUFJLGFBQWEsS0FBSyxJQUFJLE1BQU07R0FDcEQsUUFBUSxLQUFLO0dBQ2IsU0FBUyxLQUFLOzs7O0dBSWQsYUFBYSxLQUFLLFFBQVEsa0JBQWtCLFlBQVk7R0FDeEQsTUFBTTtFQUNQLENBQUM7RUFDRCxNQUFNLFVBQVUsYUFBYTtFQUM3QixPQUFPLGNBQWMsV0FBVyxZQUFZLFNBQVMsRUFBRSxhQUFhLENBQUMsWUFBWSxPQUFPLFdBQVc7R0FDbEcsTUFBTSxTQUFTLE9BQU87R0FDdEIsUUFBUSxZQUFSO0lBQ0MsS0FBSztJQUNMLEtBQUssT0FBTztLQUNYLE1BQU0sQ0FBQyxZQUFZLGVBQWU7Ozs7Ozs7S0FPbEMsSUFBSSxRQUFRLElBQUksVUFBVSxHQUFHLEtBQUssUUFBUSxpQkFBaUIsWUFBWSxXQUFXO0tBQ2xGO0lBQ0Q7SUFDQSxLQUFLLFVBQVU7S0FDZCxNQUFNLENBQUMsY0FBYztLQUNyQixRQUFRLEtBQUssb0NBQW9DLFdBQVcscURBQXFELGFBQWEsT0FBTyxHQUFHLGFBQWEsSUFBSSxxREFBcUQ7S0FDOU07SUFDRDtHQUNEO0dBQ0EsT0FBTztFQUNSLEVBQUUsQ0FBQyxDQUFDO0VBQ0osS0FBSyxPQUFPLFFBQVEsNkNBQTZDLFlBQVk7RUFDN0UsT0FBTztDQUNSO0FBQ0Q7QUFDQSxTQUFTLGNBQWMsS0FBSzs7Ozs7Ozs7Q0FRM0IsSUFBSSxPQUFPLGFBQWEsYUFBYSxPQUFPLElBQUksSUFBSSxHQUFHO0NBQ3ZELE9BQU8sSUFBSSxJQUFJLElBQUksU0FBUyxHQUFHLFNBQVMsSUFBSTtBQUM3QztBQUNBLFNBQVMsT0FBTyxRQUFRLFVBQVUsT0FBTztDQUN4QyxRQUFRLGVBQWUsUUFBUSxVQUFVO0VBQ3hDLFVBQVU7RUFDVixZQUFZO0VBQ1o7Q0FDRCxDQUFDO0FBQ0Y7Ozs7OztBQVFBLFNBQVMsMEJBQTBCLEVBQUUsU0FBUyxVQUFVO0NBQ3ZELE9BQU8sSUFBSSxNQUFNLFdBQVcsZ0JBQWdCLEVBQUUsVUFBVSxRQUFRLE1BQU0sV0FBVztFQUNoRixPQUFPLFFBQVEsZ0NBQWdDO0VBQy9DLE1BQU0sa0JBQWtCLFFBQVEsVUFBVSxRQUFRLE1BQU0sU0FBUzs7Ozs7Ozs7RUFRakUsTUFBTSx1QkFBdUIsT0FBTywwQkFBMEIsT0FBTyxTQUFTO0VBQzlFLEtBQUssTUFBTSxnQkFBZ0Isc0JBQXNCLFFBQVEsZUFBZSxpQkFBaUIsY0FBYyxxQkFBcUIsYUFBYTtFQUN6SSxNQUFNLHVCQUF1QixJQUFJLHlCQUF5QixpQkFBaUIsTUFBTTtFQUNqRixxQkFBcUIsWUFBWSxlQUFlLEVBQUUsU0FBUyxhQUFhO0dBQ3ZFLE1BQU0sYUFBYSxJQUFJLGtCQUFrQixTQUFTO0lBQ2pELG1CQUFtQjtLQUNsQixLQUFLLE9BQU8sUUFBUSwwREFBMEQ7SUFDL0U7SUFDQSxhQUFhLE9BQU8sYUFBYTtLQUNoQyxNQUFNLEtBQUssWUFBWSxRQUFRO0lBQ2hDO0lBQ0EsWUFBWSxXQUFXO0tBQ3RCLEtBQUssT0FBTyxRQUFRLHNCQUFzQixFQUFFLE9BQU8sT0FBTyxDQUFDO0tBQzNELElBQUksa0JBQWtCLE9BQU8sS0FBSyxVQUFVLE1BQU07SUFDbkQ7R0FDRCxHQUFHO0lBQ0Y7SUFDQTtHQUNELENBQUM7R0FDRCxLQUFLLE9BQU8sUUFBUSwwQkFBMEI7R0FDOUMsS0FBSyxPQUFPLFFBQVEsd0RBQXdELFFBQVEsY0FBYyxTQUFTLENBQUM7R0FDNUcsTUFBTSxjQUFjO0lBQ25CLFdBQVcsS0FBSztJQUNoQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EscUJBQXFCLGFBQWEsZUFBZSxFQUFFLFVBQVUsY0FBYyxTQUFTLGFBQWE7R0FDaEcsS0FBSyxPQUFPLFFBQVEseURBQXlELFFBQVEsY0FBYyxVQUFVLENBQUM7R0FDOUcsTUFBTSxRQUFRLGNBQWMsSUFBSSxrQkFBa0I7SUFDakQsV0FBVyxLQUFLO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQyxDQUFDO0VBQ0g7RUFDQSxPQUFPLHFCQUFxQjtDQUM3QixFQUFFLENBQUM7QUFDSjtBQUdBLElBQU1DLFdBQVMsYUFBYSxLQUFLO0FBQ2pDLElBQUksNEJBQTRCLGNBQWMsWUFBWTtDQUN6RDtFQUNDLEtBQUssU0FBUyxPQUFPLElBQUksaUJBQWlCO0NBQzNDO0NBQ0EsWUFBWTtFQUNYLE9BQU8sc0JBQXNCLGdCQUFnQjtDQUM5QztDQUNBLFFBQVE7RUFDUCxTQUFPLFFBQVEsZ0NBQWdDO0VBQy9DLEtBQUssY0FBYyxLQUFLLGdCQUFnQixXQUFXLFlBQVksd0JBQXdCO0dBQ3RGLE9BQU8sMEJBQTBCO0lBQ2hDLFNBQVMsS0FBSztJQUNkLFFBQUE7R0FDRCxDQUFDO0VBQ0YsQ0FBQyxDQUFDO0VBQ0YsU0FBTyxRQUFRLHNDQUFzQyxXQUFXLGVBQWUsSUFBSTtDQUNwRjtBQUNEOzs7QUN2ekJBLFNBQVMsbUJBQW1CLE9BQU87Q0FDbEMsT0FBTyxPQUFPLHVCQUF1QixJQUFJLFVBQVUsaUJBQWlCLEdBQUcsRUFBRSxNQUFNLENBQUM7QUFDakY7QUFHQSxJQUFNLHVCQUF1QjtDQUM1QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7QUFDQSxJQUFNLGlCQUFpQixPQUFPLGdCQUFnQjs7OztBQUk5QyxlQUFlLG9CQUFvQixTQUFTLFVBQVU7Q0FDckQsSUFBSSxTQUFTLFdBQVcsT0FBTyxRQUFRLFFBQVEsTUFBTSxPQUFPLFFBQVEsT0FBTyxtQkFBbUIsQ0FBQztDQUMvRixNQUFNLGFBQWEsSUFBSSxJQUFJLFFBQVEsR0FBRztDQUN0QyxJQUFJO0NBQ0osSUFBSTtFQUNILGNBQWMsSUFBSSxJQUFJLFNBQVMsUUFBUSxJQUFJLFVBQVUsR0FBRyxRQUFRLEdBQUc7Q0FDcEUsU0FBUyxPQUFPO0VBQ2YsT0FBTyxRQUFRLE9BQU8sbUJBQW1CLEtBQUssQ0FBQztDQUNoRDtDQUNBLElBQUksRUFBRSxZQUFZLGFBQWEsV0FBVyxZQUFZLGFBQWEsV0FBVyxPQUFPLFFBQVEsT0FBTyxtQkFBbUIscUNBQXFDLENBQUM7Q0FDN0osSUFBSSxRQUFRLElBQUksU0FBUyxjQUFjLElBQUksSUFBSSxPQUFPLFFBQVEsT0FBTyxtQkFBbUIseUJBQXlCLENBQUM7Q0FDbEgsT0FBTyxlQUFlLFNBQVMsZ0JBQWdCLEVBQUUsUUFBUSxRQUFRLElBQUksU0FBUyxjQUFjLEtBQUssS0FBSyxFQUFFLENBQUM7Q0FDekcsSUFBSSxRQUFRLFNBQVMsV0FBVyxZQUFZLFlBQVksWUFBWSxhQUFhLENBQUMsV0FBVyxZQUFZLFdBQVcsR0FBRyxPQUFPLFFBQVEsT0FBTyxtQkFBbUIsb0RBQW9ELENBQUM7Q0FDck4sTUFBTSxjQUFjLENBQUM7Q0FDckIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsU0FBUyxTQUFTLE1BQU0sS0FBSyxRQUFRLFdBQVcsVUFBVSxTQUFTLFdBQVcsT0FBTyxDQUFDLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQyxTQUFTLFFBQVEsTUFBTSxHQUFHO0VBQzlJLFlBQVksU0FBUztFQUNyQixZQUFZLE9BQU87RUFDbkIscUJBQXFCLFNBQVMsZUFBZTtHQUM1QyxRQUFRLFFBQVEsT0FBTyxVQUFVO0VBQ2xDLENBQUM7Q0FDRjtDQUNBLElBQUksQ0FBQyxXQUFXLFlBQVksV0FBVyxHQUFHO0VBQ3pDLFFBQVEsUUFBUSxPQUFPLGVBQWU7RUFDdEMsUUFBUSxRQUFRLE9BQU8scUJBQXFCO0VBQzVDLFFBQVEsUUFBUSxPQUFPLFFBQVE7RUFDL0IsUUFBUSxRQUFRLE9BQU8sTUFBTTtDQUM5Qjs7Ozs7O0NBTUEsWUFBWSxVQUFVLFFBQVE7Q0FDOUIsTUFBTSxnQkFBZ0IsTUFBTSxNQUFNLElBQUksUUFBUSxhQUFhLFdBQVcsQ0FBQztDQUN2RSxPQUFPLGVBQWUsZUFBZSxjQUFjO0VBQ2xELE9BQU87RUFDUCxjQUFjO0NBQ2YsQ0FBQztDQUNELE9BQU87QUFDUjs7OztBQUlBLFNBQVMsV0FBVyxNQUFNLE9BQU87Q0FDaEMsSUFBSSxLQUFLLFdBQVcsTUFBTSxVQUFVLEtBQUssV0FBVyxRQUFRLE9BQU87Q0FDbkUsSUFBSSxLQUFLLGFBQWEsTUFBTSxZQUFZLEtBQUssYUFBYSxNQUFNLFlBQVksS0FBSyxTQUFTLE1BQU0sTUFBTSxPQUFPO0NBQzdHLE9BQU87QUFDUjtBQUdBLElBQUksNEJBQTRCLGNBQWMsZ0JBQWdCO0NBQzdELGNBQWM7RUFDYixRQUFRLEtBQUssMEZBQTBGO0VBQ3ZHLE1BQU0sRUFBRSxVQUFVLE9BQU8sWUFBWTtHQUNwQyxXQUFXLFFBQVEsS0FBSztFQUN6QixFQUFFLENBQUM7Q0FDSjtBQUNEO0FBR0EsSUFBSSxpQkFBaUIsY0FBYyxnQkFBZ0I7Q0FDbEQsWUFBWSxrQkFBa0IsR0FBRyxZQUFZO0VBQzVDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsVUFBVTtFQUN2QixNQUFNLFdBQVcsQ0FBQyxNQUFNLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsVUFBVSxjQUFjLFNBQVMsWUFBWSxTQUFTLENBQUM7RUFDdEgsT0FBTyxlQUFlLE1BQU0sWUFBWSxFQUFFLE1BQU07R0FDL0MsT0FBTztFQUNSLEVBQUUsQ0FBQztDQUNKO0FBQ0Q7QUFDQSxTQUFTLHFCQUFxQixpQkFBaUI7Q0FDOUMsT0FBTyxnQkFBZ0IsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFdBQVcsT0FBTyxLQUFLLENBQUM7QUFDOUU7QUFDQSxTQUFTLDBCQUEwQixpQkFBaUI7Q0FDbkQsT0FBTyxJQUFJLGVBQWUscUJBQXFCLGVBQWUsQ0FBQyxDQUFDLGFBQWEsY0FBYyxXQUFXO0VBQ3JHLElBQUksV0FBVyxVQUFVLFdBQVcsVUFBVSxPQUFPLGFBQWEsT0FBTyxJQUFJLG9CQUFvQixNQUFNLENBQUM7T0FDbkcsSUFBSSxXQUFXLFdBQVcsT0FBTyxhQUFhLE9BQU8sSUFBSSxvQkFBb0IsU0FBUyxDQUFDO09BQ3ZGLElBQUksV0FBVyxNQUFNLE9BQU8sYUFBYSxPQUFPLElBQUksMEJBQTBCLENBQUM7T0FDL0UsYUFBYSxTQUFTO0VBQzNCLE9BQU87Q0FDUixHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1A7Ozs7O0FBS0EsU0FBUyxxQkFBcUIsVUFBVTtDQUN2QyxJQUFJLFNBQVMsU0FBUyxNQUFNLE9BQU87Q0FDbkMsTUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksa0JBQWtCO0NBQy9ELE9BQU8sb0JBQW9CLFFBQVEsZ0JBQWdCLEtBQUssTUFBTTtBQUMvRDs7OztBQUlBLFNBQVMsbUJBQW1CLFVBQVU7Q0FDckMsVUFBVSxxQkFBcUIsUUFBUSxHQUFHLDhHQUE4RztDQUN4SixNQUFNLHNCQUFzQiwwQkFBMEIsU0FBUyxRQUFRLElBQUksa0JBQWtCLENBQUM7Q0FDOUYsU0FBUyxLQUFLLE9BQU8sb0JBQW9CLFFBQVE7Q0FDakQsT0FBTyxvQkFBb0I7QUFDNUI7O0FBSUEsU0FBUyxjQUFjLFVBQVU7Q0FDaEMsTUFBTSxRQUFRLGNBQWMsTUFBTSxRQUFRO0NBQzFDLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQyxNQUFNLE1BQU0sT0FBTyxDQUFDLFVBQVUsS0FBSztDQUMxRCxNQUFNLFdBQVcsYUFBYSxLQUFLO0NBQ25DLE9BQU8sQ0FBQyxhQUFhLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxVQUFVLFNBQVMsUUFBUTtBQUM1RTtBQUNBLFNBQVMsYUFBYSxVQUFVLFVBQVU7Q0FDekMsTUFBTSxPQUFPLFNBQVM7Q0FDdEIsTUFBTSxTQUFTLEtBQUssVUFBVTtDQUM5QixNQUFNLFVBQVUsV0FBVztFQUMxQixPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sTUFBTSxJQUFJLEtBQUssT0FBTyxNQUFNO0NBQ2hFO0NBQ0EsTUFBTSxTQUFTLElBQUksZUFBZTtFQUNqQyxNQUFNLEtBQUssWUFBWTtHQUN0QixJQUFJO0lBQ0gsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLE9BQU8sS0FBSztJQUMxQyxJQUFJLE1BQU07S0FDVCxXQUFXLE1BQU07S0FDakIsT0FBTyxZQUFZO0tBQ25CO0lBQ0Q7SUFDQSxXQUFXLFFBQVEsS0FBSztHQUN6QixTQUFTLE9BQU87SUFDZixXQUFXLE1BQU0sS0FBSztJQUN0QixPQUFPLFlBQVk7R0FDcEI7RUFDRDtFQUNBLE1BQU0sT0FBTyxRQUFRO0dBQ3BCLElBQUk7SUFDSCxNQUFNLGVBQWUsT0FBTyxNQUFNO0lBQ2xDLElBQUksVUFBVSxNQUFNLFFBQVEsSUFBSSxDQUFDLGNBQWMsU0FBUyxNQUFNLENBQUMsQ0FBQztTQUMzRCxhQUFhLFlBQVksQ0FBQyxDQUFDO0dBQ2pDLFVBQVU7SUFDVCxPQUFPLFlBQVk7R0FDcEI7RUFDRDtDQUNELEdBQUcsRUFBRSxlQUFlLEVBQUUsQ0FBQztDQUN2QixNQUFNLGtCQUFrQixJQUFJLGNBQWMsUUFBUSxRQUFRO0NBQzFELGVBQWUsU0FBUyxTQUFTLGdCQUFnQixPQUFPO0NBQ3hELE9BQU8saUJBQWlCLGlCQUFpQjtFQUN4QyxNQUFNLEVBQUUsT0FBTyxTQUFTLEtBQUs7RUFDN0IsWUFBWSxFQUFFLE9BQU8sU0FBUyxXQUFXO0NBQzFDLENBQUM7Q0FDRCxPQUFPO0VBQ04sVUFBVTtFQUNWO0NBQ0Q7QUFDRDtBQUdBLElBQU0sU0FBUyxhQUFhLE9BQU87Ozs7QUFJbkMsSUFBSSxtQkFBbUIsY0FBYyxZQUFZO0NBQ2hEO0VBQ0MsS0FBSyxTQUFTLE9BQU8sSUFBSSxtQkFBbUI7Q0FDN0M7Q0FDQSxZQUFZO0VBQ1gsT0FBTyxzQkFBc0IsT0FBTztDQUNyQztDQUNBLE1BQU0sUUFBUTtFQUNiLE9BQU8sUUFBUSwwQkFBMEI7RUFDekMsS0FBSyxjQUFjLEtBQUssZ0JBQWdCLFdBQVcsWUFBWSxVQUFVLGNBQWM7R0FDdEYsT0FBTyxPQUFPLE9BQU8sU0FBUztJQUM3QixNQUFNLFlBQVksZ0JBQWdCOzs7Ozs7O0lBT2xDLE1BQU0sZ0JBQWdCLE9BQU8sVUFBVSxZQUFZLE9BQU8sYUFBYSxlQUFlLENBQUMsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLElBQUksT0FBTyxTQUFTLElBQUksSUFBSTtJQUM3SSxNQUFNLFVBQVUsSUFBSSxRQUFRLGVBQWUsSUFBSTtJQUMvQyxNQUFNLGtCQUFrQixRQUFRLGNBQWM7SUFDOUMsTUFBTSxhQUFhLElBQUksa0JBQWtCLFNBQVM7S0FDakQsYUFBYSxZQUFZO01BQ3hCLE9BQU8sUUFBUSwwQkFBMEI7Ozs7Ozs7Ozs7OztNQVl6QyxNQUFNLGVBQWUsUUFBUSxNQUFNO01BQ25DLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixNQUFNLFlBQVksVUFBVSxZQUFZLENBQUM7TUFDbkYsSUFBSSxlQUFlLE9BQU8sZ0JBQWdCLE9BQU8sYUFBYTtNQUM5RCxPQUFPLFFBQVEsK0JBQStCLGdCQUFnQjtNQUM5RCxJQUFJLEtBQUssUUFBUSxjQUFjLFVBQVUsSUFBSSxHQUFHO09BQy9DLE9BQU8sUUFBUSxpQ0FBaUM7T0FDaEQsTUFBTSxDQUFDLFVBQVUsaUJBQWlCLGNBQWMsZ0JBQWdCO09BQ2hFLE1BQU0sS0FBSyxRQUFRLGNBQWMsSUFBSSxrQkFBa0I7UUFDdEQsV0FBVztRQUNYO1FBQ0E7UUFDQSxVQUFVO1FBQ1YsY0FBYztPQUNmLENBQUMsQ0FBQztPQUNGLGdCQUFnQixRQUFRLFFBQVE7T0FDaEM7TUFDRDtNQUNBLGdCQUFnQixRQUFRLGdCQUFnQjtLQUN6QztLQUNBLGFBQWEsT0FBTyxnQkFBZ0I7TUFDbkMsSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO09BQ2pDLE9BQU8sUUFBUSxzQkFBc0IsRUFBRSxVQUFVLFlBQVksQ0FBQztPQUM5RCxnQkFBZ0IsT0FBTyxtQkFBbUIsV0FBVyxDQUFDO09BQ3REO01BQ0Q7Ozs7Ozs7Ozs7Ozs7TUFhQSxJQUFJO01BQ0osSUFBSSxxQkFBcUIsV0FBVyxHQUFHO09BQ3RDLFdBQVcsSUFBSSxjQUFjLG1CQUFtQixXQUFXLEdBQUc7UUFDN0QsUUFBUSxZQUFZO1FBQ3BCLFlBQVksWUFBWTtRQUN4QixTQUFTLFlBQVk7T0FDdEIsQ0FBQztPQUNELGVBQWUsWUFBWSxTQUFTLFNBQVMsT0FBTztNQUNyRCxPQUFPLFdBQVc7TUFDbEIsY0FBYyxPQUFPLFFBQVEsS0FBSyxRQUFROzs7Ozs7O01BTzFDLElBQUksY0FBYyxtQkFBbUIsU0FBUyxNQUFNLEdBQUc7T0FDdEQsSUFBSSxRQUFRLGFBQWEsU0FBUztRQUNqQyxnQkFBZ0IsT0FBTyxtQkFBbUIscUJBQXFCLENBQUM7UUFDaEU7T0FDRDtPQUNBLElBQUksUUFBUSxhQUFhLFVBQVU7UUFDbEMsb0JBQW9CLFNBQVMsUUFBUSxDQUFDLENBQUMsTUFBTSxhQUFhO1NBQ3pELGdCQUFnQixRQUFRLFFBQVE7UUFDakMsSUFBSSxXQUFXO1NBQ2QsZ0JBQWdCLE9BQU8sTUFBTTtRQUM5QixDQUFDO1FBQ0Q7T0FDRDtNQUNEO01BQ0EsSUFBSSxLQUFLLFFBQVEsY0FBYyxVQUFVLElBQUksR0FBRztPQUMvQyxPQUFPLFFBQVEsaUNBQWlDO09BQ2hELE1BQU0sQ0FBQyxnQkFBZ0IsaUJBQWlCLGNBQWMsUUFBUTtPQUM5RCxNQUFNLEtBQUssUUFBUSxjQUFjLElBQUksa0JBQWtCO1FBQ3RELFdBQVc7UUFDWCxVQUFVO1FBQ1YsY0FBYztRQUNkO1FBQ0E7T0FDRCxDQUFDLENBQUM7T0FDRixnQkFBZ0IsUUFBUSxjQUFjO09BQ3RDO01BQ0Q7TUFDQSxnQkFBZ0IsUUFBUSxRQUFRO0tBQ2pDO0tBQ0EsWUFBWSxXQUFXO01BQ3RCLE9BQU8sUUFBUSxzQkFBc0IsRUFBRSxPQUFPLENBQUM7TUFDL0MsZ0JBQWdCLE9BQU8sTUFBTTtLQUM5QjtJQUNELEdBQUc7S0FDRjtLQUNBO0lBQ0QsQ0FBQztJQUNELE9BQU8sUUFBUSw2QkFBNkI7SUFDNUMsT0FBTyxRQUFRLHdEQUF3RCxLQUFLLFFBQVEsY0FBYyxTQUFTLENBQUM7Ozs7Ozs7OztJQVM1RyxNQUFNLFFBQVEsUUFBUTtJQUN0QixNQUFNLGNBQWM7S0FDbkIsV0FBVztLQUNYO0tBQ0E7S0FDQSxTQUFTLEtBQUs7S0FDZDtLQUNBO0lBQ0QsQ0FBQztJQUNELE9BQU8sZ0JBQWdCO0dBQ3hCO0VBQ0QsQ0FBQyxDQUFDO0VBQ0YsT0FBTyxRQUFRLDRCQUE0QixXQUFXLE1BQU0sSUFBSTtDQUNqRTtBQUNEOzs7Ozs7O0FDdFRBLFNBQVMsd0JBQXdCO0NBQ2hDLE9BQU8sT0FBTyxjQUFjLGVBQWUsbUJBQW1CLGFBQWEsT0FBTyxhQUFhLGVBQWUsU0FBUyxhQUFhO0FBQ3JJOzs7Ozs7QUFNQSxTQUFTLGlDQUFpQztDQUN6QyxJQUFJO0VBQ0gsTUFBTSxTQUFTLElBQUksZUFBZSxFQUFFLFFBQVEsZUFBZSxXQUFXLE1BQU0sRUFBRSxDQUFDO0VBQy9FLElBQUksZUFBZSxDQUFDLENBQUMsTUFBTSxZQUFZLFFBQVEsQ0FBQyxNQUFNLENBQUM7RUFDdkQsT0FBTztDQUNSLFFBQVE7RUFDUCxPQUFPO0NBQ1I7QUFDRDtBQUdBLFNBQVMsZUFBZSxVQUFVO0NBQ2pDLE9BQU87RUFDTixRQUFRLFNBQVM7RUFDakIsWUFBWSxTQUFTO0VBQ3JCLFNBQVMsT0FBTyxZQUFZLFNBQVMsUUFBUSxRQUFRLENBQUM7Q0FDdkQ7QUFDRDs7Ozs7QUFPQSxTQUFTLHFCQUFxQixXQUFXO0NBQ3hDLE9BQU8sSUFBSSxJQUFJLFdBQVcsU0FBUyxJQUFJLENBQUMsQ0FBQztBQUMxQzs7Ozs7QUFPQSxTQUFTLHdCQUF3QixjQUFjLG1CQUFtQixZQUFZO0NBQzdFLE9BQU87RUFDTixhQUFhO0VBQ2IsYUFBYTtFQUNiLGFBQWE7Q0FDZCxDQUFDLENBQUMsUUFBUSxVQUFVO0VBQ25CLE9BQU8sU0FBUztDQUNqQixDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7RUFDbkIsT0FBTyxXQUFXLE9BQU8sV0FBVyxpQkFBaUI7Q0FDdEQsQ0FBQyxLQUFLO0FBQ1A7Ozs7O0FBT0EsSUFBTSxvQkFBb0IsT0FBTyxLQUFLLFVBQVUsQ0FBQyxHQUFHLGVBQWU7Q0FDbEUsTUFBTSxvQkFBb0IscUJBQXFCLEdBQUc7Q0FDbEQsTUFBTSxvQkFBb0IsTUFBTSxVQUFVLGNBQWMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLGtCQUFrQixjQUFjLFFBQVEsaUJBQWlCLHdCQUF3QixjQUFjLG1CQUFtQixVQUFVLENBQUMsQ0FBQztDQUMvTSxJQUFJLENBQUMsVUFBVSxjQUFjLGNBQWMsa0JBQWtCLFNBQVMsR0FBRyxTQUFTLE9BQU87Q0FDekYsTUFBTSxDQUFDLHdCQUF3QjtDQUMvQixJQUFJLHNCQUFzQjtFQUN6QixxQkFBcUIsT0FBTztFQUM1QixPQUFPLENBQUMsd0JBQXdCLHNCQUFzQixtQkFBbUIsVUFBVSxHQUFHLG9CQUFvQjtDQUMzRztDQUNBLE1BQU0sQ0FBQyxtQkFBbUIsc0JBQXNCLE1BQU1DLFFBQU0sWUFBWTtFQUN2RSxNQUFNLGVBQWUsTUFBTSxVQUFVLGNBQWMsU0FBUyxLQUFLLE9BQU87RUFDeEUsT0FBTyxDQUFDLHdCQUF3QixjQUFjLG1CQUFtQixVQUFVLEdBQUcsWUFBWTtDQUMzRixDQUFDO0NBQ0QsSUFBSSxtQkFBbUI7RUFDdEIsSUFBSSxrQkFBa0IsUUFBUSxTQUFTLE9BQU8sR0FBRztHQUNoRCxNQUFNLFdBQVcsSUFBSSxJQUFJLFNBQVMsU0FBUyxLQUFLLFNBQVMsSUFBSTtHQUM3RCxNQUFNLElBQUksTUFBTSxTQUFTLGNBQWM7a0RBQ1EsU0FBUyxLQUFLLG1CQUFtQixrQkFBa0I7Ozs7b0ZBSWpCLENBQUM7RUFDbkY7RUFDQSxNQUFNLElBQUksTUFBTSxTQUFTLGNBQWMsZ0RBQWdELGtCQUFrQixPQUFPLENBQUM7Q0FDbEg7Q0FDQSxPQUFPO0FBQ1I7QUFHQSxJQUFNLDBCQUEwQixzQkFBc0I7QUFDdEQsSUFBSSxjQUFjLGNBQWMsV0FBVztDQUMxQztDQUNBLFlBQVksYUFBYTtFQUN4QixNQUFNLE9BQU8sWUFBWSxLQUFLO0VBQzlCLE1BQU0sT0FBTyxZQUFZLEtBQUs7Ozs7OztFQU05QixNQUFNLE1BQU0sRUFBRSxLQUFLLENBQUM7RUFDcEIsS0FBSyxlQUFlO0NBQ3JCO0NBQ0EsSUFBSSxRQUFRO0VBQ1gsT0FBTyxLQUFLLGFBQWE7Q0FDMUI7Ozs7Q0FJQSxZQUFZLE1BQU0sR0FBRyxNQUFNO0VBQzFCLEtBQUssYUFBYSxNQUFNLEVBQUUsQ0FBQyxZQUFZO0dBQ3RDO0dBQ0EsTUFBTSxLQUFLO0VBQ1osR0FBRyxFQUFFLFVBQVUsS0FBSyxHQUFHLENBQUM7Q0FDekI7QUFDRDtBQUNBLElBQUksZ0JBQWdCLGNBQWMsUUFBUTtDQUN6QztDQUNBO0NBQ0EsWUFBWSxTQUFTO0VBQ3BCLE1BQU07RUFDTixVQUFVLHlCQUF5QixzRkFBc0Y7RUFDekgsS0FBSyxhQUFhLFFBQVE7RUFDMUIsS0FBSyxjQUFjLElBQUksZ0JBQWdCO0VBQ3ZDLFVBQVUsY0FBYyxpQkFBaUIsV0FBVyxPQUFPLFVBQVU7R0FDcEUsTUFBTSxTQUFTLE1BQU0sS0FBSyxXQUFXO0dBQ3JDLElBQUksTUFBTSxVQUFVLFFBQVEsTUFBTSxXQUFXLFFBQVE7R0FDckQsSUFBSSxNQUFNLFFBQVFDLFdBQVMsTUFBTSxJQUFJLEtBQUssVUFBVSxNQUFNLE1BQU0sS0FBSyxLQUFLLElBQUksWUFBWSxLQUFLLENBQUM7RUFDakcsR0FBRyxFQUFFLFFBQVEsS0FBSyxZQUFZLE9BQU8sQ0FBQztDQUN2Qzs7Ozs7Q0FLQSxZQUFZLE1BQU07RUFDakIsVUFBVSx5QkFBeUIseU1BQXlNO0VBQzVPLEtBQUssV0FBVyxDQUFDLENBQUMsTUFBTSxXQUFXO0dBQ2xDLE9BQU8sWUFBWSxJQUFJO0VBQ3hCLENBQUM7Q0FDRjs7Ozs7Q0FLQSxZQUFZO0VBQ1gsS0FBSyxZQUFZLE1BQU07RUFDdkIsS0FBSyxtQkFBbUI7Q0FDekI7QUFDRDs7Ozs7QUFPQSxTQUFTLG1CQUFtQixtQkFBbUI7Q0FDOUMsT0FBTyxJQUFJLGFBQWEsa0JBQWtCLEtBQUssRUFBRSxHQUFHLGtCQUFrQixDQUFDO0FBQ3hFOzs7Ozs7QUFRQSxTQUFTLG9CQUFvQixjQUFjO0NBQzFDLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxhQUFhLEtBQUssR0FBRyxTQUFTLEtBQUssdUZBQXVGLGFBQWEsTUFBTTs7O2tGQUcxRjtBQUNsRjtBQUdBLFNBQVMsdUJBQXVCLGFBQWEsYUFBYTtDQUN6RCxPQUFPLFlBQVksZUFBZSxZQUFZLGNBQWMsWUFBWSxjQUFjLFFBQVEsWUFBWSxjQUFjLE9BQU8sS0FBSyxVQUFVLFlBQVksY0FBYyxPQUFPLE1BQU0sS0FBSyxVQUFVLFlBQVksY0FBYyxPQUFPO0FBQ3RPO0FBR0EsSUFBSSxzQkFBc0IsTUFBTSw0QkFBNEIsY0FBYztDQUN6RSxPQUFPOzs7OztDQUtQLGFBQWEsS0FBSyxTQUFTO0VBQzFCLElBQUksb0JBQW9CLFlBQVksTUFBTSxvQkFBb0IsV0FBVyxJQUFJLG9CQUFvQixPQUFPO09BQ25HLElBQUksdUJBQXVCLG9CQUFvQixTQUFTLFVBQVUsT0FBTyxHQUFHO0dBQ2hGLE1BQU0sb0JBQW9CLFNBQVMsVUFBVTtHQUM3QyxvQkFBb0IsV0FBVyxJQUFJLG9CQUFvQixPQUFPO0VBQy9EO0VBQ0EsT0FBTyxvQkFBb0I7Q0FDNUI7Q0FDQTs7Ozs7Q0FLQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxTQUFTO0VBQ3BCLE1BQU07RUFDTixVQUFVLHNCQUFzQixHQUFHLGlIQUFpSDtFQUNwSixLQUFLLFdBQVc7RUFDaEIsS0FBSywwQkFBMEIsSUFBSSxJQUFJO0VBQ3ZDLEtBQUssbUJBQW1CLFFBQVEsY0FBYztFQUM5QyxLQUFLLGdCQUFnQixLQUFLLGlCQUFpQjtFQUMzQyxLQUFLLGVBQWU7RUFDcEIsS0FBSyxXQUFXLElBQUksY0FBYyxFQUFFLGlCQUFpQixLQUFLLGNBQWMsTUFBTSxDQUFDLFlBQVksTUFBTSxFQUFFLENBQUM7Q0FDckc7Q0FDQSxNQUFNLFNBQVM7RUFDZCxLQUFLLFNBQVMsbUJBQW1CO0VBQ2pDLEtBQUssUUFBUSxNQUFNO0VBQ25CLEtBQUssc0JBQXNCLElBQUksZ0JBQWdCO0VBQy9DLE1BQU0sQ0FBQyxRQUFRLGdCQUFnQixNQUFNLEtBQUssYUFBYTtFQUN2RCxJQUFJLE9BQU8sVUFBVSxhQUFhO0dBQ2pDLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtHQUN2QyxNQUFNLG9CQUFvQixRQUFRLGNBQWM7R0FDaEQsa0JBQWtCLFFBQVEsV0FBVyxXQUFXLE1BQU0sQ0FBQztHQUN2RCxPQUFPLGlCQUFpQixxQkFBcUI7SUFDNUMsSUFBSSxPQUFPLFVBQVUsYUFBYSxrQkFBa0IsUUFBUTtHQUM3RCxHQUFHLEVBQUUsUUFBUSxXQUFXLE9BQU8sQ0FBQztHQUNoQyxNQUFNLGtCQUFrQjtFQUN6QjtFQUNBLEtBQUssU0FBUyxZQUFZLGVBQWU7RUFDekMsTUFBTSw0QkFBNEIsUUFBUSxjQUFjO0VBQ3hELEtBQUssaUJBQWlCLDBCQUEwQjtFQUNoRCxLQUFLLFNBQVMsS0FBSyxvQkFBb0IsVUFBVTtHQUNoRCwwQkFBMEIsUUFBUSxNQUFNLEtBQUssTUFBTTtFQUNwRCxDQUFDO0VBQ0QsTUFBTSwwQkFBMEI7RUFDaEMsSUFBSSxDQUFDLEtBQUssU0FBUyxPQUFPLEtBQUssbUJBQW1CO0VBQ2xELE9BQU87Q0FDUjtDQUNBLE1BQU0sVUFBVTs7Ozs7OztFQU9mLEtBQUsscUJBQXFCLE1BQU07RUFDaEMsS0FBSyxzQkFBc0IsS0FBSztFQUNoQyxNQUFNLGdCQUFnQixRQUFRLGNBQWM7RUFDNUMsS0FBSyxTQUFTLEtBQUssdUJBQXVCLGNBQWMsUUFBUSxDQUFDO0VBQ2pFLEtBQUssU0FBUyxZQUFZLGNBQWM7RUFDeEMsTUFBTSxjQUFjOzs7Ozs7O0VBT3BCLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTyxLQUFLLGtCQUFrQjtDQUNsRDs7Ozs7O0NBTUEsTUFBTSxZQUFZO0VBQ2pCLElBQUksS0FBSyxzQkFBc0IsTUFBTTtHQUNwQyxjQUFjLEtBQUssa0JBQWtCO0dBQ3JDLEtBQUsscUJBQXFCLEtBQUs7RUFDaEM7RUFDQSxLQUFLLFFBQVEsTUFBTTtFQUNuQixLQUFLLFNBQVMsVUFBVTtFQUN4QixLQUFLLHFCQUFxQixNQUFNO0VBQ2hDLEtBQUssc0JBQXNCLEtBQUs7RUFDaEMsSUFBSSxLQUFLLGlCQUFpQixhQUFhO0dBQ3RDLE1BQU0sR0FBRyxnQkFBZ0IsTUFBTSxLQUFLO0dBQ3BDLE1BQU0sYUFBYSxXQUFXO0VBQy9CO0VBQ0EsSUFBSSxvQkFBb0IsYUFBYSxNQUFNLG9CQUFvQixXQUFXLEtBQUs7Q0FDaEY7Q0FDQSxNQUFNLGVBQWU7RUFDcEIsSUFBSSxLQUFLLG9CQUFvQixjQUFjLEtBQUssa0JBQWtCO0VBQ2xFLE1BQU0sWUFBWSxLQUFLLFNBQVMsY0FBYztFQUM5QyxNQUFNLENBQUMsUUFBUSxnQkFBZ0IsTUFBTSxrQkFBa0IsV0FBVyxLQUFLLFNBQVMsY0FBYyxTQUFTLEtBQUssU0FBUyxjQUFjLEtBQUssa0JBQWtCO0VBQzFKLElBQUksVUFBVSxNQUFNO0dBQ25CLE1BQU0sdUJBQXVCLEtBQUssVUFBVSxhQUFhLFNBQVMsY0FBYzs7OztRQUkzRSxTQUFTLElBQUksU0FBUyxjQUFjOzs7OzJQQUkrTSxXQUFXLFNBQVMsSUFBSTtHQUNoUixNQUFNLElBQUksTUFBTSxvQkFBb0I7RUFDckM7RUFDQSxJQUFJLEtBQUssaUJBQWlCLFdBQVc7R0FDcEMsS0FBSyxpQkFBaUIsUUFBUSxDQUFDLFFBQVEsWUFBWSxDQUFDO0dBQ3BELEtBQUssZUFBZTtFQUNyQixPQUFPOzs7Ozs7R0FNTixLQUFLLG1CQUFtQixRQUFRLGNBQWM7R0FDOUMsS0FBSyxpQkFBaUIsUUFBUSxDQUFDLFFBQVEsWUFBWSxDQUFDO0dBQ3BELEtBQUssZ0JBQWdCLEtBQUssaUJBQWlCO0VBQzVDO0VBQ0EsS0FBSyxTQUFTLEdBQUcsV0FBVyxLQUFLLGVBQWUsS0FBSyxJQUFJLENBQUM7RUFDMUQsS0FBSyxTQUFTLEdBQUcsWUFBWSxLQUFLLGdCQUFnQixLQUFLLElBQUksQ0FBQztFQUM1RCxLQUFLLFNBQVMsR0FBRyxpQkFBaUIsS0FBSyxvQkFBb0IsS0FBSyxJQUFJLENBQUM7RUFDckUsT0FBTyxpQkFBaUIsYUFBYSxVQUFVO0dBQzlDLElBQUksTUFBTSxXQUFXO0dBQ3JCLElBQUksT0FBTyxVQUFVLGFBQWEsS0FBSyxTQUFTLFlBQVksY0FBYztHQUMxRSxjQUFjLEtBQUssa0JBQWtCO0dBQ3JDLE9BQU8sWUFBWSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7RUFDL0MsR0FBRyxFQUFFLFFBQVEsS0FBSyxxQkFBcUIsT0FBTyxDQUFDO0VBQy9DLE1BQU0sS0FBSyxzQkFBc0IsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUNuRCxTQUFTLE1BQU0sNEpBQTRKO0dBQzNLLFFBQVEsTUFBTSxLQUFLO0VBQ3BCLENBQUM7RUFDRCxLQUFLLHFCQUFxQixPQUFPLGtCQUFrQjtHQUNsRCxLQUFLLFNBQVMsWUFBWSxtQkFBbUI7RUFDOUMsR0FBRyxHQUFHO0VBQ04sSUFBSSxDQUFDLEtBQUssU0FBUyxPQUFPLG9CQUFvQixZQUFZO0VBQzFELE9BQU8sQ0FBQyxRQUFRLFlBQVk7Q0FDN0I7Q0FDQSxNQUFNLGVBQWUsT0FBTztFQUMzQixNQUFNLFVBQVUsbUJBQW1CLE1BQU0sSUFBSTtFQUM3QyxlQUFlLE1BQU0sSUFBSSxTQUFTLFFBQVEsTUFBTSxDQUFDO0VBQ2pELE1BQU0sUUFBUSxJQUFJLDhCQUE4QjtHQUMvQztHQUNBO0VBQ0QsQ0FBQztFQUNELEtBQUssUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUs7RUFDckMsTUFBTSxLQUFLLE1BQU0sS0FBSztDQUN2QjtDQUNBLE1BQU0sZ0JBQWdCLE9BQU87RUFDNUIsTUFBTSxFQUFFLFNBQVMsVUFBVSxxQkFBcUIsTUFBTTtFQUN0RCxNQUFNLFFBQVEsS0FBSyxRQUFRLElBQUksUUFBUSxFQUFFOzs7Ozs7OztFQVF6QyxJQUFJLFNBQVMsTUFBTSxTQUFTLFFBQVEsR0FBRztHQUN0QyxLQUFLLFFBQVEsT0FBTyxRQUFRLEVBQUU7R0FDOUIsT0FBTyxPQUFPLG1CQUFtQjtHQUNqQztFQUNEO0VBQ0EsS0FBSyxRQUFRLE9BQU8sUUFBUSxFQUFFOzs7OztFQUs5QixJQUFJLFNBQVMsTUFBTTtFQUNuQixNQUFNLGVBQWUsbUJBQW1CLE9BQU87RUFDL0MsTUFBTSxnQkFBZ0IsU0FBUyxXQUFXLElBQUksU0FBUyxNQUFNLElBQUksSUFBSTs7Ozs7OztHQU9wRSxjQUFjLG1CQUFtQixTQUFTLE1BQU0sSUFBSSxTQUFTLE9BQU87R0FDcEU7SUFDQyxHQUFHOzs7Ozs7SUFNSCxLQUFLLFFBQVE7R0FDZDtFQUNEO0VBQ0EsSUFBSTtHQUNILE1BQU0sT0FBTyxLQUFLLElBQUksY0FBYyxtQkFBbUIsb0JBQW9CLG1CQUFtQjtJQUM3RixXQUFXLE1BQU0sS0FBSztJQUN0QixTQUFTO0lBQ1QsVUFBVTtJQUNWO0dBQ0QsQ0FBQyxDQUFDO0VBQ0gsVUFBVTtHQUNULE1BQU0sT0FBTyxtQkFBbUI7RUFDakM7Q0FDRDs7Ozs7Ozs7O0NBU0Esb0JBQW9CLE9BQU87RUFDMUIsTUFBTSxFQUFFLFlBQVksTUFBTTtFQUMxQixNQUFNLFFBQVEsS0FBSyxRQUFRLElBQUksUUFBUSxFQUFFO0VBQ3pDLEtBQUssUUFBUSxPQUFPLFFBQVEsRUFBRTtFQUM5QixPQUFPLE9BQU8sbUJBQW1CO0NBQ2xDO0NBQ0Esc0JBQXNCLFdBQVcseUJBQXlCO0VBQ3pELE9BQU8sY0FBYztDQUN0QjtDQUNBLE1BQU0sd0JBQXdCO0VBQzdCLE1BQU0sd0JBQXdCLFFBQVEsY0FBYztFQUNwRCxLQUFLLFNBQVMsWUFBWSx5QkFBeUI7RUFDbkQsS0FBSyxTQUFTLEtBQUssNkJBQTZCLFVBQVU7R0FDekQsTUFBTSxFQUFFLFVBQVUsbUJBQW1CLE1BQU07R0FDM0MsSUFBSSxhQUFhLG9DQUFvQyxTQUFTLEtBQUssNkZBQTZGLGVBQWU7Ozs7Ozs4SkFNcEI7R0FDM0osc0JBQXNCLFFBQVE7RUFDL0IsQ0FBQztFQUNELE9BQU8sc0JBQXNCO0NBQzlCO0NBQ0EsTUFBTSxxQkFBcUI7RUFDMUIsSUFBSSxLQUFLLGlCQUFpQixZQUFZO0VBQ3RDLFVBQVUsS0FBSyxrQkFBa0IsTUFBTSx5RkFBeUY7RUFDaEksTUFBTSxTQUFTLE1BQU0sS0FBSztFQUMxQixNQUFNLENBQUMsUUFBUSxnQkFBZ0IsTUFBTSxLQUFLO0VBQzFDLFFBQVEsZUFBZSxLQUFLLFNBQVMsY0FBYyxrQkFBa0IsS0FBSyxtQ0FBbUM7RUFDN0csUUFBUSxJQUFJLDRDQUE0QyxvQkFBb0Isb0JBQW9CO0VBQ2hHLFFBQVEsSUFBSSxxREFBcUQ7RUFDakUsUUFBUSxJQUFJLHNCQUFzQixPQUFPLFNBQVM7RUFDbEQsUUFBUSxJQUFJLGlCQUFpQixhQUFhLEtBQUs7RUFDL0MsSUFBSSxRQUFRLFFBQVEsSUFBSSxzQkFBc0IsT0FBTyxJQUFJLE9BQU8sU0FBUztFQUN6RSxRQUFRLFNBQVM7Q0FDbEI7Q0FDQSxvQkFBb0I7RUFDbkIsUUFBUSxJQUFJLEtBQUssU0FBUyxjQUFjLG1CQUFtQixLQUFLLG1DQUFtQztDQUNwRztBQUNEO0FBQ0EsSUFBSSxnQ0FBZ0MsY0FBYyxpQkFBaUI7Q0FDbEU7Q0FDQSxZQUFZLFNBQVM7RUFDcEIsTUFBTSxFQUFFLFNBQVMsUUFBUSxRQUFRLENBQUM7RUFDbEMsS0FBSyxTQUFTLFFBQVE7Q0FDdkI7Q0FDQSxjQUFjO0VBQ2IsS0FBSyxPQUFPLFlBQVksZUFBZSxFQUFFLFNBQVMsRUFBRSxTQUFTLE1BQU0sS0FBSyxLQUFLLEtBQUssUUFBUSxPQUFPLEVBQUUsRUFBRSxDQUFDO0NBQ3ZHO0NBQ0EsWUFBWSxVQUFVO0VBQ3JCLElBQUksVUFBVSxLQUFLLGFBQWEsUUFBUTtDQUN6QztDQUNBLFVBQVUsUUFBUTtFQUNqQixJQUFJLGtCQUFrQixVQUFVLE9BQU8sS0FBSyxZQUFZLE1BQU07RUFDOUQsU0FBUyxLQUFLLHFWQUFxVixLQUFLLEtBQUssUUFBUSxRQUFRLEtBQUssS0FBSyxRQUFRLEdBQUc7RUFDbFosTUFBTSxRQUFRLGtCQUFrQixRQUFRLFNBQVMsSUFBSSxNQUFNLFFBQVEsU0FBUyxLQUFLLGlCQUFpQjtFQUNsRyxLQUFLLFlBQVksYUFBYSxLQUFLO0dBQ2xDLE1BQU0sTUFBTTtHQUNaLFNBQVMsTUFBTTtHQUNmLE9BQU8sTUFBTTtFQUNkLEdBQUc7R0FDRixRQUFRO0dBQ1IsWUFBWTtFQUNiLENBQUMsQ0FBQztDQUNIO0NBQ0EsTUFBTSxhQUFhLFVBQVU7RUFDNUIsSUFBSTtFQUNKLElBQUk7RUFDSixNQUFNLGVBQWUsZUFBZSxRQUFRO0VBQzVDLElBQUksK0JBQStCLEdBQUc7R0FDckMsZUFBZSxTQUFTO0dBQ3hCLFdBQVcsU0FBUyxRQUFRLE9BQU8sS0FBSyxJQUFJLENBQUMsU0FBUyxJQUFJO0VBQzNELE9BQU8sZUFBZSxTQUFTLFFBQVEsT0FBTyxPQUFPLE1BQU0sU0FBUyxNQUFNLENBQUMsQ0FBQyxZQUFZO0VBQ3hGLEtBQUssT0FBTyxZQUFZLGlCQUFpQjtHQUN4QyxHQUFHO0dBQ0gsTUFBTTtFQUNQLEdBQUcsUUFBUTtDQUNaO0FBQ0Q7QUFHQSxJQUFJLHFCQUFxQixjQUFjLGtCQUFrQjtDQUN4RDtDQUNBLFlBQVksU0FBUztFQUNwQixNQUFNLEVBQUUsY0FBYyxDQUFDLElBQUksMEJBQTBCLEdBQUcsSUFBSSxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7RUFDakYsS0FBSyxVQUFVO0NBQ2hCO0NBQ0EsU0FBUztFQUNSLE1BQU0sT0FBTztFQUNiLElBQUksQ0FBQyxLQUFLLFFBQVEsT0FBTyxLQUFLLG1CQUFtQjtDQUNsRDtDQUNBLFVBQVU7RUFDVCxNQUFNLFFBQVE7RUFDZCxJQUFJLENBQUMsS0FBSyxRQUFRLE9BQU8sS0FBSyxrQkFBa0I7Q0FDakQ7Q0FDQSxxQkFBcUI7RUFDcEIsUUFBUSxlQUFlLEtBQUssU0FBUyxjQUFjLGtDQUFrQyxLQUFLLG1DQUFtQztFQUM3SCxRQUFRLElBQUksNENBQTRDLG9CQUFvQixvQkFBb0I7RUFDaEcsUUFBUSxJQUFJLHFEQUFxRDtFQUNqRSxRQUFRLFNBQVM7Q0FDbEI7Q0FDQSxvQkFBb0I7RUFDbkIsUUFBUSxJQUFJLEtBQUssU0FBUyxjQUFjLG1CQUFtQixLQUFLLG1DQUFtQztDQUNwRztBQUNEO0FBR0EsSUFBTSxxQkFBcUI7Ozs7Ozs7QUFPM0IsU0FBUyxZQUFZLEdBQUcsVUFBVTtDQUNqQyxVQUFVLENBQUMsY0FBYyxHQUFHLFNBQVMsY0FBYyw4REFBOEQsQ0FBQztDQUNsSCxNQUFNLFVBQVUsY0FBYztFQUM3QixTQUFTLENBQUM7RUFDVjtDQUNELENBQUM7Q0FDRCxPQUFPO0VBQ04sSUFBSSxhQUFhO0dBQ2hCLE9BQU8sUUFBUTtFQUNoQjtFQUNBLE1BQU0sTUFBTSxTQUFTO0dBQ3BCLFVBQVUsUUFBUSxlQUFlLEdBQUcsU0FBUyxjQUFjLGlIQUFpSCxDQUFDO0dBQzdLLE1BQU0sYUFBYSxzQkFBc0IsSUFBSSxNQUFNLG9CQUFvQixLQUFLO0lBQzNFLGVBQWU7S0FDZCxLQUFLLFNBQVMsZUFBZSxLQUFLLFNBQVMsS0FBSztLQUNoRCxTQUFTLFNBQVMsZUFBZTtJQUNsQztJQUNBLFlBQVksU0FBUztJQUNyQixPQUFPLFNBQVM7R0FDakIsQ0FBQyxJQUFJLElBQUksbUJBQW1CLEVBQUUsT0FBTyxTQUFTLE1BQU0sQ0FBQztHQUNyRCxRQUFRLFVBQVU7SUFDakIsU0FBUyxDQUFDLFlBQVksSUFBSSxrQkFBa0IsRUFBRSxjQUFjLENBQUMsSUFBSSxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMzRixrQkFBa0IsU0FBUyxvQkFBb0I7SUFDL0MsU0FBUyxFQUFFLE9BQU8sU0FBUyxNQUFNO0dBQ2xDLENBQUM7R0FDRCxNQUFNLFFBQVEsT0FBTztHQUNyQixJQUFJLHNCQUFzQixxQkFBcUI7SUFDOUMsTUFBTSxHQUFHLGdCQUFnQixNQUFNLFdBQVc7SUFDMUMsT0FBTztHQUNSO0VBQ0Q7RUFDQSxNQUFNLE9BQU87R0FDWixNQUFNLFFBQVEsUUFBUTtHQUN0QixPQUFPLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0VBQy9DO0VBQ0EsUUFBUSxRQUFRO0VBQ2hCLEtBQUssUUFBUSxJQUFJLEtBQUssT0FBTztFQUM3QixlQUFlLFFBQVEsY0FBYyxLQUFLLE9BQU87RUFDakQsaUJBQWlCLFFBQVEsZ0JBQWdCLEtBQUssT0FBTztFQUNyRCxjQUFjLFFBQVEsYUFBYSxLQUFLLE9BQU87Q0FDaEQ7QUFDRDtBQUdBLFNBQVMsNEJBQTRCLFlBQVkseUJBQXlCO0NBQ3pFLE9BQU87RUFDTixTQUFTLENBQUMsc0JBQXNCLElBQUksSUFBSSxvQkFBb0IsRUFBRSxlQUFlLEVBQUUsS0FBSyxVQUFVLEVBQUUsQ0FBQyxJQUFJLElBQUksbUJBQW1CLENBQUMsQ0FBQyxHQUFHLElBQUksa0JBQWtCLEVBQUUsY0FBYyxDQUFDLElBQUkscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUM7RUFDdE0sa0JBQWtCO0NBQ25CO0FBQ0Q7QUFDQSxJQUFNLHdCQUF3Qiw0QkFBNEIiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNl19