import { Container } from "/node_modules/.vite/deps/pixi__js.js?v=eccdfead";
import { Entity } from "/src/game/entities/Entity.ts";
import { Player } from "/src/game/entities/Player.ts";
import { Projectile } from "/src/game/entities/Projectile.ts";
import { Island } from "/src/game/entities/Island.ts";
import { Enemy } from "/src/game/entities/Enemy.ts";
import { Chaser } from "/src/game/entities/Chaser.ts";
import { Shooter } from "/src/game/entities/Shooter.ts";
import { gameEngine } from "/src/game/GameApplication.ts";
import { TiledMapParser } from "/src/game/TiledMapParser.ts";
import { soundManager } from "/src/game/SoundManager.ts";
export class EntityManager {
	entities = [];
	player;
	islands = [];
	container;
	mapWidth = 0;
	mapHeight = 0;
	spawnCooldown = 0;
	SPAWN_RATE = 8;
	constructor(container) {
		this.container = container;
	}
	async loadMap() {
		const { mapWidth, mapHeight } = await TiledMapParser.loadMap("/assets/maps/level1.json", this.container, this.islands);
		this.mapWidth = mapWidth;
		this.mapHeight = mapHeight;
		for (const island of this.islands) {
			this.entities.push(island);
			this.container.addChild(island.container);
		}
	}
	initPlayer() {
		this.player = new Player();
		this.player.x = 400;
		this.player.y = 300;
		this.player.onFire = (x, y, rotation) => {
			const proj = new Projectile(x, y, rotation, false);
			this.addEntity(proj);
		};
		this.addEntity(this.player);
	}
	addEntity(entity) {
		this.entities.push(entity);
		this.container.addChild(entity.container);
	}
	removeEntity(entity) {
		const index = this.entities.indexOf(entity);
		if (index > -1) {
			this.entities.splice(index, 1);
			this.container.removeChild(entity.container);
			entity.destroy();
		}
	}
	update(delta) {
		this.spawnCooldown -= delta;
		if (this.spawnCooldown <= 0) {
			this.spawnEnemy();
			this.spawnCooldown = this.SPAWN_RATE;
		}
		for (let i = this.entities.length - 1; i >= 0; i--) {
			const entity = this.entities[i];
			entity.update(delta);
			if (entity.isDead) {
				if (entity instanceof Enemy && !this.player.isDead) {
					if (entity.scoreValue > 0) {
						gameEngine.addScore(entity.scoreValue);
						soundManager.play("score_point", .8);
					}
				}
				this.removeEntity(entity);
			}
		}
		this.checkCollisions();
	}
	findSafeSpawnPoint(avoidPlayer = false) {
		let x = this.mapWidth / 2;
		let y = this.mapHeight / 2;
		let validSpawn = false;
		let attempts = 0;
		while (!validSpawn && attempts < 50) {
			attempts++;
			x = 100 + Math.random() * (this.mapWidth - 200);
			y = 100 + Math.random() * (this.mapHeight - 200);
			if (avoidPlayer && this.player) {
				if (Math.abs(x - this.player.x) < 400 && Math.abs(y - this.player.y) < 400) {
					continue;
				}
			}
			let insideIsland = false;
			for (const island of this.islands) {
				if (island.isRect) {
					const rx = island.x - island.width / 2;
					const ry = island.y - island.height / 2;
					if (x > rx - 50 && x < rx + island.width + 50 && y > ry - 50 && y < ry + island.height + 50) {
						insideIsland = true;
						break;
					}
				} else {
					const dist = Math.sqrt(Math.pow(x - island.x, 2) + Math.pow(y - island.y, 2));
					if (dist < island.radius + 50) {
						insideIsland = true;
						break;
					}
				}
			}
			if (insideIsland) {
				continue;
			}
			validSpawn = true;
		}
		if (!validSpawn) return null;
		return {
			x,
			y
		};
	}
	spawnEnemy() {
		if (this.player.isDead) return;
		const spawnPoint = this.findSafeSpawnPoint(true);
		if (!spawnPoint) return;
		const { x, y } = spawnPoint;
		const isChaser = Math.random() > .5;
		const enemy = isChaser ? new Chaser(this.player, x, y) : new Shooter(this.player, x, y);
		if (enemy instanceof Shooter) {
			enemy.onFire = (sx, sy, sRot) => {
				const proj = new Projectile(sx, sy, sRot, true);
				this.addEntity(proj);
			};
		}
		this.addEntity(enemy);
	}
	checkCollisions() {
		const getDistance = (x1, y1, x2, y2) => {
			return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
		};
		const resolveCircleVsRect = (circleX, circleY, circleRadius, rectX, rectY, rectW, rectH) => {
			const rx = rectX - rectW / 2;
			const ry = rectY - rectH / 2;
			const closestX = Math.max(rx, Math.min(circleX, rx + rectW));
			const closestY = Math.max(ry, Math.min(circleY, ry + rectH));
			const distanceX = circleX - closestX;
			const distanceY = circleY - closestY;
			const distanceSquared = distanceX * distanceX + distanceY * distanceY;
			if (distanceSquared < circleRadius * circleRadius) {
				const distance = Math.sqrt(distanceSquared);
				if (distance === 0) {
					return {
						overlap: circleRadius,
						angle: -Math.PI / 2
					};
				}
				return {
					overlap: circleRadius - distance,
					angle: Math.atan2(distanceY, distanceX)
				};
			}
			return null;
		};
		const resolveCircleVsCircle = (x1, y1, r1, x2, y2, r2) => {
			const dist = getDistance(x1, y1, x2, y2);
			if (dist < r1 + r2) {
				return {
					overlap: r1 + r2 - dist,
					angle: Math.atan2(y1 - y2, x1 - x2)
				};
			}
			return null;
		};
		const projectiles = this.entities.filter((e) => e instanceof Projectile);
		const enemies = this.entities.filter((e) => e instanceof Enemy);
		for (const island of this.islands) {
			for (const proj of projectiles) {
				if (proj.isDead) continue;
				let hit = false;
				if (island.isRect) {
					hit = resolveCircleVsRect(proj.x, proj.y, 5, island.x, island.y, island.width, island.height) !== null;
				} else {
					hit = resolveCircleVsCircle(proj.x, proj.y, 5, island.x, island.y, island.radius) !== null;
				}
				if (hit) {
					proj.isDead = true;
				}
			}
			if (this.player && !this.player.isDead) {
				const playerRadius = 15;
				let collision = island.isRect ? resolveCircleVsRect(this.player.x, this.player.y, playerRadius, island.x, island.y, island.width, island.height) : resolveCircleVsCircle(this.player.x, this.player.y, playerRadius, island.x, island.y, island.radius);
				if (collision) {
					this.player.x += Math.cos(collision.angle) * collision.overlap;
					this.player.y += Math.sin(collision.angle) * collision.overlap;
					this.player.vx = 0;
					this.player.vy = 0;
				}
			}
			for (const enemy of enemies) {
				if (enemy.isDead) continue;
				const enemyRadius = 15;
				let collision = island.isRect ? resolveCircleVsRect(enemy.x, enemy.y, enemyRadius, island.x, island.y, island.width, island.height) : resolveCircleVsCircle(enemy.x, enemy.y, enemyRadius, island.x, island.y, island.radius);
				if (collision) {
					enemy.x += Math.cos(collision.angle) * collision.overlap;
					enemy.y += Math.sin(collision.angle) * collision.overlap;
					enemy.vx = 0;
					enemy.vy = 0;
				}
			}
		}
		const shipRadius = 35;
		for (const proj of projectiles) {
			if (proj.isDead) continue;
			if (!proj.isEnemy) {
				for (const enemy of enemies) {
					if (enemy.isDead) continue;
					if (getDistance(proj.x, proj.y, enemy.x, enemy.y) < shipRadius + 5) {
						enemy.takeDamage(proj.damage);
						soundManager.playRandom(["ship_wood_hit_1", "ship_wood_hit_2"], .6);
						proj.isDead = true;
						break;
					}
				}
			} else {
				if (!this.player.isDead) {
					if (getDistance(proj.x, proj.y, this.player.x, this.player.y) < shipRadius + 5) {
						this.player.takeDamage(proj.damage);
						soundManager.playRandom(["ship_wood_hit_1", "ship_wood_hit_2"], .8);
						proj.isDead = true;
					}
				}
			}
		}
		if (!this.player.isDead) {
			for (const enemy of enemies) {
				if (enemy instanceof Chaser && enemy.health > 0 && !this.player.isDead) {
					if (getDistance(this.player.x, this.player.y, enemy.x, enemy.y) < shipRadius * 2) {
						this.player.takeDamage(enemy.collisionDamage);
						soundManager.play("ship_collision", .8);
						enemy.scoreValue = 0;
						enemy.takeDamage(9999);
					}
				}
			}
		}
	}
	destroyAll() {
		for (const entity of this.entities) {
			this.container.removeChild(entity.container);
			entity.destroy();
		}
		this.entities = [];
		this.islands = [];
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsY0FBYztBQUN2QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGNBQWM7QUFDdkIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxvQkFBb0I7QUFFN0IsT0FBTyxNQUFNLGNBQWM7Q0FDekIsQUFBTyxXQUFxQixDQUFDO0NBQzdCLEFBQU87Q0FDUCxBQUFPLFVBQW9CLENBQUM7Q0FDNUIsQUFBTztDQUVQLEFBQU8sV0FBbUI7Q0FDMUIsQUFBTyxZQUFvQjtDQUUzQixBQUFPLGdCQUFnQjtDQUN2QixBQUFPLGFBQWE7Q0FFcEIsWUFBWSxXQUFzQjtFQUNoQyxLQUFLLFlBQVk7Q0FDbkI7Q0FFQSxNQUFhLFVBQVU7RUFDckIsTUFBTSxFQUFFLFVBQVUsY0FBYyxNQUFNLGVBQWUsUUFBUSw0QkFBNEIsS0FBSyxXQUFXLEtBQUssT0FBTztFQUNySCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxZQUFZO0VBRWpCLEtBQUssTUFBTSxVQUFVLEtBQUssU0FBUztHQUNqQyxLQUFLLFNBQVMsS0FBSyxNQUFNO0dBQ3pCLEtBQUssVUFBVSxTQUFTLE9BQU8sU0FBUztFQUMxQztDQUNGO0NBRUEsQUFBTyxhQUFhO0VBQ2xCLEtBQUssU0FBUyxJQUFJLE9BQU87RUFDekIsS0FBSyxPQUFPLElBQUk7RUFDaEIsS0FBSyxPQUFPLElBQUk7RUFFaEIsS0FBSyxPQUFPLFVBQVUsR0FBVyxHQUFXLGFBQXFCO0dBQy9ELE1BQU0sT0FBTyxJQUFJLFdBQVcsR0FBRyxHQUFHLFVBQVUsS0FBSztHQUNqRCxLQUFLLFVBQVUsSUFBSTtFQUNyQjtFQUVBLEtBQUssVUFBVSxLQUFLLE1BQU07Q0FDNUI7Q0FFQSxBQUFPLFVBQVUsUUFBZ0I7RUFDL0IsS0FBSyxTQUFTLEtBQUssTUFBTTtFQUN6QixLQUFLLFVBQVUsU0FBUyxPQUFPLFNBQVM7Q0FDMUM7Q0FFQSxBQUFPLGFBQWEsUUFBZ0I7RUFDbEMsTUFBTSxRQUFRLEtBQUssU0FBUyxRQUFRLE1BQU07RUFDMUMsSUFBSSxRQUFRLENBQUMsR0FBRztHQUNkLEtBQUssU0FBUyxPQUFPLE9BQU8sQ0FBQztHQUM3QixLQUFLLFVBQVUsWUFBWSxPQUFPLFNBQVM7R0FDM0MsT0FBTyxRQUFRO0VBQ2pCO0NBQ0Y7Q0FFQSxBQUFPLE9BQU8sT0FBZTtFQUUzQixLQUFLLGlCQUFpQjtFQUN0QixJQUFJLEtBQUssaUJBQWlCLEdBQUc7R0FDM0IsS0FBSyxXQUFXO0dBQ2hCLEtBQUssZ0JBQWdCLEtBQUs7RUFDNUI7RUFFQSxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ2xELE1BQU0sU0FBUyxLQUFLLFNBQVM7R0FDN0IsT0FBTyxPQUFPLEtBQUs7R0FFbkIsSUFBSSxPQUFPLFFBQVE7SUFDakIsSUFBSSxrQkFBa0IsU0FBUyxDQUFDLEtBQUssT0FBTyxRQUFRO0tBQ2xELElBQUksT0FBTyxhQUFhLEdBQUc7TUFDekIsV0FBVyxTQUFTLE9BQU8sVUFBVTtNQUNyQyxhQUFhLEtBQUssZUFBZSxFQUFHO0tBQ3RDO0lBQ0Y7SUFDQSxLQUFLLGFBQWEsTUFBTTtHQUMxQjtFQUNGO0VBRUEsS0FBSyxnQkFBZ0I7Q0FDdkI7Q0FFQSxBQUFPLG1CQUFtQixjQUF1QixPQUF3QztFQUN2RixJQUFJLElBQUksS0FBSyxXQUFXO0VBQ3hCLElBQUksSUFBSSxLQUFLLFlBQVk7RUFDekIsSUFBSSxhQUFhO0VBQ2pCLElBQUksV0FBVztFQUVmLE9BQU8sQ0FBQyxjQUFjLFdBQVcsSUFBSTtHQUNuQztHQUNBLElBQUksTUFBTSxLQUFLLE9BQU8sS0FBSyxLQUFLLFdBQVc7R0FDM0MsSUFBSSxNQUFNLEtBQUssT0FBTyxLQUFLLEtBQUssWUFBWTtHQUU1QyxJQUFJLGVBQWUsS0FBSyxRQUFRO0lBQzlCLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxPQUFPLENBQUMsSUFBSSxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssT0FBTyxDQUFDLElBQUksS0FBSztLQUMxRTtJQUNGO0dBQ0Y7R0FFQSxJQUFJLGVBQWU7R0FDbkIsS0FBSyxNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQ2pDLElBQUksT0FBTyxRQUFRO0tBQ2pCLE1BQU0sS0FBSyxPQUFPLElBQUksT0FBTyxRQUFRO0tBQ3JDLE1BQU0sS0FBSyxPQUFPLElBQUksT0FBTyxTQUFTO0tBQ3RDLElBQUksSUFBSSxLQUFLLE1BQU0sSUFBSSxLQUFLLE9BQU8sUUFBUSxNQUFNLElBQUksS0FBSyxNQUFNLElBQUksS0FBSyxPQUFPLFNBQVMsSUFBSTtNQUMzRixlQUFlO01BQ2Y7S0FDRjtJQUNGLE9BQU87S0FDTCxNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssSUFBSSxJQUFJLE9BQU8sR0FBRyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQztLQUM1RSxJQUFJLE9BQU8sT0FBTyxTQUFTLElBQUk7TUFDN0IsZUFBZTtNQUNmO0tBQ0Y7SUFDRjtHQUNGO0dBRUEsSUFBSSxjQUFjO0lBQ2hCO0dBQ0Y7R0FDQSxhQUFhO0VBQ2Y7RUFFQSxJQUFJLENBQUMsWUFBWSxPQUFPO0VBQ3hCLE9BQU87R0FBRTtHQUFHO0VBQUU7Q0FDaEI7Q0FFQSxBQUFRLGFBQWE7RUFDbkIsSUFBSSxLQUFLLE9BQU8sUUFBUTtFQUV4QixNQUFNLGFBQWEsS0FBSyxtQkFBbUIsSUFBSTtFQUMvQyxJQUFJLENBQUMsWUFBWTtFQUNqQixNQUFNLEVBQUUsR0FBRyxNQUFNO0VBRWpCLE1BQU0sV0FBVyxLQUFLLE9BQU8sSUFBSTtFQUNqQyxNQUFNLFFBQVEsV0FBVyxJQUFJLE9BQU8sS0FBSyxRQUFRLEdBQUcsQ0FBQyxJQUFJLElBQUksUUFBUSxLQUFLLFFBQVEsR0FBRyxDQUFDO0VBRXRGLElBQUksaUJBQWlCLFNBQVM7R0FDNUIsTUFBTSxVQUFVLElBQUksSUFBSSxTQUFTO0lBQy9CLE1BQU0sT0FBTyxJQUFJLFdBQVcsSUFBSSxJQUFJLE1BQU0sSUFBSTtJQUM5QyxLQUFLLFVBQVUsSUFBSTtHQUNyQjtFQUNGO0VBRUEsS0FBSyxVQUFVLEtBQUs7Q0FDdEI7Q0FFQSxBQUFRLGtCQUFrQjtFQUN4QixNQUFNLGVBQWUsSUFBWSxJQUFZLElBQVksT0FBZTtHQUN0RSxPQUFPLEtBQUssS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQztFQUM5RDtFQUVBLE1BQU0sdUJBQXVCLFNBQWlCLFNBQWlCLGNBQXNCLE9BQWUsT0FBZSxPQUFlLFVBQWtCO0dBRWxKLE1BQU0sS0FBSyxRQUFRLFFBQVE7R0FDM0IsTUFBTSxLQUFLLFFBQVEsUUFBUTtHQUUzQixNQUFNLFdBQVcsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLFNBQVMsS0FBSyxLQUFLLENBQUM7R0FDM0QsTUFBTSxXQUFXLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxTQUFTLEtBQUssS0FBSyxDQUFDO0dBRTNELE1BQU0sWUFBWSxVQUFVO0dBQzVCLE1BQU0sWUFBWSxVQUFVO0dBQzVCLE1BQU0sa0JBQW1CLFlBQVksWUFBYyxZQUFZO0dBRS9ELElBQUksa0JBQW1CLGVBQWUsY0FBZTtJQUNuRCxNQUFNLFdBQVcsS0FBSyxLQUFLLGVBQWU7SUFDMUMsSUFBSSxhQUFhLEdBQUc7S0FFbEIsT0FBTztNQUFFLFNBQVM7TUFBYyxPQUFPLENBQUMsS0FBSyxLQUFLO0tBQUU7SUFDdEQ7SUFDQSxPQUFPO0tBQUUsU0FBUyxlQUFlO0tBQVUsT0FBTyxLQUFLLE1BQU0sV0FBVyxTQUFTO0lBQUU7R0FDckY7R0FDQSxPQUFPO0VBQ1Q7RUFFQSxNQUFNLHlCQUF5QixJQUFZLElBQVksSUFBWSxJQUFZLElBQVksT0FBZTtHQUN4RyxNQUFNLE9BQU8sWUFBWSxJQUFJLElBQUksSUFBSSxFQUFFO0dBQ3ZDLElBQUksT0FBTyxLQUFLLElBQUk7SUFDbEIsT0FBTztLQUFFLFNBQVUsS0FBSyxLQUFNO0tBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRTtJQUFFO0dBQzFFO0dBQ0EsT0FBTztFQUNUO0VBRUEsTUFBTSxjQUFjLEtBQUssU0FBUyxRQUFPLE1BQUssYUFBYSxVQUFVO0VBQ3JFLE1BQU0sVUFBVSxLQUFLLFNBQVMsUUFBTyxNQUFLLGFBQWEsS0FBSztFQUU1RCxLQUFLLE1BQU0sVUFBVSxLQUFLLFNBQVM7R0FFakMsS0FBSyxNQUFNLFFBQVEsYUFBYTtJQUM5QixJQUFJLEtBQUssUUFBUTtJQUVqQixJQUFJLE1BQU07SUFDVixJQUFJLE9BQU8sUUFBUTtLQUNqQixNQUFNLG9CQUFvQixLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsT0FBTyxHQUFHLE9BQU8sR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNLE1BQU07SUFDcEcsT0FBTztLQUNMLE1BQU0sc0JBQXNCLEtBQUssR0FBRyxLQUFLLEdBQUcsR0FBRyxPQUFPLEdBQUcsT0FBTyxHQUFHLE9BQU8sTUFBTSxNQUFNO0lBQ3hGO0lBRUEsSUFBSSxLQUFLO0tBQ1AsS0FBSyxTQUFTO0lBQ2hCO0dBQ0Y7R0FFQSxJQUFJLEtBQUssVUFBVSxDQUFDLEtBQUssT0FBTyxRQUFRO0lBQ3RDLE1BQU0sZUFBZTtJQUNyQixJQUFJLFlBQVksT0FBTyxTQUNuQixvQkFBb0IsS0FBSyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsY0FBYyxPQUFPLEdBQUcsT0FBTyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU0sSUFDL0csc0JBQXNCLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxHQUFHLGNBQWMsT0FBTyxHQUFHLE9BQU8sR0FBRyxPQUFPLE1BQU07SUFFdkcsSUFBSSxXQUFXO0tBQ2IsS0FBSyxPQUFPLEtBQUssS0FBSyxJQUFJLFVBQVUsS0FBSyxJQUFJLFVBQVU7S0FDdkQsS0FBSyxPQUFPLEtBQUssS0FBSyxJQUFJLFVBQVUsS0FBSyxJQUFJLFVBQVU7S0FDdkQsS0FBSyxPQUFPLEtBQUs7S0FDakIsS0FBSyxPQUFPLEtBQUs7SUFDbkI7R0FDRjtHQUVBLEtBQUssTUFBTSxTQUFTLFNBQVM7SUFDM0IsSUFBSSxNQUFNLFFBQVE7SUFDbEIsTUFBTSxjQUFjO0lBQ3BCLElBQUksWUFBWSxPQUFPLFNBQ25CLG9CQUFvQixNQUFNLEdBQUcsTUFBTSxHQUFHLGFBQWEsT0FBTyxHQUFHLE9BQU8sR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNLElBQ2xHLHNCQUFzQixNQUFNLEdBQUcsTUFBTSxHQUFHLGFBQWEsT0FBTyxHQUFHLE9BQU8sR0FBRyxPQUFPLE1BQU07SUFFMUYsSUFBSSxXQUFXO0tBQ2IsTUFBTSxLQUFLLEtBQUssSUFBSSxVQUFVLEtBQUssSUFBSSxVQUFVO0tBQ2pELE1BQU0sS0FBSyxLQUFLLElBQUksVUFBVSxLQUFLLElBQUksVUFBVTtLQUNqRCxNQUFNLEtBQUs7S0FDWCxNQUFNLEtBQUs7SUFDYjtHQUNGO0VBQ0Y7RUFFQSxNQUFNLGFBQWE7RUFDbkIsS0FBSyxNQUFNLFFBQVEsYUFBYTtHQUM5QixJQUFJLEtBQUssUUFBUTtHQUVqQixJQUFJLENBQUMsS0FBSyxTQUFTO0lBRWpCLEtBQUssTUFBTSxTQUFTLFNBQVM7S0FDM0IsSUFBSSxNQUFNLFFBQVE7S0FDbEIsSUFBSSxZQUFZLEtBQUssR0FBRyxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLGFBQWEsR0FBRztNQUNsRSxNQUFNLFdBQVcsS0FBSyxNQUFNO01BQzVCLGFBQWEsV0FBVyxDQUFDLG1CQUFtQixpQkFBaUIsR0FBRyxFQUFHO01BQ25FLEtBQUssU0FBUztNQUNkO0tBQ0Y7SUFDRjtHQUNGLE9BQU87SUFFTCxJQUFJLENBQUMsS0FBSyxPQUFPLFFBQVE7S0FDdkIsSUFBSSxZQUFZLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxPQUFPLEdBQUcsS0FBSyxPQUFPLENBQUMsSUFBSSxhQUFhLEdBQUc7TUFDOUUsS0FBSyxPQUFPLFdBQVcsS0FBSyxNQUFNO01BQ2xDLGFBQWEsV0FBVyxDQUFDLG1CQUFtQixpQkFBaUIsR0FBRyxFQUFHO01BQ25FLEtBQUssU0FBUztLQUNoQjtJQUNGO0dBQ0Y7RUFDRjtFQUVBLElBQUksQ0FBQyxLQUFLLE9BQU8sUUFBUTtHQUN2QixLQUFLLE1BQU0sU0FBUyxTQUFTO0lBQzNCLElBQUksaUJBQWlCLFVBQVUsTUFBTSxTQUFTLEtBQUssQ0FBQyxLQUFLLE9BQU8sUUFBUTtLQUN0RSxJQUFJLFlBQVksS0FBSyxPQUFPLEdBQUcsS0FBSyxPQUFPLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLGFBQWEsR0FBRztNQUNoRixLQUFLLE9BQU8sV0FBVyxNQUFNLGVBQWU7TUFDNUMsYUFBYSxLQUFLLGtCQUFrQixFQUFHO01BQ3ZDLE1BQU0sYUFBYTtNQUNuQixNQUFNLFdBQVcsSUFBSTtLQUN2QjtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBRUEsQUFBTyxhQUFhO0VBQ2xCLEtBQUssTUFBTSxVQUFVLEtBQUssVUFBVTtHQUNsQyxLQUFLLFVBQVUsWUFBWSxPQUFPLFNBQVM7R0FDM0MsT0FBTyxRQUFRO0VBQ2pCO0VBQ0EsS0FBSyxXQUFXLENBQUM7RUFDakIsS0FBSyxVQUFVLENBQUM7Q0FDbEI7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFbnRpdHlNYW5hZ2VyLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJ3BpeGkuanMnO1xuaW1wb3J0IHsgRW50aXR5IH0gZnJvbSAnLi9lbnRpdGllcy9FbnRpdHknO1xuaW1wb3J0IHsgUGxheWVyIH0gZnJvbSAnLi9lbnRpdGllcy9QbGF5ZXInO1xuaW1wb3J0IHsgUHJvamVjdGlsZSB9IGZyb20gJy4vZW50aXRpZXMvUHJvamVjdGlsZSc7XG5pbXBvcnQgeyBJc2xhbmQgfSBmcm9tICcuL2VudGl0aWVzL0lzbGFuZCc7XG5pbXBvcnQgeyBFbmVteSB9IGZyb20gJy4vZW50aXRpZXMvRW5lbXknO1xuaW1wb3J0IHsgQ2hhc2VyIH0gZnJvbSAnLi9lbnRpdGllcy9DaGFzZXInO1xuaW1wb3J0IHsgU2hvb3RlciB9IGZyb20gJy4vZW50aXRpZXMvU2hvb3Rlcic7XG5pbXBvcnQgeyBnYW1lRW5naW5lIH0gZnJvbSAnLi9HYW1lQXBwbGljYXRpb24nO1xuaW1wb3J0IHsgVGlsZWRNYXBQYXJzZXIgfSBmcm9tICcuL1RpbGVkTWFwUGFyc2VyJztcbmltcG9ydCB7IHNvdW5kTWFuYWdlciB9IGZyb20gJy4vU291bmRNYW5hZ2VyJztcblxuZXhwb3J0IGNsYXNzIEVudGl0eU1hbmFnZXIge1xuICBwdWJsaWMgZW50aXRpZXM6IEVudGl0eVtdID0gW107XG4gIHB1YmxpYyBwbGF5ZXIhOiBQbGF5ZXI7XG4gIHB1YmxpYyBpc2xhbmRzOiBJc2xhbmRbXSA9IFtdO1xuICBwdWJsaWMgY29udGFpbmVyOiBDb250YWluZXI7XG5cbiAgcHVibGljIG1hcFdpZHRoOiBudW1iZXIgPSAwO1xuICBwdWJsaWMgbWFwSGVpZ2h0OiBudW1iZXIgPSAwO1xuXG4gIHB1YmxpYyBzcGF3bkNvb2xkb3duID0gMDtcbiAgcHVibGljIFNQQVdOX1JBVEUgPSA4LjA7IC8vIFNlY29uZHMgYmV0d2VlbiBzcGF3bnNcblxuICBjb25zdHJ1Y3Rvcihjb250YWluZXI6IENvbnRhaW5lcikge1xuICAgIHRoaXMuY29udGFpbmVyID0gY29udGFpbmVyO1xuICB9XG5cbiAgcHVibGljIGFzeW5jIGxvYWRNYXAoKSB7XG4gICAgY29uc3QgeyBtYXBXaWR0aCwgbWFwSGVpZ2h0IH0gPSBhd2FpdCBUaWxlZE1hcFBhcnNlci5sb2FkTWFwKCcvYXNzZXRzL21hcHMvbGV2ZWwxLmpzb24nLCB0aGlzLmNvbnRhaW5lciwgdGhpcy5pc2xhbmRzKTtcbiAgICB0aGlzLm1hcFdpZHRoID0gbWFwV2lkdGg7XG4gICAgdGhpcy5tYXBIZWlnaHQgPSBtYXBIZWlnaHQ7XG4gICAgXG4gICAgZm9yIChjb25zdCBpc2xhbmQgb2YgdGhpcy5pc2xhbmRzKSB7XG4gICAgICB0aGlzLmVudGl0aWVzLnB1c2goaXNsYW5kKTtcbiAgICAgIHRoaXMuY29udGFpbmVyLmFkZENoaWxkKGlzbGFuZC5jb250YWluZXIpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBpbml0UGxheWVyKCkge1xuICAgIHRoaXMucGxheWVyID0gbmV3IFBsYXllcigpO1xuICAgIHRoaXMucGxheWVyLnggPSA0MDA7XG4gICAgdGhpcy5wbGF5ZXIueSA9IDMwMDtcbiAgICBcbiAgICB0aGlzLnBsYXllci5vbkZpcmUgPSAoeDogbnVtYmVyLCB5OiBudW1iZXIsIHJvdGF0aW9uOiBudW1iZXIpID0+IHtcbiAgICAgIGNvbnN0IHByb2ogPSBuZXcgUHJvamVjdGlsZSh4LCB5LCByb3RhdGlvbiwgZmFsc2UpO1xuICAgICAgdGhpcy5hZGRFbnRpdHkocHJvaik7XG4gICAgfTtcblxuICAgIHRoaXMuYWRkRW50aXR5KHRoaXMucGxheWVyKTtcbiAgfVxuXG4gIHB1YmxpYyBhZGRFbnRpdHkoZW50aXR5OiBFbnRpdHkpIHtcbiAgICB0aGlzLmVudGl0aWVzLnB1c2goZW50aXR5KTtcbiAgICB0aGlzLmNvbnRhaW5lci5hZGRDaGlsZChlbnRpdHkuY29udGFpbmVyKTtcbiAgfVxuXG4gIHB1YmxpYyByZW1vdmVFbnRpdHkoZW50aXR5OiBFbnRpdHkpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuZW50aXRpZXMuaW5kZXhPZihlbnRpdHkpO1xuICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICB0aGlzLmVudGl0aWVzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICB0aGlzLmNvbnRhaW5lci5yZW1vdmVDaGlsZChlbnRpdHkuY29udGFpbmVyKTtcbiAgICAgIGVudGl0eS5kZXN0cm95KCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHVwZGF0ZShkZWx0YTogbnVtYmVyKSB7XG5cbiAgICB0aGlzLnNwYXduQ29vbGRvd24gLT0gZGVsdGE7XG4gICAgaWYgKHRoaXMuc3Bhd25Db29sZG93biA8PSAwKSB7XG4gICAgICB0aGlzLnNwYXduRW5lbXkoKTtcbiAgICAgIHRoaXMuc3Bhd25Db29sZG93biA9IHRoaXMuU1BBV05fUkFURTtcbiAgICB9XG5cbiAgICBmb3IgKGxldCBpID0gdGhpcy5lbnRpdGllcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgY29uc3QgZW50aXR5ID0gdGhpcy5lbnRpdGllc1tpXTtcbiAgICAgIGVudGl0eS51cGRhdGUoZGVsdGEpO1xuXG4gICAgICBpZiAoZW50aXR5LmlzRGVhZCkge1xuICAgICAgICBpZiAoZW50aXR5IGluc3RhbmNlb2YgRW5lbXkgJiYgIXRoaXMucGxheWVyLmlzRGVhZCkge1xuICAgICAgICAgIGlmIChlbnRpdHkuc2NvcmVWYWx1ZSA+IDApIHtcbiAgICAgICAgICAgIGdhbWVFbmdpbmUuYWRkU2NvcmUoZW50aXR5LnNjb3JlVmFsdWUpO1xuICAgICAgICAgICAgc291bmRNYW5hZ2VyLnBsYXkoJ3Njb3JlX3BvaW50JywgMC44KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZW1vdmVFbnRpdHkoZW50aXR5KTtcbiAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgdGhpcy5jaGVja0NvbGxpc2lvbnMoKTtcbiAgfVxuXG4gIHB1YmxpYyBmaW5kU2FmZVNwYXduUG9pbnQoYXZvaWRQbGF5ZXI6IGJvb2xlYW4gPSBmYWxzZSk6IHsgeDogbnVtYmVyLCB5OiBudW1iZXIgfSB8IG51bGwge1xuICAgIGxldCB4ID0gdGhpcy5tYXBXaWR0aCAvIDI7XG4gICAgbGV0IHkgPSB0aGlzLm1hcEhlaWdodCAvIDI7XG4gICAgbGV0IHZhbGlkU3Bhd24gPSBmYWxzZTtcbiAgICBsZXQgYXR0ZW1wdHMgPSAwO1xuXG4gICAgd2hpbGUgKCF2YWxpZFNwYXduICYmIGF0dGVtcHRzIDwgNTApIHtcbiAgICAgIGF0dGVtcHRzKys7XG4gICAgICB4ID0gMTAwICsgTWF0aC5yYW5kb20oKSAqICh0aGlzLm1hcFdpZHRoIC0gMjAwKTtcbiAgICAgIHkgPSAxMDAgKyBNYXRoLnJhbmRvbSgpICogKHRoaXMubWFwSGVpZ2h0IC0gMjAwKTtcbiAgICAgIFxuICAgICAgaWYgKGF2b2lkUGxheWVyICYmIHRoaXMucGxheWVyKSB7XG4gICAgICAgIGlmIChNYXRoLmFicyh4IC0gdGhpcy5wbGF5ZXIueCkgPCA0MDAgJiYgTWF0aC5hYnMoeSAtIHRoaXMucGxheWVyLnkpIDwgNDAwKSB7XG4gICAgICAgICAgY29udGludWU7IFxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGxldCBpbnNpZGVJc2xhbmQgPSBmYWxzZTtcbiAgICAgIGZvciAoY29uc3QgaXNsYW5kIG9mIHRoaXMuaXNsYW5kcykge1xuICAgICAgICBpZiAoaXNsYW5kLmlzUmVjdCkge1xuICAgICAgICAgIGNvbnN0IHJ4ID0gaXNsYW5kLnggLSBpc2xhbmQud2lkdGggLyAyO1xuICAgICAgICAgIGNvbnN0IHJ5ID0gaXNsYW5kLnkgLSBpc2xhbmQuaGVpZ2h0IC8gMjtcbiAgICAgICAgICBpZiAoeCA+IHJ4IC0gNTAgJiYgeCA8IHJ4ICsgaXNsYW5kLndpZHRoICsgNTAgJiYgeSA+IHJ5IC0gNTAgJiYgeSA8IHJ5ICsgaXNsYW5kLmhlaWdodCArIDUwKSB7XG4gICAgICAgICAgICBpbnNpZGVJc2xhbmQgPSB0cnVlO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IGRpc3QgPSBNYXRoLnNxcnQoTWF0aC5wb3coeCAtIGlzbGFuZC54LCAyKSArIE1hdGgucG93KHkgLSBpc2xhbmQueSwgMikpO1xuICAgICAgICAgIGlmIChkaXN0IDwgaXNsYW5kLnJhZGl1cyArIDUwKSB7XG4gICAgICAgICAgICBpbnNpZGVJc2xhbmQgPSB0cnVlO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChpbnNpZGVJc2xhbmQpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICB2YWxpZFNwYXduID0gdHJ1ZTtcbiAgICB9XG4gICAgXG4gICAgaWYgKCF2YWxpZFNwYXduKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyB4LCB5IH07XG4gIH1cblxuICBwcml2YXRlIHNwYXduRW5lbXkoKSB7XG4gICAgaWYgKHRoaXMucGxheWVyLmlzRGVhZCkgcmV0dXJuO1xuXG4gICAgY29uc3Qgc3Bhd25Qb2ludCA9IHRoaXMuZmluZFNhZmVTcGF3blBvaW50KHRydWUpO1xuICAgIGlmICghc3Bhd25Qb2ludCkgcmV0dXJuO1xuICAgIGNvbnN0IHsgeCwgeSB9ID0gc3Bhd25Qb2ludDtcblxuICAgIGNvbnN0IGlzQ2hhc2VyID0gTWF0aC5yYW5kb20oKSA+IDAuNTtcbiAgICBjb25zdCBlbmVteSA9IGlzQ2hhc2VyID8gbmV3IENoYXNlcih0aGlzLnBsYXllciwgeCwgeSkgOiBuZXcgU2hvb3Rlcih0aGlzLnBsYXllciwgeCwgeSk7XG4gICAgXG4gICAgaWYgKGVuZW15IGluc3RhbmNlb2YgU2hvb3Rlcikge1xuICAgICAgZW5lbXkub25GaXJlID0gKHN4LCBzeSwgc1JvdCkgPT4ge1xuICAgICAgICBjb25zdCBwcm9qID0gbmV3IFByb2plY3RpbGUoc3gsIHN5LCBzUm90LCB0cnVlKTtcbiAgICAgICAgdGhpcy5hZGRFbnRpdHkocHJvaik7XG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICB0aGlzLmFkZEVudGl0eShlbmVteSk7XG4gIH1cblxuICBwcml2YXRlIGNoZWNrQ29sbGlzaW9ucygpIHtcbiAgICBjb25zdCBnZXREaXN0YW5jZSA9ICh4MTogbnVtYmVyLCB5MTogbnVtYmVyLCB4MjogbnVtYmVyLCB5MjogbnVtYmVyKSA9PiB7XG4gICAgICByZXR1cm4gTWF0aC5zcXJ0KE1hdGgucG93KHgyIC0geDEsIDIpICsgTWF0aC5wb3coeTIgLSB5MSwgMikpO1xuICAgIH07XG5cbiAgICBjb25zdCByZXNvbHZlQ2lyY2xlVnNSZWN0ID0gKGNpcmNsZVg6IG51bWJlciwgY2lyY2xlWTogbnVtYmVyLCBjaXJjbGVSYWRpdXM6IG51bWJlciwgcmVjdFg6IG51bWJlciwgcmVjdFk6IG51bWJlciwgcmVjdFc6IG51bWJlciwgcmVjdEg6IG51bWJlcikgPT4ge1xuICAgICAgXG4gICAgICBjb25zdCByeCA9IHJlY3RYIC0gcmVjdFcgLyAyO1xuICAgICAgY29uc3QgcnkgPSByZWN0WSAtIHJlY3RIIC8gMjtcbiAgICAgIFxuICAgICAgY29uc3QgY2xvc2VzdFggPSBNYXRoLm1heChyeCwgTWF0aC5taW4oY2lyY2xlWCwgcnggKyByZWN0VykpO1xuICAgICAgY29uc3QgY2xvc2VzdFkgPSBNYXRoLm1heChyeSwgTWF0aC5taW4oY2lyY2xlWSwgcnkgKyByZWN0SCkpO1xuXG4gICAgICBjb25zdCBkaXN0YW5jZVggPSBjaXJjbGVYIC0gY2xvc2VzdFg7XG4gICAgICBjb25zdCBkaXN0YW5jZVkgPSBjaXJjbGVZIC0gY2xvc2VzdFk7XG4gICAgICBjb25zdCBkaXN0YW5jZVNxdWFyZWQgPSAoZGlzdGFuY2VYICogZGlzdGFuY2VYKSArIChkaXN0YW5jZVkgKiBkaXN0YW5jZVkpO1xuXG4gICAgICBpZiAoZGlzdGFuY2VTcXVhcmVkIDwgKGNpcmNsZVJhZGl1cyAqIGNpcmNsZVJhZGl1cykpIHtcbiAgICAgICAgY29uc3QgZGlzdGFuY2UgPSBNYXRoLnNxcnQoZGlzdGFuY2VTcXVhcmVkKTtcbiAgICAgICAgaWYgKGRpc3RhbmNlID09PSAwKSB7XG4gICAgICAgICAgXG4gICAgICAgICAgcmV0dXJuIHsgb3ZlcmxhcDogY2lyY2xlUmFkaXVzLCBhbmdsZTogLU1hdGguUEkgLyAyIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHsgb3ZlcmxhcDogY2lyY2xlUmFkaXVzIC0gZGlzdGFuY2UsIGFuZ2xlOiBNYXRoLmF0YW4yKGRpc3RhbmNlWSwgZGlzdGFuY2VYKSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfTtcblxuICAgIGNvbnN0IHJlc29sdmVDaXJjbGVWc0NpcmNsZSA9ICh4MTogbnVtYmVyLCB5MTogbnVtYmVyLCByMTogbnVtYmVyLCB4MjogbnVtYmVyLCB5MjogbnVtYmVyLCByMjogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCBkaXN0ID0gZ2V0RGlzdGFuY2UoeDEsIHkxLCB4MiwgeTIpO1xuICAgICAgaWYgKGRpc3QgPCByMSArIHIyKSB7XG4gICAgICAgIHJldHVybiB7IG92ZXJsYXA6IChyMSArIHIyKSAtIGRpc3QsIGFuZ2xlOiBNYXRoLmF0YW4yKHkxIC0geTIsIHgxIC0geDIpIH07XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9O1xuXG4gICAgY29uc3QgcHJvamVjdGlsZXMgPSB0aGlzLmVudGl0aWVzLmZpbHRlcihlID0+IGUgaW5zdGFuY2VvZiBQcm9qZWN0aWxlKSBhcyBQcm9qZWN0aWxlW107XG4gICAgY29uc3QgZW5lbWllcyA9IHRoaXMuZW50aXRpZXMuZmlsdGVyKGUgPT4gZSBpbnN0YW5jZW9mIEVuZW15KSBhcyBFbmVteVtdO1xuICAgIFxuICAgIGZvciAoY29uc3QgaXNsYW5kIG9mIHRoaXMuaXNsYW5kcykge1xuXG4gICAgICBmb3IgKGNvbnN0IHByb2ogb2YgcHJvamVjdGlsZXMpIHtcbiAgICAgICAgaWYgKHByb2ouaXNEZWFkKSBjb250aW51ZTtcbiAgICAgICAgXG4gICAgICAgIGxldCBoaXQgPSBmYWxzZTtcbiAgICAgICAgaWYgKGlzbGFuZC5pc1JlY3QpIHtcbiAgICAgICAgICBoaXQgPSByZXNvbHZlQ2lyY2xlVnNSZWN0KHByb2oueCwgcHJvai55LCA1LCBpc2xhbmQueCwgaXNsYW5kLnksIGlzbGFuZC53aWR0aCwgaXNsYW5kLmhlaWdodCkgIT09IG51bGw7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaGl0ID0gcmVzb2x2ZUNpcmNsZVZzQ2lyY2xlKHByb2oueCwgcHJvai55LCA1LCBpc2xhbmQueCwgaXNsYW5kLnksIGlzbGFuZC5yYWRpdXMpICE9PSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBpZiAoaGl0KSB7XG4gICAgICAgICAgcHJvai5pc0RlYWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLnBsYXllciAmJiAhdGhpcy5wbGF5ZXIuaXNEZWFkKSB7XG4gICAgICAgIGNvbnN0IHBsYXllclJhZGl1cyA9IDE1O1xuICAgICAgICBsZXQgY29sbGlzaW9uID0gaXNsYW5kLmlzUmVjdCBcbiAgICAgICAgICA/IHJlc29sdmVDaXJjbGVWc1JlY3QodGhpcy5wbGF5ZXIueCwgdGhpcy5wbGF5ZXIueSwgcGxheWVyUmFkaXVzLCBpc2xhbmQueCwgaXNsYW5kLnksIGlzbGFuZC53aWR0aCwgaXNsYW5kLmhlaWdodClcbiAgICAgICAgICA6IHJlc29sdmVDaXJjbGVWc0NpcmNsZSh0aGlzLnBsYXllci54LCB0aGlzLnBsYXllci55LCBwbGF5ZXJSYWRpdXMsIGlzbGFuZC54LCBpc2xhbmQueSwgaXNsYW5kLnJhZGl1cyk7XG5cbiAgICAgICAgaWYgKGNvbGxpc2lvbikge1xuICAgICAgICAgIHRoaXMucGxheWVyLnggKz0gTWF0aC5jb3MoY29sbGlzaW9uLmFuZ2xlKSAqIGNvbGxpc2lvbi5vdmVybGFwO1xuICAgICAgICAgIHRoaXMucGxheWVyLnkgKz0gTWF0aC5zaW4oY29sbGlzaW9uLmFuZ2xlKSAqIGNvbGxpc2lvbi5vdmVybGFwO1xuICAgICAgICAgIHRoaXMucGxheWVyLnZ4ID0gMDtcbiAgICAgICAgICB0aGlzLnBsYXllci52eSA9IDA7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZm9yIChjb25zdCBlbmVteSBvZiBlbmVtaWVzKSB7XG4gICAgICAgIGlmIChlbmVteS5pc0RlYWQpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBlbmVteVJhZGl1cyA9IDE1O1xuICAgICAgICBsZXQgY29sbGlzaW9uID0gaXNsYW5kLmlzUmVjdCBcbiAgICAgICAgICA/IHJlc29sdmVDaXJjbGVWc1JlY3QoZW5lbXkueCwgZW5lbXkueSwgZW5lbXlSYWRpdXMsIGlzbGFuZC54LCBpc2xhbmQueSwgaXNsYW5kLndpZHRoLCBpc2xhbmQuaGVpZ2h0KVxuICAgICAgICAgIDogcmVzb2x2ZUNpcmNsZVZzQ2lyY2xlKGVuZW15LngsIGVuZW15LnksIGVuZW15UmFkaXVzLCBpc2xhbmQueCwgaXNsYW5kLnksIGlzbGFuZC5yYWRpdXMpO1xuXG4gICAgICAgIGlmIChjb2xsaXNpb24pIHtcbiAgICAgICAgICBlbmVteS54ICs9IE1hdGguY29zKGNvbGxpc2lvbi5hbmdsZSkgKiBjb2xsaXNpb24ub3ZlcmxhcDtcbiAgICAgICAgICBlbmVteS55ICs9IE1hdGguc2luKGNvbGxpc2lvbi5hbmdsZSkgKiBjb2xsaXNpb24ub3ZlcmxhcDtcbiAgICAgICAgICBlbmVteS52eCA9IDA7XG4gICAgICAgICAgZW5lbXkudnkgPSAwO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3Qgc2hpcFJhZGl1cyA9IDM1O1xuICAgIGZvciAoY29uc3QgcHJvaiBvZiBwcm9qZWN0aWxlcykge1xuICAgICAgaWYgKHByb2ouaXNEZWFkKSBjb250aW51ZTtcblxuICAgICAgaWYgKCFwcm9qLmlzRW5lbXkpIHtcblxuICAgICAgICBmb3IgKGNvbnN0IGVuZW15IG9mIGVuZW1pZXMpIHtcbiAgICAgICAgICBpZiAoZW5lbXkuaXNEZWFkKSBjb250aW51ZTtcbiAgICAgICAgICBpZiAoZ2V0RGlzdGFuY2UocHJvai54LCBwcm9qLnksIGVuZW15LngsIGVuZW15LnkpIDwgc2hpcFJhZGl1cyArIDUpIHtcbiAgICAgICAgICAgIGVuZW15LnRha2VEYW1hZ2UocHJvai5kYW1hZ2UpO1xuICAgICAgICAgICAgc291bmRNYW5hZ2VyLnBsYXlSYW5kb20oWydzaGlwX3dvb2RfaGl0XzEnLCAnc2hpcF93b29kX2hpdF8yJ10sIDAuNik7XG4gICAgICAgICAgICBwcm9qLmlzRGVhZCA9IHRydWU7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgaWYgKCF0aGlzLnBsYXllci5pc0RlYWQpIHtcbiAgICAgICAgICBpZiAoZ2V0RGlzdGFuY2UocHJvai54LCBwcm9qLnksIHRoaXMucGxheWVyLngsIHRoaXMucGxheWVyLnkpIDwgc2hpcFJhZGl1cyArIDUpIHtcbiAgICAgICAgICAgIHRoaXMucGxheWVyLnRha2VEYW1hZ2UocHJvai5kYW1hZ2UpO1xuICAgICAgICAgICAgc291bmRNYW5hZ2VyLnBsYXlSYW5kb20oWydzaGlwX3dvb2RfaGl0XzEnLCAnc2hpcF93b29kX2hpdF8yJ10sIDAuOCk7XG4gICAgICAgICAgICBwcm9qLmlzRGVhZCA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLnBsYXllci5pc0RlYWQpIHtcbiAgICAgIGZvciAoY29uc3QgZW5lbXkgb2YgZW5lbWllcykge1xuICAgICAgICBpZiAoZW5lbXkgaW5zdGFuY2VvZiBDaGFzZXIgJiYgZW5lbXkuaGVhbHRoID4gMCAmJiAhdGhpcy5wbGF5ZXIuaXNEZWFkKSB7XG4gICAgICAgICAgaWYgKGdldERpc3RhbmNlKHRoaXMucGxheWVyLngsIHRoaXMucGxheWVyLnksIGVuZW15LngsIGVuZW15LnkpIDwgc2hpcFJhZGl1cyAqIDIpIHtcbiAgICAgICAgICAgIHRoaXMucGxheWVyLnRha2VEYW1hZ2UoZW5lbXkuY29sbGlzaW9uRGFtYWdlKTtcbiAgICAgICAgICAgIHNvdW5kTWFuYWdlci5wbGF5KCdzaGlwX2NvbGxpc2lvbicsIDAuOCk7XG4gICAgICAgICAgICBlbmVteS5zY29yZVZhbHVlID0gMDsgXG4gICAgICAgICAgICBlbmVteS50YWtlRGFtYWdlKDk5OTkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBkZXN0cm95QWxsKCkge1xuICAgIGZvciAoY29uc3QgZW50aXR5IG9mIHRoaXMuZW50aXRpZXMpIHtcbiAgICAgIHRoaXMuY29udGFpbmVyLnJlbW92ZUNoaWxkKGVudGl0eS5jb250YWluZXIpO1xuICAgICAgZW50aXR5LmRlc3Ryb3koKTtcbiAgICB9XG4gICAgdGhpcy5lbnRpdGllcyA9IFtdO1xuICAgIHRoaXMuaXNsYW5kcyA9IFtdO1xuICB9XG59XG4iXX0=